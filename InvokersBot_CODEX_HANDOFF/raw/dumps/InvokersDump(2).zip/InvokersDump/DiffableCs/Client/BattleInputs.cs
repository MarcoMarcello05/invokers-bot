//Type is in global namespace

public class BattleInputs : IInputActionCollection2, IInputActionCollection, IEnumerable<InputAction>, IEnumerable, IDisposable
{
	internal struct BaseMapActions
	{
		private BattleInputs m_Wrapper; //Field offset: 0x0

		public InputAction ActiveSkill1
		{
			 get { } //Length: 24
		}

		public InputAction ActiveSkill2
		{
			 get { } //Length: 24
		}

		public InputAction ActiveSkill3
		{
			 get { } //Length: 24
		}

		public InputAction AnimaFirstInQueue
		{
			 get { } //Length: 24
		}

		public InputAction AnimaSkill
		{
			 get { } //Length: 24
		}

		public InputAction AnyKey
		{
			 get { } //Length: 24
		}

		public InputAction AssembleTeam
		{
			 get { } //Length: 24
		}

		public InputAction AutoBattle
		{
			 get { } //Length: 24
		}

		public InputAction BattleInventorySlot1
		{
			 get { } //Length: 24
		}

		public InputAction BattleInventorySlot2
		{
			 get { } //Length: 24
		}

		public InputAction CameraLook
		{
			 get { } //Length: 24
		}

		public InputAction CameraZoom
		{
			 get { } //Length: 24
		}

		public InputAction ComboAttack
		{
			 get { } //Length: 24
		}

		public InputAction CycleNextCharacter
		{
			 get { } //Length: 24
		}

		public InputAction Dash
		{
			 get { } //Length: 24
		}

		public bool enabled
		{
			 get { } //Length: 36
		}

		public InputAction JoystickPressed
		{
			 get { } //Length: 24
		}

		public InputAction Move
		{
			 get { } //Length: 24
		}

		public InputAction NotificationClick
		{
			 get { } //Length: 24
		}

		public InputAction PauseMenu
		{
			 get { } //Length: 24
		}

		public InputAction SelectCharacter
		{
			 get { } //Length: 24
		}

		public InputAction UltimateSkill
		{
			 get { } //Length: 24
		}

		public BaseMapActions(BattleInputs wrapper) { }

		public void AddCallbacks(IBaseMapActions instance) { }

		public void Disable() { }

		public void Enable() { }

		public InputActionMap Get() { }

		public InputAction get_ActiveSkill1() { }

		public InputAction get_ActiveSkill2() { }

		public InputAction get_ActiveSkill3() { }

		public InputAction get_AnimaFirstInQueue() { }

		public InputAction get_AnimaSkill() { }

		public InputAction get_AnyKey() { }

		public InputAction get_AssembleTeam() { }

		public InputAction get_AutoBattle() { }

		public InputAction get_BattleInventorySlot1() { }

		public InputAction get_BattleInventorySlot2() { }

		public InputAction get_CameraLook() { }

		public InputAction get_CameraZoom() { }

		public InputAction get_ComboAttack() { }

		public InputAction get_CycleNextCharacter() { }

		public InputAction get_Dash() { }

		public bool get_enabled() { }

		public InputAction get_JoystickPressed() { }

		public InputAction get_Move() { }

		public InputAction get_NotificationClick() { }

		public InputAction get_PauseMenu() { }

		public InputAction get_SelectCharacter() { }

		public InputAction get_UltimateSkill() { }

		public static InputActionMap op_Implicit(BaseMapActions set) { }

		public void RemoveCallbacks(IBaseMapActions instance) { }

		public void SetCallbacks(IBaseMapActions instance) { }

		private void UnregisterCallbacks(IBaseMapActions instance) { }

	}

	internal struct DebugMapActions
	{
		private BattleInputs m_Wrapper; //Field offset: 0x0

		public bool enabled
		{
			 get { } //Length: 36
		}

		public InputAction PointerClick
		{
			 get { } //Length: 24
		}

		public DebugMapActions(BattleInputs wrapper) { }

		public void AddCallbacks(IDebugMapActions instance) { }

		public void Disable() { }

		public void Enable() { }

		public InputActionMap Get() { }

		public bool get_enabled() { }

		public InputAction get_PointerClick() { }

		public static InputActionMap op_Implicit(DebugMapActions set) { }

		public void RemoveCallbacks(IDebugMapActions instance) { }

		public void SetCallbacks(IDebugMapActions instance) { }

		private void UnregisterCallbacks(IDebugMapActions instance) { }

	}

	internal interface IBaseMapActions
	{

		public void OnActiveSkill1(CallbackContext context) { }

		public void OnActiveSkill2(CallbackContext context) { }

		public void OnActiveSkill3(CallbackContext context) { }

		public void OnAnimaFirstInQueue(CallbackContext context) { }

		public void OnAnimaSkill(CallbackContext context) { }

		public void OnAnyKey(CallbackContext context) { }

		public void OnAssembleTeam(CallbackContext context) { }

		public void OnAutoBattle(CallbackContext context) { }

		public void OnBattleInventorySlot1(CallbackContext context) { }

		public void OnBattleInventorySlot2(CallbackContext context) { }

		public void OnCameraLook(CallbackContext context) { }

		public void OnCameraZoom(CallbackContext context) { }

		public void OnComboAttack(CallbackContext context) { }

		public void OnCycleNextCharacter(CallbackContext context) { }

		public void OnDash(CallbackContext context) { }

		public void OnJoystickPressed(CallbackContext context) { }

		public void OnMove(CallbackContext context) { }

		public void OnNotificationClick(CallbackContext context) { }

		public void OnPauseMenu(CallbackContext context) { }

		public void OnSelectCharacter(CallbackContext context) { }

		public void OnUltimateSkill(CallbackContext context) { }

	}

	internal interface IDebugMapActions
	{

		public void OnPointerClick(CallbackContext context) { }

	}

	[CompilerGenerated]
	private readonly InputActionAsset <asset>k__BackingField; //Field offset: 0x10
	private readonly InputActionMap m_BaseMap; //Field offset: 0x18
	private List<IBaseMapActions> m_BaseMapActionsCallbackInterfaces; //Field offset: 0x20
	private readonly InputAction m_BaseMap_Move; //Field offset: 0x28
	private readonly InputAction m_BaseMap_ComboAttack; //Field offset: 0x30
	private readonly InputAction m_BaseMap_ActiveSkill1; //Field offset: 0x38
	private readonly InputAction m_BaseMap_ActiveSkill2; //Field offset: 0x40
	private readonly InputAction m_BaseMap_ActiveSkill3; //Field offset: 0x48
	private readonly InputAction m_BaseMap_BattleInventorySlot1; //Field offset: 0x50
	private readonly InputAction m_BaseMap_BattleInventorySlot2; //Field offset: 0x58
	private readonly InputAction m_BaseMap_UltimateSkill; //Field offset: 0x60
	private readonly InputAction m_BaseMap_AnimaSkill; //Field offset: 0x68
	private readonly InputAction m_BaseMap_SelectCharacter; //Field offset: 0x70
	private readonly InputAction m_BaseMap_JoystickPressed; //Field offset: 0x78
	private readonly InputAction m_BaseMap_Dash; //Field offset: 0x80
	private readonly InputAction m_BaseMap_AnyKey; //Field offset: 0x88
	private readonly InputAction m_BaseMap_NotificationClick; //Field offset: 0x90
	private readonly InputAction m_BaseMap_PauseMenu; //Field offset: 0x98
	private readonly InputAction m_BaseMap_AssembleTeam; //Field offset: 0xA0
	private readonly InputAction m_BaseMap_CycleNextCharacter; //Field offset: 0xA8
	private readonly InputAction m_BaseMap_AnimaFirstInQueue; //Field offset: 0xB0
	private readonly InputAction m_BaseMap_CameraZoom; //Field offset: 0xB8
	private readonly InputAction m_BaseMap_AutoBattle; //Field offset: 0xC0
	private readonly InputAction m_BaseMap_CameraLook; //Field offset: 0xC8
	private readonly InputActionMap m_DebugMap; //Field offset: 0xD0
	private List<IDebugMapActions> m_DebugMapActionsCallbackInterfaces; //Field offset: 0xD8
	private readonly InputAction m_DebugMap_PointerClick; //Field offset: 0xE0
	private int m_KeyboardMouseSchemeIndex; //Field offset: 0xE8
	private int m_GamepadSchemeIndex; //Field offset: 0xEC
	private int m_TouchSchemeIndex; //Field offset: 0xF0

	public InputActionAsset asset
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public BaseMapActions BaseMap
	{
		 get { } //Length: 28
	}

	public override Nullable<InputBinding> bindingMask
	{
		 get { } //Length: 32
		 set { } //Length: 60
	}

	public override IEnumerable<InputBinding> bindings
	{
		 get { } //Length: 24
	}

	public override ReadOnlyArray<InputControlScheme> controlSchemes
	{
		 get { } //Length: 24
	}

	public DebugMapActions DebugMap
	{
		 get { } //Length: 28
	}

	public override Nullable<ReadOnlyArray`1<InputDevice>> devices
	{
		 get { } //Length: 64
		 set { } //Length: 60
	}

	public InputControlScheme GamepadScheme
	{
		 get { } //Length: 200
	}

	public InputControlScheme KeyboardMouseScheme
	{
		 get { } //Length: 200
	}

	public InputControlScheme TouchScheme
	{
		 get { } //Length: 200
	}

	public BattleInputs() { }

	public override bool Contains(InputAction action) { }

	public override void Disable() { }

	public override void Dispose() { }

	public override void Enable() { }

	protected virtual void Finalize() { }

	public override InputAction FindAction(string actionNameOrId, bool throwIfNotFound = false) { }

	public override int FindBinding(InputBinding bindingMask, out InputAction action) { }

	[CompilerGenerated]
	public InputActionAsset get_asset() { }

	public BaseMapActions get_BaseMap() { }

	public override Nullable<InputBinding> get_bindingMask() { }

	public override IEnumerable<InputBinding> get_bindings() { }

	public override ReadOnlyArray<InputControlScheme> get_controlSchemes() { }

	public DebugMapActions get_DebugMap() { }

	public override Nullable<ReadOnlyArray`1<InputDevice>> get_devices() { }

	public InputControlScheme get_GamepadScheme() { }

	public InputControlScheme get_KeyboardMouseScheme() { }

	public InputControlScheme get_TouchScheme() { }

	public override IEnumerator<InputAction> GetEnumerator() { }

	public override void set_bindingMask(Nullable<InputBinding> value) { }

	public override void set_devices(Nullable<ReadOnlyArray`1<InputDevice>> value) { }

	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

