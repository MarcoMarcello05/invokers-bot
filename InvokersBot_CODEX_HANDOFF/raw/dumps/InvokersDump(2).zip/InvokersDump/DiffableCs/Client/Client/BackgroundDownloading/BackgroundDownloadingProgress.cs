namespace Client.BackgroundDownloading;

public class BackgroundDownloadingProgress : IEquatable<BackgroundDownloadingProgress>
{
	public readonly int TotalItems; //Field offset: 0x10
	public readonly long TotalRemoteBytes; //Field offset: 0x18
	public long TotalDownloadedBytes; //Field offset: 0x20
	public long SessionDownloadedBytes; //Field offset: 0x28
	public int SessionDownloadedItems; //Field offset: 0x30
	public int SessionProcessedItems; //Field offset: 0x34
	public string SessionLastProcessedItem; //Field offset: 0x38
	public float DownloadSpeedMbPerSec; //Field offset: 0x40

	public static BackgroundDownloadingProgress Default
	{
		 get { } //Length: 124
	}

	[CompilerGenerated]
	[Nullable(1)]
	protected override Type EqualityContract
	{
		[CompilerGenerated]
		[NullableContext(1)]
		 get { } //Length: 96
	}

	public bool IsDone
	{
		 get { } //Length: 56
	}

	public float Normalized
	{
		 get { } //Length: 40
	}

	public BackgroundDownloadingProgress(int TotalItems, long TotalRemoteBytes, long TotalDownloadedBytes) { }

	[CompilerGenerated]
	protected BackgroundDownloadingProgress(BackgroundDownloadingProgress original) { }

	[CompilerGenerated]
	[NullableContext(1)]
	public override BackgroundDownloadingProgress <Clone>$() { }

	[CompilerGenerated]
	public void Deconstruct(out int TotalItems, out long TotalRemoteBytes, out long TotalDownloadedBytes) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public override bool Equals(BackgroundDownloadingProgress other) { }

	public static BackgroundDownloadingProgress get_Default() { }

	[CompilerGenerated]
	[NullableContext(1)]
	protected override Type get_EqualityContract() { }

	public bool get_IsDone() { }

	public float get_Normalized() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Equality(BackgroundDownloadingProgress left, BackgroundDownloadingProgress right) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Inequality(BackgroundDownloadingProgress left, BackgroundDownloadingProgress right) { }

	[CompilerGenerated]
	[NullableContext(1)]
	protected override bool PrintMembers(StringBuilder builder) { }

	public virtual string ToString() { }

}

