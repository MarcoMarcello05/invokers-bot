namespace Client.CharacterControllers;

public class CharacterUI : BaseCharacterView, IObjectsPoolItem<CharacterUI>
{
	private const string WORLD_UI_SORTING_LAYER_NAME = "WorldUI"; //Field offset: 0x0
	private static int _worldUISortingLayerID; //Field offset: 0x0
	public bool HiddenByTutorial; //Field offset: 0x20
	[CompilerGenerated]
	private Action<CharacterUI> OnDead; //Field offset: 0x28
	[SerializeField]
	private Transform _uiRoot; //Field offset: 0x30
	[SerializeField]
	private Image _elementImage; //Field offset: 0x38
	[SerializeField]
	private Image _inBattleImage; //Field offset: 0x40
	[SerializeField]
	private SegmentedHealthBar _segmentedHealthBar; //Field offset: 0x48
	[SerializeField]
	private CharacterBuffContainer _characterBuffContainer; //Field offset: 0x50
	[SerializeField]
	private TextMeshProUGUI _levelLabel; //Field offset: 0x58
	[SerializeField]
	private LookAtCamera _lookAtCamera; //Field offset: 0x60
	[SerializeField]
	private bool _useNotches; //Field offset: 0x68
	[SerializeField]
	private HealthBarNotchRenderer _notches; //Field offset: 0x70
	private Vector3 _initialLocalScale; //Field offset: 0x78
	private readonly GameObjectsPoolItemBase<CharacterUI> _itemBase; //Field offset: 0x88

	public event Action<CharacterUI> OnDead
	{
		[CompilerGenerated]
		 add { } //Length: 176
		[CompilerGenerated]
		 remove { } //Length: 176
	}

	public override CharacterUI Template
	{
		 get { } //Length: 72
	}

	private static CharacterUI() { }

	public CharacterUI() { }

	[CompilerGenerated]
	public void add_OnDead(Action<CharacterUI> value) { }

	public void AddCorruption(ref CorruptionHudData corruptionData) { }

	public void AddCustomStatusEffect(ref CustomStatusEffectHudData customStatusEffectHudData) { }

	public void AddMovementEffect(ref MovementEffectHudData movementEffectHudData) { }

	public void AddStatusEffect(ref StatusEffectHudData statusEffectHudData) { }

	public void ChangeBuffsVisibility(bool isVisible) { }

	public void ChangeInBattleState(bool isInBattle) { }

	public void ChangeParent(Transform root) { }

	public void ChangeVisibility(bool isVisible) { }

	public HealthBarState CurrentHealthState() { }

	public override CharacterUI get_Template() { }

	public void Init(int level, bool isEnemy, Sprite elementSprite, BuffsInfo buffsInfo, Camera mainCamera, IObjectsPool<BuffView> buffViewPool) { }

	private void OnDisable() { }

	public override void OnInstantiate(IObjectsPool<CharacterUI> ownerPool, CharacterUI template) { }

	private void OnValidate() { }

	[CompilerGenerated]
	public void remove_OnDead(Action<CharacterUI> value) { }

	public void RemoveCorruption(CorruptionType type) { }

	public void RemoveCustomStatusEffect(long effectType, uint effectUniqueId) { }

	public void RemoveMovementEffect(MovementEffectType type) { }

	public void RemoveStatusEffect(StatusEffectType buffType, uint effectId) { }

	public void Reset() { }

	public override void ResetBeforeRent() { }

	public override void ReturnToPool() { }

	public void SetDead() { }

	private void SetDebugValue(float currentPercent01, int maxHealth = 10000) { }

	public void UpdateBarPosition(float characterViewOffsetCurrent) { }

	public void UpdateCorruption(ref CorruptionHudData corruptionData) { }

	public void UpdateCustomStatusEffect(ref CustomStatusEffectHudData customStatusEffectHudData) { }

	public void UpdateHealthBar(HealthBarState state, bool animate = true) { }

	public void UpdateMovementEffect(ref MovementEffectHudData movementEffectHudData) { }

	public void UpdateStatusEffect(ref StatusEffectHudData statusEffectHudData) { }

}

