namespace Client.Core.ErrorHandling;

[UsedAsInjection]
public class NotEnoughResourcesPopupController : AwaitableDialogController<NotEnoughResourcesPopup>
{
	[CompilerGenerated]
	private struct <HandleCloseButtonClick>d__19 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public NotEnoughResourcesPopupController <>4__this; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <HandleTransitionCommandClick>d__18 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public NotEnoughResourcesPopupController <>4__this; //Field offset: 0x28
		public ResourceOrigin origin; //Field offset: 0x30
		private Awaiter <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ShowUntilClosedAsync>d__14 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public NotEnoughResourcesPopupController <>4__this; //Field offset: 0x18
		public ResourceTypeId resourceTypeId; //Field offset: 0x20
		public int amount; //Field offset: 0x24
		private Awaiter <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IContentManager _content; //Field offset: 0x88
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x90
	private readonly IUISystem _uiSystem; //Field offset: 0x98
	private readonly ButtonCommandBuilder _buttonCommandBuilder; //Field offset: 0xA0
	private readonly GameRewardCache _gameRewardCache; //Field offset: 0xA8
	private readonly ResourceOriginResolver _resourceOriginResolver; //Field offset: 0xB0
	private readonly BlockingContext _blockingContext; //Field offset: 0xB8
	private GameItemHolderController _resourceIconController; //Field offset: 0xC0
	private ResourceTypeId _resourceType; //Field offset: 0xC8
	private int _amount; //Field offset: 0xCC

	public NotEnoughResourcesPopupController(IUISystem uiSystem, IContentManager content, IStagingContainer stagingContainer, ButtonCommandBuilder buttonCommandBuilder, GameRewardCache gameRewardCache, ResourceOriginResolver resourceOriginResolver) { }

	[CompilerGenerated]
	[DebuggerHidden]
	private UniTask <>n__0(DialogSubLayer dialogSubLayer, bool forceShow, bool showBlocker, CancellationToken cancellationToken) { }

	[AsyncStateMachine(typeof(<HandleCloseButtonClick>d__19))]
	private ValueTask HandleCloseButtonClick() { }

	[AsyncStateMachine(typeof(<HandleTransitionCommandClick>d__18))]
	private ValueTask HandleTransitionCommandClick(ResourceOrigin origin) { }

	protected virtual void OnDisposing() { }

	protected virtual void OnViewClose() { }

	protected virtual void OnViewLoaded() { }

	public UniTask ShowUntilClosedAsync(NotEnoughResourcesError error) { }

	public UniTask ShowUntilClosedAsync(IResources price, IResources balance) { }

	[AsyncStateMachine(typeof(<ShowUntilClosedAsync>d__14))]
	public UniTask ShowUntilClosedAsync(ResourceTypeId resourceTypeId, int amount) { }

	private bool TrySetFirstMissingResource(IResources requiredResources, IResources balance) { }

	protected virtual IAsyncInitializable<NotEnoughResourcesPopup> ViewFactory() { }

}

