namespace Client;

[Nullable(0)]
[NullableContext(2)]
public class AddressablesContentCatalog
{
	[CompilerGenerated]
	private static AddressablesContentCatalog <Main>k__BackingField; //Field offset: 0x0
	[Nullable(1)]
	private readonly string _locatorId; //Field offset: 0x10
	[CompilerGenerated]
	private readonly IResourceLocator <Locator>k__BackingField; //Field offset: 0x18

	public bool IsAvailable
	{
		 get { } //Length: 16
	}

	public IResourceLocator Locator
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public private static AddressablesContentCatalog Main
	{
		[CompilerGenerated]
		 get { } //Length: 72
		[CompilerGenerated]
		private set { } //Length: 88
	}

	[NullableContext(1)]
	private AddressablesContentCatalog(string locatorId) { }

	[NullableContext(1)]
	private static object EvaluateKey(AssetKey assetKey) { }

	public bool get_IsAvailable() { }

	[CompilerGenerated]
	public IResourceLocator get_Locator() { }

	[CompilerGenerated]
	public static AddressablesContentCatalog get_Main() { }

	public static void InitializeMain() { }

	[NullableContext(1)]
	public IList<IResourceLocation> Locate(AssetKey assetKey) { }

	[CompilerGenerated]
	private static void set_Main(AddressablesContentCatalog value) { }

}

