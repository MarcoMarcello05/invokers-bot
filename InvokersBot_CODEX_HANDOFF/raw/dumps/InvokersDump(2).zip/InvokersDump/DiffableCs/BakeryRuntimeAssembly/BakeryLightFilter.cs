//Type is in global namespace

[DisallowMultipleComponent]
[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Light_Filter")]
public class BakeryLightFilter : MonoBehaviour
{
	public Texture2D texture; //Field offset: 0x20
	[HideInInspector]
	public int lmid; //Field offset: 0x28

	public BakeryLightFilter() { }

}

