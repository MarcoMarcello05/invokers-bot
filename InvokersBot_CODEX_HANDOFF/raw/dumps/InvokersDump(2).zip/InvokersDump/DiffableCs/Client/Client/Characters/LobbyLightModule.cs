namespace Client.Characters;

public sealed class LobbyLightModule : ICharacterModule, IDisposable
{
	private LobbyStagePart _stage; //Field offset: 0x10
	private GameObject _customLight; //Field offset: 0x18
	private bool _useCustomLights; //Field offset: 0x20
	private bool _extractPending; //Field offset: 0x21

	public LobbyLightModule() { }

	public override void Bind(CharacterView view) { }

	public override void Dispose() { }

	public override void OnViewDisabled() { }

	public override void OnViewEnabled() { }

	public override void Tick(float deltaTime) { }

	public override void Unbind() { }

	public void UseCustomLight(bool activate) { }

}

