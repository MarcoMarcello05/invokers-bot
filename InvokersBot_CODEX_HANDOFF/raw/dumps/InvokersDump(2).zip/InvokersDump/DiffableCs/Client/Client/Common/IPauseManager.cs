namespace Client.Common;

public interface IPauseManager
{

	public float DebugTimescale
	{
		 get { } //Length: 0
		 set { } //Length: 0
	}

	public bool Paused
	{
		 get { } //Length: 0
	}

	public Observable<Boolean> PauseStateChanged
	{
		 get { } //Length: 0
	}

	public float get_DebugTimescale() { }

	public bool get_Paused() { }

	public Observable<Boolean> get_PauseStateChanged() { }

	public void Pause(PauseReason reason) { }

	public void Resume(PauseReason reason) { }

	public void set_DebugTimescale(float value) { }

}

