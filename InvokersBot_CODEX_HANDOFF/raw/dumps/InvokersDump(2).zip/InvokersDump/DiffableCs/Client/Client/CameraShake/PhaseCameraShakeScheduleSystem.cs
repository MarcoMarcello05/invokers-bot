namespace Client.CameraShake;

public class PhaseCameraShakeScheduleSystem : IViewSystem
{
	private static readonly ILogger Log; //Field offset: 0x0
	private readonly FxConfigsProvider _configsProvider; //Field offset: 0x10
	private readonly CameraShakeViewDataPool _pool; //Field offset: 0x18
	private readonly SharedViewData _shared; //Field offset: 0x20

	private static PhaseCameraShakeScheduleSystem() { }

	public PhaseCameraShakeScheduleSystem(SharedViewData shared, FxConfigsProvider configsProvider, CameraShakeViewDataPool pool) { }

	private SkillPhase LifecycleEventAsPhase(SkillLifecycleEvent phaseEvent) { }

	private void ScheduleShake(ModelEntity producer, SkillInstanceId instanceId, SkillPhase skillPhase, SkillPhaseCameraShakeSlot shakeSlot, float speedFactor) { }

	public override void Tick() { }

}

