namespace Client.Authentication.ExternalAuth;

[Nullable(0)]
[NullableContext(2)]
public struct ExternalAuthResult : IEquatable<ExternalAuthResult>
{
	[CompilerGenerated]
	private readonly bool <Success>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private readonly bool <Canceled>k__BackingField; //Field offset: 0x1
	[CompilerGenerated]
	private readonly string <Error>k__BackingField; //Field offset: 0x8
	[CompilerGenerated]
	private readonly AuthenticationParameters <Parameters>k__BackingField; //Field offset: 0x10

	public bool Canceled
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string Error
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public AuthenticationParameters Parameters
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public bool Success
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public ExternalAuthResult(bool Success, bool Canceled, string Error, AuthenticationParameters Parameters) { }

	public static ExternalAuthResult Cancel(string error = null) { }

	[CompilerGenerated]
	public void Deconstruct(out bool Success, out bool Canceled, out string Error, out AuthenticationParameters Parameters) { }

	[CompilerGenerated]
	[NullableContext(0)]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	public override bool Equals(ExternalAuthResult other) { }

	[NullableContext(1)]
	public static ExternalAuthResult Fail(string error) { }

	[CompilerGenerated]
	public bool get_Canceled() { }

	[CompilerGenerated]
	public string get_Error() { }

	[CompilerGenerated]
	public AuthenticationParameters get_Parameters() { }

	[CompilerGenerated]
	public bool get_Success() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	public static bool op_Equality(ExternalAuthResult left, ExternalAuthResult right) { }

	[CompilerGenerated]
	public static bool op_Inequality(ExternalAuthResult left, ExternalAuthResult right) { }

	[CompilerGenerated]
	[NullableContext(0)]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	public void set_Canceled(bool value) { }

	[CompilerGenerated]
	public void set_Error(string value) { }

	[CompilerGenerated]
	public void set_Parameters(AuthenticationParameters value) { }

	[CompilerGenerated]
	public void set_Success(bool value) { }

	[NullableContext(1)]
	public static ExternalAuthResult Succeed(AuthenticationParameters parameters) { }

	[CompilerGenerated]
	[NullableContext(0)]
	public virtual string ToString() { }

}

