namespace Client.Analytics;

public static class ClientSideAbExperimentConfig
{

	public static IEnumerable<AbExperimentDefinition> ExperimentDefinitions() { }

}

