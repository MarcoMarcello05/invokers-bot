//Type is in global namespace

[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Pack_As_Single_Square")]
public class BakeryPackAsSingleSquare : MonoBehaviour
{

	public BakeryPackAsSingleSquare() { }

}

