namespace Client.Common.Diagnostics;

public class BatchingHttpLogProcessor : BatchingAsyncLogProcessor
{
	[CompilerGenerated]
	private struct <ProcessAsync>d__5 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public IReadOnlyList<INonReturnableZLoggerEntry> list; //Field offset: 0x28
		public BatchingHttpLogProcessor <>4__this; //Field offset: 0x30
		private ConfiguredTaskAwaiter<HttpResponseMessage> <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly string _url; //Field offset: 0x30
	private readonly HttpClient _httpClient; //Field offset: 0x38
	private readonly ArrayBufferWriter<Byte> _bufferWriter; //Field offset: 0x40
	private readonly IZLoggerFormatter _formatter; //Field offset: 0x48

	public BatchingHttpLogProcessor(int batchSize, ZLoggerOptions options, string url, HttpClient httpClient) { }

	protected virtual ValueTask DisposeAsyncCore() { }

	[AsyncStateMachine(typeof(<ProcessAsync>d__5))]
	protected virtual ValueTask ProcessAsync(IReadOnlyList<INonReturnableZLoggerEntry> list) { }

}

