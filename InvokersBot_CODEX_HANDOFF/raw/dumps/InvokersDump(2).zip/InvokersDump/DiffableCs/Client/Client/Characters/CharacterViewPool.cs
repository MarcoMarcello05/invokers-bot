namespace Client.Characters;

public sealed class CharacterViewPool : GameObjectsPool<CharacterView>
{

	protected virtual IEnumerable<AssetKey> RequiredAssets
	{
		 get { } //Length: 148
	}

	public CharacterViewPool(IBootstrap bootstrap) { }

	protected virtual IEnumerable<AssetKey> get_RequiredAssets() { }

	protected virtual UniTask Init(IOperationProgressObserver onProgressChange) { }

}

