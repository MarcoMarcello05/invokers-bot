namespace Client.Configuration;

[Nullable(0)]
[NullableContext(1)]
public class MetaServerRemoteConfigurationSource : IConfigurationSource
{
	private readonly MetaServerRemoteConfigurationProvider _provider; //Field offset: 0x10

	public MetaServerRemoteConfigurationSource() { }

	public MetaServerRemoteConfigurationSource(MetaServerRemoteConfigurationProvider provider) { }

	public override IConfigurationProvider Build(IConfigurationBuilder builder) { }

}

