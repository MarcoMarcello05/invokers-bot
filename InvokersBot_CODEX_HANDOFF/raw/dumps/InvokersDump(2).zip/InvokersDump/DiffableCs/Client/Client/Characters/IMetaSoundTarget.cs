namespace Client.Characters;

public interface IMetaSoundTarget
{

	public void SetMetaSoundsEnabled(bool enabled, bool immediate) { }

}

