namespace Client.Common.UI;

public class HZButton : Button, IButton
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Action<Unit, HZButton> <>9__32_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal void <Awake>b__32_0(Unit _, HZButton self) { }

	}

	[SerializeField]
	private TextMeshProUGUI _label; //Field offset: 0x108
	[SerializeField]
	private uint _debounceMs; //Field offset: 0x110
	[SerializeField]
	private ButtonSoundReference _clickSoundRef; //Field offset: 0x118
	[SerializeField]
	private bool _needToReportAnalytics; //Field offset: 0x120
	[AnalyticsEvent]
	[SerializeField]
	private string _eventButtonName; //Field offset: 0x128
	[SerializeField]
	private BaseHZButtonProcessAnimation _stateVisualizer; //Field offset: 0x130
	[SerializeField]
	private bool _useStateVisualiser; //Field offset: 0x138
	private object _value; //Field offset: 0x140
	private IButtonCommand _command; //Field offset: 0x148
	private Func<Object> _valueGetter; //Field offset: 0x150
	private Subject<Unit> _dimensionsChanged; //Field offset: 0x158
	[CompilerGenerated]
	private bool <ShowSpinnerOnLongExecution>k__BackingField; //Field offset: 0x160

	public override bool ActiveSelf
	{
		 get { } //Length: 32
		 set { } //Length: 40
	}

	public override uint DebounceMs
	{
		 get { } //Length: 8
		 set { } //Length: 8
	}

	public override bool Interactable
	{
		 get { } //Length: 8
		 set { } //Length: 8
	}

	public TextMeshProUGUI Label
	{
		 get { } //Length: 8
	}

	public Observable<Unit> OnDimensionsChanged
	{
		 get { } //Length: 132
	}

	public override bool ShowSpinnerOnLongExecution
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public HZButton() { }

	protected virtual void Awake() { }

	public override void Bind(IButtonCommand command, object value = null) { }

	public override void Bind(IButtonCommand command, Func<Object> valueGetter) { }

	protected virtual void DoStateTransition(SelectionState state, bool instant) { }

	private void ExecuteCommand() { }

	public override bool get_ActiveSelf() { }

	public override uint get_DebounceMs() { }

	public override bool get_Interactable() { }

	public TextMeshProUGUI get_Label() { }

	public Observable<Unit> get_OnDimensionsChanged() { }

	[CompilerGenerated]
	public override bool get_ShowSpinnerOnLongExecution() { }

	protected string GetAnimationTrigger(SelectionState state) { }

	protected virtual void OnRectTransformDimensionsChange() { }

	private void ReportAnalyticsIfNeeded() { }

	public void ResetBinding() { }

	public override void set_ActiveSelf(bool value) { }

	public override void set_DebounceMs(uint value) { }

	public override void set_Interactable(bool value) { }

	[CompilerGenerated]
	public override void set_ShowSpinnerOnLongExecution(bool value) { }

	public void SetInteractable(bool value, bool animate) { }

	public void SetLabelColor(Color color) { }

	public override void SetText(string text) { }

	private void SnapStateVisual(SelectionState state) { }

}

