namespace Client;

[Nullable(0)]
[NullableContext(1)]
public class AssetDownloadRequest : IDisposable
{
	private readonly CancellationTokenSource _cts; //Field offset: 0x10
	private AsyncOperationHandle _operation; //Field offset: 0x18
	private bool _isDisposed; //Field offset: 0x30
	[CompilerGenerated]
	private readonly AssetKey <Key>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	[Nullable(2)]
	private Exception <Exception>k__BackingField; //Field offset: 0x40

	public bool Canceled
	{
		 get { } //Length: 96
	}

	public string DownloadError
	{
		 get { } //Length: 120
	}

	public DownloadStatus DownloadStatus
	{
		 get { } //Length: 96
	}

	[Nullable(2)]
	public private Exception Exception
	{
		[CompilerGenerated]
		[NullableContext(2)]
		 get { } //Length: 8
		[CompilerGenerated]
		[NullableContext(2)]
		private set { } //Length: 8
	}

	public bool Failed
	{
		 get { } //Length: 108
	}

	public AssetKey Key
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public bool Ready
	{
		 get { } //Length: 116
	}

	[Nullable(2)]
	public object Result
	{
		[NullableContext(2)]
		 get { } //Length: 44
	}

	public AssetDownloadRequest(AssetKey key, AsyncOperationHandle operation, CancellationTokenSource cts) { }

	public override void Dispose() { }

	public bool get_Canceled() { }

	public string get_DownloadError() { }

	public DownloadStatus get_DownloadStatus() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public Exception get_Exception() { }

	public bool get_Failed() { }

	[CompilerGenerated]
	public AssetKey get_Key() { }

	public bool get_Ready() { }

	[NullableContext(2)]
	public object get_Result() { }

	[NullableContext(2)]
	public void OnDownloadCompleted(AsyncOperationStatus status, Exception exception) { }

	[CompilerGenerated]
	[NullableContext(2)]
	private void set_Exception(Exception value) { }

	public virtual string ToString() { }

}

