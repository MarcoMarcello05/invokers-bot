namespace Client.Common.DI;

[Extension]
public static class MainDIModule
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<IObjectResolver, ISentryService> <>9__0_0; //Field offset: 0x8
		public static Func<IObjectResolver, LocalizationPackageProvider> <>9__0_1; //Field offset: 0x10
		public static Func<IObjectResolver, LocalizationStore> <>9__0_2; //Field offset: 0x18
		public static Func<IObjectResolver, FirebaseService> <>9__0_3; //Field offset: 0x20
		public static Func<IObjectResolver, AnalyticEventsStore> <>9__0_4; //Field offset: 0x28
		public static Func<IObjectResolver, IAbExperimentService> <>9__0_5; //Field offset: 0x30

		private static <>c() { }

		public <>c() { }

		internal ISentryService <AddCoreDependencies>b__0_0(IObjectResolver _) { }

		internal LocalizationPackageProvider <AddCoreDependencies>b__0_1(IObjectResolver _) { }

		internal LocalizationStore <AddCoreDependencies>b__0_2(IObjectResolver p) { }

		internal FirebaseService <AddCoreDependencies>b__0_3(IObjectResolver container) { }

		internal AnalyticEventsStore <AddCoreDependencies>b__0_4(IObjectResolver _) { }

		internal IAbExperimentService <AddCoreDependencies>b__0_5(IObjectResolver provider) { }

	}


	[Extension]
	public static IContainerBuilder AddCoreDependencies(IContainerBuilder builder, bool offlineMode) { }

}

