namespace AppsFlyerSDK;

public interface IAppsFlyerAndroidBridge : IAppsFlyerNativeBridge
{

	public string getAttributionId() { }

	public string getOutOfStore() { }

	public void handlePushNotifications() { }

	public bool isPreInstalledApp() { }

	public void setAndroidIdData(string androidId) { }

	public void setCollectAndroidID(bool isCollect) { }

	public void setCollectIMEI(bool isCollect) { }

	public void setCollectOaid(bool isCollect) { }

	public void setCustomerIdAndStartSDK(string id) { }

	public void setDisableAdvertisingIdentifiers(bool disable) { }

	public void setDisableNetworkData(bool disable) { }

	public void setImeiData(string imei) { }

	public void setIsUpdate(bool isUpdate) { }

	public void setOutOfStore(string sourceName) { }

	public void setPreinstallAttribution(string mediaSource, string campaign, string siteId) { }

	public void updateServerUninstallToken(string token) { }

	public void validateAndSendInAppPurchase(string publicKey, string signature, string purchaseData, string price, string currency, Dictionary<String, String> additionalParameters, MonoBehaviour gameObject) { }

	public void validateAndSendInAppPurchase(AFPurchaseDetailsAndroid details, Dictionary<String, String> purchaseAdditionalDetails, MonoBehaviour gameObject) { }

	public void waitForCustomerUserId(bool wait) { }

}

