namespace Client.CharacterPlatforms;

public sealed class CharacterPlatform3dView : BaseView, ICharacterPlatform3dView
{
	[SerializeField]
	private Transform _back; //Field offset: 0x58
	[SerializeField]
	private Transform _container; //Field offset: 0x60
	[SerializeField]
	private CharacterFaction _characterFaction; //Field offset: 0x68
	[SerializeField]
	private GameObject _platform; //Field offset: 0x70

	public override Transform Back
	{
		 get { } //Length: 8
	}

	public override CharacterFaction CharacterFaction
	{
		 get { } //Length: 8
	}

	public override Transform Container
	{
		 get { } //Length: 8
	}

	public override GameObject Platform
	{
		 get { } //Length: 8
	}

	public CharacterPlatform3dView() { }

	public override Transform get_Back() { }

	public override CharacterFaction get_CharacterFaction() { }

	public override Transform get_Container() { }

	public override GameObject get_Platform() { }

	private void OnValidate() { }

}

