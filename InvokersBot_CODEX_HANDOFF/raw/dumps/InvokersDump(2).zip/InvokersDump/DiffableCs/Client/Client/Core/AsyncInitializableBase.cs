namespace Client.Core;

public abstract class AsyncInitializableBase : IAsyncInitializable, IDisposable
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass31_0
	{
		public AsyncInitializableBase <>4__this; //Field offset: 0x10
		public CancellationToken cancellationToken; //Field offset: 0x18

		public <>c__DisplayClass31_0() { }

		internal void <GetInitOperation>g__ProcessCompletionWithToken|0() { }

	}

	private static readonly ILogger Logger; //Field offset: 0x0
	private IAsyncOperationWithProgress _initOperation; //Field offset: 0x10
	private bool _isDisposed; //Field offset: 0x18
	private readonly CancellationTokenSource _disposeCancellationToken; //Field offset: 0x20
	[CompilerGenerated]
	private readonly string <OperationId>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private readonly string <LocalizedOperationName>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private readonly bool <IsParallelInitFactory>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private readonly CompositeDisposable <Disposables>k__BackingField; //Field offset: 0x40
	protected readonly CancellationToken CancellationToken; //Field offset: 0x48
	[CompilerGenerated]
	private bool <IsInitialized>k__BackingField; //Field offset: 0x50

	protected CompositeDisposable Disposables
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public override IAsyncOperationWithProgress InitOperation
	{
		 get { } //Length: 168
	}

	protected bool IsDisposed
	{
		 get { } //Length: 8
	}

	public private bool IsInitialized
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	protected bool IsParallelInitFactory
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	protected string LocalizedOperationName
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	protected string OperationId
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	private static AsyncInitializableBase() { }

	protected AsyncInitializableBase(string operationId, string localizedOperationName = null) { }

	public void AddDisposable(IDisposable disposable) { }

	public override void Dispose() { }

	protected override void DisposeInternal() { }

	[CompilerGenerated]
	protected CompositeDisposable get_Disposables() { }

	public override IAsyncOperationWithProgress get_InitOperation() { }

	protected bool get_IsDisposed() { }

	[CompilerGenerated]
	public bool get_IsInitialized() { }

	[CompilerGenerated]
	protected bool get_IsParallelInitFactory() { }

	[CompilerGenerated]
	protected string get_LocalizedOperationName() { }

	[CompilerGenerated]
	protected string get_OperationId() { }

	private IAsyncOperationWithProgress GetInitOperation() { }

	protected abstract IEnumerable<IAsyncOperationWithProgress> InitFactory() { }

	protected override void OnInitialised() { }

	private void ProcessCompletion(CancellationToken cancellationToken) { }

	protected void ResetInitOperation() { }

	[CompilerGenerated]
	private void set_IsInitialized(bool value) { }

	[CompilerGenerated]
	protected void set_IsParallelInitFactory(bool value) { }

	[CompilerGenerated]
	protected void set_LocalizedOperationName(string value) { }

	[CompilerGenerated]
	protected void set_OperationId(string value) { }

}

