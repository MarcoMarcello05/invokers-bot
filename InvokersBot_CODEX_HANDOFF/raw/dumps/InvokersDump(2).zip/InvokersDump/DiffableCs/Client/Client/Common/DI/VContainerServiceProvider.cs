namespace Client.Common.DI;

public class VContainerServiceProvider : IServiceProvider
{
	[CompilerGenerated]
	private IObjectResolver <Resolver>k__BackingField; //Field offset: 0x10

	public private IObjectResolver Resolver
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public VContainerServiceProvider(IObjectResolver resolver) { }

	[CompilerGenerated]
	public IObjectResolver get_Resolver() { }

	public override object GetService(Type serviceType) { }

	[CompilerGenerated]
	private void set_Resolver(IObjectResolver value) { }

}

