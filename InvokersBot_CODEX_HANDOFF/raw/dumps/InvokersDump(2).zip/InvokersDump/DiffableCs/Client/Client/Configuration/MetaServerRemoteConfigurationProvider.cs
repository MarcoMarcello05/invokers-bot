namespace Client.Configuration;

[Nullable(0)]
[NullableContext(1)]
public sealed class MetaServerRemoteConfigurationProvider : ConfigurationProvider, IKeyEnumerator, IMetaServerRemoteConfigurationSync
{
	[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
	private sealed class MetaServerRemoteConfigurationStorage : PersistentSerializedDictionary<Int32, PlayerAppSettingsSnapshotData>
	{

		public MetaServerRemoteConfigurationStorage(ILogger logger) { }

		protected virtual int GetKey(PlayerAppSettingsSnapshotData data) { }

		protected virtual int GetKey(string fileName, PlayerAppSettingsSnapshotData data) { }

	}

	public const string LastAppliedHashPlayerPrefsKey = "MetaServerRemoteConfigurationProvider.LastAppliedHash"; //Field offset: 0x0
	private readonly ILogger _logger; //Field offset: 0x20
	private readonly MetaServerRemoteConfigurationStorage _storage; //Field offset: 0x28
	[CompilerGenerated]
	private int <LastSyncedAppSettingsHashCode>k__BackingField; //Field offset: 0x30

	public private override int LastSyncedAppSettingsHashCode
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public static string StorageDirectoryPath
	{
		 get { } //Length: 184
	}

	public MetaServerRemoteConfigurationProvider() { }

	public override void ApplySnapshot(PlayerAppSettingsRemoteSnapshot snapshot) { }

	private static void ClearLastAppliedHash() { }

	private static Dictionary<String, String> ConvertSnapshotToData(PlayerAppSettingsSnapshotData snapshot) { }

	private static Dictionary<String, String> CreateEmptyData() { }

	[CompilerGenerated]
	public override int get_LastSyncedAppSettingsHashCode() { }

	public static string get_StorageDirectoryPath() { }

	public override IEnumerable<String> GetAllKeys() { }

	private PlayerAppSettingsSnapshotData GetSnapshotToApply(PlayerAppSettingsRemoteSnapshot snapshot) { }

	public virtual void Load() { }

	private static int LoadLastAppliedHash() { }

	private Dictionary<String, String> LoadPersistedData(out int hashCode) { }

	private static void SaveLastAppliedHash(int hashCode) { }

	[CompilerGenerated]
	private void set_LastSyncedAppSettingsHashCode(int value) { }

}

