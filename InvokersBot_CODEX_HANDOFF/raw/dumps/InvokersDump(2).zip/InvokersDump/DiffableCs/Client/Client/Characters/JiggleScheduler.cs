namespace Client.Characters;

public sealed class JiggleScheduler : IJiggleScheduler
{
	private sealed class Registration : IDisposable
	{
		private readonly IReadOnlyList<Jiggle> _bones; //Field offset: 0x10
		private JiggleScheduler _scheduler; //Field offset: 0x18

		public Registration(JiggleScheduler scheduler, IReadOnlyList<Jiggle> bones) { }

		public override void Dispose() { }

	}

	private readonly Dictionary<Jiggle, Int32> _depths; //Field offset: 0x10
	private readonly List<Jiggle> _ordered; //Field offset: 0x18
	private readonly Comparison<Jiggle> _byDepth; //Field offset: 0x20
	private bool _orderDirty; //Field offset: 0x28

	public JiggleScheduler() { }

	[CompilerGenerated]
	private int <.ctor>b__4_0(Jiggle a, Jiggle b) { }

	private void Advance(float deltaTime, bool withPhysics) { }

	private void EnsureOrdered() { }

	public override void FixedTick(float fixedDeltaTime) { }

	private static int GetHierarchyDepth(Transform bone) { }

	public override IDisposable Register(IReadOnlyList<Jiggle> bones) { }

	public override void Tick(float deltaTime) { }

	private void Unregister(IReadOnlyList<Jiggle> bones) { }

}

