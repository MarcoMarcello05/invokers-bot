namespace Client.CharacterAddons;

public sealed class CharacterAddonHudPresentation
{
	[Tooltip("Shows a one-shot activation animation without a duration slot.")]
	public bool IsInstant; //Field offset: 0x10
	[Tooltip("Shared accent for the cooldown ring and inventory pickup trail.")]
	public Color AccentColor; //Field offset: 0x14
	public Color CooldownFxColor; //Field offset: 0x24
	public Color ActivationBackgroundColor; //Field offset: 0x34
	public string ActivationMessageKey; //Field offset: 0x48
	public string ActivationMessageInvariant; //Field offset: 0x50

	public CharacterAddonHudPresentation() { }

	public string GetActivationMessage() { }

	public bool TryGetDuration(CharacterAddonConfig config, out F64 duration) { }

}

