namespace Client.Common.DI;

[Preserve]
public class GameLifetimeScope
{
	private static GameLifetimeScope _instance; //Field offset: 0x0
	[CompilerGenerated]
	private IServiceProvider <Provider>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private IReflectionServiceInjector <Injector>k__BackingField; //Field offset: 0x18

	public private IReflectionServiceInjector Injector
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public static GameLifetimeScope Instance
	{
		 get { } //Length: 72
	}

	public static IReflectionServiceInjector InstanceInjector
	{
		 get { } //Length: 152
	}

	public private IServiceProvider Provider
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public GameLifetimeScope() { }

	[CompilerGenerated]
	public IReflectionServiceInjector get_Injector() { }

	public static GameLifetimeScope get_Instance() { }

	public static IReflectionServiceInjector get_InstanceInjector() { }

	[CompilerGenerated]
	public IServiceProvider get_Provider() { }

	public static void InjectInto(object target) { }

	public static void Reset() { }

	[CompilerGenerated]
	private void set_Injector(IReflectionServiceInjector value) { }

	[CompilerGenerated]
	private void set_Provider(IServiceProvider value) { }

	public static void SetContainer(IObjectResolver resolver) { }

}

