namespace Client.Authentication;

public class GoogleCredentialManager : IGoogleCredentialManager
{
	[CompilerGenerated]
	private struct <Authenticate>d__6 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder<AuthenticationResult> <>t__builder; //Field offset: 0x8
		public GoogleCredentialManager <>4__this; //Field offset: 0x30
		public CancellationToken cancellationToken; //Field offset: 0x38
		public string nonce; //Field offset: 0x40
		private Awaiter<AuthenticationResult> <>u__1; //Field offset: 0x48

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static class PluginErrorCodes
	{
		public const string UserCancelled = "user_cancelled"; //Field offset: 0x0
		public const string CustomCredentialError = "custom_credential_error"; //Field offset: 0x0
		public const string NetworkError = "network_error"; //Field offset: 0x0
		public const string ProviderError = "provider_error"; //Field offset: 0x0
		public const string ProviderUnsupported = "provider_unsupported"; //Field offset: 0x0
		public const string RuntimeException = "runtime_exception"; //Field offset: 0x0
		public const string ProviderMisconfigured = "provider_misconfigured"; //Field offset: 0x0
		public const string AccountReauthFailure = "account_reauth_failure"; //Field offset: 0x0
		public const string RequestReplaced = "request_replaced"; //Field offset: 0x0
		public const string UnsupportedCredentialType = "unsupported_credential_type"; //Field offset: 0x0
		public const string CredentialParseFailure = "credential_parse_failure"; //Field offset: 0x0
		public const string EmptyIdToken = "empty_id_token"; //Field offset: 0x0
		public const string ServerClientIdMissing = "server_client_id_missing"; //Field offset: 0x0
		public const string UnityActivityLost = "unity_activity_lost"; //Field offset: 0x0
		public const string UnityActivityMissing = "unity_activity_missing"; //Field offset: 0x0
		public const string AccountReauthRequired = "account_reauth_required"; //Field offset: 0x0
		public const string ProviderInterrupted = "provider_interrupted"; //Field offset: 0x0
		public const string NoCredentials = "no_credentials"; //Field offset: 0x0
		public const string ProviderUnknownError = "provider_unknown_error"; //Field offset: 0x0
		public const string TransactionTooLarge = "transaction_too_large"; //Field offset: 0x0

	}

	private static readonly Dictionary<String, AuthenticationStatus> PluginErrorStatusMap; //Field offset: 0x0
	private readonly IOptionsMonitor<GoogleAuthOptions> _options; //Field offset: 0x10
	private ICredentialManagerBridge _managerBridge; //Field offset: 0x18
	private readonly ILogger _logger; //Field offset: 0x20
	private UniTaskCompletionSource<AuthenticationResult> _activeTcs; //Field offset: 0x28
	private bool _isConfigured; //Field offset: 0x30

	private static GoogleCredentialManager() { }

	public GoogleCredentialManager(IOptionsMonitor<GoogleAuthOptions> options) { }

	[CompilerGenerated]
	private void <Authenticate>b__6_0() { }

	[AsyncStateMachine(typeof(<Authenticate>d__6))]
	public override ValueTask<AuthenticationResult> Authenticate(string nonce, CancellationToken cancellationToken = null) { }

	public override void CancelSignIn() { }

	private void EnsureConfigured() { }

	private static AuthenticationStatus MapPluginErrorToStatus(string errorCode) { }

	private void SetFailureResult(string errorJson) { }

	private void SetSuccessResult(string idToken) { }

	private void Shutdown() { }

	private bool TryParsePluginError(string json, out AuthenticationError error) { }

}

