namespace Client.Lobby;

[DisallowMultipleComponent]
[ExecuteAlways]
public sealed class LobbyV2CameraController : MonoBehaviour
{
	private const float PositionEpsilon = 1E-06; //Field offset: 0x0
	private const float RotationEpsilonDegrees = 0,001; //Field offset: 0x0
	private const float MinAspect = 0,0001; //Field offset: 0x0
	private const float ReferenceAspect = 1,7777778; //Field offset: 0x0
	private static readonly List<Int32> DragFingerIds; //Field offset: 0x0
	[SerializeField]
	private Camera _camera; //Field offset: 0x20
	[SerializeField]
	private LobbyParallax _parallax; //Field offset: 0x28
	[SerializeField]
	[Tooltip("Parallax range covered by a horizontal drag across the full screen width.")]
	private float _parallaxDragSensitivity; //Field offset: 0x30
	[Min(0)]
	[SerializeField]
	private float _swipePrecision; //Field offset: 0x34
	[Min(0.01)]
	[SerializeField]
	private float _parallaxMomentum; //Field offset: 0x38
	[SerializeField]
	private Vector3 _position; //Field offset: 0x3C
	[SerializeField]
	private Vector3 _rotation; //Field offset: 0x48
	[SerializeField]
	[Tooltip("Camera local Z units applied for each 1.0 aspect-ratio amount narrower than 16:9, based on Screen.safeArea.")]
	private float _narrowSafeAreaLocalZOffsetPerAspectDelta; //Field offset: 0x54
	[SerializeField]
	[Tooltip("Camera local X rotation degrees applied for each 1.0 aspect-ratio amount narrower than 16:9, based on Screen.safeArea.")]
	private float _narrowSafeAreaLocalXRotationPerAspectDelta; //Field offset: 0x58
	[SerializeField]
	[Tooltip("Camera global Y rotation degrees applied for each 1.0 aspect-ratio amount narrower than 16:9, based on Screen.safeArea.")]
	private float _narrowSafeAreaGlobalYRotationPerAspectDelta; //Field offset: 0x5C
	private int _lastScreenWidth; //Field offset: 0x60
	private int _lastScreenHeight; //Field offset: 0x64
	private int _lastSafeAreaX; //Field offset: 0x68
	private int _lastSafeAreaY; //Field offset: 0x6C
	private int _lastSafeAreaWidth; //Field offset: 0x70
	private int _lastSafeAreaHeight; //Field offset: 0x74
	private ScreenOrientation _lastScreenOrientation; //Field offset: 0x78
	private bool _hasViewportState; //Field offset: 0x7C
	private SingleTouchProvider _touchProvider; //Field offset: 0x80
	private bool _isDragging; //Field offset: 0x88
	private float _lastDragDeltaX; //Field offset: 0x8C

	public float CurrentAspect
	{
		 get { } //Length: 4
	}

	public float CurrentNarrowAspectDelta
	{
		 get { } //Length: 116
	}

	private static LobbyV2CameraController() { }

	public LobbyV2CameraController() { }

	private void ApplyCameraTransform(bool force) { }

	private void ApplyParallaxDelta(float normalizedDelta) { }

	private static float CalculateNarrowAspectDelta(float currentAspect) { }

	private Vector3 CalculatePosition(Transform cameraTransform, float aspectDelta) { }

	private Quaternion CalculateRotation(float aspectDelta) { }

	public float get_CurrentAspect() { }

	public float get_CurrentNarrowAspectDelta() { }

	private Transform GetCameraTransform() { }

	private float GetCurrentSafeAreaAspect() { }

	private static RectInt GetCurrentSafeAreaPixels() { }

	private void OnDisable() { }

	private void OnEnable() { }

	private void OnValidate() { }

	private void ProcessParallaxInput() { }

	private void Reset() { }

	private void ResolveCameraReference() { }

	private void Update() { }

	private bool UpdateViewportState() { }

}

