namespace Client.Core;

[Nullable(0)]
[NullableContext(1)]
public abstract class BaseAsyncOperationGroup : IAsyncOperationsGroup, IAsyncOperationWithProgress
{
	private readonly AsyncOperationWithProgress _asyncOperation; //Field offset: 0x10
	protected readonly OperationsContainer OperationGraph; //Field offset: 0x18

	public override UniTask CompletedTask
	{
		 get { } //Length: 24
	}

	public override IReadOnlyList<IAsyncOperationWithProgress> GroupRawOperations
	{
		 get { } //Length: 24
	}

	public override string OperationId
	{
		 get { } //Length: 24
	}

	protected BaseAsyncOperationGroup(string operationId) { }

	public override IAsyncOperationsGroup AddOperation(IAsyncOperationWithProgress operation, Order order = 1) { }

	public IAsyncOperationsGroup AddOperations(IEnumerable<IAsyncOperationWithProgress> operations, Order order) { }

	public override bool AttachProgressObserver(IOperationProgressObserver progressObserver) { }

	public override void CollectListOfTypesRecursive(HashSet<T> collector) { }

	public override int CountOfTypeRecursive() { }

	[NullableContext(2)]
	public override UniTask ExecuteOperationAsync(IOperationProgressObserver progressObserver = null) { }

	public override UniTask get_CompletedTask() { }

	public override IReadOnlyList<IAsyncOperationWithProgress> get_GroupRawOperations() { }

	public override string get_OperationId() { }

	public override List<IAsyncOperationWithProgress> GetAllOperationsRecursive() { }

	public override List<T> GetListOfTypeRecursive() { }

	public override List<T> GetOperationsOfExactType() { }

	protected abstract UniTask HandleAllOperation(IOperationProgressObserver observer) { }

	public override bool HasOperation(IAsyncOperationWithProgress operation) { }

	public override bool HasOperationRecursive(IAsyncOperationWithProgress operation) { }

	public override bool RemoveRecursive(IAsyncOperationWithProgress operation) { }

}

