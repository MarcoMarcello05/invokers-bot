namespace Client.Authentication;

public sealed class UnityCredentialManagerBridge : ICredentialManagerBridge, IDisposable
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass13_0
	{
		public UnityCredentialManagerBridge <>4__this; //Field offset: 0x10
		public string idToken; //Field offset: 0x18

		public <>c__DisplayClass13_0() { }

		internal void <DispatchSuccess>b__0(object _) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass14_0
	{
		public UnityCredentialManagerBridge <>4__this; //Field offset: 0x10
		public string errorMessage; //Field offset: 0x18

		public <>c__DisplayClass14_0() { }

		internal void <DispatchError>b__0(object _) { }

	}

	private sealed class CredentialCallbackProxy : AndroidJavaProxy
	{
		private readonly Action<String> success; //Field offset: 0x20
		private readonly Action<String> error; //Field offset: 0x28

		public CredentialCallbackProxy(Action<String> success, Action<String> error) { }

		public void onError(string message) { }

		public void onSuccess(string idToken) { }

	}

	private const string BridgeClassName = "zone.hitzone.invokers.credentialplugin.CredentialBridge"; //Field offset: 0x0
	private const string CallbackInterfaceName = "zone.hitzone.invokers.credentialplugin.CredentialResultCallback"; //Field offset: 0x0
	private readonly SynchronizationContext unityContext; //Field offset: 0x10
	private CredentialCallbackProxy callbackProxy; //Field offset: 0x18
	private Action<String> onSuccess; //Field offset: 0x20
	private Action<String> onError; //Field offset: 0x28

	public UnityCredentialManagerBridge() { }

	public override void CancelSignIn() { }

	private void DispatchError(string errorMessage) { }

	private void DispatchSuccess(string idToken) { }

	public override void Dispose() { }

	private void EnsureCallbackProxy() { }

	public override string GetAndroidId() { }

	public override void Initialize(Action<String> successCallback, Action<String> errorCallback) { }

	public override void StartGoogleSignIn(string serverClientId, bool filterAuthorizedAccountsOnly, bool autoSelectEnabled, string nonce) { }

}

