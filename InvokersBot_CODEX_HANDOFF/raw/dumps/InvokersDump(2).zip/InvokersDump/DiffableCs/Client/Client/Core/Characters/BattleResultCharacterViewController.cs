namespace Client.Core.Characters;

public class BattleResultCharacterViewController : CharacterViewController
{
	[CompilerGenerated]
	private readonly BattleCharacterSetup <Setup>k__BackingField; //Field offset: 0xA0

	public CharacterStandSide BattleResultStandSide
	{
		 get { } //Length: 20
	}

	public BattleCharacterSetup Setup
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	[TupleElementNames(new IL2CPP_TYPE_STRING[] {"WithSound", "CustomLight"})]
	protected virtual ValueTuple<Boolean, Boolean> StagingOptions
	{
		 get { } //Length: 104
	}

	public BattleResultCharacterViewController(CharacterVariant variant, BattleCharacterSetup setup, IAssetProvider assetProvider, IJiggleScheduler jiggleScheduler, IStagingContainer stagingContainer) { }

	public CharacterStandSide get_BattleResultStandSide() { }

	[CompilerGenerated]
	public BattleCharacterSetup get_Setup() { }

	protected virtual ValueTuple<Boolean, Boolean> get_StagingOptions() { }

}

