namespace Client.Authentication;

public class GoogleAuthService : IGoogleAuthService
{
	[CompilerGenerated]
	private struct <Authenticate>d__4 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncTaskMethodBuilder<AuthenticationResult> <>t__builder; //Field offset: 0x8
		public GoogleAuthService <>4__this; //Field offset: 0x20
		public CancellationToken cancellationToken; //Field offset: 0x28
		private string <pkceCodeVerifier>5__2; //Field offset: 0x30
		private string <state>5__3; //Field offset: 0x38
		private string <redirectUri>5__4; //Field offset: 0x40
		private string <clientId>5__5; //Field offset: 0x48
		private StringBuilder <authUrlBuilder>5__6; //Field offset: 0x50
		private TaskAwaiter<AuthorizationCodeResponse> <>u__1; //Field offset: 0x58

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly ILogger _logger; //Field offset: 0x10
	private readonly IOptionsMonitor<GoogleAuthOptions> _options; //Field offset: 0x18
	private readonly IGoogleAuthenticator _googleAuthenticator; //Field offset: 0x20

	public GoogleAuthService(IOptionsMonitor<GoogleAuthOptions> options, IGoogleAuthenticator googleAuthenticator, ILoggerFactory loggerFactory) { }

	[AsyncStateMachine(typeof(<Authenticate>d__4))]
	public override Task<AuthenticationResult> Authenticate(CancellationToken cancellationToken = null) { }

}

