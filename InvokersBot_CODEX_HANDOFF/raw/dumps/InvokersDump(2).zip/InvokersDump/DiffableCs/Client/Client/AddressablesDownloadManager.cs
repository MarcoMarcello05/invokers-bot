namespace Client;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public sealed class AddressablesDownloadManager : IDownloadManager
{
	[CompilerGenerated]
	private struct <DownloadAsync>d__14 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<AssetDownloadRequest> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public AssetKey key; //Field offset: 0x20
		public CancellationToken ct; //Field offset: 0x28
		[Nullable(0)]
		public Action<DownloadStatus> onProgress; //Field offset: 0x30
		[Nullable(0)]
		public AddressablesDownloadManager <>4__this; //Field offset: 0x38
		private AutoScope <_>5__2; //Field offset: 0x40
		private AsyncOperationHandle <aoh>5__3; //Field offset: 0x58
		[Nullable(0)]
		private IDisposable <subscription>5__4; //Field offset: 0x70
		[Nullable(0)]
		private AssetDownloadRequest <request>5__5; //Field offset: 0x78
		[Nullable(0)]
		private TaskAwaiter<Object> <>u__1; //Field offset: 0x80

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <DownloadAsync>d__15 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<AssetListDownloadRequest> <>t__builder; //Field offset: 0x8
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		public IReadOnlyCollection<AssetKey> keys; //Field offset: 0x20
		public CancellationToken ct; //Field offset: 0x28
		[Nullable(0)]
		public Action<DownloadStatus> onProgress; //Field offset: 0x30
		[Nullable(0)]
		public AddressablesDownloadManager <>4__this; //Field offset: 0x38
		private AutoScope <_>5__2; //Field offset: 0x40
		private AsyncOperationHandle <aoh>5__3; //Field offset: 0x58
		[Nullable(0)]
		private IDisposable <subscription>5__4; //Field offset: 0x70
		[Nullable(0)]
		private AssetListDownloadRequest <request>5__5; //Field offset: 0x78
		[Nullable(0)]
		private TaskAwaiter<Object> <>u__1; //Field offset: 0x80

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <GetDownloadSizeAsync>d__13 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<Int64> <>t__builder; //Field offset: 0x8
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		public IReadOnlyCollection<AssetKey> keys; //Field offset: 0x20
		private AutoScope <_>5__2; //Field offset: 0x28
		[Nullable(0)]
		private Stopwatch <timer>5__3; //Field offset: 0x40
		[Nullable(0)]
		private AsyncOperationHandle<Int64> <downloadSizeOperation>5__4; //Field offset: 0x48
		[Nullable(0)]
		private TaskAwaiter<Int64> <>u__1; //Field offset: 0x60

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <LoadResourceLocationsAsync>d__16 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(new IL2CPP_TYPE_U1[] {0, 0, 1, 1})]
		public AsyncUniTaskMethodBuilder<AssetListRequest`1<IList`1<IResourceLocation>>> <>t__builder; //Field offset: 0x8
		public ResourceLocationMode mode; //Field offset: 0x20
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		public List<AssetKey> keys; //Field offset: 0x28
		private AutoScope <_>5__2; //Field offset: 0x30
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		private AssetListRequest<IList`1<IResourceLocation>> <request>5__3; //Field offset: 0x48
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		private TaskAwaiter<IList`1<IResourceLocation>> <>u__1; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Scope IsDownloadedScope; //Field offset: 0x0
	private static readonly Activity GetDownloadSizeAsyncScope; //Field offset: 0x20
	private static readonly Activity DownloadAsyncScope; //Field offset: 0x30
	private static readonly Activity LoadResourceLocationsAsyncScope; //Field offset: 0x40
	private readonly IDownloadsTrackerInternal _downloadsTracker; //Field offset: 0x10

	public override IReadOnlyList<ActiveDownload> ActiveDownloads
	{
		 get { } //Length: 160
	}

	public override bool IsUsingAssetDatabase
	{
		 get { } //Length: 164
	}

	private static AddressablesDownloadManager() { }

	public AddressablesDownloadManager(IDownloadsTracker downloadsTracker) { }

	[AsyncStateMachine(typeof(<DownloadAsync>d__14))]
	public override UniTask<AssetDownloadRequest> DownloadAsync(AssetKey key, Action<DownloadStatus> onProgress = null, CancellationToken ct = null) { }

	[AsyncStateMachine(typeof(<DownloadAsync>d__15))]
	public override UniTask<AssetListDownloadRequest> DownloadAsync(IReadOnlyCollection<AssetKey> keys, Action<DownloadStatus> onProgress = null, CancellationToken ct = null) { }

	public override IReadOnlyList<ActiveDownload> get_ActiveDownloads() { }

	public override bool get_IsUsingAssetDatabase() { }

	[NullableContext(0)]
	public override UniTask<Int64> GetDownloadSizeAsync(AssetKey key) { }

	[AsyncStateMachine(typeof(<GetDownloadSizeAsync>d__13))]
	[NullableContext(0)]
	public override UniTask<Int64> GetDownloadSizeAsync(IReadOnlyCollection<AssetKey> keys) { }

	public override bool IsDownloaded(AssetKey assetKey, bool markAsUsed = true) { }

	public override bool IsDownloaded(IReadOnlyCollection<AssetKey> assetKeys, bool markAsUsed = true) { }

	[AsyncStateMachine(typeof(<LoadResourceLocationsAsync>d__16))]
	public override UniTask<AssetListRequest`1<IList`1<IResourceLocation>>> LoadResourceLocationsAsync(List<AssetKey> keys, ResourceLocationMode mode) { }

}

