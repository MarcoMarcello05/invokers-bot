namespace Client.Common;

public static class ComponentIndexerInitializer
{

	[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType::AfterAssembliesLoaded (2))]
	private static void Init() { }

}

