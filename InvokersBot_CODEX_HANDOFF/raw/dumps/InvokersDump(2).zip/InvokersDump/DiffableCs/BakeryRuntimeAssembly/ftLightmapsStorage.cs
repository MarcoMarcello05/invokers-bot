//Type is in global namespace

[ExecuteInEditMode]
public class ftLightmapsStorage : MonoBehaviour
{
	public const bool externalStorage = False; //Field offset: 0x0
	public List<Renderer> bakedRenderers; //Field offset: 0x20
	public List<Renderer> nonBakedRenderers; //Field offset: 0x28
	public List<Light> bakedLights; //Field offset: 0x30
	public List<Terrain> bakedRenderersTerrain; //Field offset: 0x38
	public List<Texture2D> maps; //Field offset: 0x40
	public List<Texture2D> masks; //Field offset: 0x48
	public List<Texture2D> dirMaps; //Field offset: 0x50
	public List<Texture2D> rnmMaps0; //Field offset: 0x58
	public List<Texture2D> rnmMaps1; //Field offset: 0x60
	public List<Texture2D> rnmMaps2; //Field offset: 0x68
	public List<Int32> mapsMode; //Field offset: 0x70
	public List<Int32> bakedIDs; //Field offset: 0x78
	public List<Vector4> bakedScaleOffset; //Field offset: 0x80
	public List<Mesh> bakedVertexColorMesh; //Field offset: 0x88
	public List<Int32> bakedLightChannels; //Field offset: 0x90
	public List<Int32> bakedIDsTerrain; //Field offset: 0x98
	public List<Vector4> bakedScaleOffsetTerrain; //Field offset: 0xA0
	public List<String> assetList; //Field offset: 0xA8
	public List<Int32> uvOverlapAssetList; //Field offset: 0xB0
	public Int32[] idremap; //Field offset: 0xB8
	public bool usesRealtimeGI; //Field offset: 0xC0
	public Texture2D emptyDirectionTex; //Field offset: 0xC8
	public bool anyVolumes; //Field offset: 0xD0
	public bool compressedVolumes; //Field offset: 0xD1

	public ftLightmapsStorage() { }

	private void Awake() { }

	private void OnDestroy() { }

	private void Start() { }

}

