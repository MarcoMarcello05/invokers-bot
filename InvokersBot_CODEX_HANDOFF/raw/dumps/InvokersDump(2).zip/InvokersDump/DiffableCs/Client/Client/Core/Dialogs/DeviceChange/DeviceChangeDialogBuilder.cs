namespace Client.Core.Dialogs.DeviceChange;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public class DeviceChangeDialogBuilder
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass7_0
	{
		public DeviceDisplayInfo thisDevice; //Field offset: 0x10
		public DeviceDisplayInfo otherDevice; //Field offset: 0x20
		public Nullable<DateTime> otherDeviceLastSyncTimeUtc; //Field offset: 0x30
		[Nullable(0)]
		public DeviceChangeDialogBuilder <>4__this; //Field offset: 0x40
		[Nullable(0)]
		public Func<UniTask> continueAsync; //Field offset: 0x48

		public <>c__DisplayClass7_0() { }

		internal void <ShowAndWaitAsync>b__0(DeviceChangeDialogController controller, DeviceChangeDialogView view) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass7_1
	{
		private struct <<ShowAndWaitAsync>b__1>d : IAsyncStateMachine
		{
			public int <>1__state; //Field offset: 0x0
			public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
			[Nullable(0)]
			public <>c__DisplayClass7_1 <>4__this; //Field offset: 0x28
			private Awaiter <>u__1; //Field offset: 0x30

			private override void MoveNext() { }

			[DebuggerHidden]
			private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

		}

		[Nullable(0)]
		public DeviceChangeDialogController controller; //Field offset: 0x10
		[Nullable(0)]
		public <>c__DisplayClass7_0 CS$<>8__locals1; //Field offset: 0x18

		public <>c__DisplayClass7_1() { }

		[AsyncStateMachine(typeof(<<ShowAndWaitAsync>b__1>d))]
		internal ValueTask <ShowAndWaitAsync>b__1() { }

	}

	[CompilerGenerated]
	private struct <ShowAndWaitAsync>d__7 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public DeviceDisplayInfo thisDevice; //Field offset: 0x18
		public DeviceDisplayInfo otherDevice; //Field offset: 0x28
		public Nullable<DateTime> otherDeviceLastSyncTimeUtc; //Field offset: 0x38
		[Nullable(0)]
		public DeviceChangeDialogBuilder <>4__this; //Field offset: 0x48
		[Nullable(0)]
		public Func<UniTask> continueAsync; //Field offset: 0x50
		[Nullable(0)]
		public AssetKey popupPrefab; //Field offset: 0x58
		public bool allowKeyDismiss; //Field offset: 0x60
		[Nullable(0)]
		private DeviceChangeDialogController <controller>5__2; //Field offset: 0x68
		private Awaiter <>u__1; //Field offset: 0x70

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IContentManager _content; //Field offset: 0x10
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x18
	private readonly IUISystem _uiSystem; //Field offset: 0x20
	private readonly ButtonCommandBuilder _buttonCommandBuilder; //Field offset: 0x28

	public DeviceChangeDialogBuilder(IContentManager content, IStagingContainer stagingContainer, IUISystem uiSystem, ButtonCommandBuilder buttonCommandBuilder) { }

	[AsyncStateMachine(typeof(<ShowAndWaitAsync>d__7))]
	private UniTask ShowAndWaitAsync(AssetKey popupPrefab, DeviceDisplayInfo thisDevice, DeviceDisplayInfo otherDevice, Nullable<DateTime> otherDeviceLastSyncTimeUtc, bool allowKeyDismiss, Func<UniTask> continueAsync = null) { }

	public UniTask ShowSessionMovedDialogAsync() { }

	public UniTask ShowTakeoverConfirmationDialogAsync(string lastDeviceModel, DateTime lastSyncTimeUtc, Func<UniTask> completeTakeoverAsync) { }

}

