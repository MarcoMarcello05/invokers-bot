namespace Client.Authentication.Apple;

public interface IAppleAuthService
{

	public ValueTask<String> Authenticate(AppleAuthLoginArgs loginArgs) { }

}

