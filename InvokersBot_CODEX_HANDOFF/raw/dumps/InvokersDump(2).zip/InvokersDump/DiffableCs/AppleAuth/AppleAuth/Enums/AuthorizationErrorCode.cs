namespace AppleAuth.Enums;

public enum AuthorizationErrorCode : int
{
	Unknown = 1000,
	Canceled = 1001,
	InvalidResponse = 1002,
	NotHandled = 1003,
	Failed = 1004,
}

