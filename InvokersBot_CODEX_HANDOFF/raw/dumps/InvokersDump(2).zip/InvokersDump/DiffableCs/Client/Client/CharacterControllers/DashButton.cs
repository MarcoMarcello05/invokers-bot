namespace Client.CharacterControllers;

public class DashButton : MonoBehaviour
{
	[SerializeField]
	private Image[] _progressBars; //Field offset: 0x20
	[SerializeField]
	private CanvasGroup _canvasGroup; //Field offset: 0x28
	[SerializeField]
	private BaseUISelectableAnimator _animator; //Field offset: 0x30
	[SerializeField]
	private UISelectableUIAnimator _borderAnimation; //Field offset: 0x38
	[SerializeField]
	private UISelectableUIAnimator _buttonAnimation; //Field offset: 0x40
	[SerializeField]
	private GameObject _blockRoot; //Field offset: 0x48
	private float _progressMax; //Field offset: 0x50
	private bool _isVisible; //Field offset: 0x54

	public DashButton() { }

	private void Awake() { }

	public void Block(bool needBlock = true) { }

	public void UpdateDashVisibility(bool isVisible) { }

	public void UpdateProgress(float progress) { }

}

