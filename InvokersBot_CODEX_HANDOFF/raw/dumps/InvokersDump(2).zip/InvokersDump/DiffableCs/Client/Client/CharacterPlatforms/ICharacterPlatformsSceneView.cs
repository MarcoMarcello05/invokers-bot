namespace Client.CharacterPlatforms;

public interface ICharacterPlatformsSceneView
{

	public ICharacterPlatformsCamera Camera
	{
		 get { } //Length: 0
	}

	public Vector3 HiddenPosition
	{
		 get { } //Length: 0
	}

	public Transform LoadingVfxTransform
	{
		 get { } //Length: 0
	}

	public Transform PlatformsRoot
	{
		 get { } //Length: 0
	}

	public Vector3 VisiblePosition
	{
		 get { } //Length: 0
	}

	public ICharacterPlatformsCamera get_Camera() { }

	public Vector3 get_HiddenPosition() { }

	public Transform get_LoadingVfxTransform() { }

	public Transform get_PlatformsRoot() { }

	public Vector3 get_VisiblePosition() { }

}

