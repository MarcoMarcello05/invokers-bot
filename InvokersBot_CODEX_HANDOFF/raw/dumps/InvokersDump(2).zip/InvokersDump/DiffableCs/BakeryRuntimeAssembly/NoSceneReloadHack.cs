//Type is in global namespace

public class NoSceneReloadHack : MonoBehaviour
{

	public NoSceneReloadHack() { }

}

