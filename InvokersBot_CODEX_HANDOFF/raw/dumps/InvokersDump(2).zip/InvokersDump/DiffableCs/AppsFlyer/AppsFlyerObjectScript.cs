//Type is in global namespace

public class AppsFlyerObjectScript : MonoBehaviour, IAppsFlyerConversionData
{
	public string devKey; //Field offset: 0x20
	public string appID; //Field offset: 0x28
	public string UWPAppID; //Field offset: 0x30
	public string macOSAppID; //Field offset: 0x38
	public bool isDebug; //Field offset: 0x40
	public bool getConversionData; //Field offset: 0x41

	public AppsFlyerObjectScript() { }

	public override void onAppOpenAttribution(string attributionData) { }

	public override void onAppOpenAttributionFailure(string error) { }

	public override void onConversionDataFail(string error) { }

	public override void onConversionDataSuccess(string conversionData) { }

	private void Start() { }

}

