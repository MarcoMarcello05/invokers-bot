namespace Client.Authentication.ExternalAuth.Providers;

public sealed class GoogleExternalAuthProvider : IExternalAuthProvider
{
	[CompilerGenerated]
	private struct <AuthenticateWithGoogleAuthorizationCodeAsync>d__11 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder<ExternalAuthResult> <>t__builder; //Field offset: 0x8
		public GoogleExternalAuthProvider <>4__this; //Field offset: 0x40
		public CancellationToken cancellationToken; //Field offset: 0x48
		private TaskAwaiter<AuthenticationResult> <>u__1; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <AuthenticateWithGoogleCredentialManagerAsync>d__10 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder<ExternalAuthResult> <>t__builder; //Field offset: 0x8
		public GoogleExternalAuthProvider <>4__this; //Field offset: 0x40
		public CancellationToken cancellationToken; //Field offset: 0x48
		private string <generatedRawNonce>5__2; //Field offset: 0x50
		private ValueTaskAwaiter<AuthenticationResult> <>u__1; //Field offset: 0x58

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <TryAuthenticateAsync>d__8 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder<ExternalAuthResult> <>t__builder; //Field offset: 0x8
		public GoogleExternalAuthProvider <>4__this; //Field offset: 0x40
		public CancellationToken ct; //Field offset: 0x48
		private ValueTaskAwaiter<ExternalAuthResult> <>u__1; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[Nullable(1)]
	private readonly ILogger<GoogleExternalAuthProvider> _logger; //Field offset: 0x10
	[Nullable(1)]
	private readonly IGoogleAuthService _googleAuthService; //Field offset: 0x18
	[Nullable(1)]
	private readonly IGoogleCredentialManager _googleCredentialManager; //Field offset: 0x20

	public override bool IsAvailable
	{
		 get { } //Length: 8
	}

	public override ExternalLoginProvider Provider
	{
		 get { } //Length: 8
	}

	[NullableContext(1)]
	public GoogleExternalAuthProvider(IGoogleAuthService googleAuthService, IGoogleCredentialManager googleCredentialManager) { }

	[AsyncStateMachine(typeof(<AuthenticateWithGoogleAuthorizationCodeAsync>d__11))]
	private ValueTask<ExternalAuthResult> AuthenticateWithGoogleAuthorizationCodeAsync(CancellationToken cancellationToken) { }

	[AsyncStateMachine(typeof(<AuthenticateWithGoogleCredentialManagerAsync>d__10))]
	private ValueTask<ExternalAuthResult> AuthenticateWithGoogleCredentialManagerAsync(CancellationToken cancellationToken) { }

	public override bool get_IsAvailable() { }

	public override ExternalLoginProvider get_Provider() { }

	[NullableContext(2)]
	public override string GetCurrentUserName() { }

	[AsyncStateMachine(typeof(<TryAuthenticateAsync>d__8))]
	public override ValueTask<ExternalAuthResult> TryAuthenticateAsync(ExternalAuthMode mode, CancellationToken ct = null) { }

}

