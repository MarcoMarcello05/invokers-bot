namespace Client;

[Extension]
[Nullable(0)]
[NullableContext(1)]
public static class AsyncOperationHandleExtensions
{
	[CompilerGenerated]
	private sealed class <>c
	{
		[Nullable(0)]
		public static readonly <>c <>9; //Field offset: 0x0
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		public static Func<Observer`1<DownloadStatus>, AsyncOperationHandle, IDisposable> <>9__0_0; //Field offset: 0x8
		[Nullable(0)]
		public static Func<Unit, AsyncOperationHandle, DownloadStatus> <>9__0_2; //Field offset: 0x10
		[Nullable(0)]
		public static Func<DownloadStatus, Single> <>9__0_3; //Field offset: 0x18
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		public static Func<Observer`1<DownloadStatus>, AsyncOperationHandle, IDisposable> <>9__1_0; //Field offset: 0x20
		[Nullable(0)]
		public static Func<Unit, AsyncOperationHandle, DownloadStatus> <>9__1_2; //Field offset: 0x28
		[Nullable(0)]
		public static Func<DownloadStatus, Single> <>9__1_3; //Field offset: 0x30

		private static <>c() { }

		public <>c() { }

		internal IDisposable <ToThrottledLoadingObservable>b__0_0(Observer<DownloadStatus> obs, AsyncOperationHandle state) { }

		internal DownloadStatus <ToThrottledLoadingObservable>b__0_2(Unit _, AsyncOperationHandle self) { }

		internal float <ToThrottledLoadingObservable>b__0_3(DownloadStatus s) { }

		internal IDisposable <ToThrottledLoadingObservable>b__1_0(Observer<DownloadStatus> obs, AsyncOperationHandle state) { }

		internal DownloadStatus <ToThrottledLoadingObservable>b__1_2(Unit _, AsyncOperationHandle self) { }

		internal float <ToThrottledLoadingObservable>b__1_3(DownloadStatus s) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass0_0
	{
		public AsyncOperationHandle aoh; //Field offset: 0x10

		public <>c__DisplayClass0_0() { }

		internal bool <ToThrottledLoadingObservable>b__1(Unit _) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass0_1
	{
		public AsyncOperationHandle state; //Field offset: 0x10
		[Nullable(0)]
		public Observer<DownloadStatus> obs; //Field offset: 0x28

		public <>c__DisplayClass0_1() { }

		internal void <ToThrottledLoadingObservable>b__4(AsyncOperationHandle _) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass1_0
	{
		public AsyncOperationHandle aoh; //Field offset: 0x10
		public CancellationToken ct; //Field offset: 0x28

		public <>c__DisplayClass1_0() { }

		internal bool <ToThrottledLoadingObservable>b__1(Unit _) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass1_1
	{
		public AsyncOperationHandle state; //Field offset: 0x10
		[Nullable(0)]
		public Observer<DownloadStatus> obs; //Field offset: 0x28

		public <>c__DisplayClass1_1() { }

		internal void <ToThrottledLoadingObservable>b__4(AsyncOperationHandle _) { }

	}


	[Extension]
	public static string GetDownloadError(AsyncOperationHandle handle) { }

	[Extension]
	public static Observable<DownloadStatus> ToThrottledLoadingObservable(AsyncOperationHandle aoh, CancellationToken ct, int throttleSpanMs = 100) { }

	[Extension]
	public static Observable<DownloadStatus> ToThrottledLoadingObservable(AsyncOperationHandle aoh, int throttleSpanMs = 100) { }

}

