namespace AppsFlyerSDK;

public class AppsFlyerConsent
{
	[CompilerGenerated]
	private Nullable<Boolean> <isUserSubjectToGDPR>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private Nullable<Boolean> <hasConsentForDataUsage>k__BackingField; //Field offset: 0x12
	[CompilerGenerated]
	private Nullable<Boolean> <hasConsentForAdsPersonalization>k__BackingField; //Field offset: 0x14
	[CompilerGenerated]
	private Nullable<Boolean> <hasConsentForAdStorage>k__BackingField; //Field offset: 0x16

	public private Nullable<Boolean> hasConsentForAdsPersonalization
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public private Nullable<Boolean> hasConsentForAdStorage
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public private Nullable<Boolean> hasConsentForDataUsage
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public private Nullable<Boolean> isUserSubjectToGDPR
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public AppsFlyerConsent(Nullable<Boolean> isUserSubjectToGDPR = null, Nullable<Boolean> hasConsentForDataUsage = null, Nullable<Boolean> hasConsentForAdsPersonalization = null, Nullable<Boolean> hasConsentForAdStorage = null) { }

	[CompilerGenerated]
	public Nullable<Boolean> get_hasConsentForAdsPersonalization() { }

	[CompilerGenerated]
	public Nullable<Boolean> get_hasConsentForAdStorage() { }

	[CompilerGenerated]
	public Nullable<Boolean> get_hasConsentForDataUsage() { }

	[CompilerGenerated]
	public Nullable<Boolean> get_isUserSubjectToGDPR() { }

	[CompilerGenerated]
	private void set_hasConsentForAdsPersonalization(Nullable<Boolean> value) { }

	[CompilerGenerated]
	private void set_hasConsentForAdStorage(Nullable<Boolean> value) { }

	[CompilerGenerated]
	private void set_hasConsentForDataUsage(Nullable<Boolean> value) { }

	[CompilerGenerated]
	private void set_isUserSubjectToGDPR(Nullable<Boolean> value) { }

}

