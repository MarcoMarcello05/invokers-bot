namespace Client.Core.ErrorHandling;

public interface IConnectionRequiredPopup : IDialogView, IView
{

	public IButton CloseButton
	{
		 get { } //Length: 0
	}

	public IButton SupportButton
	{
		 get { } //Length: 0
	}

	public IButton TryReconnectNowButton
	{
		 get { } //Length: 0
	}

	public IButton get_CloseButton() { }

	public IButton get_SupportButton() { }

	public IButton get_TryReconnectNowButton() { }

	public void SetActionsInteractable(bool interactable) { }

	public void SetContent(string description) { }

	public void SetReconnectButtonActive(bool isActive) { }

	public void SetSessionDebugInfo(string sessionDebugInfo) { }

	public void SetSupportButtonActive(bool isActive) { }

}

