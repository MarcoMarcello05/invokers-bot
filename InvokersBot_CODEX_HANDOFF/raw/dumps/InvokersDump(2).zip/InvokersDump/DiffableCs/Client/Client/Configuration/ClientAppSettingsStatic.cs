namespace Client.Configuration;

public class ClientAppSettingsStatic
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		[Nullable(new IL2CPP_TYPE_U1[] {0, 0, 2})]
		public static Action<ClientAppSettings, String> <>9__11_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal void <Initialize>b__11_0(ClientAppSettings settings, string _) { }

	}

	private static readonly Scope SettingsChange; //Field offset: 0x0
	private static readonly Subject<ClientAppSettings> SettingsSubject; //Field offset: 0x20
	private static ClientAppSettings _settings; //Field offset: 0x28
	private static IDisposable _subscription; //Field offset: 0x30
	private static ClientAppSettings _previousSettings; //Field offset: 0x38
	private static IOptionsMonitor<ClientAppSettings> _optionsMonitor; //Field offset: 0x40

	public static Observable<ClientAppSettings> OnChange
	{
		 get { } //Length: 88
	}

	public static ClientAppSettings Value
	{
		 get { } //Length: 260
	}

	private static ClientAppSettingsStatic() { }

	public ClientAppSettingsStatic() { }

	public static void Build() { }

	public static Observable<ClientAppSettings> get_OnChange() { }

	public static ClientAppSettings get_Value() { }

	public static void Initialize(IOptionsMonitor<ClientAppSettings> optionsMonitor) { }

	private static void TryUnsubscribe() { }

}

