namespace Client.Characters;

public static class LobbyCharacterControllerFactory
{

	public static LobbyCharacterController Bind(GameObject instance, BaseCharacterConfig config, bool withSound, bool customLightActive, IJiggleScheduler jiggleScheduler) { }

}

