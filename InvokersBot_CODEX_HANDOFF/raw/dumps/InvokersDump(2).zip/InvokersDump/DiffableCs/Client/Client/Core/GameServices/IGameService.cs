namespace Client.Core.GameServices;

public interface IGameService
{

	public string ServiceName
	{
		 get { } //Length: 0
	}

	public bool SilentInitializationMode
	{
		 get { } //Length: 0
	}

	public string get_ServiceName() { }

	public bool get_SilentInitializationMode() { }

	public UniTask InitAsync() { }

	public void OnAppServicesInitialized() { }

}

