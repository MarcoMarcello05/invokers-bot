namespace Client.Animations.AnimStateHandlers;

public class ResetSkillHandler : StateMachineBehaviour
{

	public ResetSkillHandler() { }

	public virtual void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) { }

}

