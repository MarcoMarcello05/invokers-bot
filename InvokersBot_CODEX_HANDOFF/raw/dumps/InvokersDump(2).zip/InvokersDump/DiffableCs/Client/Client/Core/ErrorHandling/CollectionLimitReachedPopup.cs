namespace Client.Core.ErrorHandling;

public class CollectionLimitReachedPopup : BaseDialogView
{
	private const float MIN_VISIBLE_OVERFLOW_RATIO = 0,012; //Field offset: 0x0
	[SerializeField]
	private HZButton _dismissButton; //Field offset: 0x58
	[SerializeField]
	private HZButton _closeButton; //Field offset: 0x60
	[SerializeField]
	private TextMeshProUGUI _title; //Field offset: 0x68
	[SerializeField]
	private TextMeshProUGUI _description; //Field offset: 0x70
	[SerializeField]
	private TextMeshProUGUI _capacityCountLabel; //Field offset: 0x78
	[SerializeField]
	private TextMeshProUGUI _capacityStatusLabel; //Field offset: 0x80
	[SerializeField]
	private TextMeshProUGUI _requiredSlotsCountLabel; //Field offset: 0x88
	[SerializeField]
	private TextMeshProUGUI _requiredSlotsTitleLabel; //Field offset: 0x90
	[SerializeField]
	private TextMeshProUGUI _requiredSlotsLabel; //Field offset: 0x98
	[SerializeField]
	private Image _capacityFill; //Field offset: 0xA0
	[SerializeField]
	private Image _capacityOverflow; //Field offset: 0xA8

	public CollectionLimitReachedPopup() { }

	public void BindCloseButton(IButtonCommand command) { }

	public void BindDismissButton(IButtonCommand command) { }

	private void OnValidate() { }

	public void SetData(string title, string description, string capacityCountLabel, string capacityStatusLabel, string requiredSlotsCountLabel, string requiredSlotsTitleLabel, string requiredSlotsLabel, float retainedRatio, float overflowRatio) { }

	public void SetDismissButtonText(string text) { }

}

