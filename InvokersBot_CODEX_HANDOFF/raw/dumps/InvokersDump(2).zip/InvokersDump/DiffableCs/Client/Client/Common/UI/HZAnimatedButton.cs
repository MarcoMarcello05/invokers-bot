namespace Client.Common.UI;

public class HZAnimatedButton : HZButton
{
	[SerializeField]
	private HZAnimator _hzAnimator; //Field offset: 0x168
	[SerializeField]
	private bool _checkAnimatorActiveAndEnabled; //Field offset: 0x170
	private bool _lockedVisual; //Field offset: 0x171

	public HZAnimatedButton() { }

	protected virtual void DoStateTransition(SelectionState state, bool instant) { }

	private void PlayState(SelectionState state) { }

	public void SetLockedVisual(bool locked) { }

}

