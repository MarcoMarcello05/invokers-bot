namespace Client.Analytics;

public class PerflyticsHttpMessageHandler : DelegatingHandler
{
	[CompilerGenerated]
	private struct <SendAsync>d__2 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncTaskMethodBuilder<HttpResponseMessage> <>t__builder; //Field offset: 0x8
		public HttpRequestMessage request; //Field offset: 0x20
		public PerflyticsHttpMessageHandler <>4__this; //Field offset: 0x28
		public CancellationToken cancellationToken; //Field offset: 0x30
		private PerflyticsNetworkRequestScope <perflyticsActivity>5__2; //Field offset: 0x38
		private AutoScope <perfScope>5__3; //Field offset: 0x40
		private TaskAwaiter<HttpResponseMessage> <>u__1; //Field offset: 0x58

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity SendActivity; //Field offset: 0x0

	private static PerflyticsHttpMessageHandler() { }

	public PerflyticsHttpMessageHandler(HttpMessageHandler innerHandler) { }

	[CompilerGenerated]
	[DebuggerHidden]
	private Task<HttpResponseMessage> <>n__0(HttpRequestMessage request, CancellationToken cancellationToken) { }

	[AsyncStateMachine(typeof(<SendAsync>d__2))]
	protected virtual Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken) { }

}

