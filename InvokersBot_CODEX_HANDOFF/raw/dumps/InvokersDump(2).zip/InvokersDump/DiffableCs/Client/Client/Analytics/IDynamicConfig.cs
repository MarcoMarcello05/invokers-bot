namespace Client.Analytics;

public interface IDynamicConfig
{

	public bool IsInitialized
	{
		 get { } //Length: 0
	}

	public Observable<Unit> OnInitialized
	{
		 get { } //Length: 0
	}

	public IConfigValue<T> Get(string featureKey, T defaultValue) { }

	public bool get_IsInitialized() { }

	public Observable<Unit> get_OnInitialized() { }

}

