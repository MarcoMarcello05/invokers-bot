namespace Client.CharacterControllers;

public class HudRadialSkillsView : UIWidget
{
	[SerializeField]
	private UIContainer _container; //Field offset: 0x20
	[SerializeField]
	private CanvasGroup _canvasGroup; //Field offset: 0x28
	[SerializeField]
	private List<HudSkillCooldown> _hudSkillCooldowns; //Field offset: 0x30
	private List<HudSkillDescriptionTrigger> _skillDescriptionTriggers; //Field offset: 0x38

	public List<HudSkillCooldown> HudSkillCooldowns
	{
		 get { } //Length: 8
	}

	public int SkillsCount
	{
		 get { } //Length: 76
	}

	public HudRadialSkillsView() { }

	private void Awake() { }

	private void EnableSkillView() { }

	public List<HudSkillCooldown> get_HudSkillCooldowns() { }

	public int get_SkillsCount() { }

	private string GetControlPath(SkillType skillType, List<SkillTypeToControlPath> controlPaths) { }

	public void Hide() { }

	public void SetSkills(HudSkillData skills, List<SkillTypeToControlPath> controlPaths) { }

	public void Show() { }

}

