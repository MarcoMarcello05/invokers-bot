namespace Client.Analytics;

[Nullable(0)]
[NullableContext(1)]
public class PerflyticsNetworkRequestScope : IDisposable
{
	private const double DURATION_THRESHOLD_SEC = 1; //Field offset: 0x0
	[CompilerGenerated]
	private readonly string <RequestName>k__BackingField; //Field offset: 0x10
	private readonly bool _isEnabled; //Field offset: 0x18
	private readonly double _startTime; //Field offset: 0x20
	[Nullable(2)]
	private string _error; //Field offset: 0x28
	private readonly bool _isFirstTimeUser; //Field offset: 0x30
	[Nullable(2)]
	private readonly ISpan _sentrySpan; //Field offset: 0x38
	private readonly NetworkMeasurementToken _measurementToken; //Field offset: 0x40

	public string RequestName
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public PerflyticsNetworkRequestScope(string requestName, bool isFirstTimeUser, bool isEnabled = true, ISpan sentrySpan = null) { }

	public override void Dispose() { }

	public void Fail(string error) { }

	[CompilerGenerated]
	public string get_RequestName() { }

}

