namespace Client.Characters;

[DisallowMultipleComponent]
public sealed class CharacterMotionPart : MonoBehaviour, ICharacterViewPart
{
	[SerializeField]
	private DelayedFollow _delayedFollow; //Field offset: 0x20
	[SerializeField]
	private CharacterTilt _characterTilt; //Field offset: 0x28
	[SerializeField]
	private DelayedLowerBodyRotation[] _lowerBodyRotations; //Field offset: 0x30
	[SerializeField]
	private SmoothFollower[] _smoothFollowers; //Field offset: 0x38
	[SerializeField]
	private bool _overrideRotationTweaks; //Field offset: 0x40
	[SerializeField]
	private RotationTweaks _rotationTweaks; //Field offset: 0x48
	private Animator _animator; //Field offset: 0x50

	public CharacterTilt CharacterTilt
	{
		 get { } //Length: 8
	}

	public DelayedFollow DelayedFollow
	{
		 get { } //Length: 8
	}

	public DelayedLowerBodyRotation[] LowerBodyRotations
	{
		 get { } //Length: 8
	}

	public bool OverrideRotationTweaks
	{
		 get { } //Length: 8
	}

	public RotationTweaks RotationTweaks
	{
		 get { } //Length: 8
	}

	public SmoothFollower[] SmoothFollowers
	{
		 get { } //Length: 8
	}

	public CharacterMotionPart() { }

	private void Awake() { }

	public CharacterTilt get_CharacterTilt() { }

	public DelayedFollow get_DelayedFollow() { }

	public DelayedLowerBodyRotation[] get_LowerBodyRotations() { }

	public bool get_OverrideRotationTweaks() { }

	public RotationTweaks get_RotationTweaks() { }

	public SmoothFollower[] get_SmoothFollowers() { }

	private void OnAnimatorIK(int layerIndex) { }

	private void OnValidate() { }

	public override void ResetForReuse() { }

}

