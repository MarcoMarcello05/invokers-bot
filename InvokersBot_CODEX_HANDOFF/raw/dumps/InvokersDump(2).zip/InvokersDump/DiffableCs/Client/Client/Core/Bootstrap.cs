namespace Client.Core;

public class Bootstrap : MonoBehaviour, IBootstrap
{
	[CompilerGenerated]
	private struct <Start>d__41 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncVoidMethodBuilder <>t__builder; //Field offset: 0x8
		public Bootstrap <>4__this; //Field offset: 0x28
		private object <>7__wrap1; //Field offset: 0x30
		private int <>7__wrap2; //Field offset: 0x38
		private IDisposable <>7__wrap3; //Field offset: 0x40
		private Awaiter <>u__1; //Field offset: 0x48
		private Awaiter<DiskSpaceSnapshot> <>u__2; //Field offset: 0x58

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	public const string GAME_OBJECT_NAME = "Bootstrap"; //Field offset: 0x0
	public const string SCENE_NAME = "Bootstrap"; //Field offset: 0x0
	public const string SCENE_PATH = "Assets/Scenes/Bootstrap.unity"; //Field offset: 0x0
	[CompilerGenerated]
	private static IBootstrap <Instance>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private static bool <ManualFlowEnabledOnce>k__BackingField; //Field offset: 0x8
	private readonly ILogger _logger; //Field offset: 0x20
	[CompilerGenerated]
	private IGameStateManager <GameStateManager>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private IClientAnalytics <ClientAnalytics>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private IObjectResolver <ServiceProvider>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private IOptionsMonitor<ClientAppSettings> <ClientSettings>k__BackingField; //Field offset: 0x40
	private IDiskSpaceMonitor _diskSpaceMonitor; //Field offset: 0x48
	private ILocalizationBootstrap _localizationService; //Field offset: 0x50
	private IErrorDialogBuilder _errorDialogBuilder; //Field offset: 0x58
	private NetworkMonitorService _networkMonitorService; //Field offset: 0x60
	private AddressableAssetProvider _addressableAssetProvider; //Field offset: 0x68
	private IUISystem _uiSystem; //Field offset: 0x70
	private IPerformanceCaptureMask _performanceCaptureMask; //Field offset: 0x78
	private ISentryService _sentryService; //Field offset: 0x80
	private IIntegrityService _integrityService; //Field offset: 0x88

	public private override IClientAnalytics ClientAnalytics
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public private IOptionsMonitor<ClientAppSettings> ClientSettings
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public private override IGameStateManager GameStateManager
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public private static IBootstrap Instance
	{
		[CompilerGenerated]
		 get { } //Length: 72
		[CompilerGenerated]
		private set { } //Length: 88
	}

	public static bool ManualFlowEnabledOnce
	{
		[CompilerGenerated]
		 get { } //Length: 72
		[CompilerGenerated]
		 set { } //Length: 80
	}

	public private override IObjectResolver ServiceProvider
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public Bootstrap() { }

	private void Awake() { }

	[Inject]
	public void Construct(IGameStateManager gameStateManager, IObjectResolver serviceProvider, IOptionsMonitor<ClientAppSettings> clientSettings, IDiskSpaceMonitor diskSpaceMonitor, ILocalizationBootstrap localizationService, IErrorDialogBuilder errorDialogBuilder, NetworkMonitorService networkMonitorService, AddressableAssetProvider addressableAssetProvider, IUISystem uiSystem, IPerformanceCaptureMask performanceCaptureMask, IClientAnalytics clientAnalytics, ISentryService sentryService, IIntegrityService integrityService, OnScreenDeviceManager _) { }

	private void CopyStartupSessionInfoToClipboard() { }

	[CompilerGenerated]
	public override IClientAnalytics get_ClientAnalytics() { }

	[CompilerGenerated]
	public IOptionsMonitor<ClientAppSettings> get_ClientSettings() { }

	[CompilerGenerated]
	public override IGameStateManager get_GameStateManager() { }

	[CompilerGenerated]
	public static IBootstrap get_Instance() { }

	[CompilerGenerated]
	public static bool get_ManualFlowEnabledOnce() { }

	[CompilerGenerated]
	public override IObjectResolver get_ServiceProvider() { }

	public override Scene GetScene() { }

	private void OnDestroy() { }

	private void OnValidate() { }

	[CompilerGenerated]
	private void set_ClientAnalytics(IClientAnalytics value) { }

	[CompilerGenerated]
	private void set_ClientSettings(IOptionsMonitor<ClientAppSettings> value) { }

	[CompilerGenerated]
	private void set_GameStateManager(IGameStateManager value) { }

	[CompilerGenerated]
	private static void set_Instance(IBootstrap value) { }

	[CompilerGenerated]
	public static void set_ManualFlowEnabledOnce(bool value) { }

	[CompilerGenerated]
	private void set_ServiceProvider(IObjectResolver value) { }

	[AsyncStateMachine(typeof(<Start>d__41))]
	private void Start() { }

}

