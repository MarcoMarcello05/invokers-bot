namespace Client.Core;

public class AsyncOperationWithProgress : IAsyncOperationWithProgress, IOperationProgressObserver
{
	[CompilerGenerated]
	private struct <StartOperation>d__26 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public AsyncOperationWithProgress <>4__this; //Field offset: 0x18
		private IDisposable <perfScope>5__2; //Field offset: 0x20
		private AutoScope <_>5__3; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity AsyncOperationActivity; //Field offset: 0x0
	private readonly Func<IOperationProgressObserver, UniTask> _action; //Field offset: 0x10
	private readonly bool _sendAnalytics; //Field offset: 0x18
	private readonly UniTaskCompletionSource _completionSource; //Field offset: 0x20
	private readonly HashSet<IOperationProgressObserver> _progressObservers; //Field offset: 0x28
	private bool _isTaskStarted; //Field offset: 0x30
	private bool _isOperationActive; //Field offset: 0x31
	protected readonly ILogger Logger; //Field offset: 0x38
	private float _lastReportedProgress; //Field offset: 0x40
	[CompilerGenerated]
	private string <OperationId>k__BackingField; //Field offset: 0x48
	[CompilerGenerated]
	private float <ActiveOperationNormalizedProgress>k__BackingField; //Field offset: 0x50
	[CompilerGenerated]
	private string <ActiveOperationProgressText>k__BackingField; //Field offset: 0x58

	public float ActiveOperationNormalizedProgress
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string ActiveOperationProgressText
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public override UniTask CompletedTask
	{
		 get { } //Length: 24
	}

	public override string OperationId
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	private static AsyncOperationWithProgress() { }

	public AsyncOperationWithProgress(string operationId, Func<IOperationProgressObserver, UniTask> action, bool sendAnalytics = false) { }

	public override bool AttachProgressObserver(IOperationProgressObserver progressObserver) { }

	private override void Client.Core.IOperationProgressObserver.OnOperationFinished(string operationName) { }

	private override void Client.Core.IOperationProgressObserver.OnOperationProgressUpdate(float normalizedProgress, string progressText) { }

	private override void Client.Core.IOperationProgressObserver.OnOperationStarted(string operationName) { }

	public override UniTask ExecuteOperationAsync(IOperationProgressObserver progressObserver = null) { }

	[CompilerGenerated]
	public float get_ActiveOperationNormalizedProgress() { }

	[CompilerGenerated]
	public string get_ActiveOperationProgressText() { }

	public override UniTask get_CompletedTask() { }

	[CompilerGenerated]
	public override string get_OperationId() { }

	[CompilerGenerated]
	protected void set_ActiveOperationNormalizedProgress(float value) { }

	[CompilerGenerated]
	protected void set_ActiveOperationProgressText(string value) { }

	[CompilerGenerated]
	protected void set_OperationId(string value) { }

	[AsyncStateMachine(typeof(<StartOperation>d__26))]
	private UniTask StartOperation() { }

}

