namespace Client.CameraShake;

public class CameraShakeUpdateSystem : IViewSystem
{
	private const float SHAKE_INTERRUPT_TIME = 0,2; //Field offset: 0x0
	private const float MULTIPLIER = 0,1; //Field offset: 0x0
	private static readonly ILogger Log; //Field offset: 0x0
	private readonly SharedViewData _shared; //Field offset: 0x10
	private readonly CameraShakeViewDataPool _pool; //Field offset: 0x18

	private static CameraShakeUpdateSystem() { }

	public CameraShakeUpdateSystem(SharedViewData shared, CameraShakeViewDataPool pool) { }

	private void DisposeShakeInstance(List<CameraShakeViewData> shakes, int index) { }

	public override void Tick() { }

	private void TickShakes() { }

	private void UpdateShake(ref CameraShakeInstance shake, float deltaTime) { }

	private void UpdateZoom(ref CameraShakeInstance shake, float deltaTime) { }

}

