namespace Client.Configuration;

[Nullable(0)]
[NullableContext(1)]
public class EnvironmentVariablesConfigurationProvider : ConfigurationProvider
{
	private readonly string _prefix; //Field offset: 0x20
	private readonly string _normalizedPrefix; //Field offset: 0x28

	public EnvironmentVariablesConfigurationProvider() { }

	[NullableContext(2)]
	public EnvironmentVariablesConfigurationProvider(string prefix) { }

	private void AddIfNormalizedKeyMatchesPrefix(Dictionary<String, String> data, string normalizedKey, string value) { }

	public virtual void Load() { }

	internal void Load(IDictionary envVariables) { }

	private static string Normalize(string key) { }

	public virtual string ToString() { }

}

