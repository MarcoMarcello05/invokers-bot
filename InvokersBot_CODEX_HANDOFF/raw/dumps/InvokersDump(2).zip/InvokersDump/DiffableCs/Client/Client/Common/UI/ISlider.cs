namespace Client.Common.UI;

public interface ISlider
{

	public bool ActiveSelf
	{
		 get { } //Length: 0
		 set { } //Length: 0
	}

	public uint DebounceMs
	{
		 get { } //Length: 0
		 set { } //Length: 0
	}

	public bool Interactable
	{
		 get { } //Length: 0
		 set { } //Length: 0
	}

	public bool ShowSpinnerOnLongExecution
	{
		 get { } //Length: 0
		 set { } //Length: 0
	}

	public void Bind(IButtonCommand command) { }

	public bool get_ActiveSelf() { }

	public uint get_DebounceMs() { }

	public bool get_Interactable() { }

	public bool get_ShowSpinnerOnLongExecution() { }

	public void set_ActiveSelf(bool value) { }

	public void set_DebounceMs(uint value) { }

	public void set_Interactable(bool value) { }

	public void set_ShowSpinnerOnLongExecution(bool value) { }

}

