namespace Client.Core;

[Nullable(0)]
[NullableContext(1)]
public sealed class AsyncOperationSequence : BaseAsyncOperationGroup
{
	[CompilerGenerated]
	private struct <HandleAllOperation>d__5 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public AsyncOperationSequence <>4__this; //Field offset: 0x18
		[Nullable(0)]
		public IOperationProgressObserver observer; //Field offset: 0x20
		private AutoScope <_>5__2; //Field offset: 0x28
		private int <operationsCount>5__3; //Field offset: 0x40
		private int <i>5__4; //Field offset: 0x44
		private Awaiter <>u__1; //Field offset: 0x48

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ProcessOperationAsync>d__6 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public IAsyncOperationWithProgress operation; //Field offset: 0x18
		[Nullable(0)]
		public IOperationProgressObserver observer; //Field offset: 0x20
		[Nullable(0)]
		public AsyncOperationSequence <>4__this; //Field offset: 0x28
		[Nullable(0)]
		private Stopwatch <stopwatch>5__2; //Field offset: 0x30
		private Awaiter <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[Nullable(0)]
	private sealed class SequenceOperationProgressObserver : IOperationProgressObserver
	{
		private readonly IOperationProgressObserver _observer; //Field offset: 0x10
		private readonly string _operationIdPrefix; //Field offset: 0x18
		private readonly int _operationIndex; //Field offset: 0x20
		private readonly int _operationsCount; //Field offset: 0x24

		public SequenceOperationProgressObserver(IOperationProgressObserver observer, string operationIdPrefix, int operationIndex, int operationsCount) { }

		public override void OnOperationFinished(string operationName) { }

		public override void OnOperationProgressUpdate(float progress, string stepMsg) { }

		public override void OnOperationStarted(string operationName) { }

	}

	private static readonly Activity OpActivity; //Field offset: 0x0
	private readonly ILogger _logger; //Field offset: 0x20
	[Nullable(2)]
	private readonly Action _onComplete; //Field offset: 0x28

	private static AsyncOperationSequence() { }

	public AsyncOperationSequence(string operationId, Action onComplete = null) { }

	public static float CalculateTotalProgress(int currentIndex, float currentProgress, int totalOperations) { }

	[AsyncStateMachine(typeof(<HandleAllOperation>d__5))]
	protected virtual UniTask HandleAllOperation(IOperationProgressObserver observer) { }

	[AsyncStateMachine(typeof(<ProcessOperationAsync>d__6))]
	private UniTask ProcessOperationAsync(IAsyncOperationWithProgress operation, IOperationProgressObserver observer) { }

}

