namespace Client.Core;

public class AsyncLoadAsset : AsyncInitializableBase, IAssetHolder, IAsyncInitializable<TAsset>, IAsyncInitializable, IDisposable
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass18_0
	{
		public IOperationProgressObserver onProgressChange; //Field offset: 0x0

		public <>c__DisplayClass18_0() { }

		internal void <LoadAsync>g__OnStatusChanged|0(DownloadStatus downloadStatus) { }

	}

	[CompilerGenerated]
	private sealed class <get_RequiredAssets>d__15 : IEnumerable<AssetKey>, IEnumerable, IEnumerator<AssetKey>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private AssetKey <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		public AsyncLoadAsset<TAsset> <>4__this; //Field offset: 0x0

		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <get_RequiredAssets>d__15(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<AssetKey> System.Collections.Generic.IEnumerable<Client.AssetKey>.GetEnumerator() { }

		[DebuggerHidden]
		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private sealed class <InitFactory>d__17 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		public AsyncLoadAsset<TAsset> <>4__this; //Field offset: 0x0

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <InitFactory>d__17(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private struct <LoadAsync>d__18 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x0
		public IOperationProgressObserver onProgressChange; //Field offset: 0x0
		public AsyncLoadAsset<TAsset> <>4__this; //Field offset: 0x0
		private AutoScope <_>5__2; //Field offset: 0x0
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 0})]
		private Awaiter<IAssetRequest<TAsset>> <>u__1; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity AssetLoad; //Field offset: 0x0
	private static readonly ILogger Logger; //Field offset: 0x0
	private readonly AssetKey _assetKey; //Field offset: 0x0
	private readonly IContentManager _content; //Field offset: 0x0
	private readonly string _ownerCallerLabel; //Field offset: 0x0
	private readonly string _ownerCallerFilePath; //Field offset: 0x0
	private readonly int _ownerCallerLine; //Field offset: 0x0
	private IAssetRequest<TAsset> _assetRequest; //Field offset: 0x0
	[CompilerGenerated]
	private TAsset <Value>k__BackingField; //Field offset: 0x0

	public AssetKey AssetKey
	{
		 get { } //Length: 8
	}

	public override IEnumerable<AssetKey> RequiredAssets
	{
		[IteratorStateMachine(typeof(<get_RequiredAssets>d__15))]
		 get { } //Length: 124
	}

	public private override TAsset Value
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	private static AsyncLoadAsset`1() { }

	public AsyncLoadAsset`1(AssetKey assetKey, IContentManager content, string ownerLabelOverride = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	public AssetKey get_AssetKey() { }

	[IteratorStateMachine(typeof(<get_RequiredAssets>d__15))]
	public override IEnumerable<AssetKey> get_RequiredAssets() { }

	[CompilerGenerated]
	public override TAsset get_Value() { }

	[IteratorStateMachine(typeof(<InitFactory>d__17))]
	protected virtual IEnumerable<IAsyncOperationWithProgress> InitFactory() { }

	[AsyncStateMachine(typeof(<LoadAsync>d__18))]
	private UniTask LoadAsync(IOperationProgressObserver onProgressChange = null) { }

	[CompilerGenerated]
	private void set_Value(TAsset value) { }

}

