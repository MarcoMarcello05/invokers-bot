namespace Client.Authentication.GooglePlayGames;

[Nullable(0)]
[NullableContext(1)]
public sealed class GooglePlayGamesServerAuthCodeResult : IEquatable<GooglePlayGamesServerAuthCodeResult>
{
	[CompilerGenerated]
	private readonly GooglePlayGamesServerAuthCodeStatus <Status>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	[Nullable(2)]
	private readonly string <AuthCode>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly IReadOnlyList<GooglePlayGamesIdentityScope> <GrantedScopes>k__BackingField; //Field offset: 0x20

	[Nullable(2)]
	public string AuthCode
	{
		[CompilerGenerated]
		[NullableContext(2)]
		 get { } //Length: 8
		[CompilerGenerated]
		[NullableContext(2)]
		 set { } //Length: 8
	}

	[CompilerGenerated]
	private Type EqualityContract
	{
		[CompilerGenerated]
		private get { } //Length: 96
	}

	public IReadOnlyList<GooglePlayGamesIdentityScope> GrantedScopes
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public GooglePlayGamesServerAuthCodeStatus Status
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public GooglePlayGamesServerAuthCodeResult(GooglePlayGamesServerAuthCodeStatus Status, string AuthCode, IReadOnlyList<GooglePlayGamesIdentityScope> GrantedScopes) { }

	[CompilerGenerated]
	private GooglePlayGamesServerAuthCodeResult(GooglePlayGamesServerAuthCodeResult original) { }

	[CompilerGenerated]
	public GooglePlayGamesServerAuthCodeResult <Clone>$() { }

	[NullableContext(2)]
	public static GooglePlayGamesServerAuthCodeResult Create(GooglePlayGamesServerAuthCodeStatus status, string authCode = null, IReadOnlyList<GooglePlayGamesIdentityScope> grantedScopes = null) { }

	[CompilerGenerated]
	public void Deconstruct(out GooglePlayGamesServerAuthCodeStatus Status, out string AuthCode, out IReadOnlyList<GooglePlayGamesIdentityScope>& GrantedScopes) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public override bool Equals(GooglePlayGamesServerAuthCodeResult other) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public string get_AuthCode() { }

	[CompilerGenerated]
	private Type get_EqualityContract() { }

	[CompilerGenerated]
	public IReadOnlyList<GooglePlayGamesIdentityScope> get_GrantedScopes() { }

	[CompilerGenerated]
	public GooglePlayGamesServerAuthCodeStatus get_Status() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Equality(GooglePlayGamesServerAuthCodeResult left, GooglePlayGamesServerAuthCodeResult right) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Inequality(GooglePlayGamesServerAuthCodeResult left, GooglePlayGamesServerAuthCodeResult right) { }

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public void set_AuthCode(string value) { }

	[CompilerGenerated]
	public void set_GrantedScopes(IReadOnlyList<GooglePlayGamesIdentityScope> value) { }

	[CompilerGenerated]
	public void set_Status(GooglePlayGamesServerAuthCodeStatus value) { }

	[CompilerGenerated]
	public virtual string ToString() { }

}

