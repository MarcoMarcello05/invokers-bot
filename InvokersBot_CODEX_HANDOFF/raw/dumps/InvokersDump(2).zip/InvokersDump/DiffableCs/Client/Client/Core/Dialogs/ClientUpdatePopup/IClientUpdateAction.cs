namespace Client.Core.Dialogs.ClientUpdatePopup;

public interface IClientUpdateAction
{

	public UniTask ExecuteAsync() { }

}

