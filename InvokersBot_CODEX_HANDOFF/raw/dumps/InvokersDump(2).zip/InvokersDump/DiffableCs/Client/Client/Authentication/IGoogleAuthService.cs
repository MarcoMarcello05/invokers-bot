namespace Client.Authentication;

public interface IGoogleAuthService
{

	public Task<AuthenticationResult> Authenticate(CancellationToken cancellationToken = null) { }

}

