namespace Client.Characters;

public sealed class CharacterActions
{
	private readonly CharacterAnimationModule _animation; //Field offset: 0x10
	private readonly CharacterSoundModule _sound; //Field offset: 0x18

	public CharacterActions(CharacterAnimationModule animation, CharacterSoundModule sound) { }

	public void ComboAttack(SkillType skill, float speed = 1, bool force = false) { }

	public void Damage() { }

	public void Dash(bool enable) { }

	public void Death(bool enable, Nullable<Int32> deathAnimationNumber = null) { }

	public void EventCustom() { }

	public void Flinch() { }

	public void Freeze(bool enable) { }

	public void HandleAnimationEvent(CharacterAnimationEvent animationEvent) { }

	public void Hit() { }

	public void Idle(bool idleInEnabled = false) { }

	public void IdleHit() { }

	public void InteractBot(bool enable) { }

	public void InteractMid(bool enable) { }

	public void Launch(int phase) { }

	public void Move(bool run) { }

	public void Paralyze(bool enable) { }

	public void SetAnimatorSpeed(float speedMultiplier) { }

	public void SetCastAnimationTime(SkillType skill, float time) { }

	public void SetFullBodyFlinch(bool fullBody) { }

	public void SetTurnBlend(float weight) { }

	public void Shock(bool enable) { }

	public void Skill(SkillType skill, SkillPhase phase, float speed = 1) { }

	public void Sleep(bool enable) { }

	public void Step() { }

	public void Stun(bool enable) { }

}

