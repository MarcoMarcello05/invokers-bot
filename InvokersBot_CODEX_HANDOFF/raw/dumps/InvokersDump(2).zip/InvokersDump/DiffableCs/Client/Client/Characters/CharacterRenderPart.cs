namespace Client.Characters;

[DisallowMultipleComponent]
public sealed class CharacterRenderPart : MonoBehaviour, ICharacterViewPart
{
	private struct ShadowCaster
	{
		public SkinnedMeshRenderer Renderer; //Field offset: 0x0
		public ShadowCastingMode AuthoredMode; //Field offset: 0x8

	}

	[SerializeField]
	private ProjectiveShadowRuntime[] _projectiveShadows; //Field offset: 0x20
	[SerializeField]
	private BlobShadowRuntime _blobShadow; //Field offset: 0x28
	[SerializeField]
	private CharacterMaterialSwapper[] _materialSwappers; //Field offset: 0x30
	[SerializeField]
	private ShadowCaster[] _shadowCasters; //Field offset: 0x38
	[SerializeField]
	private Bounds _localBounds; //Field offset: 0x40
	private readonly CharacterMaterialInstances _materialInstances; //Field offset: 0x58
	[CompilerGenerated]
	private readonly StructList<CharacterMaterialDesc> <MaterialDescs>k__BackingField; //Field offset: 0x60

	public BlobShadowRuntime BlobShadow
	{
		 get { } //Length: 8
	}

	public Bounds LocalBounds
	{
		 get { } //Length: 20
	}

	public StructList<CharacterMaterialDesc> MaterialDescs
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public IReadOnlyList<CharacterMaterialSwapper> MaterialSwappers
	{
		 get { } //Length: 8
	}

	public ProjectiveShadowRuntime[] ProjectiveShadows
	{
		 get { } //Length: 8
	}

	public CharacterRenderPart() { }

	private void Awake() { }

	private void BuildMaterialDescs() { }

	private void EnsureMaterials() { }

	public BlobShadowRuntime get_BlobShadow() { }

	public Bounds get_LocalBounds() { }

	[CompilerGenerated]
	public StructList<CharacterMaterialDesc> get_MaterialDescs() { }

	public IReadOnlyList<CharacterMaterialSwapper> get_MaterialSwappers() { }

	public ProjectiveShadowRuntime[] get_ProjectiveShadows() { }

	private void OnDestroy() { }

	private void OnValidate() { }

	public override void ResetForReuse() { }

	public void SetMaterialVariant(int index) { }

	public void SetShadowCastingEnabled(bool enabled) { }

	private void SetupSwappers(in BattleCharacterMaterialPolicy policy) { }

}

