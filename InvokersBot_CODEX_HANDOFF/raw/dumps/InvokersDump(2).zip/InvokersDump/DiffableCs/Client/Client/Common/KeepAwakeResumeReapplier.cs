namespace Client.Common;

[UsedAsInjection]
public sealed class KeepAwakeResumeReapplier : IStartable, IDisposable
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<Boolean, Boolean> <>9__4_0; //Field offset: 0x8
		public static Action<Boolean, KeepAwakeResumeReapplier> <>9__4_1; //Field offset: 0x10

		private static <>c() { }

		public <>c() { }

		internal bool <Start>b__4_0(bool focused) { }

		internal void <Start>b__4_1(bool _, KeepAwakeResumeReapplier self) { }

	}

	private readonly IKeepAwakeManager _keepAwakeManager; //Field offset: 0x10
	private readonly IGameLifeCycleObserver _gameLifeCycleObserver; //Field offset: 0x18
	private IDisposable _subscription; //Field offset: 0x20

	public KeepAwakeResumeReapplier(IKeepAwakeManager keepAwakeManager, IGameLifeCycleObserver gameLifeCycleObserver) { }

	public override void Dispose() { }

	public override void Start() { }

}

