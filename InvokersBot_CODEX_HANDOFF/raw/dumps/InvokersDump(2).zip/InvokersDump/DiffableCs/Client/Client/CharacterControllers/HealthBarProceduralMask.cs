namespace Client.CharacterControllers;

[RequireComponent(typeof(CanvasRenderer))]
public class HealthBarProceduralMask : Graphic
{
	internal enum ShapeType : int
	{
		Angled = 0,
		CurvedPoint = 1,
	}

	[SerializeField]
	private ShapeType _shape; //Field offset: 0xA4
	[SerializeField]
	private float _capWidth; //Field offset: 0xA8
	[SerializeField]
	public RectOffset _padding; //Field offset: 0xB0
	[SerializeField]
	private int _cornerSegments; //Field offset: 0xB8
	[SerializeField]
	private float _curveIntensity; //Field offset: 0xBC

	public virtual Texture mainTexture
	{
		 get { } //Length: 8
	}

	public HealthBarProceduralMask() { }

	private Vector2 CalculateQuadraticBezierPoint(float t, Vector2 p0, Vector2 p1, Vector2 p2) { }

	public virtual Texture get_mainTexture() { }

	protected virtual void OnPopulateMesh(VertexHelper vh) { }

	private void PopulateAngledMesh(VertexHelper vh) { }

	private void PopulateCurvedPointMesh(VertexHelper vh) { }

}

