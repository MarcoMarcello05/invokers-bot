namespace Client;

[Extension]
[Nullable(0)]
[NullableContext(1)]
public static class ContentCachingExtensions
{

	[Extension]
	public static string FormatCacheSizes(IEnumerable<CacheSizeInfo> sizeInfos) { }

	[Extension]
	public static long GetTotalFreeBytes(IReadOnlyList<CacheSizeInfo> sizeInfos) { }

	[Extension]
	public static long GetTotalMaximumAvailableBytes(IReadOnlyList<CacheSizeInfo> sizeInfos) { }

	[Extension]
	public static long GetTotalOccupiedBytes(IReadOnlyList<CacheSizeInfo> sizeInfos) { }

}

