namespace Client.Common;

public static class UnityLayerIndices
{
	public static readonly int Default; //Field offset: 0x0
	public static readonly int Destructible; //Field offset: 0x4
	public static readonly int LevelCamera; //Field offset: 0x8
	public static readonly int ProjectiveDecals; //Field offset: 0xC
	public static readonly int Outline; //Field offset: 0x10
	public static readonly int Character; //Field offset: 0x14
	public static readonly int CharacterSilhouette; //Field offset: 0x18
	public static readonly int Ground; //Field offset: 0x1C
	public static readonly int Terrain; //Field offset: 0x20
	public static readonly int Blend; //Field offset: 0x24
	public static readonly int BlendGround; //Field offset: 0x28
	public static readonly int Ui; //Field offset: 0x2C
	public static readonly int FogPlanes; //Field offset: 0x30
	public static readonly int SilhouetteVfx; //Field offset: 0x34

	private static UnityLayerIndices() { }

}

