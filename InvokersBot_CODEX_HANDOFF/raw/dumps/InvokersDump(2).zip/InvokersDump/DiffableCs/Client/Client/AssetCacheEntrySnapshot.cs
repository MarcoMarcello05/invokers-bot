namespace Client;

[Nullable(0)]
[NullableContext(1)]
public sealed class AssetCacheEntrySnapshot : IEquatable<AssetCacheEntrySnapshot>
{
	[CompilerGenerated]
	private readonly AssetKey <Key>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly string <Status>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly Nullable<TimeSpan> <LoadTime>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private readonly string <DownloadStatus>k__BackingField; //Field offset: 0x30

	public string DownloadStatus
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	[CompilerGenerated]
	private Type EqualityContract
	{
		[CompilerGenerated]
		private get { } //Length: 96
	}

	public AssetKey Key
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public Nullable<TimeSpan> LoadTime
	{
		[CompilerGenerated]
		 get { } //Length: 12
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string Status
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public AssetCacheEntrySnapshot(AssetKey Key, string Status, Nullable<TimeSpan> LoadTime, string DownloadStatus) { }

	[CompilerGenerated]
	private AssetCacheEntrySnapshot(AssetCacheEntrySnapshot original) { }

	[CompilerGenerated]
	public AssetCacheEntrySnapshot <Clone>$() { }

	[CompilerGenerated]
	public void Deconstruct(out AssetKey Key, out string Status, out Nullable<TimeSpan>& LoadTime, out string DownloadStatus) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public override bool Equals(AssetCacheEntrySnapshot other) { }

	[CompilerGenerated]
	public string get_DownloadStatus() { }

	[CompilerGenerated]
	private Type get_EqualityContract() { }

	[CompilerGenerated]
	public AssetKey get_Key() { }

	[CompilerGenerated]
	public Nullable<TimeSpan> get_LoadTime() { }

	[CompilerGenerated]
	public string get_Status() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Equality(AssetCacheEntrySnapshot left, AssetCacheEntrySnapshot right) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Inequality(AssetCacheEntrySnapshot left, AssetCacheEntrySnapshot right) { }

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	public void set_DownloadStatus(string value) { }

	[CompilerGenerated]
	public void set_Key(AssetKey value) { }

	[CompilerGenerated]
	public void set_LoadTime(Nullable<TimeSpan> value) { }

	[CompilerGenerated]
	public void set_Status(string value) { }

	[CompilerGenerated]
	public virtual string ToString() { }

}

