namespace Client;

public class AssetKey : IEquatable<AssetKey>
{
	[CompilerGenerated]
	private readonly string <Address>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly string <Label>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly AssetReference <AssetReference>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private readonly IResourceLocation <ResourceLocation>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private readonly bool <HasGlobalLifetime>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private readonly AssetCacheGroup <CacheGroup>k__BackingField; //Field offset: 0x34

	public string Address
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public AssetReference AssetReference
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public AssetCacheGroup CacheGroup
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public object EditorAsset
	{
		 get { } //Length: 8
	}

	public bool HasGlobalLifetime
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string Label
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public IResourceLocation ResourceLocation
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public object Value
	{
		 get { } //Length: 156
	}

	public AssetKey() { }

	public virtual bool Equals(object obj) { }

	public override bool Equals(AssetKey other) { }

	public static AssetKey FromAddress(string address, AssetCacheGroup group = 0, bool hasGlobalLifetime = false) { }

	public static AssetKey FromAddress(string address, string label, AssetCacheGroup group = 0, bool hasGlobalLifetime = false) { }

	public static AssetKey FromLabel(string label) { }

	public static AssetKey FromLocation(IResourceLocation location, AssetCacheGroup group = 0, bool hasGlobalLifetime = false) { }

	public static AssetKey FromReference(AssetReference reference, AssetCacheGroup group = 0, bool hasGlobalLifetime = false) { }

	[CompilerGenerated]
	public string get_Address() { }

	[CompilerGenerated]
	public AssetReference get_AssetReference() { }

	[CompilerGenerated]
	public AssetCacheGroup get_CacheGroup() { }

	public object get_EditorAsset() { }

	[CompilerGenerated]
	public bool get_HasGlobalLifetime() { }

	[CompilerGenerated]
	public string get_Label() { }

	[CompilerGenerated]
	public IResourceLocation get_ResourceLocation() { }

	public object get_Value() { }

	public virtual int GetHashCode() { }

	private bool IsEmpty() { }

	public static bool op_Equality(AssetKey left, AssetKey right) { }

	public static bool op_Inequality(AssetKey left, AssetKey right) { }

	[CompilerGenerated]
	public void set_Address(string value) { }

	[CompilerGenerated]
	public void set_AssetReference(AssetReference value) { }

	[CompilerGenerated]
	public void set_CacheGroup(AssetCacheGroup value) { }

	[CompilerGenerated]
	public void set_HasGlobalLifetime(bool value) { }

	[CompilerGenerated]
	public void set_Label(string value) { }

	[CompilerGenerated]
	public void set_ResourceLocation(IResourceLocation value) { }

	public virtual string ToString() { }

}

