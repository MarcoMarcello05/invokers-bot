namespace Client.Core.Dialogs.ClientUpdatePopup;

[UsedAsInjection]
public sealed class SoftUpdateDialogController : HardUpdateDialogController
{
	private readonly ILastSeenStorage _lastSeenStorage; //Field offset: 0xB8

	public SoftUpdateDialogController(IUISystem uiSystem, IContentManager content, IStagingContainer stagingContainer, ButtonCommandBuilder buttonCommandBuilder, InMemoryLastSeenStorage lastSeenStorage, ILauncherClient launcherClient, ApplicationExitController applicationExitController) { }

	[CompilerGenerated]
	private ValueTask <OnViewLoaded>b__2_0() { }

	protected virtual void OnViewLoaded() { }

}

