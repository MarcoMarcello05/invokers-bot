namespace Client.Core.ErrorHandling;

[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
[NullableContext(1)]
public sealed class OfflineModeEnabledPopupController : AwaitableDialogController<IOfflineModeEnabledPopup>
{
	private readonly IContentManager _content; //Field offset: 0x88
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x90
	private readonly OfflineModeWarning _warning; //Field offset: 0x98

	public OfflineModeEnabledPopupController(IContentManager content, IStagingContainer stagingContainer, IUISystem uiSystem, OfflineModeWarning warning) { }

	[CompilerGenerated]
	private void <OnViewLoaded>b__5_0(Unit _) { }

	protected virtual void OnViewLoaded() { }

	protected virtual IAsyncInitializable<IOfflineModeEnabledPopup> ViewFactory() { }

}

