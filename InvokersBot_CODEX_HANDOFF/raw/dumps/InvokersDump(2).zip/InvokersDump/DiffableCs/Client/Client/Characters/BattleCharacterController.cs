namespace Client.Characters;

public sealed class BattleCharacterController : CharacterControllerBase
{
	private static readonly StructList<CharacterMaterialDesc> NoMaterials; //Field offset: 0x0
	[CompilerGenerated]
	private readonly AnimaSwapModule <AnimaSwap>k__BackingField; //Field offset: 0x58
	[CompilerGenerated]
	private ModelEntity <ModelEntity>k__BackingField; //Field offset: 0x60
	[CompilerGenerated]
	private CharacterRigPart <Rig>k__BackingField; //Field offset: 0x70
	[CompilerGenerated]
	private CharacterRenderPart <Render>k__BackingField; //Field offset: 0x78
	[CompilerGenerated]
	private CharacterMotionPart <Motion>k__BackingField; //Field offset: 0x80

	public AnimaSwapModule AnimaSwap
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public BlobShadowRuntime BlobShadow
	{
		 get { } //Length: 128
	}

	public GameObject GameObject
	{
		 get { } //Length: 24
	}

	public Bounds LocalBounds
	{
		 get { } //Length: 156
	}

	public StructList<CharacterMaterialDesc> MaterialDescs
	{
		 get { } //Length: 172
	}

	public private ModelEntity ModelEntity
	{
		[CompilerGenerated]
		 get { } //Length: 12
		[CompilerGenerated]
		private set { } //Length: 20
	}

	public private CharacterMotionPart Motion
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public private CharacterRenderPart Render
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public private CharacterRigPart Rig
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public Transform Root
	{
		 get { } //Length: 24
	}

	public Transform RootBone
	{
		 get { } //Length: 128
	}

	public SocketProvider SocketProvider
	{
		 get { } //Length: 128
	}

	private static BattleCharacterController() { }

	public BattleCharacterController(IJiggleScheduler jiggleScheduler) { }

	public void EnableShadows(bool enable) { }

	[CompilerGenerated]
	public AnimaSwapModule get_AnimaSwap() { }

	public BlobShadowRuntime get_BlobShadow() { }

	public GameObject get_GameObject() { }

	public Bounds get_LocalBounds() { }

	public StructList<CharacterMaterialDesc> get_MaterialDescs() { }

	[CompilerGenerated]
	public ModelEntity get_ModelEntity() { }

	[CompilerGenerated]
	public CharacterMotionPart get_Motion() { }

	[CompilerGenerated]
	public CharacterRenderPart get_Render() { }

	[CompilerGenerated]
	public CharacterRigPart get_Rig() { }

	public Transform get_Root() { }

	public Transform get_RootBone() { }

	public SocketProvider get_SocketProvider() { }

	public void Initialize(in ModelEntity modelEntity, CharacterStaticData staticData) { }

	protected virtual void OnBound() { }

	protected virtual void OnUnbinding() { }

	[CompilerGenerated]
	private void set_ModelEntity(ModelEntity value) { }

	[CompilerGenerated]
	private void set_Motion(CharacterMotionPart value) { }

	[CompilerGenerated]
	private void set_Render(CharacterRenderPart value) { }

	[CompilerGenerated]
	private void set_Rig(CharacterRigPart value) { }

	public void SetMaterialVariant(int index) { }

}

