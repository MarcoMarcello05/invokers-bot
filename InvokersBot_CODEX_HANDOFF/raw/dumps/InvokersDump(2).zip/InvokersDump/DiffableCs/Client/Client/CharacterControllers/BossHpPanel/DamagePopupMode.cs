namespace Client.CharacterControllers.BossHpPanel;

public enum DamagePopupMode : int
{
	Normal = 0,
	Counter = 1,
}

