namespace Client.Configuration;

[Nullable(0)]
[NullableContext(1)]
public class AbExperimentsConfigurationSource : IConfigurationSource
{
	[CompilerGenerated]
	private readonly IAbExperimentService <AbExperimentService>k__BackingField; //Field offset: 0x10

	public IAbExperimentService AbExperimentService
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public AbExperimentsConfigurationSource(IAbExperimentService service) { }

	public override IConfigurationProvider Build(IConfigurationBuilder builder) { }

	[CompilerGenerated]
	public IAbExperimentService get_AbExperimentService() { }

}

