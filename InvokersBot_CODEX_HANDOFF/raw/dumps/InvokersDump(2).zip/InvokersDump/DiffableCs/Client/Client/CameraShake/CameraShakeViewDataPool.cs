namespace Client.CameraShake;

public class CameraShakeViewDataPool : IDisposable
{
	private readonly Stack<CameraShakeViewData> _pool; //Field offset: 0x10

	public CameraShakeViewDataPool() { }

	public override void Dispose() { }

	public CameraShakeViewData Rent() { }

	public void Return(CameraShakeViewData d) { }

}

