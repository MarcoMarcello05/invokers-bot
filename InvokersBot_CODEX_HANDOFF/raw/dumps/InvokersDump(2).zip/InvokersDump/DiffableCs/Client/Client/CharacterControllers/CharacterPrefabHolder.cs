namespace Client.CharacterControllers;

public class CharacterPrefabHolder : ScriptableObject
{
	public GameObject Prefab; //Field offset: 0x18

	public CharacterPrefabHolder() { }

	public GameObject GetPrefab() { }

}

