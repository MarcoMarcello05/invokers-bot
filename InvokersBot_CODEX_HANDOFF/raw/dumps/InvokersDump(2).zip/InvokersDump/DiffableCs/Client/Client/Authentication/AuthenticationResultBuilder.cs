namespace Client.Authentication;

[Nullable(0)]
[NullableContext(1)]
public class AuthenticationResultBuilder
{
	private AuthenticationStatus _status; //Field offset: 0x10
	private readonly AuthenticationError _error; //Field offset: 0x18

	public AuthenticationResultBuilder() { }

	public AuthenticationResultBuilder AsDeveloperFault() { }

	public AuthenticationResultBuilder AsUserFault() { }

	public AuthenticationResult Build() { }

	public AuthenticationResultBuilder Fail() { }

	public AuthenticationResultBuilder UserCancelled() { }

	public AuthenticationResultBuilder WithDebugMessage(string debugMessage) { }

	public AuthenticationResultBuilder WithErrorCode(string code) { }

	public AuthenticationResultBuilder WithErrorMessage(string message) { }

	public AuthenticationResultBuilder WithException(Exception ex) { }

	public AuthenticationResultBuilder WithStatus(AuthenticationStatus status) { }

	public AuthenticationResultBuilder WithSuggestion(string suggestion) { }

}

