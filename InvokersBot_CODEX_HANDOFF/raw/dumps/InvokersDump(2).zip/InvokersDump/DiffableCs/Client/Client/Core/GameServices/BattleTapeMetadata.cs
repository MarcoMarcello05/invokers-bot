namespace Client.Core.GameServices;

[MemoryPackable(GenerateType::Object (0))]
public class BattleTapeMetadata : IMemoryPackable<BattleTapeMetadata>, IMemoryPackFormatterRegister, IEquatable<BattleTapeMetadata>
{
	[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
	[NullableContext(1)]
	[Preserve]
	private sealed class BattleTapeMetadataFormatter : MemoryPackFormatter<BattleTapeMetadata>
	{

		public BattleTapeMetadataFormatter() { }

		[Preserve]
		public virtual void Deserialize(ref MemoryPackReader reader, ref BattleTapeMetadata value) { }

		[Preserve]
		public virtual void Serialize(ref MemoryPackWriter<TBufferWriter>& writer, ref BattleTapeMetadata value) { }

	}

	[CompilerGenerated]
	private readonly Guid <TapeId>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly string <SharedVersion>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private readonly string <ConfigVersion>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private readonly DateTime <StartTime>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private readonly BattleResultType <ResultType>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private readonly int <DurationSeconds>k__BackingField; //Field offset: 0x3C
	[CompilerGenerated]
	private readonly long <LevelId>k__BackingField; //Field offset: 0x40
	[CompilerGenerated]
	private readonly BattleTapeHeroSnapshot[] <Heroes>k__BackingField; //Field offset: 0x48
	[CompilerGenerated]
	private readonly ArenaLeagueId <ArenaLeagueId>k__BackingField; //Field offset: 0x50

	public ArenaLeagueId ArenaLeagueId
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string ConfigVersion
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public int DurationSeconds
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	[CompilerGenerated]
	[Nullable(1)]
	protected override Type EqualityContract
	{
		[CompilerGenerated]
		[NullableContext(1)]
		 get { } //Length: 96
	}

	public BattleTapeHeroSnapshot[] Heroes
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public long LevelId
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public BattleResultType ResultType
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string SharedVersion
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public DateTime StartTime
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public Guid TapeId
	{
		[CompilerGenerated]
		 get { } //Length: 12
		[CompilerGenerated]
		 set { } //Length: 8
	}

	private static BattleTapeMetadata() { }

	public BattleTapeMetadata(Guid TapeId, string SharedVersion, string ConfigVersion, DateTime StartTime, BattleResultType ResultType, int DurationSeconds, long LevelId, BattleTapeHeroSnapshot[] Heroes, ArenaLeagueId ArenaLeagueId) { }

	[CompilerGenerated]
	protected BattleTapeMetadata(BattleTapeMetadata original) { }

	[CompilerGenerated]
	[NullableContext(1)]
	public override BattleTapeMetadata <Clone>$() { }

	[CompilerGenerated]
	public void Deconstruct(out Guid TapeId, out string SharedVersion, out string ConfigVersion, out DateTime StartTime, out BattleResultType ResultType, out int DurationSeconds, out long LevelId, out BattleTapeHeroSnapshot[] Heroes, out ArenaLeagueId ArenaLeagueId) { }

	[NullableContext(2)]
	[Preserve]
	public static void Deserialize(ref MemoryPackReader reader, ref BattleTapeMetadata value) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public override bool Equals(BattleTapeMetadata other) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	public ArenaLeagueId get_ArenaLeagueId() { }

	[CompilerGenerated]
	public string get_ConfigVersion() { }

	[CompilerGenerated]
	public int get_DurationSeconds() { }

	[CompilerGenerated]
	[NullableContext(1)]
	protected override Type get_EqualityContract() { }

	[CompilerGenerated]
	public BattleTapeHeroSnapshot[] get_Heroes() { }

	[CompilerGenerated]
	public long get_LevelId() { }

	[CompilerGenerated]
	public BattleResultType get_ResultType() { }

	[CompilerGenerated]
	public string get_SharedVersion() { }

	[CompilerGenerated]
	public DateTime get_StartTime() { }

	[CompilerGenerated]
	public Guid get_TapeId() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Equality(BattleTapeMetadata left, BattleTapeMetadata right) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Inequality(BattleTapeMetadata left, BattleTapeMetadata right) { }

	[CompilerGenerated]
	[NullableContext(1)]
	protected override bool PrintMembers(StringBuilder builder) { }

	[Preserve]
	public static void RegisterFormatter() { }

	[NullableContext(1)]
	[Preserve]
	public static void Serialize(ref MemoryPackWriter<TBufferWriter>& writer, ref BattleTapeMetadata value) { }

	[CompilerGenerated]
	public void set_ArenaLeagueId(ArenaLeagueId value) { }

	[CompilerGenerated]
	public void set_ConfigVersion(string value) { }

	[CompilerGenerated]
	public void set_DurationSeconds(int value) { }

	[CompilerGenerated]
	public void set_Heroes(BattleTapeHeroSnapshot[] value) { }

	[CompilerGenerated]
	public void set_LevelId(long value) { }

	[CompilerGenerated]
	public void set_ResultType(BattleResultType value) { }

	[CompilerGenerated]
	public void set_SharedVersion(string value) { }

	[CompilerGenerated]
	public void set_StartTime(DateTime value) { }

	[CompilerGenerated]
	public void set_TapeId(Guid value) { }

	[CompilerGenerated]
	[NullableContext(1)]
	public virtual string ToString() { }

}

