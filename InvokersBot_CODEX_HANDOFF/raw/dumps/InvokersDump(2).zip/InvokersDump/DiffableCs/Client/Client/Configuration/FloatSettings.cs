namespace Client.Configuration;

public class FloatSettings : SettingsValue<Single>
{
	private IDeviceStorage _localDeviceStorage; //Field offset: 0x20

	public FloatSettings(string key, string rootKey, float defaultValue) { }

	public virtual float GetValue() { }

	public virtual void SetValue(float value) { }

}

