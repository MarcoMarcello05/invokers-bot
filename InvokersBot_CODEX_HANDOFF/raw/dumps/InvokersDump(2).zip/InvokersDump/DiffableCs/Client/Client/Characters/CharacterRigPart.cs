namespace Client.Characters;

[DisallowMultipleComponent]
public sealed class CharacterRigPart : MonoBehaviour, ICharacterViewPart
{
	[SerializeField]
	private Transform _rootBone; //Field offset: 0x20
	[SerializeField]
	private SocketProvider _socketProvider; //Field offset: 0x28

	public Transform RootBone
	{
		 get { } //Length: 8
	}

	public SocketProvider SocketProvider
	{
		 get { } //Length: 8
	}

	public CharacterRigPart() { }

	public Transform get_RootBone() { }

	public SocketProvider get_SocketProvider() { }

	private void OnValidate() { }

	public override void ResetForReuse() { }

}

