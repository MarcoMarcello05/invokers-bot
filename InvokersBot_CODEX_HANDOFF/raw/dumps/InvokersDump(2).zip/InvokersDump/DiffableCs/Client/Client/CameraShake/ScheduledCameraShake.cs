namespace Client.CameraShake;

public struct ScheduledCameraShake
{
	public long ShakePresetId; //Field offset: 0x0
	public float TimeLeft; //Field offset: 0x8
	public ModelEntity ProducerEntity; //Field offset: 0x10
	public bool ForSelectedCharacterOnly; //Field offset: 0x20
	public float ShiftInTime; //Field offset: 0x24
	public float ShiftOutTime; //Field offset: 0x28
	public float SpeedFactor; //Field offset: 0x2C

	public bool TimeHasCome
	{
		 get { } //Length: 16
	}

	public bool get_TimeHasCome() { }

	public virtual string ToString() { }

}

