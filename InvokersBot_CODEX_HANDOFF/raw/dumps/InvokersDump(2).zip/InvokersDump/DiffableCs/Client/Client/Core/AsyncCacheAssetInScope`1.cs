namespace Client.Core;

public class AsyncCacheAssetInScope : AsyncInitializableBase, IAssetHolder, IAsyncInitializable<TAsset>, IAsyncInitializable, IDisposable
{
	[CompilerGenerated]
	private struct <CacheAssetInScopeAsync>d__14 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x0
		public AsyncCacheAssetInScope<TAsset> <>4__this; //Field offset: 0x0
		private AutoScope <_>5__2; //Field offset: 0x0
		[Nullable(new IL2CPP_TYPE_U1[] {0, 2})]
		private Awaiter<TAsset> <>u__1; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private sealed class <get_RequiredAssets>d__11 : IEnumerable<AssetKey>, IEnumerable, IEnumerator<AssetKey>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private AssetKey <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		public AsyncCacheAssetInScope<TAsset> <>4__this; //Field offset: 0x0

		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <get_RequiredAssets>d__11(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<AssetKey> System.Collections.Generic.IEnumerable<Client.AssetKey>.GetEnumerator() { }

		[DebuggerHidden]
		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private sealed class <InitFactory>d__13 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		public AsyncCacheAssetInScope<TAsset> <>4__this; //Field offset: 0x0

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <InitFactory>d__13(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	private static readonly Activity CacheAssetInScope; //Field offset: 0x0
	private readonly AssetKey _assetKey; //Field offset: 0x0
	private readonly IScopedAssetProvider _scopedAssetProvider; //Field offset: 0x0
	private readonly string _ownerCallerMemberName; //Field offset: 0x0
	private readonly string _ownerCallerFilePath; //Field offset: 0x0
	private readonly int _ownerCallerLine; //Field offset: 0x0
	[CompilerGenerated]
	private TAsset <Value>k__BackingField; //Field offset: 0x0

	public override IEnumerable<AssetKey> RequiredAssets
	{
		[IteratorStateMachine(typeof(<get_RequiredAssets>d__11))]
		 get { } //Length: 124
	}

	public private override TAsset Value
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	private static AsyncCacheAssetInScope`1() { }

	public AsyncCacheAssetInScope`1(AssetKey assetKey, IScopedAssetProvider scopedAssetProvider, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	[AsyncStateMachine(typeof(<CacheAssetInScopeAsync>d__14))]
	private UniTask CacheAssetInScopeAsync(IOperationProgressObserver onProgressChange = null) { }

	[IteratorStateMachine(typeof(<get_RequiredAssets>d__11))]
	public override IEnumerable<AssetKey> get_RequiredAssets() { }

	[CompilerGenerated]
	public override TAsset get_Value() { }

	[IteratorStateMachine(typeof(<InitFactory>d__13))]
	protected virtual IEnumerable<IAsyncOperationWithProgress> InitFactory() { }

	[CompilerGenerated]
	private void set_Value(TAsset value) { }

}

