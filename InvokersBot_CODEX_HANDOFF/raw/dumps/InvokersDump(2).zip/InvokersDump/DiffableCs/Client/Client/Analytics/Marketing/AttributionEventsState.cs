namespace Client.Analytics.Marketing;

[MemoryPackable(GenerateType::VersionTolerant (1))]
[Nullable(0)]
[NullableContext(1)]
internal sealed class AttributionEventsState : IMemoryPackable<AttributionEventsState>, IMemoryPackFormatterRegister
{
	[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
	[Preserve]
	private sealed class AttributionEventsStateFormatter : MemoryPackFormatter<AttributionEventsState>
	{

		public AttributionEventsStateFormatter() { }

		[Preserve]
		public virtual void Deserialize(ref MemoryPackReader reader, ref AttributionEventsState value) { }

		[Preserve]
		public virtual void Serialize(ref MemoryPackWriter<TBufferWriter>& writer, ref AttributionEventsState value) { }

	}

	[CompilerGenerated]
	private HashSet<String> <TriggeredEvents>k__BackingField; //Field offset: 0x10

	public HashSet<String> TriggeredEvents
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	private static AttributionEventsState() { }

	public AttributionEventsState() { }

	[NullableContext(2)]
	[Preserve]
	public static void Deserialize(ref MemoryPackReader reader, ref AttributionEventsState value) { }

	[CompilerGenerated]
	public HashSet<String> get_TriggeredEvents() { }

	[Preserve]
	public static void RegisterFormatter() { }

	[Preserve]
	public static void Serialize(ref MemoryPackWriter<TBufferWriter>& writer, ref AttributionEventsState value) { }

	[CompilerGenerated]
	public void set_TriggeredEvents(HashSet<String> value) { }

}

