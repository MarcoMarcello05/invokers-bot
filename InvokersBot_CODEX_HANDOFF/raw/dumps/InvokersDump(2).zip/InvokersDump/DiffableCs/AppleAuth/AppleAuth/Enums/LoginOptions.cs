namespace AppleAuth.Enums;

[Flags]
public enum LoginOptions : int
{
	None = 0,
	IncludeFullName = 1,
	IncludeEmail = 2,
}

