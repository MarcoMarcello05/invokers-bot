namespace Client.Analytics;

public class PerflyticsGrpcFilter : IClientFilter
{
	[CompilerGenerated]
	private struct <SendAsync>d__1 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder<ResponseContext> <>t__builder; //Field offset: 0x8
		public RequestContext context; //Field offset: 0x30
		public Func<RequestContext, ValueTask`1<ResponseContext>> next; //Field offset: 0x38
		private PerflyticsNetworkRequestScope <perflyticsActivity>5__2; //Field offset: 0x40
		private AutoScope <perfScope>5__3; //Field offset: 0x48
		private ValueTaskAwaiter<ResponseContext> <>u__1; //Field offset: 0x60

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity GrpcActivity; //Field offset: 0x0

	private static PerflyticsGrpcFilter() { }

	public PerflyticsGrpcFilter() { }

	[AsyncStateMachine(typeof(<SendAsync>d__1))]
	public override ValueTask<ResponseContext> SendAsync(RequestContext context, Func<RequestContext, ValueTask`1<ResponseContext>> next) { }

}

