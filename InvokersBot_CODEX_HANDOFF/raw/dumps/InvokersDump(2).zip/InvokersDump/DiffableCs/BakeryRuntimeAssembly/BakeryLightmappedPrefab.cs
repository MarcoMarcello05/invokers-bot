//Type is in global namespace

[DisallowMultipleComponent]
[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Lightmapped_Prefab")]
public class BakeryLightmappedPrefab : MonoBehaviour
{

	public BakeryLightmappedPrefab() { }

}

