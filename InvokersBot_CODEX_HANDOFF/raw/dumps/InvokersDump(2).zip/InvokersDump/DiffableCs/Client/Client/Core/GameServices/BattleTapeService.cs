namespace Client.Core.GameServices;

[UsedAsInjection]
public class BattleTapeService : IGameService, IBattleTapeStore
{
	[CompilerGenerated]
	private struct <StartPlaybackAsync>d__31 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public BattleTapeService <>4__this; //Field offset: 0x18
		public IGameStateManager gameStateManager; //Field offset: 0x20
		public long levelId; //Field offset: 0x28
		public MetaBattleSetup metaBattleSetup; //Field offset: 0x30
		private Awaiter <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	public const string DirectoryName = "BattleTapeService"; //Field offset: 0x0
	public const string MetadataFolderName = "metadata"; //Field offset: 0x0
	public const string TapeFolderName = "tape"; //Field offset: 0x0
	private const int MaxBattleTapesCount = 50; //Field offset: 0x0
	private const int MaxBattleTapesCountLowDisk = 5; //Field offset: 0x0
	private readonly ILogger _logger; //Field offset: 0x10
	private readonly ChoreographManager _choreographManager; //Field offset: 0x18
	private readonly IPlayerSessionState _playerSessionState; //Field offset: 0x20
	private readonly IDiskSpaceMonitor _diskSpaceMonitor; //Field offset: 0x28
	private readonly object _fileLock; //Field offset: 0x30
	private FinishLevelBattleAction _scheduledTape; //Field offset: 0x38
	[CompilerGenerated]
	private bool <IsPlaybackRequested>k__BackingField; //Field offset: 0x40

	private int ActiveTapeLimit
	{
		private get { } //Length: 196
	}

	public private bool IsPlaybackRequested
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public override string ServiceName
	{
		 get { } //Length: 64
	}

	public override bool SilentInitializationMode
	{
		 get { } //Length: 8
	}

	public BattleTapeService(ChoreographManager choreographManager, IPlayerSessionState playerSessionState, IDiskSpaceMonitor diskSpaceMonitor) { }

	private void ApplyTapeLimit(List<BattleTapeMetadata> sortedEntries, ValueTuple<String, String> storageDirectories) { }

	private static BattleTapeHeroSnapshot[] BuildHeroSnapshots(MetaBattleSetup battleSetup) { }

	private static int CompareByStartTimeDescending(BattleTapeMetadata left, BattleTapeMetadata right) { }

	public FinishLevelBattleAction ConsumeScheduledTape() { }

	private BattleTapeMetadata CreateMetadata(FinishLevelBattleAction tape, ArenaLeagueId arenaLeagueId) { }

	private void DeleteLegacyStorageDirectory(string folderName) { }

	private int get_ActiveTapeLimit() { }

	[CompilerGenerated]
	public bool get_IsPlaybackRequested() { }

	public override string get_ServiceName() { }

	public override bool get_SilentInitializationMode() { }

	public IReadOnlyList<BattleTapeMetadata> GetMetadata() { }

	private static string GetMetadataFilePath(string metadataDirectoryPath, Guid tapeId) { }

	private string GetProfileId() { }

	internal ValueTuple<String, String> GetStorageDirectories() { }

	private static string GetTapeFilePath(string tapeDirectoryPath, Guid tapeId) { }

	public override UniTask InitAsync() { }

	private static bool IsSupportedBattleResult(FinishLevelBattleAction tape) { }

	private static bool IsVersionMismatch(BattleTapeMetadata metadata, string currentSharedVersion, string currentConfigVersion) { }

	private List<BattleTapeMetadata> ReadMetadataEntries(ValueTuple<String, String> storageDirectories) { }

	private List<BattleTapeMetadata> ReadSortedMetadataEntries(ValueTuple<String, String> storageDirectories) { }

	[CompilerGenerated]
	private void set_IsPlaybackRequested(bool value) { }

	[AsyncStateMachine(typeof(<StartPlaybackAsync>d__31))]
	private UniTask StartPlaybackAsync(IGameStateManager gameStateManager, long levelId, MetaBattleSetup metaBattleSetup) { }

	public override void Store(FinishLevelBattleAction tape) { }

	private static FinishLevelBattleAction TrimTape(FinishLevelBattleAction tape) { }

	private void TryDeleteBothFiles(ValueTuple<String, String> storageDirectories, string fileName) { }

	public bool TryGetBattleResult(Guid tapeId, out BattleResult battleResult) { }

	public bool TryGetScheduledTape(out FinishLevelBattleAction tape) { }

	private bool TryPrepareMetaBattleSetup(FinishLevelBattleAction tape, out long levelId, out MetaBattleSetup metaBattleSetup) { }

	private bool TryReadTape(Guid tapeId, out FinishLevelBattleAction tape) { }

	public bool TryScheduleTape(Guid tapeId) { }

	public bool TryStartPlayback(IGameStateManager gameStateManager, Guid tapeId) { }

	private void WriteMetadataFile(Guid tapeId, BattleTapeMetadata metadata, string metadataDirectoryPath) { }

	private void WriteTapeFile(Guid tapeId, FinishLevelBattleAction trimmedTape, string tapeDirectoryPath) { }

}

