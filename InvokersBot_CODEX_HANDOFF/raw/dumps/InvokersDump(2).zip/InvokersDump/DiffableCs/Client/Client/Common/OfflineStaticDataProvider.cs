namespace Client.Common;

[UsedAsInjection]
public sealed class OfflineStaticDataProvider : IStaticDataProvider, IDisposable, IActiveStaticDataCache
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass8_0
	{
		public CompositeStaticData staticData; //Field offset: 0x10
		public CompositeStaticData sourceData; //Field offset: 0x18

		public <>c__DisplayClass8_0() { }

		internal CompositeStaticData <LoadAndActivateAsync>b__0() { }

	}

	[CompilerGenerated]
	private struct <LoadAndActivateAsync>d__8 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public string version; //Field offset: 0x28
		public OfflineStaticDataProvider <>4__this; //Field offset: 0x30
		public CancellationToken ct; //Field offset: 0x38
		private <>c__DisplayClass8_0 <>8__1; //Field offset: 0x40
		private TaskAwaiter<CompositeStaticData> <>u__1; //Field offset: 0x48
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private ValueTaskAwaiter<CompositeStaticData> <>u__2; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static ILogger Logger; //Field offset: 0x0
	private readonly StaticDataStorage _staticDataStorage; //Field offset: 0x10
	private CompositeStaticData _compositeStaticData; //Field offset: 0x18

	public override CompositeStaticData Data
	{
		 get { } //Length: 8
	}

	private static OfflineStaticDataProvider() { }

	public OfflineStaticDataProvider() { }

	public override void ClearActiveStaticData() { }

	public override void ClearCache() { }

	public override void Dispose() { }

	public override CompositeStaticData get_Data() { }

	public override string GetDefaultVersion(string version) { }

	public override bool HasVersion(string version) { }

	[AsyncStateMachine(typeof(<LoadAndActivateAsync>d__8))]
	public override ValueTask LoadAndActivateAsync(string version, string configUrl, CancellationToken ct = null) { }

	private static string SelectDefaultEmbeddedVersion(String[] versions) { }

	public void SetCompositeData(CompositeStaticData compositeData) { }

	public override void StartPrefetchIfNeeded(string version, string configUrl) { }

}

