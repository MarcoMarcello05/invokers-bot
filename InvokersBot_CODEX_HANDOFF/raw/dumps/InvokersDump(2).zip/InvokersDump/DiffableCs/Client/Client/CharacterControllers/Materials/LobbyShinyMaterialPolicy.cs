namespace Client.CharacterControllers.Materials;

public struct LobbyShinyMaterialPolicy : ICharacterMaterialPolicy
{
	private const string ALPHA_TEST_KEYWORD = "ALPHA_TEST"; //Field offset: 0x0
	private static readonly HashSet<String> SupportedShaderNames; //Field offset: 0x0
	private readonly Shader _shinyShader; //Field offset: 0x0

	private static LobbyShinyMaterialPolicy() { }

	public LobbyShinyMaterialPolicy(Shader shinyShader) { }

	public override void Configure(Material clone, Material source) { }

	private static bool IsBlocked(SkinnedMeshRenderer renderer) { }

	public override bool ShouldConvert(SkinnedMeshRenderer renderer) { }

	public override bool ShouldConvert(Material source) { }

}

