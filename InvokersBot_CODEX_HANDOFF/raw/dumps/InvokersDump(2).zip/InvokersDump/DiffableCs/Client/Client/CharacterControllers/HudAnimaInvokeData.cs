namespace Client.CharacterControllers;

public class HudAnimaInvokeData
{
	public string LocalizationKey; //Field offset: 0x10
	public int SkillLevel; //Field offset: 0x18
	public Sprite Icon; //Field offset: 0x20
	public SkillConfig AnimaInConfig; //Field offset: 0x28
	public SkillConfig AnimaOutConfig; //Field offset: 0x30
	public AnimaStats AnimaStats; //Field offset: 0x38
	public int Level; //Field offset: 0x40
	public int Rank; //Field offset: 0x44
	public int Priority; //Field offset: 0x48
	public IReadOnlyDictionary<Int64, CustomStatusEffectPresentation> CustomStatusEffectPresentations; //Field offset: 0x50

	public HudAnimaInvokeData() { }

}

