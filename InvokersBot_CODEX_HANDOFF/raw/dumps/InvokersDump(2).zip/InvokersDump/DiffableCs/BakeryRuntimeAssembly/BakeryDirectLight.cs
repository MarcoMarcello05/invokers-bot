//Type is in global namespace

[DisallowMultipleComponent]
[ExecuteInEditMode]
[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Direct_Light")]
public class BakeryDirectLight : MonoBehaviour
{
	public static int lightsChanged; //Field offset: 0x0
	private static GameObject objShownError; //Field offset: 0x8
	public Color color; //Field offset: 0x20
	public float intensity; //Field offset: 0x30
	public float shadowSpread; //Field offset: 0x34
	public int samples; //Field offset: 0x38
	public int bitmask; //Field offset: 0x3C
	public bool bakeToIndirect; //Field offset: 0x40
	public bool shadowmask; //Field offset: 0x41
	public bool shadowmaskDenoise; //Field offset: 0x42
	public float indirectIntensity; //Field offset: 0x44
	public Texture2D cloudShadow; //Field offset: 0x48
	public float cloudShadowTilingX; //Field offset: 0x50
	public float cloudShadowTilingY; //Field offset: 0x54
	public float cloudShadowOffsetX; //Field offset: 0x58
	public float cloudShadowOffsetY; //Field offset: 0x5C
	public bool supersample; //Field offset: 0x60
	public int UID; //Field offset: 0x64

	public BakeryDirectLight() { }

}

