namespace Client.Core;

[Nullable(0)]
[NullableContext(1)]
public class DelegatingOperationProgressObserver : IOperationProgressObserver
{
	[Nullable(new IL2CPP_TYPE_U1[] {2, 1})]
	private readonly Action<String> _onOperationStarted; //Field offset: 0x10
	[Nullable(new IL2CPP_TYPE_U1[] {2, 1})]
	private readonly Action<String> _onOperationFinished; //Field offset: 0x18
	[Nullable(new IL2CPP_TYPE_U1[] {2, 1})]
	private readonly Action<Single, String> _onProgressChange; //Field offset: 0x20

	public DelegatingOperationProgressObserver(Action<String> onOperationStarted = null, Action<String> onOperationFinished = null, Action<Single, String> onProgressChange = null) { }

	public override void OnOperationFinished(string operationName) { }

	public override void OnOperationProgressUpdate(float progress, string stepMsg) { }

	public override void OnOperationStarted(string operationName) { }

}

