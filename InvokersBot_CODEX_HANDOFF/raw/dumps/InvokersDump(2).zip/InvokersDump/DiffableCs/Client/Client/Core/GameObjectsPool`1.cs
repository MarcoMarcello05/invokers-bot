namespace Client.Core;

public abstract class GameObjectsPool : AsyncInitializableBase, IObjectsPool<T>
{
	[CompilerGenerated]
	private sealed class <InitFactory>d__13 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		public GameObjectsPool<T> <>4__this; //Field offset: 0x0

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <InitFactory>d__13(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private struct <RentAsync>d__9 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder<T> <>t__builder; //Field offset: 0x0
		public GameObjectsPool<T> <>4__this; //Field offset: 0x0
		public T prefab; //Field offset: 0x0
		private Awaiter<T> <>u__1; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <WarmUp>d__15 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x0
		public GameObjectsPool<T> <>4__this; //Field offset: 0x0
		public T prefab; //Field offset: 0x0
		public int count; //Field offset: 0x0
		private AutoScope <_>5__2; //Field offset: 0x0
		private Awaiter<T[]> <>u__1; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity WarmUpActivity; //Field offset: 0x0
	private static readonly ILogger Logger; //Field offset: 0x0
	private readonly Dictionary<T, List`1<T>> _instances; //Field offset: 0x0
	private readonly Transform _container; //Field offset: 0x0
	private bool _disposed; //Field offset: 0x0

	protected IReadOnlyDictionary<T, List`1<T>> Instances
	{
		 get { } //Length: 8
	}

	protected abstract IEnumerable<AssetKey> RequiredAssets
	{
		 get { } //Length: 0
	}

	private static GameObjectsPool`1() { }

	protected GameObjectsPool`1(string containerName, IBootstrap bootstrap) { }

	private static void DestroyInstances(T[] instances) { }

	protected virtual void DisposeInternal() { }

	protected IReadOnlyDictionary<T, List`1<T>> get_Instances() { }

	protected abstract IEnumerable<AssetKey> get_RequiredAssets() { }

	private T GetFromPool(T prefab) { }

	protected override int GetMaxCachedInstances(T prefab) { }

	protected int GetSize() { }

	protected abstract UniTask Init(IOperationProgressObserver onProgressChange) { }

	[IteratorStateMachine(typeof(<InitFactory>d__13))]
	protected virtual IEnumerable<IAsyncOperationWithProgress> InitFactory() { }

	private void MoveToPool(T instance) { }

	public override T Rent(T prefab) { }

	[AsyncStateMachine(typeof(<RentAsync>d__9))]
	public override UniTask<T> RentAsync(T prefab) { }

	public override void Return(T instance) { }

	private static void SafeDestroy(GameObject go) { }

	[Conditional("UNITY_EDITOR")]
	private void UpdateContainerDebugName() { }

	[AsyncStateMachine(typeof(<WarmUp>d__15))]
	protected UniTask WarmUp(T prefab, int count) { }

}

