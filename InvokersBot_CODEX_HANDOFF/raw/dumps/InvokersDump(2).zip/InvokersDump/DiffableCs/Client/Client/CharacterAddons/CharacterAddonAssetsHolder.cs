namespace Client.CharacterAddons;

public sealed class CharacterAddonAssetsHolder : ScriptableObject, ILocalizationKeyProvider
{
	[SerializeField]
	private Sprite _icon; //Field offset: 0x18
	[SerializeField]
	private LevelLootFx _lootVisualization; //Field offset: 0x20
	[SerializeField]
	private LevelLootFx _lootFx; //Field offset: 0x28
	[SerializeField]
	private List<BlockVfxSlot> _scriptVfxs; //Field offset: 0x30
	[SerializeField]
	private CharacterAddonHudPresentation _hudPresentation; //Field offset: 0x38

	public CharacterAddonHudPresentation HudPresentation
	{
		 get { } //Length: 8
	}

	public Sprite Icon
	{
		 get { } //Length: 8
	}

	public LevelLootFx LootFx
	{
		 get { } //Length: 8
	}

	public LevelLootFx LootVisualization
	{
		 get { } //Length: 8
	}

	public List<BlockVfxSlot> ScriptVfxs
	{
		 get { } //Length: 8
	}

	public CharacterAddonAssetsHolder() { }

	public CharacterAddonHudPresentation get_HudPresentation() { }

	public Sprite get_Icon() { }

	public LevelLootFx get_LootFx() { }

	public LevelLootFx get_LootVisualization() { }

	public List<BlockVfxSlot> get_ScriptVfxs() { }

	public override Dictionary<String, String> GetLocalizationKeys() { }

}

