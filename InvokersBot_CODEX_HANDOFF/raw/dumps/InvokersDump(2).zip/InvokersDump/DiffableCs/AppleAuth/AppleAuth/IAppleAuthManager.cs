namespace AppleAuth;

public interface IAppleAuthManager
{

	public void LoginWithAppleId(AppleAuthLoginArgs loginArgs, Action<ICredential> successCallback, Action<IAppleError> errorCallback) { }

	public void Update() { }

}

