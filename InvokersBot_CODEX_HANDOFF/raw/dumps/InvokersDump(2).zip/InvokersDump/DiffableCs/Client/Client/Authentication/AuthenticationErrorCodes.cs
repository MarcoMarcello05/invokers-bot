namespace Client.Authentication;

public static class AuthenticationErrorCodes
{
	[Nullable(1)]
	public const string INVALID_PARAMETERS_CONFIGURATION = "invalid_parameters_configuration"; //Field offset: 0x0

}

