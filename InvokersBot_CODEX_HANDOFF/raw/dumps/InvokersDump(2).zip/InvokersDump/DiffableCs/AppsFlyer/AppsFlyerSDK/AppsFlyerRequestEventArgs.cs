namespace AppsFlyerSDK;

public class AppsFlyerRequestEventArgs : EventArgs
{
	[CompilerGenerated]
	private readonly int <statusCode>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly string <errorDescription>k__BackingField; //Field offset: 0x18

	public string errorDescription
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public int statusCode
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public AppsFlyerRequestEventArgs(int code, string description) { }

	[CompilerGenerated]
	public string get_errorDescription() { }

	[CompilerGenerated]
	public int get_statusCode() { }

}

