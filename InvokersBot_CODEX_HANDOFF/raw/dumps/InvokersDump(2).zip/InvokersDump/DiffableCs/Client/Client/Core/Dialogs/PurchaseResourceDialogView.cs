namespace Client.Core.Dialogs;

public class PurchaseResourceDialogView : BaseDialogView
{
	[SerializeField]
	private HZButton _closeButton; //Field offset: 0x58
	[SerializeField]
	private HZButton _backgroundCloseButton; //Field offset: 0x60
	[SerializeField]
	private HZButton _okButton; //Field offset: 0x68
	[SerializeField]
	private HZButton _buyButton; //Field offset: 0x70
	[SerializeField]
	private ResourcePanelOptionsHolder _resourcePanelOptionsHolder; //Field offset: 0x78
	[SerializeField]
	private GameItemHolderView _packIconHolder; //Field offset: 0x80
	[SerializeField]
	private string _fallbackPackIconId; //Field offset: 0x88
	[SerializeField]
	private TextMeshProUGUI _descriptionText; //Field offset: 0x90
	[SerializeField]
	private TextMeshProUGUI _priceLabel; //Field offset: 0x98
	[SerializeField]
	private TextMeshProUGUI _amountLabel; //Field offset: 0xA0
	[SerializeField]
	private GameObject _baseContent; //Field offset: 0xA8
	[SerializeField]
	private GameObject _noPackContent; //Field offset: 0xB0
	[SerializeField]
	private List<GameObject> _normalStateElements; //Field offset: 0xB8
	[SerializeField]
	private List<GameObject> _notEnoughStateElements; //Field offset: 0xC0

	public HZButton BuyButton
	{
		 get { } //Length: 8
	}

	public HZButton CloseButton
	{
		 get { } //Length: 8
	}

	public string FallbackPackIconId
	{
		 get { } //Length: 8
	}

	public HZButton OkButton
	{
		 get { } //Length: 8
	}

	public GameItemHolderView PackIconHolder
	{
		 get { } //Length: 8
	}

	public ResourcePanelOptions ResourcePanelOptions
	{
		 get { } //Length: 24
	}

	public PurchaseResourceDialogView() { }

	public void BindCloseButton(IButtonCommand closeCommand) { }

	public HZButton get_BuyButton() { }

	public HZButton get_CloseButton() { }

	public string get_FallbackPackIconId() { }

	public HZButton get_OkButton() { }

	public GameItemHolderView get_PackIconHolder() { }

	public ResourcePanelOptions get_ResourcePanelOptions() { }

	private void OnValidate() { }

	public void SetupNoPack() { }

	public void SetupPack(string iconResourceId, PackPrice price, int amount, ResourceTypeId resourceType) { }

	public void SetupState(bool isNotEnoughResources) { }

}

