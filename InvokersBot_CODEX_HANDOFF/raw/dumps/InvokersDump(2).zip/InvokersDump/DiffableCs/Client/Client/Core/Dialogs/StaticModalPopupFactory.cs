namespace Client.Core.Dialogs;

[UsedAsInjection]
public class StaticModalPopupFactory
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass8_0
	{
		public string headerText; //Field offset: 0x10
		public string descriptionText; //Field offset: 0x18
		public string confirmButtonText; //Field offset: 0x20
		public bool showCancelButton; //Field offset: 0x28
		public bool showCloseControls; //Field offset: 0x29
		public StaticModalPopupFactory <>4__this; //Field offset: 0x30
		public UniTaskCompletionSource<Boolean> tcs; //Field offset: 0x38
		public string cancelButtonText; //Field offset: 0x40

		public <>c__DisplayClass8_0() { }

		internal void <CreatePopupAndAskForConfirmationAsync>b__0(StaticModalPopupController controller, StaticModalPopup popup) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass8_1
	{
		private struct <<CreatePopupAndAskForConfirmationAsync>b__1>d : IAsyncStateMachine
		{
			public int <>1__state; //Field offset: 0x0
			public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
			public <>c__DisplayClass8_1 <>4__this; //Field offset: 0x28
			private Awaiter <>u__1; //Field offset: 0x30

			private override void MoveNext() { }

			[DebuggerHidden]
			private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

		}

		private struct <<CreatePopupAndAskForConfirmationAsync>b__2>d : IAsyncStateMachine
		{
			public int <>1__state; //Field offset: 0x0
			public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
			public <>c__DisplayClass8_1 <>4__this; //Field offset: 0x28
			private Awaiter <>u__1; //Field offset: 0x30

			private override void MoveNext() { }

			[DebuggerHidden]
			private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

		}

		public StaticModalPopupController controller; //Field offset: 0x10
		public <>c__DisplayClass8_0 CS$<>8__locals1; //Field offset: 0x18

		public <>c__DisplayClass8_1() { }

		[AsyncStateMachine(typeof(<<CreatePopupAndAskForConfirmationAsync>b__1>d))]
		internal ValueTask <CreatePopupAndAskForConfirmationAsync>b__1() { }

		[AsyncStateMachine(typeof(<<CreatePopupAndAskForConfirmationAsync>b__2>d))]
		internal ValueTask <CreatePopupAndAskForConfirmationAsync>b__2() { }

	}

	[CompilerGenerated]
	private struct <CreatePopupAndAskForConfirmationAsync>d__8 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder<Boolean> <>t__builder; //Field offset: 0x8
		public string headerText; //Field offset: 0x20
		public string descriptionText; //Field offset: 0x28
		public string confirmButtonText; //Field offset: 0x30
		public bool showCancelButton; //Field offset: 0x38
		public bool showCloseControls; //Field offset: 0x39
		public StaticModalPopupFactory <>4__this; //Field offset: 0x40
		public string cancelButtonText; //Field offset: 0x48
		public AssetKey viewPrefab; //Field offset: 0x50
		private <>c__DisplayClass8_0 <>8__1; //Field offset: 0x58
		private Awaiter <>u__1; //Field offset: 0x60
		private Awaiter<Boolean> <>u__2; //Field offset: 0x70

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ShowPopupWithSpinnerAsync>d__6 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public StaticModalPopupFactory <>4__this; //Field offset: 0x18
		public AssetKey viewPrefab; //Field offset: 0x20
		public Action<StaticModalPopupController, StaticModalPopup> configurePopup; //Field offset: 0x28
		public ILoadingScreenService loadingScreenService; //Field offset: 0x30
		private StaticModalPopupController <popupController>5__2; //Field offset: 0x38
		private Awaiter <>u__1; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IContentManager _content; //Field offset: 0x10
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x18
	private readonly IUISystem _uiSystem; //Field offset: 0x20
	private readonly ButtonCommandBuilder _buttonCommandBuilder; //Field offset: 0x28

	public StaticModalPopupFactory(IContentManager content, IStagingContainer stagingContainer, IUISystem uiSystem, ButtonCommandBuilder buttonCommandBuilder) { }

	public StaticModalPopupController CreatePopup(AssetKey viewPrefab, Action<StaticModalPopupController, StaticModalPopup> configurePopup) { }

	public UniTask<Boolean> CreatePopupAndAskForConfirmationAsync(string headerText, string descriptionText, string confirmButtonText = null, string cancelButtonText = null, bool showCloseControls = true) { }

	[AsyncStateMachine(typeof(<CreatePopupAndAskForConfirmationAsync>d__8))]
	public UniTask<Boolean> CreatePopupAndAskForConfirmationAsync(AssetKey viewPrefab, string headerText, string descriptionText, string confirmButtonText, string cancelButtonText, bool showCloseControls = true, bool showCancelButton = true) { }

	[AsyncStateMachine(typeof(<ShowPopupWithSpinnerAsync>d__6))]
	public UniTask ShowPopupWithSpinnerAsync(AssetKey viewPrefab, Action<StaticModalPopupController, StaticModalPopup> configurePopup, ILoadingScreenService loadingScreenService) { }

}

