namespace Client.Configuration;

public class PlayerPrefsConfigurationSource : IConfigurationSource
{
	[CompilerGenerated]
	private readonly string <PrefixKey>k__BackingField; //Field offset: 0x10

	public string PrefixKey
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public PlayerPrefsConfigurationSource(string prefixKey) { }

	public override IConfigurationProvider Build(IConfigurationBuilder builder) { }

	[CompilerGenerated]
	public string get_PrefixKey() { }

}

