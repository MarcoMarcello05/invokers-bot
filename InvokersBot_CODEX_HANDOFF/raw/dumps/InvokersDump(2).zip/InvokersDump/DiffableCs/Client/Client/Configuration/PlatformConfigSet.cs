namespace Client.Configuration;

public struct PlatformConfigSet
{
	public readonly List<PlatformConfigEntry> Entries; //Field offset: 0x0
	public readonly QualityTier DeviceQualityTier; //Field offset: 0x8

	public PlatformConfigSet(List<PlatformConfigEntry> entries, QualityTier deviceQualityTier) { }

}

