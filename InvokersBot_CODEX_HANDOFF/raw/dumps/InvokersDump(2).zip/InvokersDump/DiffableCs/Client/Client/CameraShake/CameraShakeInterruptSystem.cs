namespace Client.CameraShake;

public class CameraShakeInterruptSystem : IViewSystem
{
	private static readonly ILogger Log; //Field offset: 0x0
	private readonly SharedViewData _shared; //Field offset: 0x10
	private readonly CameraShakeViewDataPool _pool; //Field offset: 0x18

	private static CameraShakeInterruptSystem() { }

	public CameraShakeInterruptSystem(SharedViewData shared, CameraShakeViewDataPool pool) { }

	private void InterruptShakeInstance(List<CameraShakeViewData> shakes, CameraShakeViewData data, int index) { }

	public override void Tick() { }

}

