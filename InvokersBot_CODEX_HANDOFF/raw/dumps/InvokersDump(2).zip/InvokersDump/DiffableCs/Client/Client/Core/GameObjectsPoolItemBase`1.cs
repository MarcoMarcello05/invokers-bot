namespace Client.Core;

public class GameObjectsPoolItemBase
{
	private IObjectsPool<T> _ownerPool; //Field offset: 0x0
	private T _self; //Field offset: 0x0
	[CompilerGenerated]
	private T <Template>k__BackingField; //Field offset: 0x0

	public private T Template
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public GameObjectsPoolItemBase`1() { }

	[CompilerGenerated]
	public T get_Template() { }

	public void OnInitialize(IObjectsPool<T> ownerPool, T template, T self) { }

	public void OnReset() { }

	public void ReturnToPool() { }

	[CompilerGenerated]
	private void set_Template(T value) { }

}

