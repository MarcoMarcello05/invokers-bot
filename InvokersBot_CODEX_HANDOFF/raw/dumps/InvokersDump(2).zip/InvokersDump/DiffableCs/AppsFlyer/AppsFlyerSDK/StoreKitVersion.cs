namespace AppsFlyerSDK;

public enum StoreKitVersion : int
{
	SK1 = 0,
	SK2 = 1,
}

