namespace Client.Configuration;

public struct PlatformConfigEntry
{
	public readonly string ConfigName; //Field offset: 0x0
	public readonly ConfigContribution Contribution; //Field offset: 0x8

	public PlatformConfigEntry(string configName, ConfigContribution contribution) { }

}

