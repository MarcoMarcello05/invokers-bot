namespace Client.Battle;

public class BattleMemoryContainer
{
	[CompilerGenerated]
	private BattleMemory <Memory>k__BackingField; //Field offset: 0x10
	private readonly ILogger _logger; //Field offset: 0x18

	public private BattleMemory Memory
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public BattleMemoryContainer() { }

	[CompilerGenerated]
	public BattleMemory get_Memory() { }

	public void Init() { }

	[CompilerGenerated]
	private void set_Memory(BattleMemory value) { }

}

