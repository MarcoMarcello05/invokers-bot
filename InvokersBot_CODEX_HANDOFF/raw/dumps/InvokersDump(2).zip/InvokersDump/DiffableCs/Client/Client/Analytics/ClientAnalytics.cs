namespace Client.Analytics;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public class ClientAnalytics : IClientAnalytics, IDisposable
{
	[CompilerGenerated]
	private struct <FlushAsync>d__20 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ClientAnalytics <>4__this; //Field offset: 0x20
		public bool clearUndelivered; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly ILogger Logger; //Field offset: 0x0
	private static readonly Queue<IClientBiEvent> PendingEvents; //Field offset: 0x8
	[Nullable(2)]
	private static ClientAnalytics s_instance; //Field offset: 0x10
	private static bool s_queueEnabled; //Field offset: 0x18
	private static int _eventSessionSeq; //Field offset: 0x1C
	[Nullable(2)]
	private static string _eventSessionId; //Field offset: 0x20
	private readonly Subject<ClientUIActionEventData> _beforeAnalyticsTrack; //Field offset: 0x10
	private readonly FirebaseService _firebaseService; //Field offset: 0x18
	private readonly AttributionService _attributionService; //Field offset: 0x20
	private readonly AnalyticEventRouter _eventRouter; //Field offset: 0x28
	private readonly AnalyticEventsServerSink _serverEventsSink; //Field offset: 0x30
	private readonly AnalyticEventsStore _serverEventsStore; //Field offset: 0x38
	private readonly ITimeProvider _timeProvider; //Field offset: 0x40
	private float _lastLogTime; //Field offset: 0x48

	public override Observable<ClientUIActionEventData> OnBeforeAnalyticsTrack
	{
		 get { } //Length: 8
	}

	private static ClientAnalytics() { }

	public ClientAnalytics(FirebaseService firebaseService, AttributionService attributionService, AnalyticEventRouter eventRouter, AnalyticEventsServerSink serverEventsSink, AnalyticEventsStore serverEventsStore, ITimeProvider timeProvider) { }

	public static CommonEventParams ApplyDefaultEnrichment() { }

	public override void Dispose() { }

	[AsyncStateMachine(typeof(<FlushAsync>d__20))]
	public override Task FlushAsync(bool clearUndelivered = false) { }

	private static void FlushPendingEvents() { }

	public override Observable<ClientUIActionEventData> get_OnBeforeAnalyticsTrack() { }

	private static bool IsQueueEnabled(ClientAppSettings settings) { }

	public override void Log(IClientBiEvent biEvent) { }

	private static void LogDroppedBiEvent(IClientBiEvent biEvent) { }

	internal static void LogOrQueue(IClientBiEvent biEvent) { }

	public override void LogUIButtonClick(UserUIActionEventType eventType, string buttonName, SortedDictionary<String, String> parameters = null) { }

	public static IDisposable MeasureFirstTimeUserPerformance(string operationName, string category) { }

	public static PerflyticsNetworkRequestScope MeasureNetworkRequest(string requestName) { }

	private void OnLowMemoryHandler() { }

	private override IDisposable Shared.Choreograph.Analytics.IClientAnalytics.MeasureFirstTimeUserPerformance(string operationName, string category) { }

	private static void UpdateQueueEnabled(ClientAppSettings settings) { }

}

