namespace Client.BackgroundDownloading;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public sealed class BackgroundDownloadingService : IBackgroundDownloadingService, IGameService, IDisposable
{
	[CompilerGenerated]
	private sealed class <>c
	{
		[Nullable(0)]
		public static readonly <>c <>9; //Field offset: 0x0
		[Nullable(0)]
		public static Func<BackgroundDownloadingService, Boolean> <>9__71_0; //Field offset: 0x8
		[Nullable(0)]
		public static Func<BackgroundDownloadingService, Boolean> <>9__72_0; //Field offset: 0x10

		private static <>c() { }

		public <>c() { }

		[NullableContext(0)]
		internal bool <QueueProcessingCycle>b__71_0(BackgroundDownloadingService self) { }

		[NullableContext(0)]
		internal bool <WaitForClearUnusedBundlesCache>b__72_0(BackgroundDownloadingService self) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass48_0
	{
		public ActiveDownload activeDownload; //Field offset: 0x10

		public <>c__DisplayClass48_0() { }

		internal bool <GetDebugSnapshot>b__0(AsyncOperationHandle handle) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass68_0
	{
		[Nullable(0)]
		public BackgroundDownloadingService <>4__this; //Field offset: 0x10
		[Nullable(0)]
		public CancellationTokenSource debugDownloadCts; //Field offset: 0x18

		public <>c__DisplayClass68_0() { }

		internal void <RunDebugDownloadAsync>b__0(DownloadStatus status) { }

	}

	[CompilerGenerated]
	private struct <>c__DisplayClass73_0
	{
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		public HashSet<String> visitedBundles; //Field offset: 0x0
		public long totalRemoteBytes; //Field offset: 0x8
		public long totalDownloadedBytes; //Field offset: 0x10

	}

	[CompilerGenerated]
	private struct <DoPotentialConnectionCheck>d__84 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public BackgroundDownloadingService <>4__this; //Field offset: 0x18
		public CancellationToken ct; //Field offset: 0x20
		[Nullable(0)]
		private TaskAwaiter<Boolean> <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <DownloadAllBundles>d__63 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public BackgroundDownloadingService <>4__this; //Field offset: 0x18
		[Nullable(0)]
		private Stopwatch <sw>5__2; //Field offset: 0x20
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private List<AssetKey> <keys>5__3; //Field offset: 0x28
		private long <requiredToDownloadSize>5__4; //Field offset: 0x30
		[Nullable(0)]
		private Awaiter<Int64> <>u__1; //Field offset: 0x38
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private Awaiter<AssetListDownloadRequest> <>u__2; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <DownloadAllQueue>d__61 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public BackgroundDownloadingService <>4__this; //Field offset: 0x18
		[Nullable(0)]
		private Stopwatch <sw>5__2; //Field offset: 0x20
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private List<AssetKey> <keys>5__3; //Field offset: 0x28
		private long <bytes>5__4; //Field offset: 0x30
		[Nullable(0)]
		private Awaiter<Int64> <>u__1; //Field offset: 0x38
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private Awaiter<AssetListDownloadRequest> <>u__2; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <DownloadAsync>d__79 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<QueueBehavior> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public BackgroundQueueItem queueItem; //Field offset: 0x20
		[Nullable(0)]
		public BackgroundDownloadingService <>4__this; //Field offset: 0x28
		public CancellationToken ct; //Field offset: 0x30
		[Nullable(0)]
		private AssetDownloadRequest <request>5__2; //Field offset: 0x38
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private Awaiter<AssetDownloadRequest> <>u__1; //Field offset: 0x40
		[Nullable(0)]
		private Awaiter<QueueBehavior> <>u__2; //Field offset: 0x58

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <HandleReadyRequest>d__80 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<QueueBehavior> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public BackgroundDownloadingService <>4__this; //Field offset: 0x20
		[Nullable(0)]
		public BackgroundQueueItem queueItem; //Field offset: 0x28
		[Nullable(0)]
		public AssetDownloadRequest request; //Field offset: 0x30
		public CancellationToken ct; //Field offset: 0x38
		[Nullable(0)]
		private Awaiter<ClearCachesResult> <>u__1; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <QueueProcessingCycle>d__71 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public BackgroundDownloadingService <>4__this; //Field offset: 0x18
		private Awaiter <>u__1; //Field offset: 0x20
		private CancellationToken <ct>5__2; //Field offset: 0x30
		[Nullable(0)]
		private BackgroundQueueItem <queueItem>5__3; //Field offset: 0x38
		[Nullable(0)]
		private Awaiter<QueueBehavior> <>u__2; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <RunDebugDownloadAsync>d__68 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<AssetListDownloadRequest> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public BackgroundDownloadingService <>4__this; //Field offset: 0x20
		[Nullable(0)]
		public string operationName; //Field offset: 0x28
		public long requestedBytes; //Field offset: 0x30
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		public IReadOnlyCollection<AssetKey> keys; //Field offset: 0x38
		[Nullable(0)]
		private <>c__DisplayClass68_0 <>8__1; //Field offset: 0x40
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private Awaiter<AssetListDownloadRequest> <>u__1; //Field offset: 0x48

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <WaitForClearUnusedBundlesCache>d__72 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public BackgroundDownloadingService <>4__this; //Field offset: 0x18
		public CancellationToken ct; //Field offset: 0x20
		private Awaiter <>u__1; //Field offset: 0x28
		[Nullable(0)]
		private Awaiter<ClearCachesResult> <>u__2; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[Nullable(0)]
	private class BackgroundQueueItem : IEquatable<BackgroundQueueItem>
	{
		[CompilerGenerated]
		private readonly AssetKey <Key>k__BackingField; //Field offset: 0x10
		public int TriesCount; //Field offset: 0x18

		[CompilerGenerated]
		protected override Type EqualityContract
		{
			[CompilerGenerated]
			 get { } //Length: 96
		}

		public AssetKey Key
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public BackgroundQueueItem(AssetKey Key) { }

		[CompilerGenerated]
		protected BackgroundQueueItem(BackgroundQueueItem original) { }

		[CompilerGenerated]
		public override BackgroundQueueItem <Clone>$() { }

		[CompilerGenerated]
		public void Deconstruct(out AssetKey Key) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public virtual bool Equals(object obj) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public override bool Equals(BackgroundQueueItem other) { }

		[CompilerGenerated]
		protected override Type get_EqualityContract() { }

		[CompilerGenerated]
		public AssetKey get_Key() { }

		[CompilerGenerated]
		public virtual int GetHashCode() { }

		[CompilerGenerated]
		[NullableContext(2)]
		public static bool op_Equality(BackgroundQueueItem left, BackgroundQueueItem right) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public static bool op_Inequality(BackgroundQueueItem left, BackgroundQueueItem right) { }

		[CompilerGenerated]
		protected override bool PrintMembers(StringBuilder builder) { }

		[CompilerGenerated]
		public void set_Key(AssetKey value) { }

		[CompilerGenerated]
		public virtual string ToString() { }

	}

	[Nullable(0)]
	private struct DebugDownloadState : IEquatable<DebugDownloadState>
	{
		[CompilerGenerated]
		private readonly string <Name>k__BackingField; //Field offset: 0x0
		[CompilerGenerated]
		private readonly bool <IsRunning>k__BackingField; //Field offset: 0x8
		[CompilerGenerated]
		private readonly bool <IsCanceled>k__BackingField; //Field offset: 0x9
		[CompilerGenerated]
		private readonly long <DownloadedBytes>k__BackingField; //Field offset: 0x10
		[CompilerGenerated]
		private readonly long <TotalBytes>k__BackingField; //Field offset: 0x18
		[CompilerGenerated]
		private readonly long <RequestedBytes>k__BackingField; //Field offset: 0x20

		public static DebugDownloadState Default
		{
			 get { } //Length: 72
		}

		public long DownloadedBytes
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public bool IsCanceled
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public bool IsRunning
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public string Name
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public long RequestedBytes
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public long TotalBytes
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public DebugDownloadState(string Name, bool IsRunning, bool IsCanceled, long DownloadedBytes, long TotalBytes, long RequestedBytes) { }

		[CompilerGenerated]
		public void Deconstruct(out string Name, out bool IsRunning, out bool IsCanceled, out long DownloadedBytes, out long TotalBytes, out long RequestedBytes) { }

		[CompilerGenerated]
		public override bool Equals(DebugDownloadState other) { }

		[CompilerGenerated]
		[NullableContext(0)]
		public virtual bool Equals(object obj) { }

		public static DebugDownloadState get_Default() { }

		[CompilerGenerated]
		public long get_DownloadedBytes() { }

		[CompilerGenerated]
		public bool get_IsCanceled() { }

		[CompilerGenerated]
		public bool get_IsRunning() { }

		[CompilerGenerated]
		public string get_Name() { }

		[CompilerGenerated]
		public long get_RequestedBytes() { }

		[CompilerGenerated]
		public long get_TotalBytes() { }

		[CompilerGenerated]
		public virtual int GetHashCode() { }

		[CompilerGenerated]
		public static bool op_Equality(DebugDownloadState left, DebugDownloadState right) { }

		[CompilerGenerated]
		public static bool op_Inequality(DebugDownloadState left, DebugDownloadState right) { }

		[CompilerGenerated]
		[NullableContext(0)]
		private bool PrintMembers(StringBuilder builder) { }

		[CompilerGenerated]
		public void set_DownloadedBytes(long value) { }

		[CompilerGenerated]
		public void set_IsCanceled(bool value) { }

		[CompilerGenerated]
		public void set_IsRunning(bool value) { }

		[CompilerGenerated]
		public void set_Name(string value) { }

		[CompilerGenerated]
		public void set_RequestedBytes(long value) { }

		[CompilerGenerated]
		public void set_TotalBytes(long value) { }

		[CompilerGenerated]
		[NullableContext(0)]
		public virtual string ToString() { }

	}

	[NullableContext(0)]
	private enum FailurePolicy : int
	{
		Critical = 0,
		RecoverableUnlimitedRetry = 1,
		RecoverableLimitedRetry = 2,
	}

	[NullableContext(0)]
	private enum QueueBehavior : int
	{
		Dequeue = 0,
		Enqueue = 1,
		LeftInQueue = 2,
	}

	private const PerformanceSection CRITICAL_SECTION = 1; //Field offset: 0x0
	private const PerformanceSection STARTUP_SECTION = 0; //Field offset: 0x0
	private static readonly Scope InitProgressScope; //Field offset: 0x0
	private static readonly ILogger Log; //Field offset: 0x20
	private readonly IChoreographManager _choreograph; //Field offset: 0x10
	private readonly IDownloadManager _downloadManager; //Field offset: 0x18
	private readonly IOptionsMonitor<ContentSettings> _contentSettings; //Field offset: 0x20
	private readonly IInternetConnectionStatus _internetConnectionStatus; //Field offset: 0x28
	private readonly PerformanceMonitor _performanceMonitor; //Field offset: 0x30
	private readonly IContentCaching _contentCaching; //Field offset: 0x38
	private readonly IClientAnalytics _analytics; //Field offset: 0x40
	private readonly IDiskSpaceMonitor _diskSpaceMonitor; //Field offset: 0x48
	private readonly IntSettings _downloadedHashSetting; //Field offset: 0x50
	private readonly StringSettings _downloadedTimeStampSetting; //Field offset: 0x58
	private readonly CompositeDisposable _disposables; //Field offset: 0x60
	private readonly Queue<BackgroundQueueItem> _queue; //Field offset: 0x68
	private readonly List<BackgroundQueueItem> _failedDownloads; //Field offset: 0x70
	private readonly Stopwatch _lastDownloadedItemSw; //Field offset: 0x78
	[Nullable(2)]
	private CancellationTokenSource _sessionScopedCts; //Field offset: 0x80
	[Nullable(2)]
	private CancellationTokenSource _debugDownloadCts; //Field offset: 0x88
	private BackgroundDownloadingProgress _progress; //Field offset: 0x90
	private DebugDownloadState _debugDownloadState; //Field offset: 0x98
	private PerformanceSection _performanceSection; //Field offset: 0xC0
	private Nullable<Int32> _currentHash; //Field offset: 0xC4
	private Nullable<DateTime> _currentTimeStamp; //Field offset: 0xD0
	private bool _hasInternetConnection; //Field offset: 0xE0
	private bool _loggedQueueProcessingFinished; //Field offset: 0xE1
	private readonly Subject<BackgroundDownloadingProgress> _progressSubject; //Field offset: 0xE8
	private readonly ReactiveProperty<BackgroundDownloadingServiceStatus> _serviceStatus; //Field offset: 0xF0

	private bool IsDisabled
	{
		private get { } //Length: 444
	}

	public override Observable<BackgroundDownloadingProgress> Progress
	{
		 get { } //Length: 8
	}

	public override string ServiceName
	{
		 get { } //Length: 64
	}

	public override Observable<BackgroundDownloadingServiceStatus> ServiceStatus
	{
		 get { } //Length: 8
	}

	public override bool SilentInitializationMode
	{
		 get { } //Length: 8
	}

	private static BackgroundDownloadingService() { }

	public BackgroundDownloadingService(IChoreographManager choreograph, IDownloadManager downloadManager, IOptionsMonitor<ContentSettings> contentSettings, IInternetConnectionStatus internetConnectionStatus, PerformanceMonitor performanceMonitor, IContentCaching contentCaching, IClientAnalytics analytics, IDiskSpaceMonitor diskSpaceMonitor, IGameStateManagerObserver gameStateManagerObserver) { }

	[CompilerGenerated]
	internal static void <InitProgress>g__VisitRemoteBundle|73_0(IResourceLocation location, ref <>c__DisplayClass73_0 unnamed_param_1) { }

	[CompilerGenerated]
	internal static FailurePolicy <ResolveFailure>g__ResolveHttpResponseCode|82_0(long code) { }

	private void CancelDebugDownload() { }

	public override void CancelDownloads() { }

	private void ChangePerformanceSection(PerformanceSection newLevel) { }

	private bool CheckActiveDownloads() { }

	private bool CheckDisconnection() { }

	private bool CheckPerformanceSection() { }

	private override UniTask Client.Core.GameServices.IGameService.InitAsync() { }

	private override void Client.Core.GameServices.IGameService.OnAppServicesInitialized() { }

	[AsyncStateMachine(typeof(<DoPotentialConnectionCheck>d__84))]
	private UniTask DoPotentialConnectionCheck(CancellationToken ct) { }

	[AsyncStateMachine(typeof(<DownloadAllBundles>d__63))]
	public override UniTask DownloadAllBundles() { }

	[AsyncStateMachine(typeof(<DownloadAllQueue>d__61))]
	public override UniTask DownloadAllQueue() { }

	[AsyncStateMachine(typeof(<DownloadAsync>d__79))]
	[NullableContext(0)]
	private UniTask<QueueBehavior> DownloadAsync(BackgroundQueueItem queueItem, CancellationToken ct) { }

	private bool get_IsDisabled() { }

	public override Observable<BackgroundDownloadingProgress> get_Progress() { }

	public override string get_ServiceName() { }

	public override Observable<BackgroundDownloadingServiceStatus> get_ServiceStatus() { }

	public override bool get_SilentInitializationMode() { }

	public override BackgroundDownloadingDebugSnapshot GetDebugSnapshot() { }

	private Nullable<DateTime> GetDownloadedTimeStamp() { }

	public override BackgroundDownloadingProgress GetProgress() { }

	public override BackgroundDownloadingServiceStatus GetServiceStatus() { }

	private void HandleDiskSpaceTierChanged(DiskSpaceTier tier) { }

	private QueueBehavior HandleFailedRequest(AssetDownloadRequest request, BackgroundQueueItem queueItem, CancellationToken ct) { }

	private void HandleGameStateChanged(Type newState) { }

	private void HandleInternetConnectionStatusChanged(bool isConnected) { }

	private void HandleQueueProcessingCycleExceptions(Exception e) { }

	[AsyncStateMachine(typeof(<HandleReadyRequest>d__80))]
	private UniTask<QueueBehavior> HandleReadyRequest(AssetDownloadRequest request, BackgroundQueueItem queueItem, CancellationToken ct) { }

	private BackgroundDownloadingProgress InitProgress(int queueCount) { }

	private bool IsCurrentBundlesVersionProcessed() { }

	private void LogQueueProcessingFinishedOnce(string caller) { }

	public static IntSettings MakeDownloadedHashSetting() { }

	public static StringSettings MakeDownloadedTimeStampSetting() { }

	private void OnDebugDownloadProgress(CancellationTokenSource debugDownloadCts, DownloadStatus status) { }

	[AsyncStateMachine(typeof(<QueueProcessingCycle>d__71))]
	private UniTask QueueProcessingCycle() { }

	private BackgroundDownloadingConfig ReadConfig(out Nullable<Int32>& configHash, out Nullable<DateTime>& timeStamp) { }

	public override void ResetDownloadedSettings() { }

	private static FailurePolicy ResolveFailure(AssetDownloadRequest request, out string error) { }

	[AsyncStateMachine(typeof(<RunDebugDownloadAsync>d__68))]
	private UniTask<AssetListDownloadRequest> RunDebugDownloadAsync(string operationName, IReadOnlyCollection<AssetKey> keys, long requestedBytes) { }

	private void SessionDispose(string caller) { }

	private void Start() { }

	private void Stop() { }

	private override void System.IDisposable.Dispose() { }

	public override void TraceProgress() { }

	private static bool TryGetInInners(Exception source, out TException result) { }

	private void UpdateHasInternetConnection(bool value) { }

	private void UpdateProfilerHUD(bool isVisible) { }

	private void UpdateProgress(AssetKey item, AssetDownloadRequest request = null, double elapsedTotalSeconds = 0) { }

	private void UpdateServiceStatus(BackgroundDownloadingServiceStatus newStatus) { }

	[AsyncStateMachine(typeof(<WaitForClearUnusedBundlesCache>d__72))]
	private UniTask WaitForClearUnusedBundlesCache(CancellationToken ct) { }

}

