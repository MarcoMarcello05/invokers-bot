namespace Client;

[Nullable(0)]
[NullableContext(1)]
public abstract class BaseAssetLoadingTask : IAssetLoadingTask<T>, IAssetLoadingTask, IDisposable
{
	private readonly AddressableAssetProvider _assetProvider; //Field offset: 0x0
	private readonly bool _errorOnDownload; //Field offset: 0x0
	private readonly UniTaskCompletionSource<T> _tcs; //Field offset: 0x0
	private long _downloadedBytesOnStart; //Field offset: 0x0
	[Nullable(2)]
	protected Subject<DownloadStatus> ProgressSubject; //Field offset: 0x0
	protected readonly CompositeDisposable DisposableBag; //Field offset: 0x0
	protected bool Started; //Field offset: 0x0
	[Nullable(2)]
	protected T Result; //Field offset: 0x0
	[CompilerGenerated]
	private int <RefCount>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private readonly AssetKey <Key>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private bool <IsDisposed>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private readonly Stopwatch <LoadTimer>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	[Nullable(2)]
	private Exception <Exception>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private bool <Finished>k__BackingField; //Field offset: 0x0

	public override T Asset
	{
		 get { } //Length: 1240
	}

	[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
	public override UniTask<T> AssetTask
	{
		 get { } //Length: 204
	}

	public abstract DownloadStatus DownloadStatus
	{
		 get { } //Length: 0
	}

	[Nullable(2)]
	public override Exception Exception
	{
		[CompilerGenerated]
		[NullableContext(2)]
		 get { } //Length: 40
		[CompilerGenerated]
		[NullableContext(2)]
		 set { } //Length: 32
	}

	public override bool Failed
	{
		 get { } //Length: 60
	}

	public private override bool Finished
	{
		[CompilerGenerated]
		 get { } //Length: 40
		[CompilerGenerated]
		private set { } //Length: 32
	}

	public private override bool IsDisposed
	{
		[CompilerGenerated]
		 get { } //Length: 40
		[CompilerGenerated]
		private set { } //Length: 32
	}

	public override AssetKey Key
	{
		[CompilerGenerated]
		 get { } //Length: 40
	}

	public override Stopwatch LoadTimer
	{
		[CompilerGenerated]
		 get { } //Length: 40
	}

	public abstract bool Ready
	{
		 get { } //Length: 0
	}

	public private override int RefCount
	{
		[CompilerGenerated]
		 get { } //Length: 40
		[CompilerGenerated]
		private set { } //Length: 32
	}

	public BaseAssetLoadingTask`1(AssetKey key, AddressableAssetProvider assetProvider, bool errorOnDownload = false) { }

	[CompilerGenerated]
	private void <SubscribeToProgress>b__51_0(DownloadStatus value) { }

	[CompilerGenerated]
	private void <SubscribeToProgress>b__51_1(Result _) { }

	protected bool CheckIfDownloadedDuringRequest(AsyncOperationHandle operation) { }

	public override void DecrementRefCount() { }

	public override void Dispose() { }

	[HideInCallstack]
	private void DisposeOnError() { }

	public override void Fail(Exception exception) { }

	public override T get_Asset() { }

	public override UniTask<T> get_AssetTask() { }

	public abstract DownloadStatus get_DownloadStatus() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public override Exception get_Exception() { }

	public override bool get_Failed() { }

	[CompilerGenerated]
	public override bool get_Finished() { }

	[CompilerGenerated]
	public override bool get_IsDisposed() { }

	[CompilerGenerated]
	public override AssetKey get_Key() { }

	[CompilerGenerated]
	public override Stopwatch get_LoadTimer() { }

	public abstract bool get_Ready() { }

	[CompilerGenerated]
	public override int get_RefCount() { }

	public override void IncrementRefCount() { }

	[NullableContext(2)]
	protected void OnLoadingCompleted(T result, AsyncOperationStatus status, Exception exception, bool wasDownloadedDuringRequest = false) { }

	protected void OnLoadingStarted(IDownloadsTracker downloadsTracker, AsyncOperationHandle operation) { }

	[CompilerGenerated]
	[NullableContext(2)]
	protected void set_Exception(Exception value) { }

	[CompilerGenerated]
	private void set_Finished(bool value) { }

	[CompilerGenerated]
	private void set_IsDisposed(bool value) { }

	[CompilerGenerated]
	private void set_RefCount(int value) { }

	public abstract void StartLoad(IDownloadsTracker downloadsTracker) { }

	protected void SubscribeToProgress(AsyncOperationHandle operation, Action<DownloadStatus> onProgress) { }

	public abstract void SubscribeToProgress(Action<DownloadStatus> onProgress) { }

	public virtual string ToString() { }

}

