namespace Client.Authentication.ExternalAuth;

[Extension]
public static class ExternalAuthLinkRequestFactory
{

	[Extension]
	[NullableContext(1)]
	public static LinkExternalAccountRequest ToLinkExternalAccountRequest(AuthenticationParameters authParameters, ExternalLoginProvider provider) { }

}

