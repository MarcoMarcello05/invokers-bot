namespace Client.Configuration;

[Nullable(0)]
[NullableContext(1)]
public class SystemInfoProvider : ISystemInfoProvider
{

	public override string DeviceModel
	{
		 get { } //Length: 8
	}

	public override string DeviceName
	{
		 get { } //Length: 8
	}

	public override string DeviceType
	{
		 get { } //Length: 104
	}

	public override string GfxApiName
	{
		 get { } //Length: 104
	}

	public override string GfxVendor
	{
		 get { } //Length: 8
	}

	public override string OsVersion
	{
		 get { } //Length: 8
	}

	public override string Platform
	{
		 get { } //Length: 104
	}

	public override string ProcessorType
	{
		 get { } //Length: 8
	}

	public override string RamSize
	{
		 get { } //Length: 148
	}

	public SystemInfoProvider() { }

	public override string get_DeviceModel() { }

	public override string get_DeviceName() { }

	public override string get_DeviceType() { }

	public override string get_GfxApiName() { }

	public override string get_GfxVendor() { }

	public override string get_OsVersion() { }

	public override string get_Platform() { }

	public override string get_ProcessorType() { }

	public override string get_RamSize() { }

	public virtual string ToString() { }

}

