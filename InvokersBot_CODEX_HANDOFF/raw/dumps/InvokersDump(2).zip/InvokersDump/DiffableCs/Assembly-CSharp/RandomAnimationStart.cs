//Type is in global namespace

public class RandomAnimationStart : MonoBehaviour
{
	private Animation _anim; //Field offset: 0x20

	public RandomAnimationStart() { }

	private void OnEnable() { }

	public void TriggerRandomAnimation() { }

}

