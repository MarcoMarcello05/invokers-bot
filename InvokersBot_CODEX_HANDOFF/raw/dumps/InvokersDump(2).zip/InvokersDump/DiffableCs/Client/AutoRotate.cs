//Type is in global namespace

public class AutoRotate : MonoBehaviour
{
	public float speedX; //Field offset: 0x20
	public float speedY; //Field offset: 0x24
	public float speedZ; //Field offset: 0x28

	public AutoRotate() { }

	private void Update() { }

}

