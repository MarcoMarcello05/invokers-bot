namespace Client.CharacterControllers.BossHpPanel;

public class TopPanelView : SmartUIWidget
{
	[CompilerGenerated]
	private sealed class <DisableCoroutine>d__29 : IEnumerator<Object>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private object <>2__current; //Field offset: 0x18
		public TopPanelView <>4__this; //Field offset: 0x20

		private override object System.Collections.Generic.IEnumerator<System.Object>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <DisableCoroutine>d__29(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private struct <LoadElementSprite>d__21 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskVoidMethodBuilder <>t__builder; //Field offset: 0x8
		public TopPanelView <>4__this; //Field offset: 0x10
		public TopPanelData data; //Field offset: 0x18
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 0})]
		private Awaiter<IAssetRequest<Sprite>> <>u__1; //Field offset: 0x98

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	public TopPanelViewTarget TargetType; //Field offset: 0x30
	[SerializeField]
	private PatternLocalizedText _bossName; //Field offset: 0x38
	[SerializeField]
	private TextMeshProUGUI _bossLevel; //Field offset: 0x40
	[SerializeField]
	private Image _bossPortrait; //Field offset: 0x48
	[SerializeField]
	private Image _elementImage; //Field offset: 0x50
	[SerializeField]
	private SegmentedHealthBar _segmentedHealthBar; //Field offset: 0x58
	[SerializeField]
	private TextMeshProUGUI _bossHpPercent; //Field offset: 0x60
	[SerializeField]
	private TextMeshProUGUI _healthBarsRemainText; //Field offset: 0x68
	[SerializeField]
	private Image _additionalHpBarImage; //Field offset: 0x70
	[SerializeField]
	private UIAnimator _onBarFlashAnimator; //Field offset: 0x78
	[SerializeField]
	private UIAnimator _onDamageReceivedAnimator; //Field offset: 0x80
	[SerializeField]
	private Image _targetPortrait; //Field offset: 0x88
	[SerializeField]
	private BossTopPanelDamagePopUp _damagePopUp; //Field offset: 0x90
	private int _totalHealthBarsCount; //Field offset: 0x98
	private long _maxHealth; //Field offset: 0xA0
	private int _healthBarsRemain; //Field offset: 0xA8
	private long _healthPerBar; //Field offset: 0xB0
	private bool _multipleHealthBars; //Field offset: 0xB8
	private Coroutine _hideCoroutine; //Field offset: 0xC0
	private IAssetRequest<Sprite> _elementImageSpriteRequest; //Field offset: 0xC8

	public TopPanelView() { }

	private static HealthBarState CalculateCurrentBarState(long currentHealth, long maxHealth, int currentShield, int totalDestroyedHealth, long healthPerBar, int totalBarCount) { }

	public void ChangeTargetSprite(Sprite targetSprite) { }

	[IteratorStateMachine(typeof(<DisableCoroutine>d__29))]
	private IEnumerator DisableCoroutine() { }

	public void Hide() { }

	[AsyncStateMachine(typeof(<LoadElementSprite>d__21))]
	private UniTaskVoid LoadElementSprite(TopPanelData data) { }

	private void OnDestroy() { }

	private void OnDisable() { }

	public void Set(ref TopPanelData data) { }

	public void SetDamagePopupMode(DamagePopupMode mode, Func<Int64> getCounterValue) { }

	public void TakeDamage(ModelEntityKey targetEntity, int damage, bool isCritical) { }

	public void UpdateHealthBar(TopPanelHealth health, bool playAnimation = true) { }

}

