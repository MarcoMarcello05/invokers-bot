namespace Client.Common.UI;

public class HZToggle : Toggle, IButton
{
	[SerializeField]
	private TextMeshProUGUI _label; //Field offset: 0x128
	[SerializeField]
	private uint _debounceMs; //Field offset: 0x130
	[SerializeField]
	private ButtonSoundReference _onSoundRef; //Field offset: 0x138
	[SerializeField]
	private ButtonSoundReference _offSoundRef; //Field offset: 0x140
	[SerializeField]
	private MultiTweenAnimator _animator; //Field offset: 0x148
	[SerializeField]
	private BaseHZButtonProcessAnimation _stateVisualizer; //Field offset: 0x150
	[SerializeField]
	private bool _useStateVisualiser; //Field offset: 0x158
	private IButtonCommand _command; //Field offset: 0x160
	private readonly Subject<Boolean> _toggleSubject; //Field offset: 0x168
	[CompilerGenerated]
	private bool <ShowSpinnerOnLongExecution>k__BackingField; //Field offset: 0x170

	public override bool ActiveSelf
	{
		 get { } //Length: 32
		 set { } //Length: 40
	}

	public override uint DebounceMs
	{
		 get { } //Length: 8
		 set { } //Length: 8
	}

	public override bool Interactable
	{
		 get { } //Length: 8
		 set { } //Length: 8
	}

	public override bool ShowSpinnerOnLongExecution
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public Observable<Boolean> ValueChanged
	{
		 get { } //Length: 8
	}

	public HZToggle() { }

	[CompilerGenerated]
	private void <Awake>b__24_0(bool active) { }

	protected virtual void Awake() { }

	public void Bind(IButtonCommand command) { }

	public override void Bind(IButtonCommand command, Func<Object> valueGetter) { }

	public override void Bind(IButtonCommand command, object value) { }

	public override bool get_ActiveSelf() { }

	public override uint get_DebounceMs() { }

	public override bool get_Interactable() { }

	[CompilerGenerated]
	public override bool get_ShowSpinnerOnLongExecution() { }

	public Observable<Boolean> get_ValueChanged() { }

	public override void set_ActiveSelf(bool value) { }

	public override void set_DebounceMs(uint value) { }

	public override void set_Interactable(bool value) { }

	[CompilerGenerated]
	public override void set_ShowSpinnerOnLongExecution(bool value) { }

	public void SetImmediately(bool active, bool notify = false) { }

	public void SetImmediatelyWithoutCommand(bool active) { }

	public override void SetText(string text) { }

}

