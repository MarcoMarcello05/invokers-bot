namespace Client.Common;

[DefaultMember("Item")]
public struct TempStructList : IDisposable
{
	[CompilerGenerated]
	private StructList<T> <List>k__BackingField; //Field offset: 0x0

	public int Count
	{
		 get { } //Length: 88
	}

	public T Item
	{
		 get { } //Length: 104
	}

	public private StructList<T> List
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public void Add(T t) { }

	public override void Dispose() { }

	public static TempStructList<T> Get(int capacity = 8) { }

	public int get_Count() { }

	public T get_Item(int idx) { }

	[CompilerGenerated]
	public StructList<T> get_List() { }

	public void RemoveAtBySwap(int idx) { }

	[CompilerGenerated]
	private void set_List(StructList<T> value) { }

}

