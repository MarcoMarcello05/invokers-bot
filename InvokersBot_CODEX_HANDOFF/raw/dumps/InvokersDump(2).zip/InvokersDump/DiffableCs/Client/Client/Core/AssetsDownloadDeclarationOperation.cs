namespace Client.Core;

public sealed class AssetsDownloadDeclarationOperation : IAsyncOperationWithProgress, IAssetHolder
{
	[CompilerGenerated]
	private readonly IEnumerable<AssetKey> <RequiredAssets>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly string <OperationId>k__BackingField; //Field offset: 0x18

	public override UniTask CompletedTask
	{
		 get { } //Length: 88
	}

	public string LocalizedOperationName
	{
		 get { } //Length: 8
	}

	public override string OperationId
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public override IEnumerable<AssetKey> RequiredAssets
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public AssetsDownloadDeclarationOperation(AssetKey key) { }

	public AssetsDownloadDeclarationOperation(IEnumerable<AssetKey> assetKeys) { }

	public override bool AttachProgressObserver(IOperationProgressObserver progressObserver) { }

	public override UniTask ExecuteOperationAsync(IOperationProgressObserver progressObserver = null) { }

	public override UniTask get_CompletedTask() { }

	public string get_LocalizedOperationName() { }

	[CompilerGenerated]
	public override string get_OperationId() { }

	[CompilerGenerated]
	public override IEnumerable<AssetKey> get_RequiredAssets() { }

	public virtual string ToString() { }

}

