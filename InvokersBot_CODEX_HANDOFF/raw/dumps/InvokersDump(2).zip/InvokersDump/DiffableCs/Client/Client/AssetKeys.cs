namespace Client;

public static class AssetKeys
{
	internal static class AnimaOverview
	{
		private const string ROOT = "Assets/UI/Feature/AnimaOverview/"; //Field offset: 0x0
		public static readonly AssetKey View; //Field offset: 0x0
		private const string TABS = "Assets/UI/Feature/AnimaOverview/Tabs/"; //Field offset: 0x0
		private const string DIALOGS = "Assets/UI/Feature/AnimaOverview/Dialogs/"; //Field offset: 0x0
		private const string TOOLTIPS = "Assets/UI/Feature/AnimaOverview/Tooltips/"; //Field offset: 0x0
		public static readonly AssetKey ProfileTab; //Field offset: 0x8
		public static readonly AssetKey LevelUpTab; //Field offset: 0x10
		public static readonly AssetKey AscensionTab; //Field offset: 0x18
		public static readonly AssetKey SkillsTab; //Field offset: 0x20
		public static readonly AssetKey EmpowermentTab; //Field offset: 0x28
		public static readonly AssetKey BioTab; //Field offset: 0x30
		public static readonly AssetKey AnimaAscensionResultDialog; //Field offset: 0x38
		public static readonly AssetKey AnimaEmpowermentResultDialog; //Field offset: 0x40
		public static readonly AssetKey AnimaQuickLevelUpDialog; //Field offset: 0x48
		public static readonly AssetKey AnimaQuickAscensionDialog; //Field offset: 0x50
		public static readonly AssetKey AnimaEmpowermentConfirmDialog; //Field offset: 0x58
		public static readonly AssetKey AnimaLevelUpResultDialog; //Field offset: 0x60
		public static readonly AssetKey AnimaUnlockConfirmation; //Field offset: 0x68
		public static readonly AssetKey AnimaLegendaryCannotBeUsedInAscendDialog; //Field offset: 0x70
		public static readonly AssetKey AnimaInArenaCannotBeUsedDialog; //Field offset: 0x78
		public static readonly AssetKey ChromaAnimaConvertDialog; //Field offset: 0x80
		public static readonly AssetKey ChromaAnimaSelectDialog; //Field offset: 0x88
		public static readonly AssetKey AnimaLevelUpMaxPotionsSelectedTooltip; //Field offset: 0x90
		public static readonly AssetKey AnimaPassiveBonusTooltip; //Field offset: 0x98
		public static readonly AssetKey AnimaSkillInfoTooltip; //Field offset: 0xA0
		public static readonly AssetKey AnimaTransformationTooltip; //Field offset: 0xA8

		private static AnimaOverview() { }

		private static AssetKey TooltipKey(string tooltipName) { }

	}

	internal static class ArenaGreatHall
	{
		private const string ROOT = "Assets/UI/Feature/ArenaTrophyRoom/"; //Field offset: 0x0
		public static readonly AssetKey View; //Field offset: 0x0
		public static readonly AssetKey TrophyRoomStatUpgradedPopup; //Field offset: 0x8
		public static readonly AssetKey TrophyRoomStatsTutorialPopup; //Field offset: 0x10
		public static readonly AssetKey TrophyRoomTutorialPopup; //Field offset: 0x18
		public static readonly AssetKey StatCantBeUpgradedPopup; //Field offset: 0x20

		private static ArenaGreatHall() { }

	}

	internal static class ArenaPvP
	{
		private const string ROOT = "Assets/UI/Feature/ArenaPvP/"; //Field offset: 0x0
		public static readonly AssetKey View; //Field offset: 0x0
		public static readonly AssetKey BattleTab; //Field offset: 0x8
		public static readonly AssetKey DefenseTab; //Field offset: 0x10
		public static readonly AssetKey LeaguesTab; //Field offset: 0x18
		public static readonly AssetKey HistoryTab; //Field offset: 0x20
		public static readonly AssetKey RatingTab; //Field offset: 0x28
		public static readonly AssetKey BattleResultVictoryView; //Field offset: 0x30
		public static readonly AssetKey BattleResultDefeatView; //Field offset: 0x38
		public static readonly AssetKey WeekRewardsPopup; //Field offset: 0x40
		public static readonly AssetKey LeagueRewardsPopup; //Field offset: 0x48
		public static readonly AssetKey LeagueChangeUpPopup; //Field offset: 0x50
		public static readonly AssetKey LeagueChangeDownPopup; //Field offset: 0x58
		public static readonly AssetKey SetupDefensePopup; //Field offset: 0x60
		public static readonly AssetKey OffenseTutorialPopup; //Field offset: 0x68
		public static readonly AssetKey LeagueTutorialPopup; //Field offset: 0x70
		public static readonly AssetKey DefenseTutorialPopup; //Field offset: 0x78

		private static ArenaPvP() { }

	}

	internal static class ArenaShop
	{
		private const string ROOT = "Assets/UI/Feature/ArenaShop/"; //Field offset: 0x0
		public static readonly AssetKey View; //Field offset: 0x0
		public static readonly AssetKey ConverterTab; //Field offset: 0x8
		public static readonly AssetKey ShopResetTutorialPopup; //Field offset: 0x10

		private static ArenaShop() { }

	}

	[AttributeUsage(AttributeTargets::Parameter (2048))]
	internal class ArgsProviderAttribute : Attribute
	{
		[CompilerGenerated]
		private readonly string <ProviderMethodName>k__BackingField; //Field offset: 0x10

		public string ProviderMethodName
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		public ArgsProviderAttribute(string providerMethodName) { }

		[CompilerGenerated]
		public string get_ProviderMethodName() { }

	}

	internal static class BaseElements
	{
		private const string ROOT = "Assets/UI/Core/BaseElements/"; //Field offset: 0x0
		public static readonly AssetKey GenericTextScrollPopup; //Field offset: 0x0
		public static readonly AssetKey ResourcePanel; //Field offset: 0x8
		public static readonly AssetKey InGameAlert; //Field offset: 0x10
		public static readonly AssetKey TournamentPointsToast; //Field offset: 0x18

		private static BaseElements() { }

	}

	internal static class Battle
	{
		private const string ROOT = "Assets/UI/Feature/Battle/"; //Field offset: 0x0
		public static readonly AssetKey VictoryScreen; //Field offset: 0x0
		private const string PAUSE_MENU_DIALOGS = "Assets/UI/Feature/Battle/HUD/PauseMenu/Dialogs/"; //Field offset: 0x0
		private const string BATTLE_COMPLETE = "Assets/UI/Feature/Battle/BattleComplete/"; //Field offset: 0x0
		private const string TOOLTIPS = "Assets/UI/Feature/Battle/Tooltips/"; //Field offset: 0x0
		private const string BACKGROUND_BATTLE = "Assets/UI/Feature/BackgroundBattle/Prefabs/"; //Field offset: 0x0
		private const string HUD = "Assets/UI/Feature/Battle/HUD/"; //Field offset: 0x0
		private const string ICONS = "Assets/UI/Feature/Battle/BattleResourceIcons/"; //Field offset: 0x0
		private const string LOOT = "Assets/UI/Feature/Battle/Loot/"; //Field offset: 0x0
		private const string HUD_VIEWS = "Assets/UI/Feature/Battle/HUD/HUDViews/"; //Field offset: 0x0
		public static readonly AssetKey DefeatScreen; //Field offset: 0x8
		public static readonly AssetKey BattleEndedScreen; //Field offset: 0x10
		public static readonly AssetKey ScoreScreen; //Field offset: 0x18
		public static readonly AssetKey MultiBattleTransitionScreen; //Field offset: 0x20
		public static readonly AssetKey MultiBattleResultScreen; //Field offset: 0x28
		public static readonly AssetKey BackgroundMultiBattleDialog; //Field offset: 0x30
		public static readonly AssetKey LootConfig; //Field offset: 0x38
		public static readonly AssetKey BattleInventoryHud; //Field offset: 0x40
		public static readonly AssetKey BattleScoreHud; //Field offset: 0x48
		public static readonly AssetKey BattlePowerUpHud; //Field offset: 0x50
		public static readonly AssetKey HUDScreen; //Field offset: 0x58
		public static readonly AssetKey PVPHUDScreen; //Field offset: 0x60
		public static readonly AssetKey HUDDamagePopUp; //Field offset: 0x68
		public static readonly AssetKey ChestCounterTooltip; //Field offset: 0x70
		public static readonly AssetKey CharacterAddonTooltip; //Field offset: 0x78
		public static readonly AssetKey BattlePauseMenuV2; //Field offset: 0x80
		public static readonly AssetKey BossStatsDescriptionDialog; //Field offset: 0x88
		public static readonly AssetKey EnemyDescriptionTooltip; //Field offset: 0x90
		public static readonly AssetKey BossDescriptionTooltip; //Field offset: 0x98
		public static readonly AssetKey StatusEffectListTooltip; //Field offset: 0xA0
		public static readonly AssetKey CharacterUIBuff; //Field offset: 0xA8
		public static readonly AssetKey CharacterUIDebuff; //Field offset: 0xB0
		public static readonly AssetKey CharacterUICorruption; //Field offset: 0xB8
		public static readonly AssetKey ExitMultiBattleDialog; //Field offset: 0xC0
		public static readonly AssetKey MultiBattleCurrentLevelScreen; //Field offset: 0xC8
		public static readonly AssetKey SlideToUnlockScreen; //Field offset: 0xD0

		private static Battle() { }

		public static AssetKey ResourceIcon(BattleResourceTypeId id) { }

	}

	internal static class BattleReplay
	{
		private const string ROOT = "Assets/UI/Feature/BattleReplay/"; //Field offset: 0x0
		public static readonly AssetKey PlaybackDialog; //Field offset: 0x0

		private static BattleReplay() { }

	}

	internal static class BattleResult
	{
		private const string ROOT = "Assets/UI/Feature/BattleResult/"; //Field offset: 0x0
		private const string SCREENS = "Assets/UI/Feature/BattleResult/Screens/"; //Field offset: 0x0
		private const string SCENES = "Assets/UI/Feature/BattleResult/Scenes/"; //Field offset: 0x0
		public static readonly AssetKey BattleResultClanBoss2View; //Field offset: 0x0
		public static readonly AssetKey BattleResultVictoryView; //Field offset: 0x8
		public static readonly AssetKey BattleResultDefeatView; //Field offset: 0x10
		public static readonly AssetKey BattleResultHeroesDataView; //Field offset: 0x18
		public static readonly AssetKey ReplayForGemsConfirmation; //Field offset: 0x20
		public static readonly AssetKey BattleResultTutorialDialog; //Field offset: 0x28
		public static readonly AssetKey BattleResultStatisticsDialog; //Field offset: 0x30
		public static readonly AssetKey BattleResultStatisticsDescriptionDialog; //Field offset: 0x38
		public static readonly AssetKey VictoryScene; //Field offset: 0x40
		public static readonly AssetKey DefeatScene; //Field offset: 0x48
		public static readonly AssetKey ShadersCollection; //Field offset: 0x50

		private static BattleResult() { }

	}

	internal static class Boosters
	{
		private const string ROOT = "Assets/UI/Feature/Boosters/"; //Field offset: 0x0
		public static readonly AssetKey BoostersDialogView; //Field offset: 0x0
		public static readonly AssetKey ActivateConfirmationPopupView; //Field offset: 0x8

		private static Boosters() { }

	}

	internal static class CharacterAddons
	{
		[CompilerGenerated]
		private sealed class <>c
		{
			public static readonly <>c <>9; //Field offset: 0x0
			public static Func<CharacterAddonConfig, Int64> <>9__3_0; //Field offset: 0x8

			private static <>c() { }

			public <>c() { }

			internal long <_allAddonIds>b__3_0(CharacterAddonConfig addon) { }

		}

		public const string FOLDER_PATH = "Assets/Addressables/ConfigsAssets/CharacterAddons"; //Field offset: 0x0
		private const string ROOT = "Assets/Addressables/ConfigsAssets/CharacterAddons/"; //Field offset: 0x0

		private static IEnumerable<Int64> _allAddonIds(IStaticDataProvider staticData) { }

		public static AssetKey Holder(long addonId) { }

	}

	internal static class CharacterAssets
	{
		[CompilerGenerated]
		private sealed class <>c
		{
			public static readonly <>c <>9; //Field offset: 0x0
			public static Func<BaseCharacterConfig, AssetsRecord> <>9__13_0; //Field offset: 0x8
			public static Func<BaseCharacterConfig, Boolean> <>9__14_0; //Field offset: 0x10
			public static Func<BaseCharacterConfig, AssetsRecord> <>9__14_1; //Field offset: 0x18
			public static Func<BaseCharacterConfig, Boolean> <>9__15_0; //Field offset: 0x20
			public static Func<BaseCharacterConfig, AssetsRecord> <>9__15_1; //Field offset: 0x28

			private static <>c() { }

			public <>c() { }

			internal AssetsRecord <_allAssetsRecords>b__13_0(BaseCharacterConfig c) { }

			internal bool <_chromaAssetsRecords>b__15_0(BaseCharacterConfig x) { }

			internal AssetsRecord <_chromaAssetsRecords>b__15_1(BaseCharacterConfig c) { }

			internal bool <_lobbyAssetsRecords>b__14_0(BaseCharacterConfig x) { }

			internal AssetsRecord <_lobbyAssetsRecords>b__14_1(BaseCharacterConfig c) { }

		}

		[CompilerGenerated]
		private sealed class <GetAllCharacters>d__16 : IEnumerable<BaseCharacterConfig>, IEnumerable, IEnumerator<BaseCharacterConfig>, IEnumerator, IDisposable
		{
			private int <>1__state; //Field offset: 0x10
			private BaseCharacterConfig <>2__current; //Field offset: 0x18
			private int <>l__initialThreadId; //Field offset: 0x20
			private IStaticDataProvider staticData; //Field offset: 0x28
			public IStaticDataProvider <>3__staticData; //Field offset: 0x30
			private Enumerator<CharacterConfig> <>7__wrap1; //Field offset: 0x38
			private Enumerator<AnimaConfig> <>7__wrap2; //Field offset: 0x50

			private override BaseCharacterConfig System.Collections.Generic.IEnumerator<Shared.Logic.Configs.BaseCharacterConfig>.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			private override object System.Collections.IEnumerator.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			[DebuggerHidden]
			public <GetAllCharacters>d__16(int <>1__state) { }

			private void <>m__Finally1() { }

			private void <>m__Finally2() { }

			private override bool MoveNext() { }

			[DebuggerHidden]
			private override IEnumerator<BaseCharacterConfig> System.Collections.Generic.IEnumerable<Shared.Logic.Configs.BaseCharacterConfig>.GetEnumerator() { }

			[DebuggerHidden]
			private override BaseCharacterConfig System.Collections.Generic.IEnumerator<Shared.Logic.Configs.BaseCharacterConfig>.get_Current() { }

			[DebuggerHidden]
			private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

			[DebuggerHidden]
			private override object System.Collections.IEnumerator.get_Current() { }

			[DebuggerHidden]
			private override void System.Collections.IEnumerator.Reset() { }

			[DebuggerHidden]
			private override void System.IDisposable.Dispose() { }

		}

		internal struct AssetsRecord : IEquatable<AssetsRecord>
		{
			[CompilerGenerated]
			private long <ConfigId>k__BackingField; //Field offset: 0x0
			[CompilerGenerated]
			private string <ConfigName>k__BackingField; //Field offset: 0x8
			[CompilerGenerated]
			private CharacterKind <Kind>k__BackingField; //Field offset: 0x10
			[CompilerGenerated]
			private CharacterFaction <Faction>k__BackingField; //Field offset: 0x12
			[CompilerGenerated]
			private string <SoundBank>k__BackingField; //Field offset: 0x18

			public long ConfigId
			{
				[CompilerGenerated]
				 get { } //Length: 8
				[CompilerGenerated]
				 set { } //Length: 8
			}

			public string ConfigName
			{
				[CompilerGenerated]
				 get { } //Length: 8
				[CompilerGenerated]
				 set { } //Length: 8
			}

			public CharacterFaction Faction
			{
				[CompilerGenerated]
				 get { } //Length: 8
				[CompilerGenerated]
				 set { } //Length: 8
			}

			public CharacterKind Kind
			{
				[CompilerGenerated]
				 get { } //Length: 8
				[CompilerGenerated]
				 set { } //Length: 8
			}

			public string SoundBank
			{
				[CompilerGenerated]
				 get { } //Length: 8
				[CompilerGenerated]
				 set { } //Length: 8
			}

			public AssetsRecord(long ConfigId, string ConfigName, CharacterKind Kind, CharacterFaction Faction, string SoundBank) { }

			[CompilerGenerated]
			public void Deconstruct(out long ConfigId, out string ConfigName, out CharacterKind Kind, out CharacterFaction Faction, out string SoundBank) { }

			[CompilerGenerated]
			public virtual bool Equals(object obj) { }

			[CompilerGenerated]
			public override bool Equals(AssetsRecord other) { }

			public static AssetsRecord FromCharacterConfig(BaseCharacterConfig config) { }

			public static AssetsRecord FromCharacterStaticData(CharacterStaticData data) { }

			[CompilerGenerated]
			public long get_ConfigId() { }

			[CompilerGenerated]
			public string get_ConfigName() { }

			[CompilerGenerated]
			public CharacterFaction get_Faction() { }

			[CompilerGenerated]
			public CharacterKind get_Kind() { }

			[CompilerGenerated]
			public string get_SoundBank() { }

			[CompilerGenerated]
			public virtual int GetHashCode() { }

			[CompilerGenerated]
			public static bool op_Equality(AssetsRecord left, AssetsRecord right) { }

			[CompilerGenerated]
			public static bool op_Inequality(AssetsRecord left, AssetsRecord right) { }

			[CompilerGenerated]
			private bool PrintMembers(StringBuilder builder) { }

			[CompilerGenerated]
			public void set_ConfigId(long value) { }

			[CompilerGenerated]
			public void set_ConfigName(string value) { }

			[CompilerGenerated]
			public void set_Faction(CharacterFaction value) { }

			[CompilerGenerated]
			public void set_Kind(CharacterKind value) { }

			[CompilerGenerated]
			public void set_SoundBank(string value) { }

			[CompilerGenerated]
			public virtual string ToString() { }

		}


		private static IEnumerable<AssetsRecord> _allAssetsRecords(IStaticDataProvider sd) { }

		private static IEnumerable<AssetsRecord> _chromaAssetsRecords(IStaticDataProvider sd) { }

		private static IEnumerable<AssetsRecord> _lobbyAssetsRecords(IStaticDataProvider sd) { }

		public static AssetKey BattleChromaPrefabHolder(AssetsRecord record) { }

		public static AssetKey BattleChromaShadersCollection(AssetsRecord record) { }

		public static AssetKey BattlePrefabHolder(AssetsRecord record) { }

		public static AssetKey BattleShadersCollection(AssetsRecord record) { }

		public static AssetKey BattleSound(AssetsRecord record) { }

		public static AssetKey CharacterAssetsHolder(AssetsRecord record) { }

		[IteratorStateMachine(typeof(<GetAllCharacters>d__16))]
		private static IEnumerable<BaseCharacterConfig> GetAllCharacters(IStaticDataProvider staticData) { }

		private static string GetRoot(long configId, string configName, CharacterKind kind) { }

		public static AssetKey LobbyChromaPrefabHolder(AssetsRecord record) { }

		public static AssetKey LobbyChromaShadersCollection(AssetsRecord record) { }

		public static AssetKey LobbyPrefabHolder(AssetsRecord record) { }

		public static AssetKey LobbyShadersCollection(AssetsRecord record) { }

		public static AssetKey LobbySound(AssetsRecord record) { }

		public static AssetKey Vfx(AssetsRecord record) { }

	}

	internal static class CharacterPlatforms
	{
		[CompilerGenerated]
		private sealed class <_argsCustomPlatformNames>d__6 : IEnumerable<String>, IEnumerable, IEnumerator<String>, IEnumerator, IDisposable
		{
			private int <>1__state; //Field offset: 0x10
			private string <>2__current; //Field offset: 0x18
			private int <>l__initialThreadId; //Field offset: 0x20
			private IStaticDataProvider staticData; //Field offset: 0x28
			public IStaticDataProvider <>3__staticData; //Field offset: 0x30
			private Enumerator<CharacterConfig> <>7__wrap1; //Field offset: 0x38
			private Enumerator<AnimaConfig> <>7__wrap2; //Field offset: 0x50

			private override string System.Collections.Generic.IEnumerator<System.String>.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			private override object System.Collections.IEnumerator.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			[DebuggerHidden]
			public <_argsCustomPlatformNames>d__6(int <>1__state) { }

			private void <>m__Finally1() { }

			private void <>m__Finally2() { }

			private override bool MoveNext() { }

			[DebuggerHidden]
			private override IEnumerator<String> System.Collections.Generic.IEnumerable<System.String>.GetEnumerator() { }

			[DebuggerHidden]
			private override string System.Collections.Generic.IEnumerator<System.String>.get_Current() { }

			[DebuggerHidden]
			private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

			[DebuggerHidden]
			private override object System.Collections.IEnumerator.get_Current() { }

			[DebuggerHidden]
			private override void System.Collections.IEnumerator.Reset() { }

			[DebuggerHidden]
			private override void System.IDisposable.Dispose() { }

		}

		internal class PlatformDescriptor : IEquatable<PlatformDescriptor>
		{
			[CompilerGenerated]
			private readonly CharacterFaction <Faction>k__BackingField; //Field offset: 0x10
			[CompilerGenerated]
			private readonly AssetKey <PlatformKey>k__BackingField; //Field offset: 0x18

			[CompilerGenerated]
			[Nullable(1)]
			protected override Type EqualityContract
			{
				[CompilerGenerated]
				[NullableContext(1)]
				 get { } //Length: 96
			}

			public CharacterFaction Faction
			{
				[CompilerGenerated]
				 get { } //Length: 8
				[CompilerGenerated]
				 set { } //Length: 8
			}

			public AssetKey PlatformKey
			{
				[CompilerGenerated]
				 get { } //Length: 8
				[CompilerGenerated]
				 set { } //Length: 8
			}

			public PlatformDescriptor(CharacterFaction Faction, AssetKey PlatformKey) { }

			[CompilerGenerated]
			protected PlatformDescriptor(PlatformDescriptor original) { }

			[CompilerGenerated]
			[NullableContext(1)]
			public override PlatformDescriptor <Clone>$() { }

			[CompilerGenerated]
			public void Deconstruct(out CharacterFaction Faction, out AssetKey PlatformKey) { }

			[CompilerGenerated]
			[NullableContext(2)]
			public virtual bool Equals(object obj) { }

			[CompilerGenerated]
			[NullableContext(2)]
			public override bool Equals(PlatformDescriptor other) { }

			[CompilerGenerated]
			[NullableContext(1)]
			protected override Type get_EqualityContract() { }

			[CompilerGenerated]
			public CharacterFaction get_Faction() { }

			[CompilerGenerated]
			public AssetKey get_PlatformKey() { }

			[CompilerGenerated]
			public virtual int GetHashCode() { }

			[CompilerGenerated]
			[NullableContext(2)]
			public static bool op_Equality(PlatformDescriptor left, PlatformDescriptor right) { }

			[CompilerGenerated]
			[NullableContext(2)]
			public static bool op_Inequality(PlatformDescriptor left, PlatformDescriptor right) { }

			[CompilerGenerated]
			[NullableContext(1)]
			protected override bool PrintMembers(StringBuilder builder) { }

			[CompilerGenerated]
			public void set_Faction(CharacterFaction value) { }

			[CompilerGenerated]
			public void set_PlatformKey(AssetKey value) { }

			[CompilerGenerated]
			[NullableContext(1)]
			public virtual string ToString() { }

		}

		private const string ROOT = "Assets/3D/Environment/CharacterPlatform/"; //Field offset: 0x0
		public static readonly AssetKey Scene; //Field offset: 0x0
		public static readonly List<PlatformDescriptor> Descriptors; //Field offset: 0x8

		[IteratorStateMachine(typeof(<_argsCustomPlatformNames>d__6))]
		private static IEnumerable<String> _argsCustomPlatformNames(IStaticDataProvider staticData) { }

		private static IEnumerable<CharacterFaction> _factionsWithPlatforms(IStaticDataProvider _) { }

		private static CharacterPlatforms() { }

		public static AssetKey CustomPlatform(string characterName) { }

		private static bool HasOverviewPlatform(CharacterFaction faction) { }

		public static AssetKey Platform(CharacterFaction faction) { }

		private static string PrefabPath(CharacterFaction faction) { }

	}

	internal static class CharacterSkills
	{
		private const string ROOT = "Assets/UI/Shared/CharacterOverview/CharacterSkills/"; //Field offset: 0x0
		public static readonly AssetKey SkillUpgradeConfirmationPopup; //Field offset: 0x0

		private static CharacterSkills() { }

	}

	internal static class CharacterUIs
	{
		private const string ROOT = "Assets/UI/Feature/Battle/CharacterUI/"; //Field offset: 0x0
		public static readonly AssetKey CharacterUI; //Field offset: 0x0
		public static readonly AssetKey BossEnemyUI; //Field offset: 0x8
		public static readonly AssetKey MiniBossEnemyUI; //Field offset: 0x10
		public static readonly AssetKey EliteEnemyUI; //Field offset: 0x18
		public static readonly AssetKey EnemyUI; //Field offset: 0x20
		public static readonly AssetKey DestructibleUI; //Field offset: 0x28

		private static CharacterUIs() { }

	}

	internal static class Chat
	{
		private const string ROOT = "Assets/UI/Feature/Chat/"; //Field offset: 0x0
		private const string DIALOGS = "Assets/UI/Feature/Chat/Dialogs/"; //Field offset: 0x0
		private const string TOOLTIPS = "Assets/UI/Feature/Chat/Tooltips/"; //Field offset: 0x0
		private const string POPUPS = "Assets/UI/Feature/Chat/Popups/"; //Field offset: 0x0
		public static readonly AssetKey Screen; //Field offset: 0x0
		public static readonly AssetKey SelectRoomDialog; //Field offset: 0x8
		public static readonly AssetKey ChatPlayerBanDialog; //Field offset: 0x10
		public static readonly AssetKey PlayerActionsTooltip; //Field offset: 0x18
		public static readonly AssetKey ReactionsTooltip; //Field offset: 0x20
		public static readonly AssetKey TutorialPopup; //Field offset: 0x28
		public static readonly AssetKey ModeratorPolicyPopup; //Field offset: 0x30
		public static readonly AssetKey ChatLimitReachedPopup; //Field offset: 0x38
		public static readonly AssetKey ChatUnsupportedPopup; //Field offset: 0x40

		private static Chat() { }

	}

	internal static class Clan
	{
		public static readonly AssetKey ChestReceivedDialog; //Field offset: 0x0
		private const string ROOT = "Assets/UI/Feature/Clan/"; //Field offset: 0x0
		private const string CHESTS_SPRITES_ROOT = "Assets/UI/Sprites/ClanRewardChests/"; //Field offset: 0x0
		public static readonly AssetKey LogoPrefab; //Field offset: 0x8
		public static readonly AssetKey LogoBakeMaterial; //Field offset: 0x10
		public static readonly AssetKey View; //Field offset: 0x18
		public static readonly AssetKey JoinTab; //Field offset: 0x20
		public static readonly AssetKey CreateTab; //Field offset: 0x28
		public static readonly AssetKey RatingsTab; //Field offset: 0x30
		public static readonly AssetKey InvitesTab; //Field offset: 0x38
		public static readonly AssetKey RequestsTab; //Field offset: 0x40
		public static readonly AssetKey InfoTab; //Field offset: 0x48
		public static readonly AssetKey MembersTab; //Field offset: 0x50
		public static readonly AssetKey ActivitiesTab; //Field offset: 0x58
		public static readonly AssetKey BossesTab; //Field offset: 0x60
		public static readonly AssetKey CreateConfirmationDialog; //Field offset: 0x68
		public static readonly AssetKey BenefitsDialog; //Field offset: 0x70
		public static readonly AssetKey DetailsDialog; //Field offset: 0x78
		public static readonly AssetKey RequirementsErrorDialog; //Field offset: 0x80
		public static readonly AssetKey QuickJoinDialog; //Field offset: 0x88
		public static readonly AssetKey LanguageSelectionDialog; //Field offset: 0x90
		public static readonly AssetKey MinPlayerLevelSelectionDialog; //Field offset: 0x98
		public static readonly AssetKey MinPowerSelectionDialog; //Field offset: 0xA0
		public static readonly AssetKey PermissionsDialog; //Field offset: 0xA8
		public static readonly AssetKey ChestRewardsPreviewDialog; //Field offset: 0xB0
		public static readonly AssetKey ActivityContributorsDialog; //Field offset: 0xB8
		public static readonly AssetKey ActivityTutorialDialog; //Field offset: 0xC0
		public static readonly AssetKey GenericInfoDialog; //Field offset: 0xC8
		public static readonly AssetKey NegativeConfirmationDialog; //Field offset: 0xD0
		public static readonly AssetKey MemberPreviewTooltip; //Field offset: 0xD8
		public static readonly AssetKey ClanBossChestConfig; //Field offset: 0xE0
		public static readonly AssetKey ActivityChestConfig; //Field offset: 0xE8

		private static Clan() { }

	}

	internal static class Configs
	{
		public static readonly AssetKey ClientTweaks; //Field offset: 0x0
		public static readonly AssetKey CommonVfxConfig; //Field offset: 0x8
		public static readonly AssetKey StartupShadersCollection; //Field offset: 0x10

		private static Configs() { }

	}

	[DontAnalyze("Creator avatar ids are assigned in the back-office and are absent from static data", new IL2CPP_TYPE_STRING[] {"Assets/UI/Feature/CreatorsAvatars/Sprites/"})]
	internal static class CreatorAvatars
	{
		private const string CREATOR_AVATARS_ROOT = "Assets/UI/Feature/CreatorsAvatars/Sprites/"; //Field offset: 0x0

		public static AssetKey Avatar(long creatorAvatarId) { }

	}

	internal static class CustomStatusEffects
	{
		[CompilerGenerated]
		private sealed class <>c
		{
			public static readonly <>c <>9; //Field offset: 0x0
			public static Func<CustomStatusEffect, Boolean> <>9__2_0; //Field offset: 0x8
			public static Func<CustomStatusEffect, Int64> <>9__2_1; //Field offset: 0x10

			private static <>c() { }

			public <>c() { }

			internal bool <_iconTypes>b__2_0(CustomStatusEffect effect) { }

			internal long <_iconTypes>b__2_1(CustomStatusEffect effect) { }

		}

		private const string ROOT = "Assets/UI/Feature/CustomStatusEffects/"; //Field offset: 0x0

		private static IEnumerable<Int64> _iconTypes(IStaticDataProvider staticData) { }

		public static AssetKey IconSpriteKey(long id) { }

	}

	internal static class Dialogs
	{
		private const string AUTH_ROOT = "Assets/UI/Core/Auth/"; //Field offset: 0x0
		private const string IN_APP_PURCHASES_ROOT = "Assets/UI/Core/InAppPurchases/"; //Field offset: 0x0
		private const string ERRORS_ROOT = "Assets/UI/Core/ErrorHandling/"; //Field offset: 0x0
		private const string APP_UPDATE = "Assets/UI/Feature/PopupSoftHardUpdate/Prefab/"; //Field offset: 0x0
		private const string CORE_POPUPS = "Assets/UI/Core/Popups/"; //Field offset: 0x0
		private const string CORE_DIALOGS = "Assets/UI/Core/Dialogs/"; //Field offset: 0x0
		public static readonly AssetKey AuthInitialLoginPopup; //Field offset: 0x0
		public static readonly AssetKey ConsentPopup; //Field offset: 0x8
		public static readonly AssetKey AuthAlreadyLinkedPopup; //Field offset: 0x10
		public static readonly AssetKey AuthSwitchAccountsPopup; //Field offset: 0x18
		public static readonly AssetKey AuthGuestLogoutPopup; //Field offset: 0x20
		public static readonly AssetKey AuthLogoutConfirmationPopup; //Field offset: 0x28
		public static readonly AssetKey AuthDeleteAccountPopup; //Field offset: 0x30
		public static readonly AssetKey AnotherDeviceLoginPopup; //Field offset: 0x38
		public static readonly AssetKey ActiveSessionOnAnotherDevicePopup; //Field offset: 0x40
		public static readonly AssetKey PrivacyPolicyPopup; //Field offset: 0x48
		public static readonly AssetKey TermsOfUsePopup; //Field offset: 0x50
		public static readonly AssetKey GenericConfirmationPopup; //Field offset: 0x58
		public static readonly AssetKey GearConfirmationPopup; //Field offset: 0x60
		public static readonly AssetKey GameExitConfirmationDialog; //Field offset: 0x68
		public static readonly AssetKey ErrorModalPopup; //Field offset: 0x70
		public static readonly AssetKey ConnectionRequiredPopup; //Field offset: 0x78
		public static readonly AssetKey OfflineModeEnabledPopup; //Field offset: 0x80
		public static readonly AssetKey CollectionLimitReachedPopup; //Field offset: 0x88
		public static readonly AssetKey NotEnoughResourcesPopup; //Field offset: 0x90
		public static readonly AssetKey NotEnoughEnergyPopup; //Field offset: 0x98
		public static readonly AssetKey FakePurchasePopup; //Field offset: 0xA0
		public static readonly AssetKey SoftUpdatePopup; //Field offset: 0xA8
		public static readonly AssetKey HardUpdatePopup; //Field offset: 0xB0
		public static readonly AssetKey ClaimUpdateRewardPopup; //Field offset: 0xB8
		public static readonly AssetKey PurchaseEnergyDialog; //Field offset: 0xC0
		public static readonly AssetKey PurchaseArenaTokensDialog; //Field offset: 0xC8
		public static readonly AssetKey PurchaseMultiBattleTokensDialog; //Field offset: 0xD0

		private static Dialogs() { }

	}

	[AttributeUsage(324)]
	internal class DontAnalyzeAttribute : Attribute
	{
		[CompilerGenerated]
		private readonly string <Reason>k__BackingField; //Field offset: 0x10
		[CompilerGenerated]
		private readonly String[] <FoldersToAlwaysIncludeInCatalog>k__BackingField; //Field offset: 0x18

		public String[] FoldersToAlwaysIncludeInCatalog
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		public string Reason
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		public DontAnalyzeAttribute(string reason, String[] foldersToAlwaysIncludeInCatalog) { }

		[CompilerGenerated]
		public String[] get_FoldersToAlwaysIncludeInCatalog() { }

		[CompilerGenerated]
		public string get_Reason() { }

	}

	internal static class Elements
	{
		private const string ROOT = "Assets/UI/Core/Sprites/Elements/"; //Field offset: 0x0

		private static IEnumerable<Element> _args(IStaticDataProvider _) { }

		public static AssetKey Key(Element element) { }

	}

	internal static class FeatureUnlock
	{
		private const string ROOT = "Assets/UI/Feature/FeatureUnlock/"; //Field offset: 0x0
		public static readonly AssetKey TowerUnlockView; //Field offset: 0x0
		public static readonly AssetKey TowerHardUnlockView; //Field offset: 0x8
		public static readonly AssetKey MultiBattleUnlockView; //Field offset: 0x10
		public static readonly AssetKey ArenaPvpUnlockView; //Field offset: 0x18
		public static readonly AssetKey FuseUnlockView; //Field offset: 0x20
		public static readonly AssetKey TournamentsUnlockView; //Field offset: 0x28
		public static readonly AssetKey VipStatusUnlockView; //Field offset: 0x30

		private static FeatureUnlock() { }

	}

	internal static class FilterDialogs
	{
		private const string ROOT = "Assets/UI/Feature/Filters/Dialogs/"; //Field offset: 0x0
		public static readonly AssetKey HeroFilterDialog; //Field offset: 0x0
		public static readonly AssetKey AnimaFilterDialog; //Field offset: 0x8
		public static readonly AssetKey ClanFilterDialog; //Field offset: 0x10

		private static FilterDialogs() { }

	}

	internal static class FirstHeroSelection
	{
		private const string ROOT = "Assets/UI/Feature/FirstHeroSelection/"; //Field offset: 0x0
		public static readonly AssetKey Screen; //Field offset: 0x0
		public static readonly AssetKey Scene; //Field offset: 0x8
		public static readonly AssetKey ShadersCollection; //Field offset: 0x10

		private static FirstHeroSelection() { }

	}

	internal static class GameRewards
	{
		public static readonly AssetKey Medium; //Field offset: 0x0
		public static readonly AssetKey Large; //Field offset: 0x8
		public static readonly AssetKey Small; //Field offset: 0x10
		public static readonly AssetKey ShopCustom; //Field offset: 0x18
		public static readonly AssetKey ChestsMedium; //Field offset: 0x20
		public static readonly AssetKey ChestsShopCustom; //Field offset: 0x28
		public static readonly AssetKey Relics; //Field offset: 0x30
		public static readonly AssetKey Accessories; //Field offset: 0x38
		public static readonly AssetKey AvatarFrames; //Field offset: 0x40
		public static readonly AssetKey CharacterMedium; //Field offset: 0x48
		public static readonly AssetKey CharacterLarge; //Field offset: 0x50

		private static GameRewards() { }

	}

	internal static class Gear
	{
		[CompilerGenerated]
		private sealed class <_accessoryFactions>d__12 : IEnumerable<CharacterFaction>, IEnumerable, IEnumerator<CharacterFaction>, IEnumerator, IDisposable
		{
			private int <>1__state; //Field offset: 0x10
			private CharacterFaction <>2__current; //Field offset: 0x14
			private int <>l__initialThreadId; //Field offset: 0x18
			private IEnumerator<CharacterFaction> <>7__wrap1; //Field offset: 0x20

			private override CharacterFaction System.Collections.Generic.IEnumerator<Shared.Choreograph.Models.CharacterFaction>.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			private override object System.Collections.IEnumerator.Current
			{
				[DebuggerHidden]
				private get { } //Length: 92
			}

			[DebuggerHidden]
			public <_accessoryFactions>d__12(int <>1__state) { }

			private void <>m__Finally1() { }

			private override bool MoveNext() { }

			[DebuggerHidden]
			private override IEnumerator<CharacterFaction> System.Collections.Generic.IEnumerable<Shared.Choreograph.Models.CharacterFaction>.GetEnumerator() { }

			[DebuggerHidden]
			private override CharacterFaction System.Collections.Generic.IEnumerator<Shared.Choreograph.Models.CharacterFaction>.get_Current() { }

			[DebuggerHidden]
			private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

			[DebuggerHidden]
			private override object System.Collections.IEnumerator.get_Current() { }

			[DebuggerHidden]
			private override void System.Collections.IEnumerator.Reset() { }

			[DebuggerHidden]
			private override void System.IDisposable.Dispose() { }

		}

		[CompilerGenerated]
		private sealed class <_accessorySlots>d__13 : IEnumerable<AccessorySlot>, IEnumerable, IEnumerator<AccessorySlot>, IEnumerator, IDisposable
		{
			private int <>1__state; //Field offset: 0x10
			private AccessorySlot <>2__current; //Field offset: 0x14
			private int <>l__initialThreadId; //Field offset: 0x18
			private IEnumerator<AccessorySlot> <>7__wrap1; //Field offset: 0x20

			private override AccessorySlot System.Collections.Generic.IEnumerator<Shared.Choreograph.Models.AccessorySlot>.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			private override object System.Collections.IEnumerator.Current
			{
				[DebuggerHidden]
				private get { } //Length: 92
			}

			[DebuggerHidden]
			public <_accessorySlots>d__13(int <>1__state) { }

			private void <>m__Finally1() { }

			private override bool MoveNext() { }

			[DebuggerHidden]
			private override IEnumerator<AccessorySlot> System.Collections.Generic.IEnumerable<Shared.Choreograph.Models.AccessorySlot>.GetEnumerator() { }

			[DebuggerHidden]
			private override AccessorySlot System.Collections.Generic.IEnumerator<Shared.Choreograph.Models.AccessorySlot>.get_Current() { }

			[DebuggerHidden]
			private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

			[DebuggerHidden]
			private override object System.Collections.IEnumerator.get_Current() { }

			[DebuggerHidden]
			private override void System.Collections.IEnumerator.Reset() { }

			[DebuggerHidden]
			private override void System.IDisposable.Dispose() { }

		}

		private const string RELIC_SETS_ROOT = "Assets/UI/Sprites/RelicSets/"; //Field offset: 0x0
		private const string RELIC_ITEMS_ROOT = "Assets/UI/Sprites/RelicItems/"; //Field offset: 0x0
		private const string ACCESSORY_FACTIONS_ROOT = "Assets/UI/Sprites/AccessoryFactions/"; //Field offset: 0x0
		private const string ACCESSORY_ITEMS_ROOT = "Assets/UI/Sprites/AccessoryItems/"; //Field offset: 0x0
		public static readonly AssetKey SetPlaceholder; //Field offset: 0x0

		[IteratorStateMachine(typeof(<_accessoryFactions>d__12))]
		private static IEnumerable<CharacterFaction> _accessoryFactions(IStaticDataProvider _) { }

		[IteratorStateMachine(typeof(<_accessorySlots>d__13))]
		private static IEnumerable<AccessorySlot> _accessorySlots(IStaticDataProvider _) { }

		private static IEnumerable<RelicSet> _relicSets(IStaticDataProvider _) { }

		private static IEnumerable<RelicSlot> _relicSlots(IStaticDataProvider _) { }

		private static Gear() { }

		public static AssetKey AccessoryFactionSprite(CharacterFaction faction) { }

		public static AssetKey AccessorySprite(CharacterFaction faction, AccessorySlot slot) { }

		public static AssetKey RandomSetSprite(RelicSet set) { }

		public static AssetKey RelicSetSprite(RelicSet set) { }

		public static AssetKey RelicSprite(RelicSet set, RelicSlot slot) { }

	}

	internal static class GlobalEvents
	{
		private const string ROOT = "Assets/UI/Feature/GlobalEvents/"; //Field offset: 0x0
		private const string BACKGROUNDS = "Assets/UI/Shared/Backgrounds/"; //Field offset: 0x0
		private const string ICONS = "Assets/UI/Feature/GlobalEvents/Sprites/Icons/"; //Field offset: 0x0
		private const string ACTIVITY_IMAGES = "Assets/UI/Feature/GlobalEvents/Sprites/ActivityImages/"; //Field offset: 0x0
		private const string RESOURCE_ICONS = "Assets/UI/Feature/GlobalEvents/Sprites/ResourceIcons/"; //Field offset: 0x0
		public static readonly AssetKey Config; //Field offset: 0x0
		public static readonly AssetKey View; //Field offset: 0x8
		public static readonly AssetKey CalendarTab; //Field offset: 0x10
		public static readonly AssetKey TournamentTimeline; //Field offset: 0x18
		public static readonly AssetKey TournamentTab; //Field offset: 0x20
		public static readonly AssetKey Tab_TournamentMultiContentTemplate; //Field offset: 0x28
		public static readonly AssetKey GetLegendaryTab; //Field offset: 0x30
		public static readonly AssetKey GetLegendaryActivityRulesPopup; //Field offset: 0x38
		public static readonly AssetKey NoviceTournamentTab; //Field offset: 0x40
		public static readonly AssetKey EventPreviewTooltip; //Field offset: 0x48
		public static readonly AssetKey UnknownIconSpriteKey; //Field offset: 0x50
		public static readonly AssetKey UnknownActivityImageSpriteKey; //Field offset: 0x58
		public static readonly AssetKey CollectDungeonRelics1Rules; //Field offset: 0x60
		public static readonly AssetKey CollectDungeonRelics2Rules; //Field offset: 0x68
		public static readonly AssetKey CollectDungeonRelics6Rules; //Field offset: 0x70
		public static readonly AssetKey ClanBoss1Rules; //Field offset: 0x78
		public static readonly AssetKey UpgradeRelicsRules; //Field offset: 0x80
		public static readonly AssetKey CollectDungeonEssenceRules; //Field offset: 0x88
		public static readonly AssetKey CollectDungeonMedalsRules; //Field offset: 0x90
		public static readonly AssetKey WinArenaMedalsRules; //Field offset: 0x98
		public static readonly AssetKey SummonInvokerRules; //Field offset: 0xA0
		public static readonly AssetKey SummonTitanRules; //Field offset: 0xA8
		public static readonly AssetKey UpgradeInvokerRules; //Field offset: 0xB0
		public static readonly AssetKey UpgradeTitanRules; //Field offset: 0xB8
		public static readonly AssetKey NoviceTournamentRules; //Field offset: 0xC0
		public static readonly AssetKey CampaignProgressionRules; //Field offset: 0xC8
		public static readonly AssetKey CollectDungeonTitanRules; //Field offset: 0xD0
		public static readonly AssetKey DynamicRules; //Field offset: 0xD8
		public static readonly AssetKey ChallengeCompletePopup; //Field offset: 0xE0

		private static IEnumerable<String> _activityImageKeys(IStaticDataProvider staticData) { }

		private static IEnumerable<String> _backgroundKeys(IStaticDataProvider staticData) { }

		private static IEnumerable<String> _iconKeys(IStaticDataProvider staticData) { }

		private static IEnumerable<String> _resourceKeys(IStaticDataProvider staticData) { }

		private static GlobalEvents() { }

		public static AssetKey ActivityImageSpriteKey(string activityImageKey) { }

		public static AssetKey BackgroundViewKey(string backgroundKey) { }

		public static AssetKey IconSpriteKey(string iconKey) { }

		public static AssetKey ResourceIconSpriteKey(string resourceIconKey) { }

	}

	internal class HeroFuse
	{
		private const string ROOT = "Assets/UI/Feature/Fuse/"; //Field offset: 0x0
		public static readonly AssetKey HeroFuseScreenViewAssetKey; //Field offset: 0x0
		public static readonly AssetKey FuseCardPopupNoHeroViewAssetKey; //Field offset: 0x8
		public static readonly AssetKey FuseCardPopupActionViewAssetKey; //Field offset: 0x10
		public static readonly AssetKey ConfirmationDialog; //Field offset: 0x18
		public static readonly AssetKey FuseHelpDialogViewAssetKey; //Field offset: 0x20

		private static HeroFuse() { }

		public HeroFuse() { }

	}

	internal static class HeroOverview
	{
		private const string ROOT = "Assets/UI/Feature/HeroOverview/"; //Field offset: 0x0
		private const string TOOLTIPS = "Assets/UI/Feature/HeroOverview/Tooltips/"; //Field offset: 0x0
		private const string DIALOGS = "Assets/UI/Feature/HeroOverview/Dialogs/"; //Field offset: 0x0
		private const string PANELS = "Assets/UI/Feature/HeroOverview/Panels/"; //Field offset: 0x0
		public static readonly AssetKey View; //Field offset: 0x0
		public static readonly AssetKey ProfileTab; //Field offset: 0x8
		public static readonly AssetKey LevelUpTab; //Field offset: 0x10
		public static readonly AssetKey AscensionTab; //Field offset: 0x18
		public static readonly AssetKey SoulSignTab; //Field offset: 0x20
		public static readonly AssetKey EquipmentTab; //Field offset: 0x28
		public static readonly AssetKey SkillsTab; //Field offset: 0x30
		public static readonly AssetKey BioTab; //Field offset: 0x38
		public static readonly AssetKey HeroQuickLevelUpDialog; //Field offset: 0x40
		public static readonly AssetKey HeroQuickAscensionDialog; //Field offset: 0x48
		public static readonly AssetKey GearRemoveConfirmation; //Field offset: 0x50
		public static readonly AssetKey GearFilterDialog; //Field offset: 0x58
		public static readonly AssetKey AccessoriesTutorialDialog; //Field offset: 0x60
		public static readonly AssetKey AutoEquipTutorialDialog; //Field offset: 0x68
		public static readonly AssetKey AccessorySlotUnlockInformation; //Field offset: 0x70
		public static readonly AssetKey HeroLevelUpResultDialog; //Field offset: 0x78
		public static readonly AssetKey HeroAscensionResultDialog; //Field offset: 0x80
		public static readonly AssetKey GearUpgradeResultDialog; //Field offset: 0x88
		public static readonly AssetKey SetFullDescription; //Field offset: 0x90
		public static readonly AssetKey HeroSell; //Field offset: 0x98
		public static readonly AssetKey HeroSellConfirmation; //Field offset: 0xA0
		public static readonly AssetKey HeroUnlockConfirmation; //Field offset: 0xA8
		public static readonly AssetKey HeroLegendaryCannotBeUsedInAscendDialog; //Field offset: 0xB0
		public static readonly AssetKey HeroInArenaCannotBeUsedInAscendDialog; //Field offset: 0xB8
		public static readonly AssetKey ChromaHeroConvertDialog; //Field offset: 0xC0
		public static readonly AssetKey ChromaHeroSelectDialog; //Field offset: 0xC8
		public static readonly AssetKey EquipmentManagement; //Field offset: 0xD0
		public static readonly AssetKey EquippedItemPreview; //Field offset: 0xD8
		public static readonly AssetKey GearAutoEquip; //Field offset: 0xE0
		public static readonly AssetKey GearUpgrade; //Field offset: 0xE8
		public static readonly AssetKey GearSetApply; //Field offset: 0xF0
		public static readonly AssetKey SoulSignNode; //Field offset: 0xF8
		public static readonly AssetKey SoulSignStarUnlock; //Field offset: 0x100
		public static readonly AssetKey SoulSignBackgroundPlaceholder; //Field offset: 0x108
		public static readonly AssetKey GearSetBonusTooltip; //Field offset: 0x110
		public static readonly AssetKey HeroLevelUpMaxPotionsSelectedTooltip; //Field offset: 0x118
		public static readonly AssetKey HeroSkillInfoTooltip; //Field offset: 0x120
		public static readonly AssetKey HeroSkillProgressionTooltip; //Field offset: 0x128
		public static readonly AssetKey HeroToleranceInfoTooltip; //Field offset: 0x130
		public static readonly AssetKey HeroPassiveSkillInfoTooltip; //Field offset: 0x138
		public static readonly AssetKey StatusEffectInfoTooltip; //Field offset: 0x140
		public static readonly AssetKey CustomStatusEffectInfoTooltip; //Field offset: 0x148
		public static readonly AssetKey CorruptionInfoTooltip; //Field offset: 0x150
		public static readonly AssetKey MovementEffectInfoTooltip; //Field offset: 0x158

		private static HeroOverview() { }

		public static AssetKey SoulSignsBackground(SoulSign sign) { }

		private static AssetKey TooltipKey(string tooltipName) { }

	}

	internal interface IAssetKeyProvider
	{

		public List<AssetKey> GetAllAssetKeys() { }

	}

	internal static class InBattleIndicators
	{
		private const string ROOT = "Assets/VFX_All/VFX_Behaviour/"; //Field offset: 0x0
		public static readonly AssetKey Selected; //Field offset: 0x0
		public static readonly AssetKey Target; //Field offset: 0x8
		public static readonly AssetKey TeamTarget; //Field offset: 0x10
		public static readonly AssetKey SoundListener; //Field offset: 0x18
		public static readonly AssetKey Fake; //Field offset: 0x20

		private static InBattleIndicators() { }

	}

	internal static class IndexScreen
	{
		private const string ROOT = "Assets/UI/Feature/Index/"; //Field offset: 0x0
		private const string SCREENS = "Assets/UI/Feature/Index/Screens/"; //Field offset: 0x0
		private const string SPRITES = "Assets/UI/Feature/Index/Sprites/"; //Field offset: 0x0
		public static readonly AssetKey IndexAnimaListView; //Field offset: 0x0
		public static readonly AssetKey IndexAnimaOverview; //Field offset: 0x8
		public static readonly AssetKey IndexHeroListView; //Field offset: 0x10
		public static readonly AssetKey IndexHeroOverview; //Field offset: 0x18
		public static readonly AssetKey IndexScreenView; //Field offset: 0x20
		public static readonly AssetKey IndexSelectionView; //Field offset: 0x28
		public static readonly AssetKey AnimaFactionCardPlaceholder; //Field offset: 0x30
		public static readonly AssetKey HeroFactionCardPlaceholder; //Field offset: 0x38

		private static IEnumerable<CharacterFaction> _animaFactions(IStaticDataProvider staticData) { }

		private static IEnumerable<CharacterFaction> _heroFactions(IStaticDataProvider staticData) { }

		private static IndexScreen() { }

		public static AssetKey AnimaFactionCard(CharacterFaction faction) { }

		public static AssetKey HeroFactionCard(CharacterFaction faction) { }

	}

	internal static class LevelLocked
	{
		private const string ROOT = "Assets/UI/Feature/LevelLocked/"; //Field offset: 0x0
		public static readonly AssetKey LevelLockedDialog; //Field offset: 0x0

		private static LevelLocked() { }

	}

	internal static class Levels
	{
		[CompilerGenerated]
		private sealed class <_availableLevels>d__3 : IEnumerable<LevelInfo>, IEnumerable, IEnumerator<LevelInfo>, IEnumerator, IDisposable
		{
			private int <>1__state; //Field offset: 0x10
			private LevelInfo <>2__current; //Field offset: 0x18
			private int <>l__initialThreadId; //Field offset: 0x20
			private IStaticDataProvider sd; //Field offset: 0x28
			public IStaticDataProvider <>3__sd; //Field offset: 0x30
			private Enumerator<LevelInfo> <>7__wrap1; //Field offset: 0x38

			private override LevelInfo System.Collections.Generic.IEnumerator<Shared.Logic.Configs.LevelInfo>.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			private override object System.Collections.IEnumerator.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			[DebuggerHidden]
			public <_availableLevels>d__3(int <>1__state) { }

			private void <>m__Finally1() { }

			private override bool MoveNext() { }

			[DebuggerHidden]
			private override IEnumerator<LevelInfo> System.Collections.Generic.IEnumerable<Shared.Logic.Configs.LevelInfo>.GetEnumerator() { }

			[DebuggerHidden]
			private override LevelInfo System.Collections.Generic.IEnumerator<Shared.Logic.Configs.LevelInfo>.get_Current() { }

			[DebuggerHidden]
			private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

			[DebuggerHidden]
			private override object System.Collections.IEnumerator.get_Current() { }

			[DebuggerHidden]
			private override void System.Collections.IEnumerator.Reset() { }

			[DebuggerHidden]
			private override void System.IDisposable.Dispose() { }

		}

		[CompilerGenerated]
		private sealed class <_availableLevelsWithUniqueScenes>d__2 : IEnumerable<LevelInfo>, IEnumerable, IEnumerator<LevelInfo>, IEnumerator, IDisposable
		{
			private int <>1__state; //Field offset: 0x10
			private LevelInfo <>2__current; //Field offset: 0x18
			private int <>l__initialThreadId; //Field offset: 0x20
			private IStaticDataProvider sd; //Field offset: 0x28
			public IStaticDataProvider <>3__sd; //Field offset: 0x30
			private HashSet<String> <seen>5__2; //Field offset: 0x38
			private Enumerator<LevelInfo> <>7__wrap2; //Field offset: 0x40

			private override LevelInfo System.Collections.Generic.IEnumerator<Shared.Logic.Configs.LevelInfo>.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			private override object System.Collections.IEnumerator.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			[DebuggerHidden]
			public <_availableLevelsWithUniqueScenes>d__2(int <>1__state) { }

			private void <>m__Finally1() { }

			private override bool MoveNext() { }

			[DebuggerHidden]
			private override IEnumerator<LevelInfo> System.Collections.Generic.IEnumerable<Shared.Logic.Configs.LevelInfo>.GetEnumerator() { }

			[DebuggerHidden]
			private override LevelInfo System.Collections.Generic.IEnumerator<Shared.Logic.Configs.LevelInfo>.get_Current() { }

			[DebuggerHidden]
			private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

			[DebuggerHidden]
			private override object System.Collections.IEnumerator.get_Current() { }

			[DebuggerHidden]
			private override void System.Collections.IEnumerator.Reset() { }

			[DebuggerHidden]
			private override void System.IDisposable.Dispose() { }

		}


		[IteratorStateMachine(typeof(<_availableLevels>d__3))]
		private static IEnumerable<LevelInfo> _availableLevels(IStaticDataProvider sd) { }

		[IteratorStateMachine(typeof(<_availableLevelsWithUniqueScenes>d__2))]
		private static IEnumerable<LevelInfo> _availableLevelsWithUniqueScenes(IStaticDataProvider sd) { }

		public static bool LevelIsAvailable(LevelInfo info) { }

		public static AssetKey Scene(LevelInfo info) { }

		public static AssetKey ShadersCollection(LevelInfo info) { }

	}

	internal static class LoadingScreens
	{
		private const string ROOT = "Assets/UI/Core/Loading/"; //Field offset: 0x0
		public static readonly AssetKey DownloadScreenView; //Field offset: 0x0
		public static readonly AssetKey InstantLoadingView; //Field offset: 0x8
		public static readonly AssetKey BlackLoadingView; //Field offset: 0x10
		public static readonly AssetKey SpinnerLoadingView; //Field offset: 0x18
		public static readonly AssetKey MainLoadingScreen; //Field offset: 0x20

		private static LoadingScreens() { }

	}

	internal static class Lobby
	{
		internal static class LobbyHome
		{
			private const string ROOT_SCREEN = "Assets/UI/Feature/Lobby/Screens/Lobby/"; //Field offset: 0x0
			private const string ROOT_SCENE = "Assets/Scenes/Lobby/"; //Field offset: 0x0
			public static readonly AssetKey Screen; //Field offset: 0x0
			public static readonly AssetKey PlayerInventoryView; //Field offset: 0x8
			public static readonly AssetKey Scene; //Field offset: 0x10
			public static readonly AssetKey ShadersCollection; //Field offset: 0x18
			public static readonly AssetKey SupportDialog; //Field offset: 0x20
			public static readonly AssetKey BurgerMenu; //Field offset: 0x28
			public static readonly AssetKey EventsButtonVisualsConfig; //Field offset: 0x30
			public static readonly AssetKey InboxDialog; //Field offset: 0x38
			public static readonly AssetKey SceneV2; //Field offset: 0x40
			public static readonly AssetKey HalloweenSceneV2; //Field offset: 0x48
			public static readonly AssetKey ChatInLobbyMessagesOSA; //Field offset: 0x50

			private static LobbyHome() { }

		}

		internal static class Quests
		{
			private const string ROOT = "Assets/UI/Feature/Lobby/Screens/Quests/"; //Field offset: 0x0
			public static readonly AssetKey Screen; //Field offset: 0x0
			public static readonly AssetKey DescriptionDialog; //Field offset: 0x8

			private static Quests() { }

		}

		internal static class Settings
		{
			private const string ROOT = "Assets/UI/Feature/Lobby/Screens/Settings/"; //Field offset: 0x0
			private const string DIALOGS = "Assets/UI/Feature/Lobby/Screens/Settings/Dialogs/"; //Field offset: 0x0
			public static readonly AssetKey Screen; //Field offset: 0x0
			private const string TABS = "Assets/UI/Feature/Lobby/Screens/Settings/Tabs/"; //Field offset: 0x0
			public static readonly AssetKey DescriptionPopup; //Field offset: 0x8
			public static readonly AssetKey DeleteProfileConfirmationPopup; //Field offset: 0x10
			public static readonly AssetKey AccountTabView; //Field offset: 0x18
			public static readonly AssetKey AccountProfilesTabView; //Field offset: 0x20
			public static readonly AssetKey ControlsTabView; //Field offset: 0x28
			public static readonly AssetKey GamepadGlyphSet; //Field offset: 0x30
			public static readonly AssetKey SoundTabView; //Field offset: 0x38
			public static readonly AssetKey LanguageTabView; //Field offset: 0x40
			public static readonly AssetKey GraphicsTabView; //Field offset: 0x48
			public static readonly AssetKey DownloadsTabView; //Field offset: 0x50
			public static readonly AssetKey NotificationsTabView; //Field offset: 0x58

			private static Settings() { }

		}

		private const string FEATURE_ROOT = "Assets/UI/Feature/Lobby/"; //Field offset: 0x0
		private const string FEATURE_SCREENS = "Assets/UI/Feature/Lobby/Screens/"; //Field offset: 0x0

	}

	internal static class LocalNotifications
	{
		private const string ROOT = "Assets/UI/Feature/LocalNotifications/"; //Field offset: 0x0
		public static readonly AssetKey PermitPopupView; //Field offset: 0x0

		private static LocalNotifications() { }

	}

	internal static class Map
	{
		[CompilerGenerated]
		private sealed class <>c
		{
			public static readonly <>c <>9; //Field offset: 0x0
			public static Func<RegionId, Boolean> <>9__51_0; //Field offset: 0x8
			public static Func<RegionId, Boolean> <>9__52_0; //Field offset: 0x10

			private static <>c() { }

			public <>c() { }

			internal bool <_campaignRegionIds>b__51_0(RegionId x) { }

			internal bool <_towerRegionIds>b__52_0(RegionId x) { }

		}

		public const string KINGDOMS_ROOT = "Assets/UI/Sprites/Kingdoms/"; //Field offset: 0x0
		private const string ROOT = "Assets/UI/Feature/Map/"; //Field offset: 0x0
		public const string SPRITES = "Assets/UI/Feature/Map/Sprites/"; //Field offset: 0x0
		private const string SCREENS = "Assets/UI/Feature/Map/Screens/"; //Field offset: 0x0
		private const string MODE_SELECTION = "Assets/UI/Feature/Map/Screens/GameModeSelection/"; //Field offset: 0x0
		private const string MODE_SELECTION_SPRITES = "Assets/UI/Sprites/GameModes/"; //Field offset: 0x0
		public const string PORTRAITS_ROOT = "Assets/UI/Feature/Map/Sprites/Portraits/"; //Field offset: 0x0
		private const string SMALL_ICONS_ROOT = "Assets/UI/Core/Sprites/GameModesIcons/"; //Field offset: 0x0
		private const string REGION_ICONS_ROOT = "Assets/UI/Sprites/RegionIcons/"; //Field offset: 0x0
		private const string TOWER_SPRITES_ROOT = "Assets/UI/Feature/Map/Sprites/Tower/"; //Field offset: 0x0
		public static readonly AssetKey Scene; //Field offset: 0x0
		public static readonly AssetKey Screen; //Field offset: 0x8
		public static readonly AssetKey Config; //Field offset: 0x10
		public static readonly AssetKey BattleLockedByBackgroundBattleDialog; //Field offset: 0x18
		public static readonly AssetKey ModeButton; //Field offset: 0x20
		public static readonly AssetKey ClanModeButton; //Field offset: 0x28
		public static readonly AssetKey GameItemHolder; //Field offset: 0x30
		public static readonly AssetKey EnemyItem; //Field offset: 0x38
		public static readonly AssetKey StarsDialogRewardItem; //Field offset: 0x40
		public static readonly AssetKey CampaignLevelsListItem; //Field offset: 0x48
		public static readonly AssetKey CampaignChapterSelectorItem; //Field offset: 0x50
		public static readonly AssetKey VipBonusesTooltip; //Field offset: 0x58
		public static readonly AssetKey RelicDungeonLevelsListItem; //Field offset: 0x60
		public static readonly AssetKey ResourceDungeonLevelsListItem; //Field offset: 0x68
		public static readonly AssetKey ClanBossStagesInfoListItem; //Field offset: 0x70
		public static readonly AssetKey TowerFloorLevelItem; //Field offset: 0x78
		public static readonly AssetKey CampaignStarsDialog; //Field offset: 0x80
		public static readonly AssetKey CampaignMissionsInfo; //Field offset: 0x88
		public static readonly AssetKey DungeonStagesInfo; //Field offset: 0x90
		public static readonly AssetKey ClanBoss1StagesInfo; //Field offset: 0x98
		public static readonly AssetKey ClanBoss1TutorialDialog; //Field offset: 0xA0
		public static readonly AssetKey ClanBoss2StagesInfo; //Field offset: 0xA8
		public static readonly AssetKey ClanBoss2TutorialDialog; //Field offset: 0xB0
		public static readonly AssetKey ChestClaimRequiredDialog; //Field offset: 0xB8
		public static readonly AssetKey ClanBossRewardsPopup; //Field offset: 0xC0
		public static readonly AssetKey TowerFloorsInfo; //Field offset: 0xC8
		public static readonly AssetKey TowersTutorialPopup; //Field offset: 0xD0
		public static readonly AssetKey LevelLockedByDayDialog; //Field offset: 0xD8
		public static readonly AssetKey FloorCompletedDialog; //Field offset: 0xE0
		public static readonly AssetKey TowerLeaderboardDialog; //Field offset: 0xE8
		public static readonly AssetKey DifficultySelector; //Field offset: 0xF0
		public static readonly AssetKey TowerDifficultySelector; //Field offset: 0xF8
		public static readonly AssetKey DungeonRelicsTutorialDialog; //Field offset: 0x100
		public static readonly AssetKey ArenaPVPTutorialDialog; //Field offset: 0x108
		public static readonly AssetKey ModeSelectorView; //Field offset: 0x110
		public static readonly AssetKey ShadersCollection; //Field offset: 0x118
		public static readonly AssetKey TowerMarkerIconPreset; //Field offset: 0x120

		private static IEnumerable<RegionId> _campaignRegionIds(IStaticDataProvider _) { }

		private static IEnumerable<MapMode> _mapModes(IStaticDataProvider _) { }

		private static IEnumerable<RegionId> _towerRegionIds(IStaticDataProvider _) { }

		private static Map() { }

		public static AssetKey CampaignRegionIcon(RegionId regionId) { }

		public static AssetKey ModeSelectionIcon(MapMode mode) { }

		public static AssetKey ModeSelectionSprite(MapMode mode) { }

		public static AssetKey TowerFloorSpritesCollection(RegionId regionId) { }

	}

	internal static class Placeholders
	{
		private const string ROOT = "Assets/UI/Core/Sprites/Placeholders/"; //Field offset: 0x0
		public static readonly AssetKey PortraitAnima; //Field offset: 0x0
		public static readonly AssetKey PortraitEnemy; //Field offset: 0x8
		public static readonly AssetKey PortraitHero; //Field offset: 0x10
		public static readonly AssetKey PortraitHeroLoader; //Field offset: 0x18
		public static readonly AssetKey ResourceIcon; //Field offset: 0x20
		public static readonly AssetKey ResourceRewardIcon; //Field offset: 0x28
		public static readonly AssetKey PlayerAvatar; //Field offset: 0x30
		public static readonly AssetKey GearItemLoader; //Field offset: 0x38
		public static readonly AssetKey SkillIcon; //Field offset: 0x40

		private static Placeholders() { }

		private static AssetKey PlaceholderKey(string name) { }

	}

	internal static class PlayerIdentity
	{
		[CompilerGenerated]
		private sealed class <_avatarFrameIds>d__3 : IEnumerable<AvatarFrameId>, IEnumerable, IEnumerator<AvatarFrameId>, IEnumerator, IDisposable
		{
			private int <>1__state; //Field offset: 0x10
			private AvatarFrameId <>2__current; //Field offset: 0x14
			private int <>l__initialThreadId; //Field offset: 0x18
			private IEnumerator<AvatarFrameId> <>7__wrap1; //Field offset: 0x20

			private override AvatarFrameId System.Collections.Generic.IEnumerator<Shared.Choreograph.Models.AvatarFrameId>.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			private override object System.Collections.IEnumerator.Current
			{
				[DebuggerHidden]
				private get { } //Length: 92
			}

			[DebuggerHidden]
			public <_avatarFrameIds>d__3(int <>1__state) { }

			private void <>m__Finally1() { }

			private override bool MoveNext() { }

			[DebuggerHidden]
			private override IEnumerator<AvatarFrameId> System.Collections.Generic.IEnumerable<Shared.Choreograph.Models.AvatarFrameId>.GetEnumerator() { }

			[DebuggerHidden]
			private override AvatarFrameId System.Collections.Generic.IEnumerator<Shared.Choreograph.Models.AvatarFrameId>.get_Current() { }

			[DebuggerHidden]
			private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

			[DebuggerHidden]
			private override object System.Collections.IEnumerator.get_Current() { }

			[DebuggerHidden]
			private override void System.Collections.IEnumerator.Reset() { }

			[DebuggerHidden]
			private override void System.IDisposable.Dispose() { }

		}

		private const string AVATAR_FRAMES = "Assets/UI/Prefabs/GameItemsContainers/AvatarFrames/"; //Field offset: 0x0
		private const string FRAME_PREFABS = "Assets/UI/Prefabs/GameItemsContainers/AvatarFrames/Prefabsv2/"; //Field offset: 0x0

		[IteratorStateMachine(typeof(<_avatarFrameIds>d__3))]
		private static IEnumerable<AvatarFrameId> _avatarFrameIds(IStaticDataProvider _) { }

		public static AssetKey AvatarFrame(AvatarFrameId frameId) { }

	}

	internal static class PlayerLevelUp
	{
		private const string ROOT = "Assets/UI/Feature/PlayerLevelUp/"; //Field offset: 0x0
		public static readonly AssetKey PlayerLevelUpPopupView; //Field offset: 0x0

		private static PlayerLevelUp() { }

	}

	internal static class PlayerNickname
	{
		private const string ROOT = "Assets/UI/Feature/PlayerNameChange/"; //Field offset: 0x0
		public static readonly AssetKey PlayerNicknameChangeView; //Field offset: 0x0

		private static PlayerNickname() { }

	}

	internal static class PlayerProfile
	{
		private const string ROOT = "Assets/UI/Feature/PlayerProfile/"; //Field offset: 0x0
		public static readonly AssetKey PlayerProfileView; //Field offset: 0x0
		public static readonly AssetKey PlayerProfileExternalDialog; //Field offset: 0x8
		public static readonly AssetKey ClanInviteCooldownDialog; //Field offset: 0x10
		public static readonly AssetKey SummaryTab; //Field offset: 0x18
		public static readonly AssetKey VipStatusTab; //Field offset: 0x20
		public static readonly AssetKey AvatarTab; //Field offset: 0x28
		public static readonly AssetKey VipStatusLoginPointPopup; //Field offset: 0x30
		public static readonly AssetKey VipBonusesTutorialPopup; //Field offset: 0x38
		public static readonly AssetKey VipDailyPointsRewardPopup; //Field offset: 0x40
		public static readonly AssetKey VipDailyChestPreviewPopup; //Field offset: 0x48
		public static readonly AssetKey VipStatusLevelUpView; //Field offset: 0x50

		private static PlayerProfile() { }

	}

	internal static class Portraits
	{
		[CompilerGenerated]
		private sealed class <>c
		{
			public static readonly <>c <>9; //Field offset: 0x0
			public static Func<CharacterConfig, Boolean> <>9__4_0; //Field offset: 0x8
			public static Func<CharacterConfig, Boolean> <>9__6_0; //Field offset: 0x10

			private static <>c() { }

			public <>c() { }

			internal bool <_enemiesNames>b__6_0(CharacterConfig c) { }

			internal bool <_heroesNames>b__4_0(CharacterConfig c) { }

		}

		internal struct PortraitRecord : IEquatable<PortraitRecord>
		{
			[CompilerGenerated]
			private string <CharacterName>k__BackingField; //Field offset: 0x0
			[CompilerGenerated]
			private CharacterFaction <Faction>k__BackingField; //Field offset: 0x8

			public string CharacterName
			{
				[CompilerGenerated]
				 get { } //Length: 8
				[CompilerGenerated]
				 set { } //Length: 8
			}

			public CharacterFaction Faction
			{
				[CompilerGenerated]
				 get { } //Length: 8
				[CompilerGenerated]
				 set { } //Length: 8
			}

			public PortraitRecord(string CharacterName, CharacterFaction Faction) { }

			[CompilerGenerated]
			public void Deconstruct(out string CharacterName, out CharacterFaction Faction) { }

			[CompilerGenerated]
			public virtual bool Equals(object obj) { }

			[CompilerGenerated]
			public override bool Equals(PortraitRecord other) { }

			public static PortraitRecord FromCharacterConfig(BaseCharacterConfig config) { }

			public static PortraitRecord FromCharacterStaticData(CharacterStaticData data) { }

			[CompilerGenerated]
			public string get_CharacterName() { }

			[CompilerGenerated]
			public CharacterFaction get_Faction() { }

			[CompilerGenerated]
			public virtual int GetHashCode() { }

			[CompilerGenerated]
			public static bool op_Equality(PortraitRecord left, PortraitRecord right) { }

			[CompilerGenerated]
			public static bool op_Inequality(PortraitRecord left, PortraitRecord right) { }

			[CompilerGenerated]
			private bool PrintMembers(StringBuilder builder) { }

			[CompilerGenerated]
			public void set_CharacterName(string value) { }

			[CompilerGenerated]
			public void set_Faction(CharacterFaction value) { }

			[CompilerGenerated]
			public virtual string ToString() { }

		}

		public const string ROOT = "Assets/UI/Feature/CharacterAssets/"; //Field offset: 0x0

		private static IEnumerable<PortraitRecord> _animaNames(IStaticDataProvider sd) { }

		private static IEnumerable<PortraitRecord> _enemiesNames(IStaticDataProvider sd) { }

		private static IEnumerable<PortraitRecord> _heroesNames(IStaticDataProvider sd) { }

		public static AssetKey Anima(PortraitRecord record) { }

		public static AssetKey Enemy(PortraitRecord record) { }

		public static AssetKey Hero(PortraitRecord record) { }

	}

	internal static class RateUs
	{
		private const string ROOT = "Assets/UI/Feature/PopupRateUs/"; //Field offset: 0x0
		public static readonly AssetKey Popup; //Field offset: 0x0

		private static RateUs() { }

	}

	internal static class Ratings
	{
		private const string ROOT = "Assets/UI/Feature/Ratings/Prefabs/"; //Field offset: 0x0
		public static readonly AssetKey Panel; //Field offset: 0x0
		public static readonly AssetKey PanelSummon; //Field offset: 0x8
		public static readonly AssetKey ListElement; //Field offset: 0x10
		public static readonly AssetKey RateDialog; //Field offset: 0x18
		public static readonly AssetKey TierListScreenView; //Field offset: 0x20
		public static readonly AssetKey TierListHeroCard; //Field offset: 0x28

		private static Ratings() { }

	}

	internal static class ResourceConverter
	{
		private const string ROOT = "Assets/UI/Feature/ResourceConverter/"; //Field offset: 0x0
		public static readonly AssetKey ResourceConverterView; //Field offset: 0x0

		private static ResourceConverter() { }

	}

	[DontAnalyze("Some of them used as AssetKeys.GameRewards; some are still here; its hard to determine check rule", new IL2CPP_TYPE_STRING[] {"Assets/UI/Prefabs/GameItemsContainers/Resourses/Medium/Sprites/", "Assets/UI/Prefabs/GameItemsContainers/Resourses/Small/Sprites/"})]
	internal static class ResourceIcons
	{
		private const string CONTAINER_RESOURCES_ROOT = "Assets/UI/Prefabs/GameItemsContainers/Resourses/"; //Field offset: 0x0
		private const string MEDIUM_ICON_ROOT = "Assets/UI/Prefabs/GameItemsContainers/Resourses/Medium/Sprites/"; //Field offset: 0x0
		private const string SMALL_ICON_ROOT = "Assets/UI/Prefabs/GameItemsContainers/Resourses/Small/Sprites/"; //Field offset: 0x0

		public static AssetKey Icon(ResourceTypeId id) { }

		public static AssetKey Small(ResourceTypeId id) { }

	}

	internal static class Root
	{
		public const string UI = "Assets/UI/"; //Field offset: 0x0
		public const string UI_CORE = "Assets/UI/Core/"; //Field offset: 0x0
		public const string UI_CORE_SPRITES = "Assets/UI/Core/Sprites/"; //Field offset: 0x0
		public const string UI_SHARED = "Assets/UI/Shared/"; //Field offset: 0x0
		public const string UI_FEATURE = "Assets/UI/Feature/"; //Field offset: 0x0
		public const string SCREENS = "Assets/UI/Screens/"; //Field offset: 0x0
		public const string DIALOGUES = "Assets/UI/Dialogues/"; //Field offset: 0x0
		public const string UI_SPRITES = "Assets/UI/Sprites/"; //Field offset: 0x0
		public const string SCENES = "Assets/Scenes/"; //Field offset: 0x0
		public const string SHADERS = "Assets/Shaders/Collections/"; //Field offset: 0x0

	}

	internal static class Shaders
	{
		public const string ROOT = "Assets/Shaders/ShaderConfigs/"; //Field offset: 0x0
		public static readonly AssetKey ShadersAsset; //Field offset: 0x0

		private static Shaders() { }

	}

	internal static class Shop
	{
		internal static class Tabs
		{
			public static readonly AssetKey ExclusiveTabAssetKey; //Field offset: 0x0
			public static readonly AssetKey CurrencyTabAssetKey; //Field offset: 0x8
			public static readonly AssetKey GemsTabAssetKey; //Field offset: 0x10

			private static Tabs() { }

		}

		private const string ROOT = "Assets/UI/Feature/Shop/"; //Field offset: 0x0
		private const string TABS = "Assets/UI/Feature/Shop/Tabs/"; //Field offset: 0x0
		private const string LOCAL_SHARED = "Assets/UI/Shared/Shop/Local/"; //Field offset: 0x0
		private const string EXCLUSIVE_PACKS = "Assets/UI/Feature/Shop/ExclusivePacks/"; //Field offset: 0x0
		private const string FAQ = "Assets/UI/Feature/Shop/FAQPurchaseDialogue/"; //Field offset: 0x0
		public static readonly AssetKey SmallRewardHolder; //Field offset: 0x0
		public static readonly AssetKey MediumRewardHolder; //Field offset: 0x8
		public static readonly AssetKey LargeRewardHolder; //Field offset: 0x10
		public static readonly AssetKey RelicRewardHolder; //Field offset: 0x18
		public static readonly AssetKey CharacterLargeRewardHolder; //Field offset: 0x20
		public static readonly AssetKey CharacterMediumRewardHolder; //Field offset: 0x28
		public static readonly AssetKey AnimaLargeRewardHolder; //Field offset: 0x30
		public static readonly AssetKey AnimaMediumRewardHolder; //Field offset: 0x38
		public static readonly AssetKey Screen; //Field offset: 0x40
		public static readonly AssetKey ExclusivePopupView; //Field offset: 0x48
		public static readonly AssetKey RetentionPackPopupKey; //Field offset: 0x50
		public static readonly AssetKey PurchaseCollectPopupView; //Field offset: 0x58
		public static readonly AssetKey PurchaseCollectMultiplePopupView; //Field offset: 0x60
		public static readonly AssetKey PurchaseFailedPopupView; //Field offset: 0x68
		public static readonly AssetKey FAQPurchaseDialogueView; //Field offset: 0x70
		public static readonly AssetKey GemSpendConfirmationDialog; //Field offset: 0x78
		public static readonly AssetKey ExclusiveOffersFallbackConfig; //Field offset: 0x80

		private static Shop() { }

		[DontAnalyze("Exclusive packs values controlled from backend only", new IL2CPP_TYPE_STRING[] {"Assets/UI/Feature/Shop/ExclusivePacks/"})]
		public static AssetKey ExclusivePacSkinAssetKey(string visualSettingsSkinLayoutId) { }

		private static string NormalizeExclusivePackSkinLayoutId(string skinLayoutId) { }

		private static string RemoveExclusivePackPositionToken(string skinLayoutId, string token) { }

	}

	internal static class Sound
	{
		[CompilerGenerated]
		private sealed class <_availableLevelsWithUniqueBanks>d__24 : IEnumerable<LevelInfo>, IEnumerable, IEnumerator<LevelInfo>, IEnumerator, IDisposable
		{
			private int <>1__state; //Field offset: 0x10
			private LevelInfo <>2__current; //Field offset: 0x18
			private int <>l__initialThreadId; //Field offset: 0x20
			private IStaticDataProvider sd; //Field offset: 0x28
			public IStaticDataProvider <>3__sd; //Field offset: 0x30
			private HashSet<String> <seen>5__2; //Field offset: 0x38
			private Enumerator<LevelInfo> <>7__wrap2; //Field offset: 0x40

			private override LevelInfo System.Collections.Generic.IEnumerator<Shared.Logic.Configs.LevelInfo>.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			private override object System.Collections.IEnumerator.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			[DebuggerHidden]
			public <_availableLevelsWithUniqueBanks>d__24(int <>1__state) { }

			private void <>m__Finally1() { }

			private override bool MoveNext() { }

			[DebuggerHidden]
			private override IEnumerator<LevelInfo> System.Collections.Generic.IEnumerable<Shared.Logic.Configs.LevelInfo>.GetEnumerator() { }

			[DebuggerHidden]
			private override LevelInfo System.Collections.Generic.IEnumerator<Shared.Logic.Configs.LevelInfo>.get_Current() { }

			[DebuggerHidden]
			private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

			[DebuggerHidden]
			private override object System.Collections.IEnumerator.get_Current() { }

			[DebuggerHidden]
			private override void System.Collections.IEnumerator.Reset() { }

			[DebuggerHidden]
			private override void System.IDisposable.Dispose() { }

		}

		public const string PreloadSamplesLable = "PreloadSamples"; //Field offset: 0x0
		public const string BANKS_ROOT = "Assets/SoundBanks/"; //Field offset: 0x0
		public const string MUSIC_ROOT = "Assets/SoundBanks/Music/"; //Field offset: 0x0
		public const string AMBIENCE_ROOT = "Assets/SoundBanks/Ambience/"; //Field offset: 0x0
		public static readonly AssetKey Tutorial; //Field offset: 0x0
		public static readonly AssetKey UI; //Field offset: 0x8
		public static readonly AssetKey MetaMusic; //Field offset: 0x10
		public static readonly AssetKey SummonMusic; //Field offset: 0x18
		public static readonly AssetKey LootDrop; //Field offset: 0x20
		public static readonly AssetKey InteractableProps; //Field offset: 0x28
		public static readonly AssetKey DestructablesProps; //Field offset: 0x30
		public static readonly AssetKey CharacterGameplay; //Field offset: 0x38
		public static readonly AssetKey StaticProps; //Field offset: 0x40
		public static readonly AssetKey Steps; //Field offset: 0x48
		public static readonly AssetKey VFXInGame; //Field offset: 0x50
		public static readonly AssetKey VoInGame; //Field offset: 0x58
		public static readonly AssetKey Empty; //Field offset: 0x60

		private static IEnumerable<String> _allMasterBanks(IStaticDataProvider _) { }

		[IteratorStateMachine(typeof(<_availableLevelsWithUniqueBanks>d__24))]
		private static IEnumerable<LevelInfo> _availableLevelsWithUniqueBanks(IStaticDataProvider sd) { }

		private static Sound() { }

		public static string GetAmbienceBankName(LevelInfo levelInfo) { }

		public static string GetMusicBankName(LevelInfo levelInfo) { }

		public static AssetKey LevelAmbience(LevelInfo levelInfo) { }

		public static AssetKey LevelMusic(LevelInfo levelInfo) { }

		public static AssetKey Master(string masterBankName) { }

		public static AssetKey MasterStrings(string masterBankName) { }

	}

	internal static class SpecialEvents
	{
		[CompilerGenerated]
		private sealed class <_specialEventsAssets>d__1 : IEnumerable<String>, IEnumerable, IEnumerator<String>, IEnumerator, IDisposable
		{
			private int <>1__state; //Field offset: 0x10
			private string <>2__current; //Field offset: 0x18
			private int <>l__initialThreadId; //Field offset: 0x20
			private IStaticDataProvider sd; //Field offset: 0x28
			public IStaticDataProvider <>3__sd; //Field offset: 0x30
			private IEnumerator<String> <>7__wrap1; //Field offset: 0x38
			private Enumerator<DailyLoginProgram> <>7__wrap2; //Field offset: 0x40

			private override string System.Collections.Generic.IEnumerator<System.String>.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			private override object System.Collections.IEnumerator.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			[DebuggerHidden]
			public <_specialEventsAssets>d__1(int <>1__state) { }

			private void <>m__Finally1() { }

			private void <>m__Finally2() { }

			private void <>m__Finally3() { }

			private override bool MoveNext() { }

			[DebuggerHidden]
			private override IEnumerator<String> System.Collections.Generic.IEnumerable<System.String>.GetEnumerator() { }

			[DebuggerHidden]
			private override string System.Collections.Generic.IEnumerator<System.String>.get_Current() { }

			[DebuggerHidden]
			private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

			[DebuggerHidden]
			private override object System.Collections.IEnumerator.get_Current() { }

			[DebuggerHidden]
			private override void System.Collections.IEnumerator.Reset() { }

			[DebuggerHidden]
			private override void System.IDisposable.Dispose() { }

		}


		[IteratorStateMachine(typeof(<_specialEventsAssets>d__1))]
		private static IEnumerable<String> _specialEventsAssets(IStaticDataProvider sd) { }

		public static AssetKey UIKey(string specialEventAssetKey) { }

	}

	internal static class Summon
	{
		[CompilerGenerated]
		private sealed class <>c
		{
			public static readonly <>c <>9; //Field offset: 0x0
			public static Func<ResourceTypeId, Boolean> <>9__13_0; //Field offset: 0x8

			private static <>c() { }

			public <>c() { }

			internal bool <_summonItems>b__13_0(ResourceTypeId r) { }

		}

		[CompilerGenerated]
		private struct <>c__DisplayClass11_0
		{
			public ResourceTypeId resourceType; //Field offset: 0x0

		}

		internal static class MercySystem
		{
			private const string ICONS_ROOT = "Assets/UI/Feature/Summon/Local/MercyBonusSystemsIcons/"; //Field offset: 0x0
			public static readonly AssetKey IconHeroLegendaryLightDark; //Field offset: 0x0
			public static readonly AssetKey IconHeroLegendaryNonLightDark; //Field offset: 0x8
			public static readonly AssetKey IconHeroUncommonLightDark; //Field offset: 0x10
			public static readonly AssetKey IconHeroEpic; //Field offset: 0x18
			public static readonly AssetKey IconHeroEpicLightDark; //Field offset: 0x20
			public static readonly AssetKey IconHeroEpicNonLightDark; //Field offset: 0x28
			public static readonly AssetKey IconAnimaLegendary; //Field offset: 0x30
			public static readonly AssetKey IconAnimaMythic; //Field offset: 0x38
			public static readonly AssetKey[] AllIcons; //Field offset: 0x40

			private static MercySystem() { }

			private static AssetKey IconKey(string iconName) { }

		}

		private const string ROOT = "Assets/UI/Feature/Summon/"; //Field offset: 0x0
		public static readonly AssetKey Screen; //Field offset: 0x0
		public static readonly AssetKey SingleHeroSummonResult; //Field offset: 0x8
		public static readonly AssetKey SingleAnimaSummonResult; //Field offset: 0x10
		public static readonly AssetKey MultipleHeroSummonResult; //Field offset: 0x18
		public static readonly AssetKey MultipleAnimaSummonResult; //Field offset: 0x20
		public static readonly AssetKey ProbabilitiesDialog; //Field offset: 0x28
		public static readonly AssetKey RevealScene; //Field offset: 0x30
		public static readonly AssetKey FragmentsConversionPopup; //Field offset: 0x38
		public static readonly AssetKey ShadersCollection; //Field offset: 0x40

		private static IEnumerable<ResourceTypeId> _summonItems(IStaticDataProvider _) { }

		private static Summon() { }

		[CompilerGenerated]
		internal static bool <Banner>g__IsLocal|11_0(ref <>c__DisplayClass11_0 unnamed_param_0) { }

		public static AssetKey Banner(ResourceTypeId resourceType) { }

		public static AssetKey BannerSmall(ResourceTypeId resourceType) { }

	}

	internal static class TeamSelection
	{
		[CompilerGenerated]
		private sealed class <_availableLevelsWithUniqueIcons>d__5 : IEnumerable<LevelInfo>, IEnumerable, IEnumerator<LevelInfo>, IEnumerator, IDisposable
		{
			private int <>1__state; //Field offset: 0x10
			private LevelInfo <>2__current; //Field offset: 0x18
			private int <>l__initialThreadId; //Field offset: 0x20
			private IStaticDataProvider sd; //Field offset: 0x28
			public IStaticDataProvider <>3__sd; //Field offset: 0x30
			private HashSet<String> <seen>5__2; //Field offset: 0x38
			private Enumerator<LevelInfo> <>7__wrap2; //Field offset: 0x40

			private override LevelInfo System.Collections.Generic.IEnumerator<Shared.Logic.Configs.LevelInfo>.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			private override object System.Collections.IEnumerator.Current
			{
				[DebuggerHidden]
				private get { } //Length: 8
			}

			[DebuggerHidden]
			public <_availableLevelsWithUniqueIcons>d__5(int <>1__state) { }

			private void <>m__Finally1() { }

			private override bool MoveNext() { }

			[DebuggerHidden]
			private override IEnumerator<LevelInfo> System.Collections.Generic.IEnumerable<Shared.Logic.Configs.LevelInfo>.GetEnumerator() { }

			[DebuggerHidden]
			private override LevelInfo System.Collections.Generic.IEnumerator<Shared.Logic.Configs.LevelInfo>.get_Current() { }

			[DebuggerHidden]
			private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

			[DebuggerHidden]
			private override object System.Collections.IEnumerator.get_Current() { }

			[DebuggerHidden]
			private override void System.Collections.IEnumerator.Reset() { }

			[DebuggerHidden]
			private override void System.IDisposable.Dispose() { }

		}

		private const string ROOT = "Assets/UI/Feature/TeamSelection/"; //Field offset: 0x0
		public static readonly AssetKey ScreenView; //Field offset: 0x0
		private const string GRIDS_ROOT = "Assets/UI/Feature/TeamSelection/GridsContent/"; //Field offset: 0x0
		private const string DESCRIPTIONS_ROOT = "Assets/UI/Feature/TeamSelection/DescriptionsContent/"; //Field offset: 0x0
		private const string MULTI_BATTLE_ROOT = "Assets/UI/Feature/TeamSelection/MultiBattle/"; //Field offset: 0x0
		public static readonly AssetKey ArenaScreenView; //Field offset: 0x8
		public static readonly AssetKey ArenaDefenseSetupScreenView; //Field offset: 0x10
		public static readonly AssetKey HeroesTabView; //Field offset: 0x18
		public static readonly AssetKey AnimasTabView; //Field offset: 0x20
		public static readonly AssetKey FormationsTabView; //Field offset: 0x28
		public static readonly AssetKey ArenaHeroesTabView; //Field offset: 0x30
		public static readonly AssetKey ArenaAnimasTabView; //Field offset: 0x38
		public static readonly AssetKey ArenaDefenseHeroesTabView; //Field offset: 0x40
		public static readonly AssetKey ArenaDefenseAnimasTabView; //Field offset: 0x48
		public static readonly AssetKey ArenaDefenseFormationsTabView; //Field offset: 0x50
		public static readonly AssetKey MissionDescriptionView; //Field offset: 0x58
		public static readonly AssetKey FormationDescriptionView; //Field offset: 0x60
		public static readonly AssetKey FormationUpgradeView; //Field offset: 0x68
		public static readonly AssetKey AnimaPriorityDescriptionView; //Field offset: 0x70
		public static readonly AssetKey ElementsSchemeTutorialPopup; //Field offset: 0x78
		public static readonly AssetKey CorruptionsTutorialPopup; //Field offset: 0x80
		public static readonly AssetKey TolerancesTutorialPopup; //Field offset: 0x88
		public static readonly AssetKey FormationTutorialPopup; //Field offset: 0x90
		public static readonly AssetKey DefenseTutorialPopup; //Field offset: 0x98
		public static readonly AssetKey LeadInvokerTutorialPopup; //Field offset: 0xA0
		public static readonly AssetKey AnimaFactionTutorialPopup; //Field offset: 0xA8
		public static readonly AssetKey AnimaPriorityTutorialPopup; //Field offset: 0xB0
		public static readonly AssetKey ArenaTeamSelectionTutorialDialog; //Field offset: 0xB8
		public static readonly AssetKey StartMultiBattleDialog; //Field offset: 0xC0
		public static readonly AssetKey MultiBattleTutorialPopup; //Field offset: 0xC8
		public static readonly AssetKey MultiClimbTutorialPopup; //Field offset: 0xD0

		[IteratorStateMachine(typeof(<_availableLevelsWithUniqueIcons>d__5))]
		private static IEnumerable<LevelInfo> _availableLevelsWithUniqueIcons(IStaticDataProvider sd) { }

		private static TeamSelection() { }

		public static AssetKey LevelIcon(LevelInfo info) { }

	}

	internal static class Tools
	{
		public const string ROOT = "Assets/Scenes/Tools/"; //Field offset: 0x0
		public static readonly AssetKey EmptyScene; //Field offset: 0x0
		public static readonly AssetKey EmptyGameplayScene; //Field offset: 0x8

		private static Tools() { }

	}

	internal static class Tooltips
	{
		private const string ROOT = "Assets/UI/Core/Tooltips/"; //Field offset: 0x0
		public static readonly AssetKey AnimaShortOverviewTooltip; //Field offset: 0x0
		public static readonly AssetKey GameItemNonResourceTooltip; //Field offset: 0x8
		public static readonly AssetKey GameItemResourceTooltip; //Field offset: 0x10
		public static readonly AssetKey HeroShortOverviewTooltip; //Field offset: 0x18
		public static readonly AssetKey SimpleTextTooltip; //Field offset: 0x20
		public static readonly AssetKey SkillLevelUpNotificationTooltip; //Field offset: 0x28
		public static readonly AssetKey SimpleNotificationTooltip; //Field offset: 0x30
		public static readonly AssetKey MultipleRewardsTooltip; //Field offset: 0x38
		public static readonly AssetKey GameItemGearTooltip; //Field offset: 0x40
		public static readonly AssetKey GameItemRandomGearTooltip; //Field offset: 0x48
		public static readonly AssetKey GameItemRandomRelicSetTooltip; //Field offset: 0x50
		public static readonly AssetKey GameItemFactionAccessoriesTooltip; //Field offset: 0x58

		private static Tooltips() { }

		private static AssetKey TooltipKey(string tooltipName) { }

	}

	internal static class Tutorial
	{
		private const string ROOT = "Assets/UI/Feature/Tutorial/"; //Field offset: 0x0
		public static readonly AssetKey View; //Field offset: 0x0
		public static readonly AssetKey PointingArrowWidget; //Field offset: 0x8
		public static readonly AssetKey PointingArrowWidgetSellHero; //Field offset: 0x10

		private static Tutorial() { }

	}

	[AttributeUsage(AttributeTargets::Method (64))]
	internal class TypedArgsProviderAttribute : Attribute
	{

		public TypedArgsProviderAttribute() { }

	}

	internal static class VFX
	{
		public const string SPAWN_VFX_FOLDER_PATH = "Assets/VFX_All/Core/CommonVfx/Spawn_Enemy/Prefab"; //Field offset: 0x0

		private static IEnumerable<String> _spawnVfxNames(IStaticDataProvider _) { }

		public static AssetKey SpawnPrefab(string name) { }

	}

	public static readonly AssetKey ChestRewardsPopup; //Field offset: 0x0
	public static readonly AssetKey BuffsDebuffsConfig; //Field offset: 0x8
	public static readonly AssetKey WeaponTypeIcons; //Field offset: 0x10

	[TypedArgsProvider]
	private static IEnumerable<BattleResourceTypeId> _argsBattleResourceTypeId(IStaticDataProvider _) { }

	[TypedArgsProvider]
	private static IEnumerable<GraphicsDeviceType> _argsGraphicsDeviceTypes(IStaticDataProvider _) { }

	[TypedArgsProvider]
	private static IEnumerable<ResourceTypeId> _argsResourceTypeIds(IStaticDataProvider _) { }

	[TypedArgsProvider]
	private static IEnumerable<ShopPackTab> _argsShopPackTabs(IStaticDataProvider _) { }

	[TypedArgsProvider]
	private static IEnumerable<SoulSign> _argsSoulSign(IStaticDataProvider _) { }

	private static AssetKeys() { }

}

