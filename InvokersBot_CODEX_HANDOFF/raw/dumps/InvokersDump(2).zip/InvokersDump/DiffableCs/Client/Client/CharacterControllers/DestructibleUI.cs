namespace Client.CharacterControllers;

public class DestructibleUI : BaseCharacterView, IObjectsPoolItem<DestructibleUI>
{
	private const string WORLD_UI_SORTING_LAYER_NAME = "WorldUI"; //Field offset: 0x0
	private static int _worldUISortingLayerID; //Field offset: 0x0
	[CompilerGenerated]
	private Action<DestructibleUI> OnDead; //Field offset: 0x20
	[SerializeField]
	private Transform _uiRoot; //Field offset: 0x28
	[SerializeField]
	private SegmentedHealthBar _segmentedHealthBar; //Field offset: 0x30
	[SerializeField]
	private LookAtCamera _lookAtCamera; //Field offset: 0x38
	private readonly GameObjectsPoolItemBase<DestructibleUI> _itemsBase; //Field offset: 0x40

	public event Action<DestructibleUI> OnDead
	{
		[CompilerGenerated]
		 add { } //Length: 176
		[CompilerGenerated]
		 remove { } //Length: 176
	}

	public override DestructibleUI Template
	{
		 get { } //Length: 72
	}

	private static DestructibleUI() { }

	public DestructibleUI() { }

	[CompilerGenerated]
	public void add_OnDead(Action<DestructibleUI> value) { }

	public void ChangeParent(Transform root) { }

	public void ChangeVisibility(bool isVisible) { }

	public override DestructibleUI get_Template() { }

	public void Init(Camera mainCamera) { }

	private void OnDisable() { }

	public override void OnInstantiate(IObjectsPool<DestructibleUI> ownerPool, DestructibleUI template) { }

	private void OnValidate() { }

	[CompilerGenerated]
	public void remove_OnDead(Action<DestructibleUI> value) { }

	public override void ResetBeforeRent() { }

	public override void ReturnToPool() { }

	public void SetDead() { }

	private void SetPercent(float percent) { }

	public void UpdateBarPosition(float characterViewOffsetCurrent) { }

	public void UpdateHealth(int currentHealth, int maxHealth) { }

	public void UpdateHealth(float percent) { }

}

