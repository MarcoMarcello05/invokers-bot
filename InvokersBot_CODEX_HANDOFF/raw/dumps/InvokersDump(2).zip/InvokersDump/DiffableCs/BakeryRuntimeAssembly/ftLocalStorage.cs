//Type is in global namespace

public class ftLocalStorage : ScriptableObject
{
	[SerializeField]
	public List<String> modifiedAssetPathList; //Field offset: 0x18
	[SerializeField]
	public List<Int32> modifiedAssetPaddingHash; //Field offset: 0x20

	public ftLocalStorage() { }

}

