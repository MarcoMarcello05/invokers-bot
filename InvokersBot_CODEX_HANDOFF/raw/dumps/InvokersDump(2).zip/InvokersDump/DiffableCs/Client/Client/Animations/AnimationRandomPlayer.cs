namespace Client.Animations;

public class AnimationRandomPlayer : MonoBehaviour
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Predicate<Animation> <>9__1_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal bool <OnValidate>b__1_0(Animation an) { }

	}

	[SerializeField]
	private List<Animation> _animations; //Field offset: 0x20

	public AnimationRandomPlayer() { }

	private void OnValidate() { }

	private void Reset() { }

	private void Start() { }

}

