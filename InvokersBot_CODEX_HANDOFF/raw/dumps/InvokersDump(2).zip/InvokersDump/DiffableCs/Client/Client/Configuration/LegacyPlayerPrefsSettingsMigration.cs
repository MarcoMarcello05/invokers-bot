namespace Client.Configuration;

public static class LegacyPlayerPrefsSettingsMigration
{
	public const string VERSION_KEY = "GameSettings > Graphics > Version"; //Field offset: 0x0
	private const int VERSION = 1; //Field offset: 0x0
	private const string LEGACY_FPS_KEY = "GameSettings > Graphics > FPS"; //Field offset: 0x0
	private const string LEGACY_ANTI_ALIASING_KEY = "GameSettings > Graphics > AntiAliasing"; //Field offset: 0x0
	private const int NO_OVERRIDE = -1; //Field offset: 0x0

	private static bool TryReadLegacy(string key, out int value) { }

	public static bool TryTakeLegacyOverrides(out Dictionary<String, String>& overrides) { }

}

