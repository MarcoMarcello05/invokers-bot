namespace Client.Core.Characters;

public sealed class LobbyCharacterViewController : CharacterViewController
{
	private bool _disableIdleBreak; //Field offset: 0x99
	private bool _useIdleTeamAnimation; //Field offset: 0x9A
	[Nullable(2)]
	private Animator _characterAnimator; //Field offset: 0xA0
	[CompilerGenerated]
	private readonly bool <InitializeSoundController>k__BackingField; //Field offset: 0xA8

	public bool InitializeSoundController
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	[TupleElementNames(new IL2CPP_TYPE_STRING[] {"WithSound", "CustomLight"})]
	protected virtual ValueTuple<Boolean, Boolean> StagingOptions
	{
		 get { } //Length: 112
	}

	[NullableContext(1)]
	public LobbyCharacterViewController(CharacterVariant variant, IAssetProvider assetProvider, IJiggleScheduler jiggleScheduler, IStagingContainer stagingContainer, bool autoActivate = true) { }

	[NullableContext(1)]
	public LobbyCharacterViewController(CharacterVariant variant, IAssetProvider assetProvider, IJiggleScheduler jiggleScheduler, IPrefabInstantiationStrategy instantiationStrategy) { }

	private void ApplyConfiguration(bool disableIdleBreak, bool useIdleTeamAnimation, bool useIdleHomeAnimation) { }

	[CompilerGenerated]
	public bool get_InitializeSoundController() { }

	protected virtual ValueTuple<Boolean, Boolean> get_StagingOptions() { }

	protected virtual void OnViewLoaded() { }

	[CompilerGenerated]
	public void set_InitializeSoundController(bool value) { }

	[NullableContext(1)]
	public void SetupCharacterForSlot(LobbyCharacterSlot characterContainer) { }

}

