namespace Client.Analytics;

[Nullable(0)]
[NullableContext(1)]
public class AnalyticEventsStore
{
	private const int MaxLocalEvents = 3000; //Field offset: 0x0
	private readonly ILogger _logger; //Field offset: 0x10
	private readonly PersistentSerializedList<ClientBiEventDto> _events; //Field offset: 0x18

	public int Count
	{
		 get { } //Length: 180
	}

	public IReadOnlyList<ClientBiEventDto> Pending
	{
		 get { } //Length: 72
	}

	public AnalyticEventsStore() { }

	internal AnalyticEventsStore(PersistentSerializedList<ClientBiEventDto> events) { }

	public void Add(ClientBiEventDto biEvent) { }

	public void Clear() { }

	public int get_Count() { }

	public IReadOnlyList<ClientBiEventDto> get_Pending() { }

	internal bool TryRemoveDeliveredEvents(int count) { }

}

