//Type is in global namespace

[HelpURL("https://geom.io/bakery/wiki/index.php?title=Partial_scene_baking")]
public class BakerySector : MonoBehaviour
{
	internal enum CaptureMode : int
	{
		None = -1,
		CaptureInPlace = 0,
		CaptureToAsset = 1,
		LoadCaptured = 2,
	}

	public CaptureMode captureMode; //Field offset: 0x20
	public string captureAssetName; //Field offset: 0x28
	public BakerySectorCapture captureAsset; //Field offset: 0x30
	public bool allowUVPaddingAdjustment; //Field offset: 0x38
	public List<Transform> tforms; //Field offset: 0x40
	public List<Transform> cpoints; //Field offset: 0x48

	public BakerySector() { }

	private void OnDrawGizmosSelected() { }

}

