namespace Client.Configuration;

public sealed class PlatformConfigProvider : ConfigurationProvider, IKeyEnumerator
{
	private static readonly ILogger Log; //Field offset: 0x0
	private const string Graphics = "Graphics"; //Field offset: 0x0
	private static readonly string MaxQualityTierKey; //Field offset: 0x8
	private static readonly string MaxTargetFpsKey; //Field offset: 0x10
	private static readonly string MaxAntiAliasingKey; //Field offset: 0x18
	private static readonly HashSet<String> CeilingKeys; //Field offset: 0x20
	private readonly string _basePath; //Field offset: 0x20
	private readonly PlatformConfigRules _rules; //Field offset: 0x28
	private readonly QualityTier _deviceQualityOverride; //Field offset: 0x30

	private static PlatformConfigProvider() { }

	public PlatformConfigProvider(string basePath, PlatformConfigRules rules, QualityTier deviceQualityOverride) { }

	public override IEnumerable<String> GetAllKeys() { }

	public virtual void Load() { }

	private static bool Skip(string key, ConfigContribution contribution) { }

}

