namespace Client.Common.UI;

public class CommonTabButton : HZTabButton
{

	public CommonTabButton() { }

}

