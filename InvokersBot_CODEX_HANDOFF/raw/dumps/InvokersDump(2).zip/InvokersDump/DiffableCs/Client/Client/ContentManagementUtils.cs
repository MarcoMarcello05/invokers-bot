namespace Client;

[Extension]
[Nullable(0)]
[NullableContext(1)]
internal static class ContentManagementUtils
{

	[Extension]
	public static string Readable(DownloadStatus status) { }

	[Extension]
	public static bool TryGetAssetBundle(IResourceLocation location, out AssetBundleRequestOptions assetBundleRequestOptions) { }

	[Extension]
	public static bool TryGetHash(AssetBundleRequestOptions bundle, out Hash128 hash) { }

}

