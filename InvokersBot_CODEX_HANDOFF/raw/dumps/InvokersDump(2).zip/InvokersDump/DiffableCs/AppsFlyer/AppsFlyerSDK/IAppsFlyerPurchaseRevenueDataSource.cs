namespace AppsFlyerSDK;

public interface IAppsFlyerPurchaseRevenueDataSource
{

	public Dictionary<String, Object> PurchaseRevenueAdditionalParametersForProducts(HashSet<Object> products, HashSet<Object> transactions) { }

}

