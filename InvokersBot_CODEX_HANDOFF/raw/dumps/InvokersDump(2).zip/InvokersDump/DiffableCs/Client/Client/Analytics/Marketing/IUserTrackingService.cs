namespace Client.Analytics.Marketing;

[NullableContext(1)]
public interface IUserTrackingService
{

	public string AttAuthorizationOutcome
	{
		 get { } //Length: 0
	}

	public Observable<Unit> AttStateChanged
	{
		 get { } //Length: 0
	}

	public string DeviceId
	{
		 get { } //Length: 0
	}

	public bool IsAttAuthorizationResolved
	{
		 get { } //Length: 0
	}

	public bool IsAttAuthorized
	{
		 get { } //Length: 0
	}

	public string get_AttAuthorizationOutcome() { }

	public Observable<Unit> get_AttStateChanged() { }

	public string get_DeviceId() { }

	public bool get_IsAttAuthorizationResolved() { }

	public bool get_IsAttAuthorized() { }

	public UniTask InitAsync() { }

}

