namespace Client.Authentication.GooglePlayGames;

[Nullable(0)]
[NullableContext(1)]
public sealed class GooglePlayGamesService : IGooglePlayGamesService
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass10_0
	{
		[Nullable(0)]
		public UniTaskCompletionSource<SignInStatus> tcs; //Field offset: 0x10

		public <>c__DisplayClass10_0() { }

		internal void <AuthenticateAsync>b__0(SignInStatus status) { }

		internal void <AuthenticateAsync>b__1(SignInStatus status) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass11_0
	{
		[Nullable(0)]
		public GooglePlayGamesService <>4__this; //Field offset: 0x10
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		public UniTaskCompletionSource<GooglePlayGamesServerAuthCodeResult> tcs; //Field offset: 0x18

		public <>c__DisplayClass11_0() { }

		[NullableContext(0)]
		internal void <GetServerAuthCodeAsync>b__0(AuthResponse response) { }

	}

	[CompilerGenerated]
	private struct <WaitAuthCodeAsync>d__13 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncValueTaskMethodBuilder<GooglePlayGamesServerAuthCodeResult> <>t__builder; //Field offset: 0x8
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		public UniTaskCompletionSource<GooglePlayGamesServerAuthCodeResult> tcs; //Field offset: 0x30
		public CancellationToken cancellationToken; //Field offset: 0x38
		[Nullable(0)]
		private Awaiter<GooglePlayGamesServerAuthCodeResult> <>u__1; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <WaitStatusAsync>d__12 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncValueTaskMethodBuilder<GooglePlayGamesAuthStatus> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public UniTaskCompletionSource<SignInStatus> tcs; //Field offset: 0x28
		public CancellationToken cancellationToken; //Field offset: 0x30
		[Nullable(0)]
		private Awaiter<SignInStatus> <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly ILogger<GooglePlayGamesService> _logger; //Field offset: 0x10
	private Nullable<Boolean> _isAvailable; //Field offset: 0x18

	public override bool IsAuthenticated
	{
		 get { } //Length: 32
	}

	public override bool IsAvailable
	{
		 get { } //Length: 344
	}

	[Nullable(2)]
	public override string UserId
	{
		[NullableContext(2)]
		 get { } //Length: 68
	}

	[Nullable(2)]
	public override string UserName
	{
		[NullableContext(2)]
		 get { } //Length: 172
	}

	public GooglePlayGamesService() { }

	[NullableContext(0)]
	public override ValueTask<GooglePlayGamesAuthStatus> AuthenticateAsync(bool manual, CancellationToken cancellationToken = null) { }

	private static void EnsureJavaClassExists(string className) { }

	private static string FormatGrantedScopes(IReadOnlyCollection<GooglePlayGamesIdentityScope> grantedScopes) { }

	public override bool get_IsAuthenticated() { }

	public override bool get_IsAvailable() { }

	[NullableContext(2)]
	public override string get_UserId() { }

	[NullableContext(2)]
	public override string get_UserName() { }

	public override ValueTask<GooglePlayGamesServerAuthCodeResult> GetServerAuthCodeAsync(CancellationToken cancellationToken = null) { }

	private static bool HasJavaClass(string className) { }

	private bool IsSdkPresent() { }

	private static List<GooglePlayGamesIdentityScope> MapGrantedScopes(List<AuthScope> grantedScopes) { }

	[AsyncStateMachine(typeof(<WaitAuthCodeAsync>d__13))]
	private static ValueTask<GooglePlayGamesServerAuthCodeResult> WaitAuthCodeAsync(UniTaskCompletionSource<GooglePlayGamesServerAuthCodeResult> tcs, CancellationToken cancellationToken) { }

	[AsyncStateMachine(typeof(<WaitStatusAsync>d__12))]
	[NullableContext(0)]
	private static ValueTask<GooglePlayGamesAuthStatus> WaitStatusAsync(UniTaskCompletionSource<SignInStatus> tcs, CancellationToken cancellationToken) { }

}

