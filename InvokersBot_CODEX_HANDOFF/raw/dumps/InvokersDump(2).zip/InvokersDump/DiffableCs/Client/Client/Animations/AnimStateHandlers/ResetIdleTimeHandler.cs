namespace Client.Animations.AnimStateHandlers;

public class ResetIdleTimeHandler : StateMachineBehaviour
{

	public ResetIdleTimeHandler() { }

	public virtual void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) { }

}

