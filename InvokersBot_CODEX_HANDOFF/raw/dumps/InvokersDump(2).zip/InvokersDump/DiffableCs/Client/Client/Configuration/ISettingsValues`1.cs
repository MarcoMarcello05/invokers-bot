namespace Client.Configuration;

public interface ISettingsValues
{

	public T GetValue() { }

	public void SetValue(T value) { }

	public void SetValueRootKey(string value) { }

}

