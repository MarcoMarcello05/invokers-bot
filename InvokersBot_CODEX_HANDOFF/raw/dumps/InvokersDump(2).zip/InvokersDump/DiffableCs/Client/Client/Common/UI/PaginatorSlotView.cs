namespace Client.Common.UI;

public sealed class PaginatorSlotView : MonoBehaviour
{
	[SerializeField]
	private GameObject _active; //Field offset: 0x20
	[SerializeField]
	private GameObject _inactive; //Field offset: 0x28

	public PaginatorSlotView() { }

	private void OnValidate() { }

	public void SetSelected(bool selected) { }

}

