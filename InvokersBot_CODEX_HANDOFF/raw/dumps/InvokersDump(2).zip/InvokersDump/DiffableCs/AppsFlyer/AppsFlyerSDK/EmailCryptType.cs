namespace AppsFlyerSDK;

public enum EmailCryptType : int
{
	EmailCryptTypeNone = 0,
	EmailCryptTypeSHA256 = 1,
}

