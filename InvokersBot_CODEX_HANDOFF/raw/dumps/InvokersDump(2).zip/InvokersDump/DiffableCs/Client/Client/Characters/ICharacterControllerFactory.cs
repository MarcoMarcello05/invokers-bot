namespace Client.Characters;

public interface ICharacterControllerFactory
{

	public TController Create() { }

}

