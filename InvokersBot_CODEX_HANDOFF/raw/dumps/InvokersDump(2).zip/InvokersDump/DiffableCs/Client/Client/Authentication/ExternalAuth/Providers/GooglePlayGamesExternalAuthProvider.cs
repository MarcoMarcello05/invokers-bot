namespace Client.Authentication.ExternalAuth.Providers;

[Nullable(0)]
[NullableContext(1)]
public sealed class GooglePlayGamesExternalAuthProvider : IExternalAuthProvider
{
	[CompilerGenerated]
	private struct <TryAuthenticateAsync>d__8 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncValueTaskMethodBuilder<ExternalAuthResult> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public GooglePlayGamesExternalAuthProvider <>4__this; //Field offset: 0x40
		public ExternalAuthMode mode; //Field offset: 0x48
		public CancellationToken ct; //Field offset: 0x50
		[Nullable(0)]
		private string <oauthClientId>5__2; //Field offset: 0x58
		[Nullable(0)]
		private ValueTaskAwaiter<GooglePlayGamesAuthStatus> <>u__1; //Field offset: 0x60
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private ValueTaskAwaiter<GooglePlayGamesServerAuthCodeResult> <>u__2; //Field offset: 0x70

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly ILogger<GooglePlayGamesExternalAuthProvider> _logger; //Field offset: 0x10
	private readonly IGooglePlayGamesService _googlePlayGamesService; //Field offset: 0x18
	private readonly IOptionsMonitor<ClientAppSettings> _options; //Field offset: 0x20

	public override bool IsAvailable
	{
		 get { } //Length: 160
	}

	public override ExternalLoginProvider Provider
	{
		 get { } //Length: 8
	}

	public GooglePlayGamesExternalAuthProvider(IGooglePlayGamesService googlePlayGamesService, IOptionsMonitor<ClientAppSettings> options) { }

	public override bool get_IsAvailable() { }

	public override ExternalLoginProvider get_Provider() { }

	[NullableContext(2)]
	public override string GetCurrentUserName() { }

	private static string GetServerAuthCodeError(GooglePlayGamesServerAuthCodeStatus status) { }

	[AsyncStateMachine(typeof(<TryAuthenticateAsync>d__8))]
	[NullableContext(0)]
	public override ValueTask<ExternalAuthResult> TryAuthenticateAsync(ExternalAuthMode mode, CancellationToken ct = null) { }

}

