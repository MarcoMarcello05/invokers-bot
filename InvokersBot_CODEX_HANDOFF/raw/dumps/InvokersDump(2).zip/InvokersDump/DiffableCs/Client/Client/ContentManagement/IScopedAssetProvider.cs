namespace Client.ContentManagement;

public interface IScopedAssetProvider : IAssetProvider, IDisposable
{

	[NullableContext(1)]
	public UniTask<TAsset> TryGetAndCacheAsync(AssetKey key, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	[NullableContext(2)]
	public bool TryGetCached(AssetKey key, out TAsset asset) { }

}

