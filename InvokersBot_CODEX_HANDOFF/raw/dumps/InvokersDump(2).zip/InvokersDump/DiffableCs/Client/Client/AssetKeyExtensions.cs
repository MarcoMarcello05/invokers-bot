namespace Client;

[Extension]
public static class AssetKeyExtensions
{

	[Extension]
	public static string Readable(IReadOnlyCollection<AssetKey> keys, int maxLimit = 10) { }

	[Extension]
	public static ICollection<Object> ToObjectsKeys(IEnumerable<AssetKey> keys) { }

}

