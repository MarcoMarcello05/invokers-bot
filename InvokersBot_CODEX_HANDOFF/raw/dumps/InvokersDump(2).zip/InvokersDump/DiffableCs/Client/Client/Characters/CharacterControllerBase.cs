namespace Client.Characters;

public abstract class CharacterControllerBase : ICharacterController, IDisposable, ICharacterViewListener
{
	private readonly List<ICharacterModule> _modules; //Field offset: 0x10
	private CharacterViewBinding _binding; //Field offset: 0x18
	private bool _disposed; //Field offset: 0x28
	[CompilerGenerated]
	private readonly CharacterAnimationModule <Animation>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private readonly CharacterSoundModule <Sound>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private readonly CharacterJiggleModule <Jiggles>k__BackingField; //Field offset: 0x40
	[CompilerGenerated]
	private readonly CharacterActions <Actions>k__BackingField; //Field offset: 0x48
	[CompilerGenerated]
	private CharacterView <View>k__BackingField; //Field offset: 0x50

	public CharacterActions Actions
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	protected CharacterAnimationModule Animation
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public bool IsBound
	{
		 get { } //Length: 96
	}

	protected CharacterJiggleModule Jiggles
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	protected CharacterSoundModule Sound
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public private CharacterView View
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	protected CharacterControllerBase(IJiggleScheduler jiggleScheduler) { }

	protected void AddModule(ICharacterModule module) { }

	public override void Bind(CharacterView view) { }

	private override void Client.Characters.ICharacterViewListener.OnAnimationEvent(CharacterAnimationEvent animationEvent) { }

	private override void Client.Characters.ICharacterViewListener.OnIdleAnimationStarted() { }

	private override void Client.Characters.ICharacterViewListener.OnIdleBreak(int idleBreakIndex) { }

	private override void Client.Characters.ICharacterViewListener.OnVfxEvent(string vfxId) { }

	private override void Client.Characters.ICharacterViewListener.OnViewDisabled() { }

	private override void Client.Characters.ICharacterViewListener.OnViewEnabled() { }

	public override void Dispose() { }

	[CompilerGenerated]
	public CharacterActions get_Actions() { }

	[CompilerGenerated]
	protected CharacterAnimationModule get_Animation() { }

	public bool get_IsBound() { }

	[CompilerGenerated]
	protected CharacterJiggleModule get_Jiggles() { }

	[CompilerGenerated]
	protected CharacterSoundModule get_Sound() { }

	[CompilerGenerated]
	public CharacterView get_View() { }

	private void NotifyModulesViewDisabled() { }

	private void NotifyModulesViewEnabled() { }

	protected override void OnBound() { }

	protected override void OnIdleAnimationStarted() { }

	protected override void OnIdleBreak(int idleBreakIndex) { }

	protected override void OnTick(float deltaTime) { }

	protected override void OnUnbinding() { }

	protected override void OnVfxEvent(string vfxId) { }

	[CompilerGenerated]
	private void set_View(CharacterView value) { }

	public override void Tick(float deltaTime) { }

	public override void Unbind() { }

}

