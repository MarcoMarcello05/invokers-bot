namespace Client.Common.DI;

[Extension]
public static class AuthenticationDiModule
{

	[Extension]
	public static IContainerBuilder AddAuthentication(IContainerBuilder builder) { }

}

