namespace Client.Authentication.ExternalAuth.Providers;

public sealed class AppleExternalAuthProvider : IExternalAuthProvider
{
	[CompilerGenerated]
	private struct <TryAuthenticateAsync>d__6 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder<ExternalAuthResult> <>t__builder; //Field offset: 0x8
		public AppleExternalAuthProvider <>4__this; //Field offset: 0x40
		private string <generatedRawNonce>5__2; //Field offset: 0x48
		private ValueTaskAwaiter<String> <>u__1; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[Nullable(1)]
	private readonly IAppleAuthService _appleAuthService; //Field offset: 0x10

	public override bool IsAvailable
	{
		 get { } //Length: 92
	}

	public override ExternalLoginProvider Provider
	{
		 get { } //Length: 8
	}

	[NullableContext(1)]
	public AppleExternalAuthProvider(IAppleAuthService appleAuthService) { }

	public override bool get_IsAvailable() { }

	public override ExternalLoginProvider get_Provider() { }

	[NullableContext(2)]
	public override string GetCurrentUserName() { }

	[AsyncStateMachine(typeof(<TryAuthenticateAsync>d__6))]
	public override ValueTask<ExternalAuthResult> TryAuthenticateAsync(ExternalAuthMode mode, CancellationToken ct = null) { }

}

