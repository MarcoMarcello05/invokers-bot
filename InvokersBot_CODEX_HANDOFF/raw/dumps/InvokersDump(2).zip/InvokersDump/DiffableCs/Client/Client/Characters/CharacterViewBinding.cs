namespace Client.Characters;

public struct CharacterViewBinding : IDisposable
{
	private readonly CharacterView _view; //Field offset: 0x0
	private readonly int _generation; //Field offset: 0x8

	internal CharacterViewBinding(CharacterView view, int generation) { }

	public override void Dispose() { }

}

