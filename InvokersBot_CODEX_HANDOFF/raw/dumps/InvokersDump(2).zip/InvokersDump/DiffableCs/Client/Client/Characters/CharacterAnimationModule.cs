namespace Client.Characters;

public sealed class CharacterAnimationModule : ICharacterModule, IDisposable
{
	private const float FLINCH_BLEND_SPEED = 15; //Field offset: 0x0
	private AnimationsController _animations; //Field offset: 0x10
	private float _targetFlinchWeight; //Field offset: 0x18
	private float _currentFlinchWeight; //Field offset: 0x1C

	public CharacterAnimationModule() { }

	public void AnimaIn() { }

	public void AnimaOut() { }

	public override void Bind(CharacterView view) { }

	public void ComboAttack(SkillType skill, float speed, bool force) { }

	public void Dash(bool enable) { }

	public void Death(bool enable, Nullable<Int32> deathAnimationNumber) { }

	public override void Dispose() { }

	public void Flinch() { }

	public void Freeze(bool enable) { }

	public void FtueIdle() { }

	public void FtueIntro() { }

	public float GetClipAnimationTime(string clipName) { }

	public void Idle(bool idleInEnabled) { }

	public void InteractBot(bool enable) { }

	public void InteractMid(bool enable) { }

	public void Intro() { }

	public void Launch(int phase) { }

	public void Move(bool run) { }

	public void Paralyze(bool enable) { }

	public void Reveal() { }

	public void RunSkillPhase(SkillType skill, SkillPhase phase, float speed) { }

	public void SetCastAnimationTime(SkillType skill, float time) { }

	public void SetFullBodyFlinch(bool fullBody) { }

	public void SetSpeed(float speedMultiplier) { }

	public void SetTurnBlend(float weight) { }

	public void Shock(bool enable) { }

	public void Sleep(bool enable) { }

	public void Stun(bool enable) { }

	public override void Tick(float deltaTime) { }

	public override void Unbind() { }

}

