namespace Client.CharacterControllers.BossHpPanel;

public class TopPanelItemContainer
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass13_0
	{
		public SkillConfig skill; //Field offset: 0x10

		public <>c__DisplayClass13_0() { }

		internal bool <Set>b__0(SkillAssets asset) { }

	}

	public ModelEntity CurrentOwner; //Field offset: 0x10
	public ModelEntityKey CurrentTarget; //Field offset: 0x20
	public CharacterKind CurrentTargetKind; //Field offset: 0x30
	private readonly IScopedAssetProvider _assetProvider; //Field offset: 0x38
	private readonly IReadOnlyDictionary<Int64, CustomStatusEffectPresentation> _customStatusEffectPresentations; //Field offset: 0x40
	private readonly HudSkillDescriptionTrigger[] _skillDescriptionTriggers; //Field offset: 0x48
	private TopPanelView _topPanelView; //Field offset: 0x50
	private DamagePopupMode _damagePopupMode; //Field offset: 0x58
	private HUDCharacterBuffContainer _buffContainer; //Field offset: 0x60
	private HudSkillCooldown[] _hudSkillsView; //Field offset: 0x68

	public TopPanelViewTarget TargetType
	{
		 get { } //Length: 24
	}

	public TopPanelItemContainer(IScopedAssetProvider assetProvider, IReadOnlyDictionary<Int64, CustomStatusEffectPresentation> customStatusEffectPresentations, TopPanelView view, IObjectsPool<BuffView> buffViewPool) { }

	public void AddBuff(ModelEntityKey characterEntity, ref StatusEffectHudData statusEffectHudData) { }

	public void AddCustomStatusEffect(ModelEntityKey characterEntity, ref CustomStatusEffectHudData customStatusEffectHudData) { }

	public void AddMovementEffect(ModelEntityKey characterEntity, ref MovementEffectHudData movementEffectHudData) { }

	public void Dispose() { }

	public TopPanelViewTarget get_TargetType() { }

	public void Hide() { }

	private bool IsDamagePopupTarget(ModelEntity characterEntity) { }

	public void RemoveBuff(ModelEntityKey characterEntity, StatusEffectType type, uint effectId) { }

	public void RemoveCustomStatusEffect(ModelEntityKey characterEntity, long effectType, uint effectUniqueId) { }

	public void RemoveMovementEffect(ModelEntityKey characterEntity, MovementEffectType type) { }

	public void ResetCastFill(SkillType skillType) { }

	public void ResetCooldown(ModelEntityKey characterEntity, SkillType skillType) { }

	public void ResetPassiveCooldown(ModelEntityKey characterEntity) { }

	public void Set(ref TopPanelData data) { }

	public void SetCastFill(SkillType skillType, float percent) { }

	public void SetCooldown(ModelEntityKey characterEntity, SkillType skillType, F64 cooldown, F64 timeLeft, bool showCooldownNumbers = true) { }

	public void SetDamagePopupMode(DamagePopupMode mode, Func<Int64> getCounterValue) { }

	public void SetPassiveCooldown(ModelEntityKey characterEntity, F64 timeLeft, bool blocked) { }

	public void TakeDamage(ModelEntity characterEntity, int damage, bool isCritical) { }

	private static bool TryCreatePassiveSkillData(CharacterAssetsHolder assetsHolder, ref CharacterState characterState, out HudPassiveSkillData passiveSkillData) { }

	private bool TryGetPassiveView(out HudSkillCooldown passiveView, out HudSkillDescriptionTrigger passiveDescriptionTrigger) { }

	private void TrySetupPassiveSkillData(CharacterAssetsHolder bossAssetsHolder, ref CharacterState ownerCharacterState) { }

	public void UpdateBuff(ModelEntityKey characterEntity, ref StatusEffectHudData statusEffectHudData) { }

	public void UpdateCustomStatusEffect(ModelEntityKey characterEntity, ref CustomStatusEffectHudData customStatusEffectHudData) { }

	public void UpdateHealthBar(TopPanelHealth ownerHealth) { }

	public void UpdateMovementEffect(ModelEntityKey characterEntity, ref MovementEffectHudData movementEffectHudData) { }

	public void UpdateTarget(ModelEntity newTarget) { }

}

