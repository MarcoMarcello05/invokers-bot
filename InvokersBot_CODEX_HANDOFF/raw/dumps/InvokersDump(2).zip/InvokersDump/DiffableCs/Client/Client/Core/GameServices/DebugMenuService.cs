namespace Client.Core.GameServices;

public sealed class DebugMenuService : IGameService
{
	private DebugMenu _debugMenu; //Field offset: 0x10

	public override string ServiceName
	{
		 get { } //Length: 64
	}

	public override bool SilentInitializationMode
	{
		 get { } //Length: 8
	}

	public DebugMenuService(DebugMenu debugMenu) { }

	public override string get_ServiceName() { }

	public override bool get_SilentInitializationMode() { }

	public override UniTask InitAsync() { }

	public override void OnAppServicesInitialized() { }

}

