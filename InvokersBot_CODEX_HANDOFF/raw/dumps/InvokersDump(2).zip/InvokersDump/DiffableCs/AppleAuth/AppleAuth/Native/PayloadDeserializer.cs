namespace AppleAuth.Native;

public class PayloadDeserializer : IPayloadDeserializer
{

	public PayloadDeserializer() { }

}

