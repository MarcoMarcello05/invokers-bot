namespace Client.Configuration;

[NullableContext(1)]
public interface ISystemInfoProvider
{

	public string DeviceModel
	{
		 get { } //Length: 0
	}

	public string DeviceName
	{
		 get { } //Length: 0
	}

	public string DeviceType
	{
		 get { } //Length: 0
	}

	public string GfxApiName
	{
		 get { } //Length: 0
	}

	public string GfxVendor
	{
		 get { } //Length: 0
	}

	public string OsVersion
	{
		 get { } //Length: 0
	}

	public string Platform
	{
		 get { } //Length: 0
	}

	public string ProcessorType
	{
		 get { } //Length: 0
	}

	public string RamSize
	{
		 get { } //Length: 0
	}

	public string get_DeviceModel() { }

	public string get_DeviceName() { }

	public string get_DeviceType() { }

	public string get_GfxApiName() { }

	public string get_GfxVendor() { }

	public string get_OsVersion() { }

	public string get_Platform() { }

	public string get_ProcessorType() { }

	public string get_RamSize() { }

}

