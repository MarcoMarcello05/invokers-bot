namespace Client.Core.Characters;

public abstract class CharacterViewController : BaseViewController<CharacterView>
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<CharacterPrefabHolder, GameObject> <>9__26_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal GameObject <ViewFactory>b__26_0(CharacterPrefabHolder holder) { }

	}

	[CompilerGenerated]
	private sealed class <InitFactory>d__20 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public CharacterViewController <>4__this; //Field offset: 0x28

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <InitFactory>d__20(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private LobbyCharacterController <Controller>k__BackingField; //Field offset: 0x68
	public readonly CharacterVariant Variant; //Field offset: 0x70
	private readonly IAssetProvider _assetProvider; //Field offset: 0x80
	private readonly IPrefabInstantiationStrategy _instantiationStrategy; //Field offset: 0x88
	private readonly IJiggleScheduler _jiggleScheduler; //Field offset: 0x90
	[CompilerGenerated]
	private readonly bool <LoadSoundBanks>k__BackingField; //Field offset: 0x98

	public BaseCharacterConfig CharacterConfig
	{
		 get { } //Length: 8
	}

	public CharacterView CharacterView
	{
		 get { } //Length: 72
	}

	public private LobbyCharacterController Controller
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public bool LoadSoundBanks
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public CharacterModelSize LobbyModelSize
	{
		 get { } //Length: 24
	}

	[TupleElementNames(new IL2CPP_TYPE_STRING[] {"WithSound", "CustomLight"})]
	protected override ValueTuple<Boolean, Boolean> StagingOptions
	{
		 get { } //Length: 108
	}

	protected CharacterViewController(CharacterVariant variant, IAssetProvider assetProvider, IJiggleScheduler jiggleScheduler, IStagingContainer stagingContainer, bool autoActivate = true) { }

	protected CharacterViewController(CharacterVariant variant, IAssetProvider assetProvider, IJiggleScheduler jiggleScheduler, IPrefabInstantiationStrategy instantiationStrategy) { }

	public BaseCharacterConfig get_CharacterConfig() { }

	public CharacterView get_CharacterView() { }

	[CompilerGenerated]
	public LobbyCharacterController get_Controller() { }

	[CompilerGenerated]
	public bool get_LoadSoundBanks() { }

	public CharacterModelSize get_LobbyModelSize() { }

	protected override ValueTuple<Boolean, Boolean> get_StagingOptions() { }

	[IteratorStateMachine(typeof(<InitFactory>d__20))]
	protected virtual IEnumerable<IAsyncOperationWithProgress> InitFactory() { }

	protected virtual void OnDisposing() { }

	protected virtual void OnViewLoaded() { }

	protected virtual void OnViewUnloaded() { }

	[CompilerGenerated]
	private void set_Controller(LobbyCharacterController value) { }

	[CompilerGenerated]
	public void set_LoadSoundBanks(bool value) { }

	public void SetEnable(bool isCharacterActive) { }

	protected virtual IAsyncInitializable<CharacterView> ViewFactory() { }

}

