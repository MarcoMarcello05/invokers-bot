namespace Client.Authentication.ExternalAuth;

public enum ExternalAuthMode : int
{
	Silent = 0,
	Manual = 1,
}

