namespace Client.Common.DI;

public static class StaticContainerFactory
{

	public static IObjectResolver CreateDetachedScope(string containerName, Action<IContainerBuilder> configure, bool enableDiagnostics = false) { }

	private static string GetProvidedDependenciesReport(IObjectResolver resolver) { }

}

