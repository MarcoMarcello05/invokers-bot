namespace Client.Common.UI;

public sealed class ButtonLongPress : IDisposable
{
	[CompilerGenerated]
	private struct <DetectLongPressAsync>d__15 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public ButtonLongPress <>4__this; //Field offset: 0x18
		public int pointerSequence; //Field offset: 0x20
		private Awaiter<Boolean> <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly Button _button; //Field offset: 0x10
	private readonly Action _onLongPress; //Field offset: 0x18
	private readonly Func<Boolean> _canLongPress; //Field offset: 0x20
	private readonly CompositeDisposable _subscriptions; //Field offset: 0x28
	private readonly CancellationTokenSource _lifetime; //Field offset: 0x30
	private int _pointerSequence; //Field offset: 0x38
	private int _pointerId; //Field offset: 0x3C
	private bool _pointerDown; //Field offset: 0x40
	private bool _longPressTriggered; //Field offset: 0x41

	public ButtonLongPress(Button button, Action onLongPress, Func<Boolean> canLongPress = null) { }

	[CompilerGenerated]
	private void <.ctor>b__9_0(Unit _) { }

	public void Cancel() { }

	private void CancelPointerHold(PointerEventData eventData) { }

	private bool CanLongPress() { }

	public bool ConsumeClick() { }

	[AsyncStateMachine(typeof(<DetectLongPressAsync>d__15))]
	private UniTask DetectLongPressAsync(int pointerSequence) { }

	public override void Dispose() { }

	private void OnPointerDown(PointerEventData eventData) { }

}

