namespace Client.Common.UI;

public abstract class ButtonStateDecorator : MonoBehaviour
{

	protected ButtonStateDecorator() { }

	public abstract void SetSelected(bool selected) { }

}

