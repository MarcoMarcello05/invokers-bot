namespace AppsFlyerSDK;

public class AFPurchaseDetailsAndroid
{
	[CompilerGenerated]
	private AFPurchaseType <purchaseType>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private string <purchaseToken>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private string <productId>k__BackingField; //Field offset: 0x20

	public string productId
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string purchaseToken
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public AFPurchaseType purchaseType
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	[CompilerGenerated]
	public string get_productId() { }

	[CompilerGenerated]
	public string get_purchaseToken() { }

	[CompilerGenerated]
	public AFPurchaseType get_purchaseType() { }

}

