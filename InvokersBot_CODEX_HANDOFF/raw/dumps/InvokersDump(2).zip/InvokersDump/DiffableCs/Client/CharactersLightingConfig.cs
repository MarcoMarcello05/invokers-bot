//Type is in global namespace

public class CharactersLightingConfig : ScriptableObject
{
	[Tooltip("Show handle for changing direction of Direct light")]
	public bool showLightHandle; //Field offset: 0x18
	[Tooltip("Direct light direction")]
	public Quaternion lightRotation; //Field offset: 0x1C
	[Tooltip("Direct light color")]
	public Color lightColor; //Field offset: 0x2C
	[Tooltip("Ambient light color")]
	public Color ambientColor; //Field offset: 0x3C
	[Tooltip("Dynamic Shadows Multiplier")]
	public float dynamicShadowMultiplier; //Field offset: 0x4C
	public Color ProjectionShadowColor; //Field offset: 0x50

	public CharactersLightingConfig() { }

	public Vector3 QuaternionForward() { }

}

