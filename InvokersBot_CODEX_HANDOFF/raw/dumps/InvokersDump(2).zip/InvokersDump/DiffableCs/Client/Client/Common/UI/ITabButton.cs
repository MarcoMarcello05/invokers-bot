namespace Client.Common.UI;

public interface ITabButton
{

	public void Bind(ITabButtonCommand command, bool earlySelection = false) { }

}

