namespace Client.CharacterAddons;

[UsedAsInjection]
public sealed class CharacterAddonAssetsProvider
{
	[CompilerGenerated]
	private struct <LoadAsync>d__2 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder<CharacterAddonAssetsHolder> <>t__builder; //Field offset: 0x8
		public long addonId; //Field offset: 0x20
		public CharacterAddonAssetsProvider <>4__this; //Field offset: 0x28
		private AssetKey <key>5__2; //Field offset: 0x30
		[Nullable(new IL2CPP_TYPE_U1[] {0, 2})]
		private Awaiter<CharacterAddonAssetsHolder> <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IScopedAssetProvider _assetProvider; //Field offset: 0x10

	public CharacterAddonAssetsProvider(IScopedAssetProvider assetProvider) { }

	[AsyncStateMachine(typeof(<LoadAsync>d__2))]
	public UniTask<CharacterAddonAssetsHolder> LoadAsync(long addonId) { }

	private bool TryGetHolder(long addonId, out CharacterAddonAssetsHolder holder) { }

	public bool TryGetHudAssets(long addonId, out Sprite icon, out CharacterAddonHudPresentation presentation) { }

	public bool TryGetIcon(long addonId, out Sprite icon) { }

	public bool TryGetLootFx(long addonId, out LevelLootFx prefab) { }

	public bool TryGetLootVisualization(long addonId, out LevelLootFx prefab) { }

	public bool TryGetScriptVfxs(long addonId, out List<BlockVfxSlot>& scriptVfxs) { }

}

