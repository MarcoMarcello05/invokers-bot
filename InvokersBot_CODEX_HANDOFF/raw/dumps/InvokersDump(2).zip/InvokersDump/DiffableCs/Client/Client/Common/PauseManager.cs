namespace Client.Common;

[UsedAsInjection]
public class PauseManager : IPauseManager, IDisposable
{
	private const float PAUSED_TIME_SCALE = 0; //Field offset: 0x0
	private readonly Subject<Boolean> _pauseStateChanged; //Field offset: 0x10
	private readonly ILogger _logger; //Field offset: 0x18
	private readonly ITimeScaleProvider _timeScaleProvider; //Field offset: 0x20
	private PauseReason _activeReasons; //Field offset: 0x28
	private float _lastTimeScale; //Field offset: 0x2C

	public override float DebugTimescale
	{
		 get { } //Length: 188
		 set { } //Length: 500
	}

	public override bool Paused
	{
		 get { } //Length: 16
	}

	public override Observable<Boolean> PauseStateChanged
	{
		 get { } //Length: 72
	}

	public PauseManager(ITimeScaleProvider timeScaleProvider) { }

	public override void Dispose() { }

	public override float get_DebugTimescale() { }

	public override bool get_Paused() { }

	public override Observable<Boolean> get_PauseStateChanged() { }

	public override void Pause(PauseReason reason) { }

	public override void Resume(PauseReason reason) { }

	public override void set_DebugTimescale(float value) { }

}

