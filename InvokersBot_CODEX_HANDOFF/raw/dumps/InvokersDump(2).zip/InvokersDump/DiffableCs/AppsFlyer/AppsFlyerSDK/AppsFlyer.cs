namespace AppsFlyerSDK;

public class AppsFlyer : MonoBehaviour
{
	public static readonly string kAppsFlyerPluginVersion; //Field offset: 0x0
	public static string CallBackObjectName; //Field offset: 0x8
	private static EventHandler onRequestResponse; //Field offset: 0x10
	private static EventHandler onInAppResponse; //Field offset: 0x18
	private static EventHandler onDeepLinkReceived; //Field offset: 0x20
	public static IAppsFlyerNativeBridge instance; //Field offset: 0x28

	public static event EventHandler OnDeepLinkReceived
	{
		 add { } //Length: 200
		 remove { } //Length: 196
	}

	public static event EventHandler OnInAppResponse
	{
		 add { } //Length: 196
		 remove { } //Length: 196
	}

	public static event EventHandler OnRequestResponse
	{
		 add { } //Length: 196
		 remove { } //Length: 196
	}

	private static AppsFlyer() { }

	public AppsFlyer() { }

	public static void add_OnDeepLinkReceived(EventHandler value) { }

	public static void add_OnInAppResponse(EventHandler value) { }

	public static void add_OnRequestResponse(EventHandler value) { }

	public static void addPushNotificationDeepLinkPath(String[] paths) { }

	public static void AFLog(string methodName, string str) { }

	public static void anonymizeUser(bool shouldAnonymizeUser) { }

	public static void attributeAndOpenStore(string appID, string campaign, Dictionary<String, String> userParams, MonoBehaviour gameObject) { }

	public static Dictionary<String, Object> CallbackStringToDictionary(string str) { }

	public static void disableSKAdNetwork(bool isDisabled) { }

	public static void enableTCFDataCollection(bool shouldCollectTcfData) { }

	public static void generateUserInviteLink(Dictionary<String, String> parameters, MonoBehaviour gameObject) { }

	public static string getAppsFlyerId() { }

	public static string getAttributionId() { }

	public static void getConversionData(string objectName) { }

	public static string getOutOfStore() { }

	public static string getSdkVersion() { }

	public static void handleOpenUrl(string url, string sourceApplication, string annotation) { }

	public static void handlePushNotifications() { }

	public void inAppResponseReceived(string response) { }

	public static void initSDK(string devKey, string appID) { }

	public static void initSDK(string devKey, string appID, MonoBehaviour gameObject) { }

	public static bool isPreInstalledApp() { }

	public static bool isSDKStopped() { }

	public static void logAdRevenue(AFAdRevenueData adRevenueData, Dictionary<String, String> additionalParameters) { }

	public void onDeepLinking(string response) { }

	private static AppsFlyerRequestEventArgs parseRequestCallback(string response) { }

	public static void recordCrossPromoteImpression(string appID, string campaign, Dictionary<String, String> parameters) { }

	public static void recordLocation(double latitude, double longitude) { }

	public static void registerUninstall(Byte[] deviceToken) { }

	public static void remove_OnDeepLinkReceived(EventHandler value) { }

	public static void remove_OnInAppResponse(EventHandler value) { }

	public static void remove_OnRequestResponse(EventHandler value) { }

	public void requestResponseReceived(string response) { }

	public static void sendEvent(string eventName, Dictionary<String, String> eventValues) { }

	public static void setAdditionalData(Dictionary<String, String> customData) { }

	public static void setAndroidIdData(string aAndroidId) { }

	public static void setAppInviteOneLinkID(string oneLinkId) { }

	public static void setCollectAndroidID(bool isCollect) { }

	public static void setCollectIMEI(bool isCollect) { }

	public static void setCollectOaid(bool isCollect) { }

	public static void setConsentData(AppsFlyerConsent appsFlyerConsent) { }

	public static void setCurrencyCode(string currencyCode) { }

	public static void setCurrentDeviceLanguage(string language) { }

	public static void setCustomerIdAndStartSDK(string id) { }

	public static void setCustomerUserId(string id) { }

	public static void setDeepLinkTimeout(long deepLinkTimeout) { }

	public static void setDisableAdvertisingIdentifiers(bool disable) { }

	public static void setDisableCollectAppleAdSupport(bool disable) { }

	public static void setDisableCollectIAd(bool disableCollectIAd) { }

	public static void setDisableNetworkData(bool disable) { }

	public static void setHost(string hostPrefixName, string hostName) { }

	public static void setImeiData(string aImei) { }

	public static void setIsDebug(bool shouldEnable) { }

	public static void setIsUpdate(bool isUpdate) { }

	public static void setMinTimeBetweenSessions(int seconds) { }

	public static void setOneLinkCustomDomain(String[] domains) { }

	public static void setOutOfStore(string sourceName) { }

	public static void setPartnerData(string partnerId, Dictionary<String, String> partnerInfo) { }

	public static void setPhoneNumber(string phoneNumber) { }

	public static void setPreinstallAttribution(string mediaSource, string campaign, string siteId) { }

	public static void setResolveDeepLinkURLs(String[] urls) { }

	[Obsolete("Please use setSharingFilterForPartners api")]
	public static void setSharingFilter(String[] partners) { }

	[Obsolete("Please use setSharingFilterForPartners api")]
	public static void setSharingFilterForAllPartners() { }

	public static void setSharingFilterForPartners(String[] partners) { }

	public static void setShouldCollectDeviceName(bool shouldCollectDeviceName) { }

	public static void setUseReceiptValidationSandbox(bool useReceiptValidationSandbox) { }

	public static void setUserEmails(EmailCryptType cryptType, String[] userEmails) { }

	public static void setUseUninstallSandbox(bool useUninstallSandbox) { }

	public static void startSDK() { }

	public static void stopSDK(bool isSDKStopped) { }

	public static void subscribeForDeepLink() { }

	public static void updateServerUninstallToken(string token) { }

	public static void validateAndSendInAppPurchase(AFPurchaseDetailsAndroid details, Dictionary<String, String> purchaseAdditionalDetails, MonoBehaviour gameObject) { }

	[Obsolete("This method is deprecated. Use validateAndSendInAppPurchase(AFPurchaseDetailsAndroid details, Dictionary<string, string> purchaseAdditionalDetails, MonoBehaviour gameObject) instead.")]
	public static void validateAndSendInAppPurchase(string publicKey, string signature, string purchaseData, string price, string currency, Dictionary<String, String> additionalParameters, MonoBehaviour gameObject) { }

	public static void validateAndSendInAppPurchase(AFSDKPurchaseDetailsIOS details, Dictionary<String, String> purchaseAdditionalDetails, MonoBehaviour gameObject) { }

	[Obsolete("This method is deprecated. Use validateAndSendInAppPurchase(AFSDKPurchaseDetailsIOS details, Dictionary<string, string> purchaseAdditionalDetails, MonoBehaviour gameObject) instead.")]
	public static void validateAndSendInAppPurchase(string productIdentifier, string price, string currency, string transactionId, Dictionary<String, String> additionalParameters, MonoBehaviour gameObject) { }

	public static void waitForATTUserAuthorizationWithTimeoutInterval(int timeoutInterval) { }

	public static void waitForCustomerUserId(bool wait) { }

}

