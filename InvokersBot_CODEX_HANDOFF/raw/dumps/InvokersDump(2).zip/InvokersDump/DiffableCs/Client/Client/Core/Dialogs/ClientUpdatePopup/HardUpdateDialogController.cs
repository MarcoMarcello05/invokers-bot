namespace Client.Core.Dialogs.ClientUpdatePopup;

[UsedAsInjection]
public class HardUpdateDialogController : AwaitableDialogController<SoftHardUpdateDialogView>
{
	[CompilerGenerated]
	private struct <HandleUpdateCommand>d__10 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public HardUpdateDialogController <>4__this; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IContentManager _contentManager; //Field offset: 0x88
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x90
	private readonly IClientUpdateAction _updateAction; //Field offset: 0x98
	protected readonly ButtonCommandBuilder _buttonCommandBuilder; //Field offset: 0xA0
	protected readonly BlockingContext _blockingContext; //Field offset: 0xA8
	protected AssetKey _assetKey; //Field offset: 0xB0

	public HardUpdateDialogController(IUISystem uiSystem, IContentManager content, IStagingContainer stagingContainer, ButtonCommandBuilder buttonCommandBuilder, ILauncherClient launcherClient, ApplicationExitController applicationExitController) { }

	private static IClientUpdateAction CreateUpdateAction(ILauncherClient launcherClient, ApplicationExitController applicationExitController) { }

	[AsyncStateMachine(typeof(<HandleUpdateCommand>d__10))]
	private ValueTask HandleUpdateCommand() { }

	protected virtual void OnViewLoaded() { }

	protected virtual IAsyncInitializable<SoftHardUpdateDialogView> ViewFactory() { }

}

