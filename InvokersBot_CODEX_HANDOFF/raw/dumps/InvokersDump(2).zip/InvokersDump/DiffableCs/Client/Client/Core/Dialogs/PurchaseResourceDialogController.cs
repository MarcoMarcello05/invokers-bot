namespace Client.Core.Dialogs;

[UsedAsInjection]
public class PurchaseResourceDialogController : AwaitableDialogController<PurchaseResourceDialogView>
{
	[CompilerGenerated]
	private struct <HandleBuyButtonClick>d__26 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public PurchaseResourceDialogController <>4__this; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30
		private Awaiter<Boolean> <>u__2; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <HandleCloseButtonClick>d__25 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public PurchaseResourceDialogController <>4__this; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <Purchase>d__27 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder<Boolean> <>t__builder; //Field offset: 0x8
		public PurchaseResourceDialogController <>4__this; //Field offset: 0x20
		private Exception <exception>5__2; //Field offset: 0x28
		[Nullable(new IL2CPP_TYPE_U1[] {0, 2, 1})]
		private ValueTaskAwaiter<ImmutableList`1<IShopRewardItem>> <>u__1; //Field offset: 0x30
		private Awaiter <>u__2; //Field offset: 0x48

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IContentManager _content; //Field offset: 0x88
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x90
	private readonly ButtonCommandBuilder _buttonCommandBuilder; //Field offset: 0x98
	private readonly IChoreographManager _choreographManager; //Field offset: 0xA0
	private readonly BlockingContext _blockingContext; //Field offset: 0xA8
	private readonly PurchaseFailedPopup _purchaseFailedPopup; //Field offset: 0xB0
	private readonly LoadingScreenService _loadingScreenService; //Field offset: 0xB8
	private readonly ClaimRewardHandler _claimRewardHandler; //Field offset: 0xC0
	private readonly GameRewardCache _gameRewardCache; //Field offset: 0xC8
	private readonly ResourcePanelController _resourcePanelController; //Field offset: 0xD0
	private ShopItem _selectedShopItem; //Field offset: 0xD8
	private ResourceTypeId _resourceType; //Field offset: 0xE0
	private PackUniqueId _packId; //Field offset: 0xE4
	private AssetKey _assetKey; //Field offset: 0xE8
	private ScopedTooltipsSystem _tooltipsSystem; //Field offset: 0xF0
	private GameItemHolderController _packInfoHolderController; //Field offset: 0xF8
	private bool _isNotEnoughResources; //Field offset: 0x100
	private Action _onPurchaseComplete; //Field offset: 0x108

	public PurchaseResourceDialogController(IUISystem uiSystem, IContentManager content, IStagingContainer stagingContainer, ButtonCommandBuilder buttonCommandBuilder, IChoreographManager choreographManager, PurchaseFailedPopup purchaseFailedPopup, LoadingScreenService loadingScreenService, GameRewardCache gameRewardCache, ClaimRewardHandler claimRewardHandler, ResourcePanelController resourcePanelController) { }

	private GameItemViewModel[] GetAllRewards() { }

	private string GetPackIconId(string iconResourceId) { }

	[AsyncStateMachine(typeof(<HandleBuyButtonClick>d__26))]
	private ValueTask HandleBuyButtonClick() { }

	[AsyncStateMachine(typeof(<HandleCloseButtonClick>d__25))]
	private ValueTask HandleCloseButtonClick() { }

	public void Init(ResourceTypeId resourceType, PackUniqueId packId, AssetKey assetKey, ScopedTooltipsSystem tooltipsSystem, bool isNotEnoughResources = false, Action onPurchaseComplete = null) { }

	protected virtual UniTask OnBeforeViewShown() { }

	protected virtual void OnDisposing() { }

	protected virtual void OnViewClose() { }

	protected virtual void OnViewLoaded() { }

	[AsyncStateMachine(typeof(<Purchase>d__27))]
	private UniTask<Boolean> Purchase() { }

	public void ReleaseHolderContent() { }

	private void SelectAndApplyPack() { }

	private void SetupNoPack() { }

	private void SetupPack(string iconResourceId, PackPrice price, int amount, ResourceTypeId resourceType) { }

	private void SetupPackIcon(string rewardId) { }

	protected virtual IAsyncInitializable<PurchaseResourceDialogView> ViewFactory() { }

}

