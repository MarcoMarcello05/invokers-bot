namespace AppsFlyerSDK;

public interface IAppsFlyerPurchaseValidation
{

}

