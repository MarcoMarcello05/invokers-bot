namespace Client.Common;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public sealed class ClientStaticDataProvider : IStaticDataProvider, IDisposable, IActiveStaticDataCache
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass15_0
	{
		[Nullable(0)]
		public ClientStaticDataProvider <>4__this; //Field offset: 0x10
		[Nullable(0)]
		public string requestedVersion; //Field offset: 0x18
		[Nullable(0)]
		public string configUrl; //Field offset: 0x20

		public <>c__DisplayClass15_0() { }

		internal Task<String> <StartPrefetchIfNeeded>b__0(string _) { }

	}

	[CompilerGenerated]
	private struct <DownloadStaticDataToValidatedTempFileAsync>d__23 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncValueTaskMethodBuilder<String> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public string operation; //Field offset: 0x30
		[Nullable(0)]
		public string requestedVersion; //Field offset: 0x38
		[Nullable(0)]
		public ClientStaticDataProvider <>4__this; //Field offset: 0x40
		[Nullable(0)]
		public string configUrl; //Field offset: 0x48
		public CancellationToken ct; //Field offset: 0x50
		[Nullable(0)]
		private string <tempPath>5__2; //Field offset: 0x58
		private TaskAwaiter <>u__1; //Field offset: 0x60

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <LoadAndActivateAsync>d__14 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public string version; //Field offset: 0x28
		[Nullable(0)]
		public ClientStaticDataProvider <>4__this; //Field offset: 0x30
		[Nullable(0)]
		public string configUrl; //Field offset: 0x38
		public CancellationToken ct; //Field offset: 0x40
		[Nullable(0)]
		private string <requestedVersion>5__2; //Field offset: 0x48
		[Nullable(0)]
		private string <downloadedVersion>5__3; //Field offset: 0x50
		[Nullable(0)]
		private ValueTaskAwaiter<Boolean> <>u__1; //Field offset: 0x58
		private ValueTaskAwaiter <>u__2; //Field offset: 0x68
		[Nullable(new IL2CPP_TYPE_U1[] {0, 2})]
		private ValueTaskAwaiter<String> <>u__3; //Field offset: 0x78
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private ValueTaskAwaiter<CompositeStaticData> <>u__4; //Field offset: 0x90

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <StartPrefetchTask>d__20 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncTaskMethodBuilder<String> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ClientStaticDataProvider <>4__this; //Field offset: 0x20
		[Nullable(0)]
		public string requestedVersion; //Field offset: 0x28
		[Nullable(0)]
		public string configUrl; //Field offset: 0x30
		[Nullable(new IL2CPP_TYPE_U1[] {0, 2})]
		private ValueTaskAwaiter<String> <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <TryDownloadStaticDataToFileSystemAsync>d__22 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncValueTaskMethodBuilder<String> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ClientStaticDataProvider <>4__this; //Field offset: 0x30
		[Nullable(0)]
		public string requestedVersion; //Field offset: 0x38
		[Nullable(0)]
		public string configUrl; //Field offset: 0x40
		public CancellationToken ct; //Field offset: 0x48
		[Nullable(new IL2CPP_TYPE_U1[] {0, 2})]
		private ValueTaskAwaiter<String> <>u__1; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <TryOpenCachedVersionAsync>d__28 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncValueTaskMethodBuilder<Boolean> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ClientStaticDataProvider <>4__this; //Field offset: 0x28
		[Nullable(0)]
		public string requestedVersion; //Field offset: 0x30
		[Nullable(0)]
		public string failureContext; //Field offset: 0x38
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private ValueTaskAwaiter<CompositeStaticData> <>u__1; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <WaitForPrefetchedVersionAsync>d__21 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ClientStaticDataProvider <>4__this; //Field offset: 0x28
		[Nullable(0)]
		public string requestedVersion; //Field offset: 0x30
		[Nullable(new IL2CPP_TYPE_U1[] {0, 2})]
		private Task<String> <prefetchTask>5__2; //Field offset: 0x38
		[Nullable(0)]
		private TaskAwaiter<Task> <>u__1; //Field offset: 0x40
		[Nullable(new IL2CPP_TYPE_U1[] {0, 2})]
		private TaskAwaiter<String> <>u__2; //Field offset: 0x48

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly TimeSpan PrefetchWaitTimeout; //Field offset: 0x0
	private readonly IStaticDataDownloader _downloader; //Field offset: 0x10
	private readonly StaticDataStorage _staticDataStorage; //Field offset: 0x18
	[Nullable(new IL2CPP_TYPE_U1[] {1, 1, 1, 2})]
	private readonly ConcurrentDictionary<String, Task`1<String>> _prefetchByVersion; //Field offset: 0x20
	private readonly Subject<String> _prefetchCompletedSubject; //Field offset: 0x28
	[Nullable(2)]
	private CompositeStaticData _compositeStaticData; //Field offset: 0x30

	public override CompositeStaticData Data
	{
		 get { } //Length: 88
	}

	private static ILogger Logger
	{
		private get { } //Length: 64
	}

	public override Observable<String> OnPrefetchCompleted
	{
		 get { } //Length: 8
	}

	private static ClientStaticDataProvider() { }

	public ClientStaticDataProvider(IStaticDataDownloader downloader) { }

	public override void ClearActiveStaticData() { }

	public override void ClearCache() { }

	private void ClearPrefetchCache() { }

	public override void Dispose() { }

	private void DisposeActiveStaticData(bool collect) { }

	[AsyncStateMachine(typeof(<DownloadStaticDataToValidatedTempFileAsync>d__23))]
	private ValueTask<String> DownloadStaticDataToValidatedTempFileAsync(string requestedVersion, string configUrl, CancellationToken ct, string operation) { }

	public override CompositeStaticData get_Data() { }

	private static ILogger get_Logger() { }

	public override Observable<String> get_OnPrefetchCompleted() { }

	[NullableContext(2)]
	public override string GetDefaultVersion(string experimentName) { }

	public override bool HasVersion(string version) { }

	[AsyncStateMachine(typeof(<LoadAndActivateAsync>d__14))]
	[NullableContext(2)]
	public override ValueTask LoadAndActivateAsync(string version, string configUrl, CancellationToken ct = null) { }

	private static string ReadPackConfigVersionFromFileHeaderOrNull(string filePath) { }

	[NullableContext(2)]
	private static void SafeDeleteFile(string path) { }

	[NullableContext(2)]
	public override void StartPrefetchIfNeeded(string version, string configUrl) { }

	[AsyncStateMachine(typeof(<StartPrefetchTask>d__20))]
	private Task<String> StartPrefetchTask(string requestedVersion, string configUrl) { }

	[AsyncStateMachine(typeof(<TryDownloadStaticDataToFileSystemAsync>d__22))]
	private ValueTask<String> TryDownloadStaticDataToFileSystemAsync(string requestedVersion, string configUrl, CancellationToken ct) { }

	[AsyncStateMachine(typeof(<TryOpenCachedVersionAsync>d__28))]
	private ValueTask<Boolean> TryOpenCachedVersionAsync(string requestedVersion, string failureContext) { }

	[AsyncStateMachine(typeof(<WaitForPrefetchedVersionAsync>d__21))]
	private ValueTask WaitForPrefetchedVersionAsync(string requestedVersion) { }

}

