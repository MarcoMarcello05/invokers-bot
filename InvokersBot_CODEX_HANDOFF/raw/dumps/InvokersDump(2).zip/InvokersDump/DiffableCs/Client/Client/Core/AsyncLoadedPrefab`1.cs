namespace Client.Core;

public class AsyncLoadedPrefab : AsyncLoadedPrefab<GameObject, TComponent>
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c<TComponent> <>9; //Field offset: 0x0
		public static Func<GameObject, GameObject> <>9__0_0; //Field offset: 0x0
		public static Func<GameObject, GameObject> <>9__1_0; //Field offset: 0x0

		private static <>c() { }

		public <>c() { }

		internal GameObject <.ctor>b__0_0(GameObject x) { }

		internal GameObject <.ctor>b__1_0(GameObject x) { }

	}


	public AsyncLoadedPrefab`1(AssetKey assetKey, IContentManager content, IPrefabInstantiationStrategy instantiationStrategy, string instanceName = null, string ownerLabelOverride = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	public AsyncLoadedPrefab`1(AssetKey assetKey, IAssetProvider assetProvider, IPrefabInstantiationStrategy instantiationStrategy, string instanceName = null, string ownerLabelOverride = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

}

