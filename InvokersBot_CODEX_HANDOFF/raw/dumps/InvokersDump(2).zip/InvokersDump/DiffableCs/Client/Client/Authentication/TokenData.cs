namespace Client.Authentication;

public class TokenData
{
	[CompilerGenerated]
	private readonly string <IdToken>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly string <AccessToken>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly string <RefreshToken>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private readonly int <ExpiresInSeconds>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private readonly string <Error>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private readonly string <ErrorDescription>k__BackingField; //Field offset: 0x38

	public string AccessToken
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string Error
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string ErrorDescription
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public int ExpiresInSeconds
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string IdToken
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public bool IsSuccess
	{
		 get { } //Length: 60
	}

	public string RefreshToken
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public TokenData(string idToken, string accessToken, string refreshToken, int expiresInSeconds, string error = null, string errorDescription = null) { }

	[CompilerGenerated]
	public string get_AccessToken() { }

	[CompilerGenerated]
	public string get_Error() { }

	[CompilerGenerated]
	public string get_ErrorDescription() { }

	[CompilerGenerated]
	public int get_ExpiresInSeconds() { }

	[CompilerGenerated]
	public string get_IdToken() { }

	public bool get_IsSuccess() { }

	[CompilerGenerated]
	public string get_RefreshToken() { }

}

