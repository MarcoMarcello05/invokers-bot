namespace Client.Configuration;

public class IntSettings : SettingsValue<Int32>
{
	private IDeviceStorage _localDeviceStorage; //Field offset: 0x20

	public IntSettings(string key, string rootKey, int defaultValue) { }

	public virtual int GetValue() { }

	public virtual void SetValue(int value) { }

}

