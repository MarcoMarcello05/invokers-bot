namespace Client.Common.Diagnostics;

public static class RemoteLoggingConfig
{
	public static bool Enabled; //Field offset: 0x0

	private static RemoteLoggingConfig() { }

}

