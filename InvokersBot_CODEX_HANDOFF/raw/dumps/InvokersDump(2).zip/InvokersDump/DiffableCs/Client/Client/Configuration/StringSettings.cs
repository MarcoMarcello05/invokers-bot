namespace Client.Configuration;

public class StringSettings : SettingsValue<String>
{
	private IDeviceStorage _localDeviceStorage; //Field offset: 0x20

	public StringSettings(string key, string rootKey, string defaultValue) { }

	public virtual string GetValue() { }

	public virtual void SetValue(string value) { }

}

