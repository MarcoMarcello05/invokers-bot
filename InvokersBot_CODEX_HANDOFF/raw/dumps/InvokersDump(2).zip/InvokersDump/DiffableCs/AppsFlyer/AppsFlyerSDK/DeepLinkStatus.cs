namespace AppsFlyerSDK;

public enum DeepLinkStatus : int
{
	FOUND = 0,
	NOT_FOUND = 1,
	ERROR = 2,
}

