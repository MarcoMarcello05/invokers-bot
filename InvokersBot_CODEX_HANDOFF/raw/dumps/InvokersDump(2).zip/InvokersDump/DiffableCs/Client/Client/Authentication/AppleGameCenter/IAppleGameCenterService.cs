namespace Client.Authentication.AppleGameCenter;

[NullableContext(1)]
public interface IAppleGameCenterService
{

	public Observable<Boolean> AuthenticationStateChanged
	{
		 get { } //Length: 0
	}

	public bool IsAuthenticated
	{
		 get { } //Length: 0
	}

	public bool IsAvailable
	{
		 get { } //Length: 0
	}

	[Nullable(2)]
	public string UserName
	{
		[NullableContext(2)]
		 get { } //Length: 0
	}

	[NullableContext(0)]
	public ValueTask<AppleGameCenterAuthStatus> AuthenticateAsync(bool manual, CancellationToken cancellationToken = null) { }

	public Observable<Boolean> get_AuthenticationStateChanged() { }

	public bool get_IsAuthenticated() { }

	public bool get_IsAvailable() { }

	[NullableContext(2)]
	public string get_UserName() { }

	public ValueTask<AppleGameCenterIdentityVerificationPayload> GetIdentityVerificationPayloadAsync(CancellationToken cancellationToken = null) { }

}

