namespace Client.Characters;

public interface ICharacterModule : IDisposable
{

	public void Bind(CharacterView view) { }

	public void OnViewDisabled() { }

	public void OnViewEnabled() { }

	public void Tick(float deltaTime) { }

	public void Unbind() { }

}

