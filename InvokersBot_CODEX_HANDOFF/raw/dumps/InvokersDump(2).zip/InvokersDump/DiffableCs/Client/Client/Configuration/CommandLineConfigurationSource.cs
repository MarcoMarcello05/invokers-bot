namespace Client.Configuration;

[Nullable(0)]
[NullableContext(1)]
public class CommandLineConfigurationSource : IConfigurationSource
{
	[CompilerGenerated]
	private sealed class <GetIOsArgs>d__4 : IEnumerable<String>, IEnumerable, IEnumerator<String>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private string <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private IEnumerable<String> switchMapKeys; //Field offset: 0x28
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		public IEnumerable<String> <>3__switchMapKeys; //Field offset: 0x30
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private IEnumerator<String> <>7__wrap1; //Field offset: 0x38
		[Nullable(0)]
		private string <key>5__3; //Field offset: 0x40

		private override string System.Collections.Generic.IEnumerator<System.String>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <GetIOsArgs>d__4(int <>1__state) { }

		private void <>m__Finally1() { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<String> System.Collections.Generic.IEnumerable<System.String>.GetEnumerator() { }

		[DebuggerHidden]
		private override string System.Collections.Generic.IEnumerator<System.String>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private sealed class <SelectMany>d__6 : IEnumerable<SwitchMap>, IEnumerable, IEnumerator<SwitchMap>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private SwitchMap <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		private IEnumerable<SwitchMap>[] switchMaps; //Field offset: 0x28
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		public IEnumerable<SwitchMap>[] <>3__switchMaps; //Field offset: 0x30
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		private IEnumerable<SwitchMap>[] <>7__wrap1; //Field offset: 0x38
		private int <>7__wrap2; //Field offset: 0x40
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private IEnumerator<SwitchMap> <>7__wrap3; //Field offset: 0x48

		private override SwitchMap System.Collections.Generic.IEnumerator<Shared.Common.CommandLine.SwitchMap>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <SelectMany>d__6(int <>1__state) { }

		private void <>m__Finally1() { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<SwitchMap> System.Collections.Generic.IEnumerable<Shared.Common.CommandLine.SwitchMap>.GetEnumerator() { }

		[DebuggerHidden]
		private override SwitchMap System.Collections.Generic.IEnumerator<Shared.Common.CommandLine.SwitchMap>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	public static readonly IEnumerable<SwitchMap>[] DefaultSwitchMaps; //Field offset: 0x0
	private readonly IEnumerable<String> _args; //Field offset: 0x10
	private readonly Dictionary<String, SwitchMap> _switchMaps; //Field offset: 0x18

	private static CommandLineConfigurationSource() { }

	public CommandLineConfigurationSource(IEnumerable<String> args = null, IEnumerable<SwitchMap>[] switchMaps) { }

	public override IConfigurationProvider Build(IConfigurationBuilder builder) { }

	[IteratorStateMachine(typeof(<GetIOsArgs>d__4))]
	private static IEnumerable<String> GetIOsArgs(IEnumerable<String> switchMapKeys) { }

	[IteratorStateMachine(typeof(<SelectMany>d__6))]
	private static IEnumerable<SwitchMap> SelectMany(IEnumerable<SwitchMap>[] switchMaps) { }

}

