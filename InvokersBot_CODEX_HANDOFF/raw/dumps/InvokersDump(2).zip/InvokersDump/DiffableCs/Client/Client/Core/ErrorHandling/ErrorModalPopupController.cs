namespace Client.Core.ErrorHandling;

public class ErrorModalPopupController : AwaitableDialogController<ErrorModalPopup>
{
	private readonly IContentManager _content; //Field offset: 0x88
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x90
	private readonly ISupportService _supportService; //Field offset: 0x98
	private readonly AssetKey _assetKey; //Field offset: 0xA0
	private readonly string _title; //Field offset: 0xA8
	private readonly string _message; //Field offset: 0xB0
	private readonly string _buttonLabel; //Field offset: 0xB8
	private readonly string _errorCode; //Field offset: 0xC0
	private UnityAction _closeHandler; //Field offset: 0xC8
	private UnityAction _supportHandler; //Field offset: 0xD0

	public ErrorModalPopupController(IContentManager content, IStagingContainer stagingContainer, IUISystem uiSystem, ISupportService supportService, AssetKey assetKey, string title, string message, string buttonLabel, string errorCode = null) { }

	private void OnCloseClicked() { }

	private void OnSupportClicked() { }

	protected virtual void OnViewClose() { }

	protected virtual void OnViewLoaded() { }

	protected virtual IAsyncInitializable<ErrorModalPopup> ViewFactory() { }

}

