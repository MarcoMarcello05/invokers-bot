namespace Client.Characters;

public sealed class LobbyCharacterController : CharacterControllerBase, IMetaSoundTarget
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Action<Unit, LobbyCharacterController> <>9__31_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal void <OnBound>b__31_0(Unit _, LobbyCharacterController controller) { }

	}

	private IDisposable _tick; //Field offset: 0x58
	[CompilerGenerated]
	private readonly LobbyIntroModule <Intro>k__BackingField; //Field offset: 0x60
	[CompilerGenerated]
	private readonly LobbyLightModule <Light>k__BackingField; //Field offset: 0x68
	[CompilerGenerated]
	private LobbyStagePart <Stage>k__BackingField; //Field offset: 0x70
	[CompilerGenerated]
	private IdleVariantsPart <IdleVariants>k__BackingField; //Field offset: 0x78

	public CharacterStandSide BattleResultStandSide
	{
		 get { } //Length: 128
	}

	public Transform FollowerRootBone
	{
		 get { } //Length: 128
	}

	public bool HidePlatform
	{
		 get { } //Length: 136
	}

	public private IdleVariantsPart IdleVariants
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public LobbyIntroModule Intro
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public Transform IntroCamera
	{
		 get { } //Length: 128
	}

	public LobbyLightModule Light
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public CharacterModelSize LobbyModelSize
	{
		 get { } //Length: 128
	}

	public InfoPosition RevealShortInfoPosition
	{
		 get { } //Length: 128
	}

	public private LobbyStagePart Stage
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public bool SupportsFovInIntro
	{
		 get { } //Length: 136
	}

	public LobbyCharacterController(IJiggleScheduler jiggleScheduler) { }

	public CharacterStandSide get_BattleResultStandSide() { }

	public Transform get_FollowerRootBone() { }

	public bool get_HidePlatform() { }

	[CompilerGenerated]
	public IdleVariantsPart get_IdleVariants() { }

	[CompilerGenerated]
	public LobbyIntroModule get_Intro() { }

	public Transform get_IntroCamera() { }

	[CompilerGenerated]
	public LobbyLightModule get_Light() { }

	public CharacterModelSize get_LobbyModelSize() { }

	public InfoPosition get_RevealShortInfoPosition() { }

	[CompilerGenerated]
	public LobbyStagePart get_Stage() { }

	public bool get_SupportsFovInIntro() { }

	public void Initialize(BaseCharacterConfig config, bool withSound, bool customLightActive) { }

	public void InterruptMetaSounds() { }

	protected virtual void OnBound() { }

	protected virtual void OnIdleAnimationStarted() { }

	protected virtual void OnIdleBreak(int idleBreakIndex) { }

	protected virtual void OnUnbinding() { }

	[CompilerGenerated]
	private void set_IdleVariants(IdleVariantsPart value) { }

	[CompilerGenerated]
	private void set_Stage(LobbyStagePart value) { }

	public override void SetMetaSoundsEnabled(bool enabled, bool immediate) { }

}

