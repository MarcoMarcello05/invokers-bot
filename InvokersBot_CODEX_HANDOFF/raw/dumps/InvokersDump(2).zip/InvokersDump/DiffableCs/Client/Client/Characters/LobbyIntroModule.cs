namespace Client.Characters;

public sealed class LobbyIntroModule : ICharacterModule, IDisposable
{
	private const string INTRO_CLIP = "IntroLOB"; //Field offset: 0x0
	private const string REVEAL_CLIP = "RevealLOB"; //Field offset: 0x0
	private readonly CharacterAnimationModule _animation; //Field offset: 0x10
	private readonly CharacterSoundModule _sound; //Field offset: 0x18

	public LobbyIntroModule(CharacterAnimationModule animation, CharacterSoundModule sound) { }

	public override void Bind(CharacterView view) { }

	public override void Dispose() { }

	public void FtueIdle() { }

	public void FtueIntro(bool withSound = true) { }

	public float GetIntroAnimationTime() { }

	public float GetRevealAnimationTime() { }

	public void Intro() { }

	public void IntroSoundStop() { }

	public void Reveal(bool withSound = true) { }

	public void RevealSoundStop() { }

}

