namespace Client.Analytics;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public sealed class FirebaseService : IDisposable
{
	[CompilerGenerated]
	private sealed class <>c
	{
		[Nullable(0)]
		public static readonly <>c <>9; //Field offset: 0x0
		[Nullable(0)]
		public static Action<Unit, FirebaseService> <>9__39_0; //Field offset: 0x8
		[Nullable(0)]
		public static Action<Unit, FirebaseService> <>9__39_1; //Field offset: 0x10

		private static <>c() { }

		public <>c() { }

		[NullableContext(0)]
		internal void <ContinueLateInitAsync>b__39_0(Unit _, FirebaseService self) { }

		[NullableContext(0)]
		internal void <ContinueLateInitAsync>b__39_1(Unit _, FirebaseService self) { }

	}

	[CompilerGenerated]
	private struct <AwaitEarlyInitWithTimeout>d__38 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<Boolean> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public FirebaseService <>4__this; //Field offset: 0x20
		[Nullable(0)]
		[TupleElementNames(new IL2CPP_TYPE_STRING[] {"IsTimeout", "Result"})]
		private Awaiter<ValueTuple<Boolean, Boolean>> <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ContinueLateInitAsync>d__39 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskVoidMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public FirebaseService <>4__this; //Field offset: 0x10
		[Nullable(0)]
		[TupleElementNames(new IL2CPP_TYPE_STRING[] {"IsTimeout", "Result"})]
		private Awaiter<ValueTuple<Boolean, Boolean>> <>u__1; //Field offset: 0x18
		private Awaiter <>u__2; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <EarlyInitAsync>d__30 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public FirebaseService <>4__this; //Field offset: 0x18
		private AutoScope <initScope>5__2; //Field offset: 0x20
		private Awaiter <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <EnsureInitialisedAsync>d__31 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public FirebaseService <>4__this; //Field offset: 0x18
		[Nullable(0)]
		public IUserTrackingService userTracking; //Field offset: 0x20
		[Nullable(0)]
		private Awaiter<Boolean> <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <PropagateFirebaseIdAsync>d__40 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public FirebaseService <>4__this; //Field offset: 0x18
		[Nullable(0)]
		private string <pseudoId>5__2; //Field offset: 0x20
		private int <attempt>5__3; //Field offset: 0x28
		[Nullable(new IL2CPP_TYPE_U1[] {0, 2})]
		private Awaiter<String> <>u__1; //Field offset: 0x30
		private Awaiter <>u__2; //Field offset: 0x48

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly TimeSpan MaxInitWaitTime; //Field offset: 0x0
	private const int MAX_PSEUDO_ID_ATTEMPTS = 3; //Field offset: 0x0
	private const int MAX_QUEUED_EVENTS = 512; //Field offset: 0x0
	private static readonly TimeSpan MaxTotalWaitTime; //Field offset: 0x8
	private static readonly TimeSpan PseudoIdRetryDelay; //Field offset: 0x10
	private static readonly Activity FirebaseInitialize; //Field offset: 0x18
	private readonly ILogger _log; //Field offset: 0x10
	private readonly IFirebaseRuntime _runtime; //Field offset: 0x18
	[Nullable(new IL2CPP_TYPE_U1[] {1, 0, 1, 2})]
	[TupleElementNames(new IL2CPP_TYPE_STRING[] {"eventName", "parameters"})]
	private readonly Queue<ValueTuple`2<String, IReadOnlyCollection`1<EventParam>>> _eventQueue; //Field offset: 0x20
	private readonly object _queueLock; //Field offset: 0x28
	private readonly CompositeDisposable _disposables; //Field offset: 0x30
	private readonly UniTaskCompletionSource<Boolean> _earlyInitTcs; //Field offset: 0x38
	private bool _isFirebaseEnabled; //Field offset: 0x40
	private bool _isInitialized; //Field offset: 0x41
	private int _earlyInitStarted; //Field offset: 0x44
	private int _lateInitStarted; //Field offset: 0x48
	[Nullable(2)]
	private string _pendingCuidAccountId; //Field offset: 0x50
	private int _droppedEventCount; //Field offset: 0x58
	private readonly IConsentService _consentService; //Field offset: 0x60
	[Nullable(2)]
	private IUserTrackingService _userTracking; //Field offset: 0x68
	private bool _pseudoIdFetchInProgress; //Field offset: 0x70
	private bool _pseudoIdFetchFailed; //Field offset: 0x71

	internal int DroppedEventCount
	{
		internal get { } //Length: 192
	}

	public bool IsEnabled
	{
		 get { } //Length: 24
	}

	public static bool IsSupportedOnCurrentPlatform
	{
		 get { } //Length: 256
	}

	private static FirebaseService() { }

	public FirebaseService(IFirebaseRuntime runtime, IConsentService consentService, bool enabled) { }

	private void ApplyAccountCuid(string accountId) { }

	internal void ApplyConsent() { }

	private void ApplyConsentCore() { }

	[AsyncStateMachine(typeof(<AwaitEarlyInitWithTimeout>d__38))]
	[NullableContext(0)]
	private UniTask<Boolean> AwaitEarlyInitWithTimeout() { }

	public void BeginEarlyInitialization() { }

	[AsyncStateMachine(typeof(<ContinueLateInitAsync>d__39))]
	private UniTaskVoid ContinueLateInitAsync() { }

	public override void Dispose() { }

	[AsyncStateMachine(typeof(<EarlyInitAsync>d__30))]
	private UniTask EarlyInitAsync() { }

	[AsyncStateMachine(typeof(<EnsureInitialisedAsync>d__31))]
	public UniTask EnsureInitialisedAsync(IUserTrackingService userTracking) { }

	internal void FlushAndMarkInitialized() { }

	internal int get_DroppedEventCount() { }

	public bool get_IsEnabled() { }

	public static bool get_IsSupportedOnCurrentPlatform() { }

	public void LogEvent(IClientBiEvent biEvent) { }

	public void LogEvent(string name, IReadOnlyCollection<EventParam> parameters = null) { }

	[NullableContext(2)]
	public void OnAccountResolved(string accountId) { }

	private void OnTelemetryChanged(Dictionary<String, String> tags) { }

	[AsyncStateMachine(typeof(<PropagateFirebaseIdAsync>d__40))]
	private UniTask PropagateFirebaseIdAsync() { }

	public void SetUserProperty(string key, string value) { }

	internal void SetUserPropertyIfNotNull(string key, string value) { }

}

