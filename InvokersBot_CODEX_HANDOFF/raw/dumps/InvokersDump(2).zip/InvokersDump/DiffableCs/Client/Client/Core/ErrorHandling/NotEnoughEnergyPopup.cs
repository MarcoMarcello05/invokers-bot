namespace Client.Core.ErrorHandling;

public class NotEnoughEnergyPopup : BaseDialogView
{
	private const string DEFAULT_PACK_ICON = "S_GemShop_EnergyRefill"; //Field offset: 0x0
	[SerializeField]
	private HZButton _closeButton; //Field offset: 0x58
	[SerializeField]
	private HZButton _backgroundCloseButton; //Field offset: 0x60
	[SerializeField]
	private HZButton _okButton; //Field offset: 0x68
	[SerializeField]
	private HZButton _buyButton; //Field offset: 0x70
	[SerializeField]
	private GameItemHolderView _gemsItemHolderView; //Field offset: 0x78
	[SerializeField]
	private GameItemHolderView _energyItemHolderView; //Field offset: 0x80
	[SerializeField]
	private GameItemHolderView _packPresentation; //Field offset: 0x88
	[SerializeField]
	private GameItemHolderView _energyObtainedHolder; //Field offset: 0x90
	[SerializeField]
	private PatternLocalizedText _descriptionText; //Field offset: 0x98
	[SerializeField]
	private TextMeshProUGUI _priceLabel; //Field offset: 0xA0
	[SerializeField]
	private GameObject _baseContent; //Field offset: 0xA8
	[SerializeField]
	private GameObject _noPackContent; //Field offset: 0xB0
	private GameItemHolderController _gemsHolderController; //Field offset: 0xB8
	private GameItemHolderController _energyHolderController; //Field offset: 0xC0
	private GameItemHolderController _packHolderController; //Field offset: 0xC8
	private GameItemHolderController _energyObtainedHolderController; //Field offset: 0xD0

	public HZButton BuyButton
	{
		 get { } //Length: 8
	}

	public HZButton CloseButton
	{
		 get { } //Length: 8
	}

	public HZButton OkButton
	{
		 get { } //Length: 8
	}

	public NotEnoughEnergyPopup() { }

	public void BindCloseButton(IButtonCommand closeCommand) { }

	public HZButton get_BuyButton() { }

	public HZButton get_CloseButton() { }

	public HZButton get_OkButton() { }

	private void OnDestroy() { }

	private void OnValidate() { }

	public void ReleaseHolderContent() { }

	public void SetCurrentBalance(int gems, int energy, int maxEnergy) { }

	public void SetupNoPack() { }

	public void SetupPack(string packIconPath, PackPrice price, int energyAmount) { }

	public void SetViewProvider(GameRewardCache gameRewardCache) { }

}

