namespace Client;

[UsedAsInjection]
public sealed class ContentManager : IContentManager
{
	[CompilerGenerated]
	private readonly IAssetProvider <Addressables>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly IDownloadManager <Downloads>k__BackingField; //Field offset: 0x18

	public override IAssetProvider Addressables
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public override IDownloadManager Downloads
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public override IResourcesApi Resources
	{
		 get { } //Length: 88
	}

	public ContentManager(IAssetProvider assetProvider, IDownloadManager downloads) { }

	[CompilerGenerated]
	public override IAssetProvider get_Addressables() { }

	[CompilerGenerated]
	public override IDownloadManager get_Downloads() { }

	public override IResourcesApi get_Resources() { }

}

