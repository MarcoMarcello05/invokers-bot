//Type is in global namespace

public class BakeryLightmapGroup : ScriptableObject
{
	internal enum AtlasPacker : int
	{
		Default = 0,
		xatlas = 1,
		Auto = 1000,
	}

	internal enum ftLMGroupMode : int
	{
		OriginalUV = 0,
		PackAtlas = 1,
		Vertex = 2,
	}

	internal enum HoleFilling : int
	{
		Auto = 0,
		Yes = 1,
		No = 2,
	}

	internal enum RenderDirMode : int
	{
		None = 0,
		BakedNormalMaps = 1,
		DominantDirection = 2,
		RNM = 3,
		SH = 4,
		ProbeSH = 5,
		MonoSH = 6,
		ProbeSHL2 = 7,
		Auto = 1000,
	}

	internal enum RenderMode : int
	{
		FullLighting = 0,
		Indirect = 1,
		Shadowmask = 2,
		Subtractive = 3,
		AmbientOcclusionOnly = 4,
		Auto = 1000,
	}

	[SerializeField]
	public int resolution; //Field offset: 0x18
	[SerializeField]
	public int bitmask; //Field offset: 0x1C
	[SerializeField]
	public int id; //Field offset: 0x20
	public int sortingID; //Field offset: 0x24
	[SerializeField]
	public bool isImplicit; //Field offset: 0x28
	[SerializeField]
	public float area; //Field offset: 0x2C
	[SerializeField]
	public int totalVertexCount; //Field offset: 0x30
	[SerializeField]
	public int vertexCounter; //Field offset: 0x34
	[SerializeField]
	public int sceneLodLevel; //Field offset: 0x38
	[SerializeField]
	public bool autoResolution; //Field offset: 0x3C
	[SerializeField]
	public string sceneName; //Field offset: 0x40
	[SerializeField]
	public int tag; //Field offset: 0x48
	[SerializeField]
	public bool containsTerrains; //Field offset: 0x4C
	[SerializeField]
	public bool probes; //Field offset: 0x4D
	[SerializeField]
	public ftLMGroupMode mode; //Field offset: 0x50
	[SerializeField]
	public RenderMode renderMode; //Field offset: 0x54
	[SerializeField]
	public RenderDirMode renderDirMode; //Field offset: 0x58
	[SerializeField]
	public AtlasPacker atlasPacker; //Field offset: 0x5C
	[SerializeField]
	public HoleFilling holeFilling; //Field offset: 0x60
	[SerializeField]
	public int vertexSamplingDensity; //Field offset: 0x64
	[SerializeField]
	public bool computeSSS; //Field offset: 0x68
	[SerializeField]
	public int sssSamples; //Field offset: 0x6C
	[SerializeField]
	public float sssDensity; //Field offset: 0x70
	[SerializeField]
	public Color sssColor; //Field offset: 0x74
	[SerializeField]
	public float sssScale; //Field offset: 0x84
	[SerializeField]
	public float fakeShadowBias; //Field offset: 0x88
	[SerializeField]
	public bool transparentSelfShadow; //Field offset: 0x8C
	[SerializeField]
	public bool flipNormal; //Field offset: 0x8D
	[SerializeField]
	public string parentName; //Field offset: 0x90
	[SerializeField]
	public string overridePath; //Field offset: 0x98
	[SerializeField]
	public bool fixPos3D; //Field offset: 0xA0
	[SerializeField]
	public Vector3 voxelSize; //Field offset: 0xA4
	public int passedFilter; //Field offset: 0xB0

	public BakeryLightmapGroup() { }

	public BakeryLightmapGroupPlain GetPlainStruct() { }

}

