namespace Client.Core;

[Nullable(0)]
[NullableContext(1)]
public sealed class AsyncOperationParallel : BaseAsyncOperationGroup
{
	[CompilerGenerated]
	private struct <HandleAllOperation>d__8 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public AsyncOperationParallel <>4__this; //Field offset: 0x18
		[Nullable(0)]
		public IOperationProgressObserver observer; //Field offset: 0x20
		private AutoScope <__>5__2; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <RunAsyncOperation>d__9 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public IAsyncOperationWithProgress operation; //Field offset: 0x18
		[Nullable(0)]
		public AsyncOperationParallel <>4__this; //Field offset: 0x20
		public int index; //Field offset: 0x28
		[Nullable(0)]
		private Stopwatch <sw>5__2; //Field offset: 0x30
		private Awaiter <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[Nullable(0)]
	private sealed class ParallelOperationProgressObserver : IOperationProgressObserver
	{
		private readonly AsyncOperationParallel _owner; //Field offset: 0x10
		private readonly int _index; //Field offset: 0x18

		public ParallelOperationProgressObserver(AsyncOperationParallel owner, int index) { }

		public override void OnOperationFinished(string operationName) { }

		public override void OnOperationProgressUpdate(float progress, string stepMsg) { }

		public override void OnOperationStarted(string operationName) { }

	}

	private static readonly Activity OpActivity; //Field offset: 0x0
	private readonly ILogger _logger; //Field offset: 0x20
	[Nullable(2)]
	private readonly Action _onComplete; //Field offset: 0x28
	[Nullable(2)]
	private Single[] _individualProgress; //Field offset: 0x30
	[Nullable(new IL2CPP_TYPE_U1[] {2, 1})]
	private String[] _individualMessages; //Field offset: 0x38
	[Nullable(2)]
	private IOperationProgressObserver _observer; //Field offset: 0x40
	private int _lastUpdatedIndex; //Field offset: 0x48

	private static AsyncOperationParallel() { }

	public AsyncOperationParallel(string operationId, Action onComplete = null) { }

	[AsyncStateMachine(typeof(<HandleAllOperation>d__8))]
	protected virtual UniTask HandleAllOperation(IOperationProgressObserver observer) { }

	[AsyncStateMachine(typeof(<RunAsyncOperation>d__9))]
	private UniTask RunAsyncOperation(IAsyncOperationWithProgress operation, int index) { }

	private void UpdateOperationProgress(int index, float progress, string stepMsg) { }

	private void UpdateTotalProgress() { }

}

