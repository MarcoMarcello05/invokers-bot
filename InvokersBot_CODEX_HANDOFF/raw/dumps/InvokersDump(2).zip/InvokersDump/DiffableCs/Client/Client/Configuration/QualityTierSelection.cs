namespace Client.Configuration;

public static class QualityTierSelection
{
	public const string KEY = "GameSettings > Graphics > QualityConfig"; //Field offset: 0x0

	public static void Clear() { }

	public static QualityTier Get() { }

	public static void Set(QualityTier tier) { }

}

