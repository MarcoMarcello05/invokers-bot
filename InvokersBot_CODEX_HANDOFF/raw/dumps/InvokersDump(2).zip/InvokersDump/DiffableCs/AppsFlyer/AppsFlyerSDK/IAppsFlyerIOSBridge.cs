namespace AppsFlyerSDK;

public interface IAppsFlyerIOSBridge : IAppsFlyerNativeBridge
{

	public void disableSKAdNetwork(bool isDisabled) { }

	public void handleOpenUrl(string url, string sourceApplication, string annotation) { }

	public void registerUninstall(Byte[] deviceToken) { }

	public void setCurrentDeviceLanguage(string language) { }

	public void setDisableCollectAppleAdSupport(bool disable) { }

	public void setDisableCollectIAd(bool disableCollectIAd) { }

	public void setShouldCollectDeviceName(bool shouldCollectDeviceName) { }

	public void setUseReceiptValidationSandbox(bool useReceiptValidationSandbox) { }

	public void setUseUninstallSandbox(bool useUninstallSandbox) { }

	public void validateAndSendInAppPurchase(string productIdentifier, string price, string currency, string transactionId, Dictionary<String, String> additionalParameters, MonoBehaviour gameObject) { }

	public void validateAndSendInAppPurchase(AFSDKPurchaseDetailsIOS details, Dictionary<String, String> purchaseAdditionalDetails, MonoBehaviour gameObject) { }

	public void waitForATTUserAuthorizationWithTimeoutInterval(int timeoutInterval) { }

}

