namespace Client.Common.DI;

[UsedAsInjection]
public class GameScopeOverrideOnce
{
	private bool _active; //Field offset: 0x10
	private Action<IContainerBuilder> _build; //Field offset: 0x18
	private Action<IReflectionServiceInjector> _afterBuild; //Field offset: 0x20
	[CompilerGenerated]
	private CompositeStaticData <StaticDataOverride>k__BackingField; //Field offset: 0x28

	public bool IsActive
	{
		 get { } //Length: 8
	}

	public CompositeStaticData StaticDataOverride
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public GameScopeOverrideOnce() { }

	public void Configure(IContainerBuilder builder) { }

	private void Finish(IObjectResolver resolver) { }

	public bool get_IsActive() { }

	[CompilerGenerated]
	public CompositeStaticData get_StaticDataOverride() { }

	public void Init(Action<IContainerBuilder> build, Action<IReflectionServiceInjector> afterBuild) { }

	[CompilerGenerated]
	public void set_StaticDataOverride(CompositeStaticData value) { }

}

