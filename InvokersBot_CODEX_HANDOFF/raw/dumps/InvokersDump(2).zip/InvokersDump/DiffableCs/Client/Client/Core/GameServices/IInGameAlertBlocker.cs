namespace Client.Core.GameServices;

public interface IInGameAlertBlocker
{

}

