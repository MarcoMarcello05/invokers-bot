namespace Client.Configuration;

public sealed class PlatformConfigSource : IConfigurationSource
{
	private readonly string _basePath; //Field offset: 0x10
	private readonly PlatformConfigRules _rules; //Field offset: 0x18
	private readonly QualityTier _deviceQualityOverride; //Field offset: 0x20

	public PlatformConfigSource(string basePath, PlatformConfigRules rules, QualityTier deviceQualityOverride = 0) { }

	public override IConfigurationProvider Build(IConfigurationBuilder builder) { }

}

