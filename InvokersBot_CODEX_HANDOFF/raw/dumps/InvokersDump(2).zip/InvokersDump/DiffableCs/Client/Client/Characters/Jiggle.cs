namespace Client.Characters;

public class Jiggle : MonoBehaviour
{
	private const float TORQUE_FACTOR = 0,001; //Field offset: 0x0
	private bool m_Initialised; //Field offset: 0x20
	private Quaternion m_RestLocalRotation; //Field offset: 0x24
	private Quaternion m_LastWorldRotation; //Field offset: 0x34
	private Quaternion m_Torque; //Field offset: 0x44
	private Vector3 m_LastCenterOfMassWorld; //Field offset: 0x54
	private float m_NoisePhase; //Field offset: 0x60
	private bool m_HasLastFrame; //Field offset: 0x64
	public bool UpdateWithPhysics; //Field offset: 0x65
	public bool UseCenterOfMass; //Field offset: 0x66
	public Vector3 CenterOfMass; //Field offset: 0x68
	public float CenterOfMassInertia; //Field offset: 0x74
	public bool AddWind; //Field offset: 0x78
	public Vector3 WindDirection; //Field offset: 0x7C
	public float WindStrength; //Field offset: 0x88
	public bool AddNoise; //Field offset: 0x8C
	public float NoiseStrength; //Field offset: 0x90
	public float NoiseScale; //Field offset: 0x94
	public float NoiseSpeed; //Field offset: 0x98
	public float RotationInertia; //Field offset: 0x9C
	public float Gravity; //Field offset: 0xA0
	public float SpringStrength; //Field offset: 0xA4
	public float Dampening; //Field offset: 0xA8
	public bool BlendToOriginalRotation; //Field offset: 0xAC
	public bool Hinge; //Field offset: 0xAD
	public float HingeAngle; //Field offset: 0xB0
	public bool UseAngleLimit; //Field offset: 0xB4
	public float AngleLimit; //Field offset: 0xB8
	public bool UseSoftLimit; //Field offset: 0xBC
	public float SoftLimitInfluence; //Field offset: 0xC0
	public float SoftLimitStrength; //Field offset: 0xC4
	public bool ShowViewportGizmos; //Field offset: 0xC8
	public float GizmoScale; //Field offset: 0xCC

	public Jiggle() { }

	private void DrawGizmosArc(Vector3 center, Vector3 startPoint, Vector3 normal, float degrees) { }

	private Quaternion GetClosestRotationFromTo(Vector3 from, Vector3 to) { }

	private Vector3 GetHingeNormalWorld() { }

	private Vector3 GetNoiseVector(Vector3 pos, float scale, float phase) { }

	private Quaternion GetRestRotationWorld() { }

	private void OnDrawGizmos() { }

	private void OnDrawGizmosSelected() { }

	public void PrepareForSimulation() { }

	public void ScheduledUpdate(float deltaTime) { }

}

