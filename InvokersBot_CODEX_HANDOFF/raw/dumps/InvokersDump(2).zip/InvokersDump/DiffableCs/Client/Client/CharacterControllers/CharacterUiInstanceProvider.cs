namespace Client.CharacterControllers;

[UsedAsInjection]
public class CharacterUiInstanceProvider : AsyncInitializableBase
{
	[CompilerGenerated]
	private sealed class <InitFactory>d__11 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public CharacterUiInstanceProvider <>4__this; //Field offset: 0x28

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <InitFactory>d__11(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private struct <LoadConfigAsync>d__13 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public CharacterUiInstanceProvider <>4__this; //Field offset: 0x18
		private AutoScope <_>5__2; //Field offset: 0x20
		private IAssetRequest<BuffsInfo> <buffsInfoRequest>5__3; //Field offset: 0x38
		private IAssetRequest<CharacterWeaponToIconList> <weaponIconsRequest>5__4; //Field offset: 0x40
		private Awaiter<BuffsInfo> <>u__1; //Field offset: 0x48
		private Awaiter<CharacterWeaponToIconList> <>u__2; //Field offset: 0x60
		private Element <el>5__5; //Field offset: 0x78
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 0})]
		private Awaiter<IAssetRequest<Sprite>> <>u__3; //Field offset: 0x80

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private sealed class <RequiredAssets>d__12 : IEnumerable<AssetKey>, IEnumerable, IEnumerator<AssetKey>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private AssetKey <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		private Element <el>5__2; //Field offset: 0x24

		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <RequiredAssets>d__12(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<AssetKey> System.Collections.Generic.IEnumerable<Client.AssetKey>.GetEnumerator() { }

		[DebuggerHidden]
		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	private static readonly Activity InitActivity; //Field offset: 0x0
	private readonly IAssetProvider _assetProvider; //Field offset: 0x58
	private readonly CharacterUIPool _characterUIPool; //Field offset: 0x60
	private readonly BuffViewPool _buffViewPool; //Field offset: 0x68
	private readonly BattleSceneStructureProvider _battleSceneStructureProvider; //Field offset: 0x70
	private BuffsInfo _buffsInfo; //Field offset: 0x78
	private Dictionary<Element, Sprite> _spritesMap; //Field offset: 0x80

	private static CharacterUiInstanceProvider() { }

	public CharacterUiInstanceProvider(IAssetProvider assetProvider, CharacterUIPool characterUIPool, BuffViewPool buffViewPool, BattleSceneStructureProvider battleSceneStructureProvider) { }

	public CharacterUI CreateCharacterUI(Transform targetTransform, ref CharacterState state, bool isEnemy) { }

	protected virtual void DisposeInternal() { }

	public Sprite GetSpriteForElement(Element sdElement) { }

	[IteratorStateMachine(typeof(<InitFactory>d__11))]
	protected virtual IEnumerable<IAsyncOperationWithProgress> InitFactory() { }

	[AsyncStateMachine(typeof(<LoadConfigAsync>d__13))]
	private UniTask LoadConfigAsync(IOperationProgressObserver arg) { }

	private static void OnDead(CharacterUI instance) { }

	[IteratorStateMachine(typeof(<RequiredAssets>d__12))]
	private static IEnumerable<AssetKey> RequiredAssets() { }

}

