namespace Client.Common.UI;

public class HZMultiToggle : UIBehaviour
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		[TupleElementNames(new IL2CPP_TYPE_STRING[] {"self", "index"})]
		public static Action<Unit, ValueTuple`2<HZMultiToggle, Int32>> <>9__24_0; //Field offset: 0x8
		public static Action<Unit, HZMultiToggle> <>9__24_1; //Field offset: 0x10

		private static <>c() { }

		public <>c() { }

		internal void <BindButtons>b__24_0(Unit _, ValueTuple<HZMultiToggle, Int32> x) { }

		internal void <BindButtons>b__24_1(Unit _, HZMultiToggle self) { }

	}

	[CompilerGenerated]
	private struct <HandleSelectionAsync>d__25 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public int index; //Field offset: 0x18
		public HZMultiToggle <>4__this; //Field offset: 0x20
		public bool animate; //Field offset: 0x28
		private ValueTaskAwaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <SelectButtonAsync>d__19 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public HZMultiToggle <>4__this; //Field offset: 0x18
		public int index; //Field offset: 0x20
		public bool animate; //Field offset: 0x24
		private Awaiter <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <SelectButtonAsync>d__21 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public HZButton button; //Field offset: 0x18
		public HZMultiToggle <>4__this; //Field offset: 0x20
		public bool animate; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[SerializeField]
	private RectTransform _background; //Field offset: 0x20
	[SerializeField]
	private List<HZButton> _buttons; //Field offset: 0x28
	[SerializeField]
	private Color _selectedTextColor; //Field offset: 0x30
	[SerializeField]
	private Color _unselectedTextColor; //Field offset: 0x40
	[SerializeField]
	private bool _changeWidth; //Field offset: 0x50
	[SerializeField]
	private bool _animate; //Field offset: 0x51
	[SerializeField]
	private float _animationTime; //Field offset: 0x54
	private Sequence _animation; //Field offset: 0x58
	private Nullable<Int32> _currentSelection; //Field offset: 0x68
	private AsyncButtonCommand<Int32> _command; //Field offset: 0x70
	private CompositeDisposable _dimensionChangeDisposables; //Field offset: 0x78
	[CompilerGenerated]
	private Func<Int32, Boolean> <CanSelectButtonFn>k__BackingField; //Field offset: 0x80

	public Func<Int32, Boolean> CanSelectButtonFn
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public HZMultiToggle() { }

	[CompilerGenerated]
	private void <MoveAnimated>b__28_0(float f) { }

	protected virtual void Awake() { }

	private void BindButtons() { }

	public void BindCommand(AsyncButtonCommand<Int32> command) { }

	[CompilerGenerated]
	public Func<Int32, Boolean> get_CanSelectButtonFn() { }

	private Sequence GetButtonTextColorTweens(HZButton button) { }

	[AsyncStateMachine(typeof(<HandleSelectionAsync>d__25))]
	private UniTask HandleSelectionAsync(int index, bool animate) { }

	private void MoveAnimated(HZButton button) { }

	private void MoveBackground(HZButton button, bool animate) { }

	private void MoveBackgroundToCurrentSelection(bool animate) { }

	private void MoveInstantly(HZButton button) { }

	protected virtual void OnDestroy() { }

	protected virtual void OnRectTransformDimensionsChange() { }

	public UniTask SelectButtonAsync(int index) { }

	[AsyncStateMachine(typeof(<SelectButtonAsync>d__19))]
	public UniTask SelectButtonAsync(int index, bool animate) { }

	public UniTask SelectButtonAsync(HZButton button) { }

	[AsyncStateMachine(typeof(<SelectButtonAsync>d__21))]
	public UniTask SelectButtonAsync(HZButton button, bool animate) { }

	[CompilerGenerated]
	public void set_CanSelectButtonFn(Func<Int32, Boolean> value) { }

	public void SetButtons(List<HZButton> buttons) { }

	private void UpdateButtonTextColorsImmediately() { }

}

