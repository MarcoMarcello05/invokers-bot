namespace Client.Analytics.Marketing;

[Nullable(0)]
[NullableContext(2)]
public sealed class AttributionEvent
{
	[CompilerGenerated]
	[Nullable(1)]
	private readonly string <Name>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly IReadOnlyCollection<EventParam> <Parameters>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly string <StateKey>k__BackingField; //Field offset: 0x20

	[Nullable(1)]
	public string Name
	{
		[CompilerGenerated]
		[NullableContext(1)]
		 get { } //Length: 8
	}

	public IReadOnlyCollection<EventParam> Parameters
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string StateKey
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public AttributionEvent(string name, IReadOnlyCollection<EventParam> parameters, string stateKey = null) { }

	[CompilerGenerated]
	[NullableContext(1)]
	public string get_Name() { }

	[CompilerGenerated]
	public IReadOnlyCollection<EventParam> get_Parameters() { }

	[CompilerGenerated]
	public string get_StateKey() { }

}

