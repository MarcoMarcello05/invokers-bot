namespace Client.Configuration;

[Nullable(0)]
[NullableContext(1)]
public class CommandLineConfigurationProvider : ConfigurationProvider
{
	[CompilerGenerated]
	private sealed class <ParseArgs>d__8 : IEnumerable<ValueTuple`2<String, String>>, IEnumerable, IEnumerator<ValueTuple`2<String, String>>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 2})]
		[TupleElementNames(new IL2CPP_TYPE_STRING[] {"key", "value"})]
		private ValueTuple<String, String> <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x28
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private IEnumerable<String> args; //Field offset: 0x30
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		public IEnumerable<String> <>3__args; //Field offset: 0x38
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		private Dictionary<String, SwitchMap> switchMaps; //Field offset: 0x40
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		public Dictionary<String, SwitchMap> <>3__switchMaps; //Field offset: 0x48
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private IEnumerator<String> <argsEnumerator>5__2; //Field offset: 0x50
		[Nullable(0)]
		private string <key>5__3; //Field offset: 0x58
		[Nullable(0)]
		private string <value>5__4; //Field offset: 0x60
		[Nullable(0)]
		private ArraySwitchMap <arraySwitchMap>5__5; //Field offset: 0x68
		[Nullable(0)]
		private DictionarySwitchMap <dictionarySwitchMap>5__6; //Field offset: 0x70
		private int <index>5__7; //Field offset: 0x78
		[Nullable(0)]
		private String[] <>7__wrap7; //Field offset: 0x80
		private int <>7__wrap8; //Field offset: 0x88

		private override ValueTuple<String, String> System.Collections.Generic.IEnumerator<(System.Stringkey,System.Stringvalue)>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 12
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 92
		}

		[DebuggerHidden]
		public <ParseArgs>d__8(int <>1__state) { }

		private void <>m__Finally1() { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<ValueTuple`2<String, String>> System.Collections.Generic.IEnumerable<(System.Stringkey,System.Stringvalue)>.GetEnumerator() { }

		[DebuggerHidden]
		private override ValueTuple<String, String> System.Collections.Generic.IEnumerator<(System.Stringkey,System.Stringvalue)>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private readonly IEnumerable<String> <Args>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private readonly Dictionary<String, SwitchMap> <SwitchMaps>k__BackingField; //Field offset: 0x28

	private IEnumerable<String> Args
	{
		[CompilerGenerated]
		private get { } //Length: 8
	}

	private Dictionary<String, SwitchMap> SwitchMaps
	{
		[CompilerGenerated]
		private get { } //Length: 8
	}

	public CommandLineConfigurationProvider(IEnumerable<String> args, Dictionary<String, SwitchMap> switchMaps) { }

	[CompilerGenerated]
	private IEnumerable<String> get_Args() { }

	[CompilerGenerated]
	private Dictionary<String, SwitchMap> get_SwitchMaps() { }

	public virtual void Load() { }

	[IteratorStateMachine(typeof(<ParseArgs>d__8))]
	private static IEnumerable<ValueTuple`2<String, String>> ParseArgs(IEnumerable<String> args, Dictionary<String, SwitchMap> switchMaps) { }

}

