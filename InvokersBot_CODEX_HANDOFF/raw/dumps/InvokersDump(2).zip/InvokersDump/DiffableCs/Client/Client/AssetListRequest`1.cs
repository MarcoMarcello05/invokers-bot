namespace Client;

[Nullable(0)]
[NullableContext(1)]
public class AssetListRequest : IDisposable
{
	[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
	private AsyncOperationHandle<T> _operation; //Field offset: 0x0
	private bool _isDisposed; //Field offset: 0x0
	[CompilerGenerated]
	private readonly List<AssetKey> <Keys>k__BackingField; //Field offset: 0x0

	[Nullable(2)]
	public T Assets
	{
		[NullableContext(2)]
		 get { } //Length: 244
	}

	public string DownloadError
	{
		 get { } //Length: 176
	}

	public DownloadStatus DownloadStatus
	{
		 get { } //Length: 116
	}

	[Nullable(2)]
	public Exception Exception
	{
		[NullableContext(2)]
		 get { } //Length: 80
	}

	public bool Failed
	{
		 get { } //Length: 88
	}

	public List<AssetKey> Keys
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public bool Ready
	{
		 get { } //Length: 88
	}

	public AssetListRequest`1(List<AssetKey> keys, AsyncOperationHandle<T> operation) { }

	[HideInCallstack]
	public void CleanupAndLogWarnIfFailed(bool required) { }

	public override void Dispose() { }

	[NullableContext(2)]
	public T get_Assets() { }

	public string get_DownloadError() { }

	public DownloadStatus get_DownloadStatus() { }

	[NullableContext(2)]
	public Exception get_Exception() { }

	public bool get_Failed() { }

	[CompilerGenerated]
	public List<AssetKey> get_Keys() { }

	public bool get_Ready() { }

	public virtual string ToString() { }

}

