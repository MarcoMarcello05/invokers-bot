namespace Client;

public class AsyncLoadTuner
{

	public AsyncLoadTuner() { }

	public static void FinishLoading() { }

	public static void StartLoading() { }

}

