namespace Client.Core.GameServices.InGameAlerts;

internal sealed class AlertTournamentIconProvider : IAlertTournamentIconProvider, IDisposable
{
	private readonly GlobalEventsModel _globalEventsModel; //Field offset: 0x10
	private readonly IContentManager _contentManager; //Field offset: 0x18
	private readonly Dictionary<Int64, IAssetRequest`1<Sprite>> _iconRequestByTournamentId; //Field offset: 0x20
	private readonly Dictionary<Int64, IAssetRequest`1<Sprite>> _retainedRequestByTournamentId; //Field offset: 0x28
	private readonly Dictionary<Int64, Sprite> _loadedIconByTournamentId; //Field offset: 0x30
	private readonly List<Int64> _tournamentIdBuffer; //Field offset: 0x38

	public AlertTournamentIconProvider(GlobalEventsModel globalEventsModel, IContentManager contentManager) { }

	public override void CheckCompletedLoads() { }

	public override void Clear() { }

	public override void Dispose() { }

	private void DisposeIconRequests() { }

	public override Sprite Get(long tournamentId) { }

	public override bool IsReady(long tournamentId) { }

	public override void RequestLoad(long tournamentId) { }

}

