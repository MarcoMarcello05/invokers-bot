namespace Client.Animations;

public class AnimationsController
{
	public const SkillType COMBO_SEQUENCE_START_POSITION = 4; //Field offset: 0x0
	private readonly ILogger _logger; //Field offset: 0x10
	private readonly Animator _animator; //Field offset: 0x18
	private IdleAnimationTimerHandler _idleTimerHandler; //Field offset: 0x20
	private int _fullBodyFlinchLayerIndex; //Field offset: 0x28
	private SkillType _synchronizedCastSkill; //Field offset: 0x2C
	private AnimationClip _synchronizedCastClip; //Field offset: 0x30
	private PlayableGraph _synchronizedCastGraph; //Field offset: 0x38
	private AnimationClipPlayable _synchronizedCastPlayable; //Field offset: 0x48

	public AnimationsController(Animator animator) { }

	private int ActiveSkillTypeToAnimControllerIndex(SkillType skill) { }

	public void AnimaIn() { }

	public void AnimaOut() { }

	public void ClearSynchronizedCastAnimation() { }

	public void ComboAttack(SkillType skill, float speed, bool forced) { }

	private void CreateSynchronizedCastGraph() { }

	public void Dash(bool enable) { }

	public void Death(bool enable, Nullable<Int32> deathAnimationNumber) { }

	public void Flinch() { }

	public void Freeze(bool enable) { }

	public void FtueIdle() { }

	public void FtueIntro() { }

	public float GetClipAnimationTime(string name) { }

	public void Idle(bool idleInEnabled) { }

	public void InteractBot(bool enable) { }

	public void InteractMid(bool enable) { }

	private void InterruptAllActions() { }

	public void Intro() { }

	public void Launch(int phase) { }

	public void Move(bool run) { }

	public void Paralyze(bool enable) { }

	public void RebindAnimator() { }

	public void Reveal() { }

	public void RunSkillPhase(SkillType skill, SkillPhase phase, float speed) { }

	public void SetCastAnimationTime(SkillType skill, float time) { }

	private void SetEffectAnimation(int animationHash, bool enable) { }

	public void SetFullBodyFlinchWeight(float weight) { }

	public void SetSpeed(float speed) { }

	public void SetTurnBlend(float weight) { }

	public void Shock(bool enable) { }

	public void SimpleModeSkill(SkillType type) { }

	public void SimpleModeSkillPhase(SkillPhase phase) { }

	public void Sleep(bool enable) { }

	public void Stun(bool enable) { }

	public void SubscribeIdleAnimationStarted(Action action) { }

	public void SubscribeIdleBreakEvent(Action<Int32> action) { }

	public void UnSubscribeIdleAnimationStarted(Action action) { }

	public void UnSubscribeIdleBreakEvent(Action<Int32> action) { }

}

