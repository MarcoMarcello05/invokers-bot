//Type is in global namespace

public class CharacterTilt : MonoBehaviour
{
	private class TiltJoint
	{
		[SerializeField]
		[Tooltip("The joint transform that should be tilted")]
		internal Transform target; //Field offset: 0x10
		[SerializeField]
		[Tooltip("Maximum tilt angle in degrees for left/right leaning")]
		internal float maxHorizontalLean; //Field offset: 0x18
		[SerializeField]
		[Tooltip("Maximum tilt angle in degrees for forward/backward leaning")]
		internal float maxVerticalLean; //Field offset: 0x1C
		[SerializeField]
		[Tooltip("How quickly the joint tilts")]
		internal float tiltSpeed; //Field offset: 0x20
		[SerializeField]
		[Tooltip("How quickly the joint returns to neutral position")]
		internal float returnSpeed; //Field offset: 0x24
		[SerializeField]
		[Tooltip("Adds the shared ground pitch alignment to this joint")]
		internal bool applyGroundPitch; //Field offset: 0x28
		internal float currentLean; //Field offset: 0x2C
		internal float currentPitch; //Field offset: 0x30
		internal Quaternion lastAppliedOffset; //Field offset: 0x34
		internal Quaternion lastWrittenLocal; //Field offset: 0x44
		internal bool initialized; //Field offset: 0x54

		public TiltJoint() { }

	}

	private const float minVelocityThreshold = 0,1; //Field offset: 0x0
	[SerializeField]
	[Tooltip("Joints to tilt, each with its own settings")]
	private TiltJoint[] joints; //Field offset: 0x20
	[SerializeField]
	[Tooltip("Aligns the character pitch to the ground sampled at the front and rear probes")]
	private bool alignPitchToGround; //Field offset: 0x28
	[Min(0.01)]
	[SerializeField]
	[Tooltip("Distance from the character origin to the front ground probe")]
	private float frontGroundProbeOffset; //Field offset: 0x2C
	[Min(0.01)]
	[SerializeField]
	[Tooltip("Distance from the character origin to the rear ground probe")]
	private float rearGroundProbeOffset; //Field offset: 0x30
	[Min(0)]
	[SerializeField]
	[Tooltip("Height above the character origin where ground probes start")]
	private float groundProbeHeight; //Field offset: 0x34
	[Min(0)]
	[SerializeField]
	[Tooltip("Maximum distance of each downward ground probe")]
	private float groundProbeDistance; //Field offset: 0x38
	[SerializeField]
	[Tooltip("Maximum ground pitch angle in degrees")]
	private float maxGroundPitch; //Field offset: 0x3C
	private Vector3 lastPosition; //Field offset: 0x40
	private Vector3 currentVelocity; //Field offset: 0x4C
	private bool hasPlatformWorldPositionOffset; //Field offset: 0x58
	private Vector3 platformWorldPositionOffset; //Field offset: 0x5C
	private int platformSubMeshId; //Field offset: 0x68
	private bool resetLastPositionOnNextUpdate; //Field offset: 0x6C
	private bool hasGroundAlignment; //Field offset: 0x6D
	private int groundLayerMask; //Field offset: 0x70

	public CharacterTilt() { }

	private static bool ApproximatelyEqual(Quaternion a, Quaternion b) { }

	private float CalculateGroundPitch() { }

	private void CalculateTilt() { }

	private void CalculateVelocity() { }

	private Vector3 GetCurrentTrackedPosition() { }

	private void LateUpdate() { }

	public void ResetForReuse() { }

	public void SetPlatformWorldPositionOffset(Vector3 offset, int newPlatformSubMeshId) { }

	private void Start() { }

	private bool TryGetGroundPoint(Vector3 probePosition, out Vector3 groundPoint) { }

}

