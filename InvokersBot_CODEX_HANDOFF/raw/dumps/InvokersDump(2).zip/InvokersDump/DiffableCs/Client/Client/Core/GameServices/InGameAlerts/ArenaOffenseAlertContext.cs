namespace Client.Core.GameServices.InGameAlerts;

public sealed class ArenaOffenseAlertContext : IAlertContext, IEquatable<ArenaOffenseAlertContext>
{
	private const string STORAGE_KEY_PREFIX = "ArenaOffenseLastBattleTime"; //Field offset: 0x0
	[CompilerGenerated]
	private readonly int <PlayTime>k__BackingField; //Field offset: 0x10

	[CompilerGenerated]
	[Nullable(1)]
	private Type EqualityContract
	{
		[CompilerGenerated]
		[NullableContext(1)]
		private get { } //Length: 96
	}

	public int PlayTime
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public ArenaOffenseAlertContext(int PlayTime) { }

	[CompilerGenerated]
	private ArenaOffenseAlertContext(ArenaOffenseAlertContext original) { }

	[CompilerGenerated]
	[NullableContext(1)]
	public ArenaOffenseAlertContext <Clone>$() { }

	[CompilerGenerated]
	public void Deconstruct(out int PlayTime) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public override bool Equals(ArenaOffenseAlertContext other) { }

	[CompilerGenerated]
	[NullableContext(1)]
	private Type get_EqualityContract() { }

	[CompilerGenerated]
	public int get_PlayTime() { }

	public string GetBiContent() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	public static ISettingsValues<String> GetLastBattleTimeSetting() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Equality(ArenaOffenseAlertContext left, ArenaOffenseAlertContext right) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Inequality(ArenaOffenseAlertContext left, ArenaOffenseAlertContext right) { }

	[CompilerGenerated]
	[NullableContext(1)]
	private bool PrintMembers(StringBuilder builder) { }

	public static DateTime ResolveLastBattleTime() { }

	[CompilerGenerated]
	public void set_PlayTime(int value) { }

	public virtual string ToString() { }

}

