namespace Client.Common;

public static class StructListPool
{
	[ThreadStatic]
	private static Stack<StructList`1<T>> _stack; //Field offset: 0xFFFFFFFF

	private static void ConditionalInit() { }

	public static StructList<T> Rent(int capacity) { }

	public static void Return(StructList<T> list) { }

}

