namespace Client.Configuration;

public class BoolSettings : SettingsValue<Boolean>
{
	private IDeviceStorage _localDeviceStorage; //Field offset: 0x20

	public BoolSettings(string key, string rootKey, bool defaultValue) { }

	public virtual bool GetValue() { }

	public virtual void SetValue(bool value) { }

}

