namespace Client.Core.ErrorHandling;

public struct OfflineModeWarning : IEquatable<OfflineModeWarning>
{
	[CompilerGenerated]
	private readonly int <DangerLevel>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private readonly TimeSpan <Duration>k__BackingField; //Field offset: 0x8
	[CompilerGenerated]
	private readonly int <TotalChanges>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly int <Battles>k__BackingField; //Field offset: 0x14
	[CompilerGenerated]
	private readonly int <HeroTitanUpgrades>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly int <RelicAccessoryUpgrades>k__BackingField; //Field offset: 0x1C
	[CompilerGenerated]
	private readonly int <OtherChanges>k__BackingField; //Field offset: 0x20

	public int Battles
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public int DangerLevel
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public TimeSpan Duration
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public int HeroTitanUpgrades
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public int OtherChanges
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public int RelicAccessoryUpgrades
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public int TotalChanges
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public OfflineModeWarning(int DangerLevel, TimeSpan Duration, int TotalChanges, int Battles, int HeroTitanUpgrades, int RelicAccessoryUpgrades, int OtherChanges) { }

	[CompilerGenerated]
	public void Deconstruct(out int DangerLevel, out TimeSpan Duration, out int TotalChanges, out int Battles, out int HeroTitanUpgrades, out int RelicAccessoryUpgrades, out int OtherChanges) { }

	[CompilerGenerated]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	public override bool Equals(OfflineModeWarning other) { }

	[CompilerGenerated]
	public int get_Battles() { }

	[CompilerGenerated]
	public int get_DangerLevel() { }

	[CompilerGenerated]
	public TimeSpan get_Duration() { }

	[CompilerGenerated]
	public int get_HeroTitanUpgrades() { }

	[CompilerGenerated]
	public int get_OtherChanges() { }

	[CompilerGenerated]
	public int get_RelicAccessoryUpgrades() { }

	[CompilerGenerated]
	public int get_TotalChanges() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	public static bool op_Equality(OfflineModeWarning left, OfflineModeWarning right) { }

	[CompilerGenerated]
	public static bool op_Inequality(OfflineModeWarning left, OfflineModeWarning right) { }

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	public void set_Battles(int value) { }

	[CompilerGenerated]
	public void set_DangerLevel(int value) { }

	[CompilerGenerated]
	public void set_Duration(TimeSpan value) { }

	[CompilerGenerated]
	public void set_HeroTitanUpgrades(int value) { }

	[CompilerGenerated]
	public void set_OtherChanges(int value) { }

	[CompilerGenerated]
	public void set_RelicAccessoryUpgrades(int value) { }

	[CompilerGenerated]
	public void set_TotalChanges(int value) { }

	[CompilerGenerated]
	public virtual string ToString() { }

}

