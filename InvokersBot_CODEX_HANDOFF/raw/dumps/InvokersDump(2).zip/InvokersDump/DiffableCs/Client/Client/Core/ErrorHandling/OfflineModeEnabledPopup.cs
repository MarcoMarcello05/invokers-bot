namespace Client.Core.ErrorHandling;

[Nullable(0)]
[NullableContext(1)]
public sealed class OfflineModeEnabledPopup : BaseDialogView, IOfflineModeEnabledPopup, IDialogView, IView
{
	[SerializeField]
	private TextMeshProUGUI _title; //Field offset: 0x58
	[SerializeField]
	private TextMeshProUGUI _durationDescription; //Field offset: 0x60
	[SerializeField]
	private TextMeshProUGUI _descriptionContext; //Field offset: 0x68
	[SerializeField]
	private TextMeshProUGUI _unsavedChangesCaption; //Field offset: 0x70
	[SerializeField]
	private TextMeshProUGUI _unsavedChanges; //Field offset: 0x78
	[SerializeField]
	private HZButton _confirmButton; //Field offset: 0x80
	[SerializeField]
	private Color _lowWarningColor; //Field offset: 0x88
	[SerializeField]
	private Color _mediumWarningColor; //Field offset: 0x98
	[SerializeField]
	private Color _highWarningColor; //Field offset: 0xA8

	public override Observable<Unit> CloseClicked
	{
		 get { } //Length: 32
	}

	public OfflineModeEnabledPopup() { }

	private static void AppendChange(StringBuilder changes, int count, string text) { }

	public override Observable<Unit> get_CloseClicked() { }

	private void OnValidate() { }

	private void SetDurationDescription(TimeSpan duration, int warningLevel) { }

	public override void SetWarning(OfflineModeWarning warning) { }

}

