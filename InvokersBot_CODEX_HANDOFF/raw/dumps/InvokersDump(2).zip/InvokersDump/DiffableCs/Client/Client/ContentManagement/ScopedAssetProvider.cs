namespace Client.ContentManagement;

[Nullable(0)]
[NullableContext(1)]
public sealed class ScopedAssetProvider : IScopedAssetProvider, IAssetProvider, IDisposable
{
	[CompilerGenerated]
	private struct <TryGetAndCacheAsync>d__12 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<TAsset> <>t__builder; //Field offset: 0x0
		[Nullable(0)]
		public AssetKey key; //Field offset: 0x0
		[Nullable(0)]
		public ScopedAssetProvider <>4__this; //Field offset: 0x0
		[Nullable(0)]
		public string callerMemberName; //Field offset: 0x0
		[Nullable(0)]
		public string callerFilePath; //Field offset: 0x0
		public int callerLineNumber; //Field offset: 0x0
		private AutoScope <_>5__2; //Field offset: 0x0
		[Nullable(0)]
		private IAssetRequest<TAsset> <typedRequest>5__3; //Field offset: 0x0
		[Nullable(0)]
		private Awaiter<TAsset> <>u__1; //Field offset: 0x0
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 0})]
		private Awaiter<IAssetRequest<TAsset>> <>u__2; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity TryGetAndCacheActivity; //Field offset: 0x0
	private readonly IAssetProvider _innerProvider; //Field offset: 0x10
	private readonly string _scopeName; //Field offset: 0x18
	private readonly Dictionary<AssetKey, IAssetRequest> _cachedRequests; //Field offset: 0x20
	private readonly CancellationTokenSource _cancellationTokenSource; //Field offset: 0x28
	private bool _disposed; //Field offset: 0x30

	private static ScopedAssetProvider() { }

	public ScopedAssetProvider(IAssetProvider innerProvider, string scopeName) { }

	public override void ClearCaches() { }

	public override void Dispose() { }

	public override IAssetRequest<T> Load(AssetKey key, Action<T> onSuccess = null, Action<DownloadStatus> onProgress = null, bool errorOnDownload = false, string diagnosticScopeTag = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	public override UniTask<IAssetRequest`1<T>> LoadAsync(AssetKey key, Action<DownloadStatus> onProgress = null, CancellationToken cancellation = null, bool errorOnDownload = false, string diagnosticScopeTag = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	public override IAssetRequest<SceneInstance> LoadScene(AssetKey key, LoadSceneMode mode = 0, bool activateOnLoad = true, Action<DownloadStatus> onProgress = null, string diagnosticScopeTag = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	public override UniTask<IAssetRequest`1<SceneInstance>> LoadSceneAsync(AssetKey key, LoadSceneMode mode = 0, bool activateOnLoad = true, Action<DownloadStatus> onProgress = null, string diagnosticScopeTag = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	[AsyncStateMachine(typeof(<TryGetAndCacheAsync>d__12`1))]
	public override UniTask<TAsset> TryGetAndCacheAsync(AssetKey key, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	[NullableContext(2)]
	public override bool TryGetCached(AssetKey key, out TAsset asset) { }

}

