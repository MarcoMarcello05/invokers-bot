namespace Client.CharacterControllers;

public abstract class BaseCharacterView : MonoBehaviour
{

	protected BaseCharacterView() { }

}

