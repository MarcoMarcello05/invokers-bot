namespace Client.Authentication.ExternalAuth;

public interface IExternalAuthProvider
{

	public bool IsAvailable
	{
		 get { } //Length: 0
	}

	public ExternalLoginProvider Provider
	{
		 get { } //Length: 0
	}

	public bool get_IsAvailable() { }

	public ExternalLoginProvider get_Provider() { }

	[NullableContext(2)]
	public string GetCurrentUserName() { }

	public ValueTask<ExternalAuthResult> TryAuthenticateAsync(ExternalAuthMode mode, CancellationToken ct = null) { }

}

