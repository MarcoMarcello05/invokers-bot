namespace Client.Core.ErrorHandling;

[NullableContext(1)]
public interface IErrorDialogBuilder
{

	public void SetApplicationExitController(ApplicationExitController applicationExitController) { }

	public void SetChoreograph(IChoreographManager choreograph) { }

	public void SetGameStateManager(IGameStateManager gameStateManager) { }

	public UniTask ShowAndWaitErrorDialog(string title, string errorMessage, string buttonText = null, ErrorType errorType = 0, string errorCode = null) { }

	public UniTask ShowAndWaitErrorDialog(IErrorDetails error) { }

	public UniTask ShowAndWaitErrorDialog(Exception exception, ErrorType errorType = 0) { }

	public UniTask ShowAndWaitOfflineModeEnabledDialog(OfflineModeWarning warning, string diagnosticMessage) { }

}

