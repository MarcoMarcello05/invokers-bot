namespace Client.Authentication.AppleGameCenter;

public enum AppleGameCenterAuthStatus : int
{
	Success = 0,
	Canceled = 1,
	Failed = 2,
	NotSupported = 3,
}

