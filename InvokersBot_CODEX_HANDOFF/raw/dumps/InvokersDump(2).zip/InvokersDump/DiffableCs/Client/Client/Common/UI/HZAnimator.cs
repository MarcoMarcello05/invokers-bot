namespace Client.Common.UI;

[RequireComponent(typeof(Animation))]
public sealed class HZAnimator : MonoBehaviour
{
	[CompilerGenerated]
	private sealed class <InvokeDelayed>d__6 : IEnumerator<Object>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private object <>2__current; //Field offset: 0x18
		public float delay; //Field offset: 0x20
		public Action action; //Field offset: 0x28

		private override object System.Collections.Generic.IEnumerator<System.Object>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <InvokeDelayed>d__6(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	public const string AnimationsPropertyName = "_animations"; //Field offset: 0x0
	[SerializeField]
	private Animation _animationComponent; //Field offset: 0x20
	[SerializeField]
	private AnimationClipDictionary _animations; //Field offset: 0x28

	public HZAnimator() { }

	private void Awake() { }

	[IteratorStateMachine(typeof(<InvokeDelayed>d__6))]
	private IEnumerator InvokeDelayed(Action action, float delay) { }

	public void Play(string animationName, Action onComplete = null) { }

	public void StopAll() { }

}

