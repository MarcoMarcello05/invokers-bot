namespace Client.Core.Dialogs.ClientUpdatePopup;

public class SoftHardUpdateDialogView : BaseDialogView
{
	[SerializeField]
	private HZButton _closeButton; //Field offset: 0x58
	[SerializeField]
	private HZButton _updateButton; //Field offset: 0x60
	[SerializeField]
	private MonoBehaviour _rewardsContainer; //Field offset: 0x68

	public HZButton CloseButton
	{
		 get { } //Length: 8
	}

	public HZButton UpdateButton
	{
		 get { } //Length: 8
	}

	public SoftHardUpdateDialogView() { }

	public HZButton get_CloseButton() { }

	public HZButton get_UpdateButton() { }

	private void OnValidate() { }

	public void ShowRewards(IList<IShopRewardItem> rewards) { }

}

