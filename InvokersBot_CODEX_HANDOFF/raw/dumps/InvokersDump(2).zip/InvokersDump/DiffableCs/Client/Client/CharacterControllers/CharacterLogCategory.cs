namespace Client.CharacterControllers;

public sealed class CharacterLogCategory
{
	public static readonly ILogger Log; //Field offset: 0x0

	private static CharacterLogCategory() { }

	public CharacterLogCategory() { }

}

