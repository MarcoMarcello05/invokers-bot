namespace Client.CharacterControllers.OwnerHpPanel;

public struct TopPanelData
{
	public ModelEntity OwnerEntity; //Field offset: 0x0
	public ModelEntity TargetEntity; //Field offset: 0x10
	public long OwnerConfigId; //Field offset: 0x20
	public long OwnerGdId; //Field offset: 0x28
	public string LocalizationKey; //Field offset: 0x30
	public int OwnerLevel; //Field offset: 0x38
	public string OwnerConfigName; //Field offset: 0x40
	public Element OwnerElement; //Field offset: 0x48
	public long OwnerBaseMaxHealth; //Field offset: 0x50
	public TopPanelHealth OwnerHealth; //Field offset: 0x58
	public Sprite OwnerIcon; //Field offset: 0x70
	public int OwnerHealthBarsCount; //Field offset: 0x78

}

