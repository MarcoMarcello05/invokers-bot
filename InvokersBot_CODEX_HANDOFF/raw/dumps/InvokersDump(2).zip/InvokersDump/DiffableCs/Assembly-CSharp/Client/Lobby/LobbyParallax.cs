namespace Client.Lobby;

[DisallowMultipleComponent]
[ExecuteAlways]
public sealed class LobbyParallax : MonoBehaviour
{
	private struct ObjectState
	{
		[CompilerGenerated]
		private readonly Transform <Transform>k__BackingField; //Field offset: 0x0
		[CompilerGenerated]
		private readonly float <Multiplier>k__BackingField; //Field offset: 0x8
		[CompilerGenerated]
		private readonly Vector3 <LocalPosition>k__BackingField; //Field offset: 0xC

		public Vector3 LocalPosition
		{
			[CompilerGenerated]
			 get { } //Length: 12
		}

		public float Multiplier
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		public Transform Transform
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		public ObjectState(Transform transform, float multiplier) { }

		[CompilerGenerated]
		public Vector3 get_LocalPosition() { }

		[CompilerGenerated]
		public float get_Multiplier() { }

		[CompilerGenerated]
		public Transform get_Transform() { }

	}

	private sealed class ParallaxObject
	{
		[SerializeField]
		private Transform _transform; //Field offset: 0x10
		[SerializeField]
		private float _multiplier; //Field offset: 0x18

		public float Multiplier
		{
			 get { } //Length: 8
		}

		public Transform Transform
		{
			 get { } //Length: 8
		}

		public ParallaxObject() { }

		public float get_Multiplier() { }

		public Transform get_Transform() { }

	}

	private const float PositionEpsilon = 1E-06; //Field offset: 0x0
	[SerializeField]
	private float _parallax; //Field offset: 0x20
	[SerializeField]
	private ParallaxObject[] _objects; //Field offset: 0x28
	private readonly List<ObjectState> _objectStates; //Field offset: 0x30

	public float Parallax
	{
		 get { } //Length: 8
		 set { } //Length: 208
	}

	public LobbyParallax() { }

	private void ApplyOffsets() { }

	private void CaptureObjectStates() { }

	public float get_Parallax() { }

	private void OnDisable() { }

	private void OnEnable() { }

	private void OnValidate() { }

	private void RestoreObjectStates() { }

	public void set_Parallax(float value) { }

	private static void SetLocalPosition(Transform target, Vector3 localPosition) { }

}

