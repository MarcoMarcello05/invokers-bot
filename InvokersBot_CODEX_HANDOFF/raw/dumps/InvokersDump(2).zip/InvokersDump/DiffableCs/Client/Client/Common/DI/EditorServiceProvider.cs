namespace Client.Common.DI;

public class EditorServiceProvider
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0

		private static <>c() { }

		public <>c() { }

		internal EditorServiceProvider <.cctor>b__12_0() { }

	}

	private static readonly Lazy<EditorServiceProvider> Lazy; //Field offset: 0x0
	private IObjectResolver _resolver; //Field offset: 0x10
	private IServiceProvider _provider; //Field offset: 0x18
	private IReflectionServiceInjector _injector; //Field offset: 0x20

	public static EditorServiceProvider Instance
	{
		 get { } //Length: 132
	}

	private static EditorServiceProvider() { }

	private EditorServiceProvider() { }

	private void Dispose() { }

	public static EditorServiceProvider get_Instance() { }

	public void Init(IObjectResolver resolver) { }

	public static void InjectInto(object target) { }

	public static bool IsReady() { }

	public static T Resolve() { }

}

