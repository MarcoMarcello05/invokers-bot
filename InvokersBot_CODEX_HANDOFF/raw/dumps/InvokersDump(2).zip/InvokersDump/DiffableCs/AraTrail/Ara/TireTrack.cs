namespace Ara;

[RequireComponent(typeof(AraTrail))]
public class TireTrack : MonoBehaviour
{
	private AraTrail trail; //Field offset: 0x20
	public float offset; //Field offset: 0x28
	public float maxDist; //Field offset: 0x2C

	public TireTrack() { }

	private void OnDisable() { }

	private void OnEnable() { }

	private void ProjectToGround() { }

}

