namespace Client.Configuration;

public enum ConfigContribution : int
{
	All = 0,
	CeilingsOnly = 1,
	ExceptCeilings = 2,
}

