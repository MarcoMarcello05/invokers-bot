namespace Client.ContentManagement;

[Nullable(0)]
[NullableContext(1)]
public class ScopedContentManager : IContentManager
{
	private readonly IContentManager _innerManager; //Field offset: 0x10
	[CompilerGenerated]
	private readonly IAssetProvider <Addressables>k__BackingField; //Field offset: 0x18

	public override IAssetProvider Addressables
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public override IDownloadManager Downloads
	{
		 get { } //Length: 164
	}

	public override IResourcesApi Resources
	{
		 get { } //Length: 160
	}

	public ScopedContentManager(IContentManager innerManager, IAssetProvider assetProvider) { }

	[CompilerGenerated]
	public override IAssetProvider get_Addressables() { }

	public override IDownloadManager get_Downloads() { }

	public override IResourcesApi get_Resources() { }

}

