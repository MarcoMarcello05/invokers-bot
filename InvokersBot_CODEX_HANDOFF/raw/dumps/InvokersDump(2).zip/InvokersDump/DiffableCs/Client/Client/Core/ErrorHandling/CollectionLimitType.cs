namespace Client.Core.ErrorHandling;

public enum CollectionLimitType : int
{
	Hero = 0,
	Anima = 1,
	Relic = 2,
	Accessory = 3,
}

