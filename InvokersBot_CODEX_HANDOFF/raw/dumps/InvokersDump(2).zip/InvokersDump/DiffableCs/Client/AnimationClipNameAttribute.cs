//Type is in global namespace

public class AnimationClipNameAttribute : PropertyAttribute
{
	public string animationFieldName; //Field offset: 0x18

	public AnimationClipNameAttribute(string animationFieldName) { }

}

