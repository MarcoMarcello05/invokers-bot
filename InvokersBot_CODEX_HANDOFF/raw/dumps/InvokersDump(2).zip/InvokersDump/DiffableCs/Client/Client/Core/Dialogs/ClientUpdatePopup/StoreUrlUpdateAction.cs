namespace Client.Core.Dialogs.ClientUpdatePopup;

public sealed class StoreUrlUpdateAction : IClientUpdateAction
{
	private const string IOS_STORE_URL = "itms-apps://apps.apple.com/app/id6755186220"; //Field offset: 0x0
	private const string ANDROID_STORE_URL = "market://details?id=hitzone.anima.spirit.guardians"; //Field offset: 0x0
	private static readonly ILogger Logger; //Field offset: 0x0

	private static StoreUrlUpdateAction() { }

	public StoreUrlUpdateAction() { }

	public override UniTask ExecuteAsync() { }

	private static string ResolveStoreUrl() { }

}

