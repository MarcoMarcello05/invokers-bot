namespace Client.Core;

public class EditableClientTimeProvider : ITimeProvider, ITimeScaleProvider
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass18_0
	{
		private struct <<set_Timescale>b__0>d : IAsyncStateMachine
		{
			public int <>1__state; //Field offset: 0x0
			public AsyncUniTaskVoidMethodBuilder <>t__builder; //Field offset: 0x8
			public <>c__DisplayClass18_0 <>4__this; //Field offset: 0x10
			private Awaiter <>u__1; //Field offset: 0x18

			private override void MoveNext() { }

			[DebuggerHidden]
			private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

		}

		public EditableClientTimeProvider <>4__this; //Field offset: 0x10
		public float value; //Field offset: 0x18

		public <>c__DisplayClass18_0() { }

		[AsyncStateMachine(typeof(<<set_Timescale>b__0>d))]
		internal UniTaskVoid <set_Timescale>b__0() { }

	}

	[CompilerGenerated]
	private Action<Single> TimescaleChanged; //Field offset: 0x10
	private long _offsetTicks; //Field offset: 0x18
	private float _timescale; //Field offset: 0x20

	public override event Action<Single> TimescaleChanged
	{
		[CompilerGenerated]
		 add { } //Length: 176
		[CompilerGenerated]
		 remove { } //Length: 176
	}

	public TimeSpan Offset
	{
		 get { } //Length: 108
		 set { } //Length: 104
	}

	public override double TimeFromStartSec
	{
		 get { } //Length: 148
	}

	public override float Timescale
	{
		 get { } //Length: 136
		 set { } //Length: 324
	}

	public override long Timestamp
	{
		 get { } //Length: 80
	}

	public override DateTime UtcNow
	{
		 get { } //Length: 132
	}

	public EditableClientTimeProvider() { }

	[CompilerGenerated]
	public override void add_TimescaleChanged(Action<Single> value) { }

	private void ApplyTimescale(float value) { }

	public TimeSpan get_Offset() { }

	public override double get_TimeFromStartSec() { }

	public override float get_Timescale() { }

	public override long get_Timestamp() { }

	public override DateTime get_UtcNow() { }

	public override DateTime GetMonotonicUtcNow() { }

	[CompilerGenerated]
	public override void remove_TimescaleChanged(Action<Single> value) { }

	public void set_Offset(TimeSpan value) { }

	public override void set_Timescale(float value) { }

}

