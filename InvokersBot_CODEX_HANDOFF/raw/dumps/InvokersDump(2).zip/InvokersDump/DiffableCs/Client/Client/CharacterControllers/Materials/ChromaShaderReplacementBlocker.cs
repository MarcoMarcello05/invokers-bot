namespace Client.CharacterControllers.Materials;

public sealed class ChromaShaderReplacementBlocker : MonoBehaviour
{

	public ChromaShaderReplacementBlocker() { }

}

