namespace Client.CameraShake;

public class CameraShakeCreateSystem : IViewSystem
{
	private static readonly ILogger Log; //Field offset: 0x0
	private readonly CameraShakeConfigProvider _shakeProvider; //Field offset: 0x10
	private readonly CameraShakeViewDataPool _pool; //Field offset: 0x18
	private readonly SharedViewData _shared; //Field offset: 0x20

	private static CameraShakeCreateSystem() { }

	public CameraShakeCreateSystem(SharedViewData shared, CameraShakeConfigProvider shakeProvider, CameraShakeViewDataPool pool) { }

	public override void Tick() { }

}

