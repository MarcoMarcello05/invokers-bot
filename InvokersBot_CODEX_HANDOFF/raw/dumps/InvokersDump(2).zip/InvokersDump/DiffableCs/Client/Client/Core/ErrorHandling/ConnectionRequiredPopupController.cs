namespace Client.Core.ErrorHandling;

[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
[NullableContext(1)]
public sealed class ConnectionRequiredPopupController : AwaitableDialogController<IConnectionRequiredPopup>
{
	[CompilerGenerated]
	private struct <HandleCloseAsync>d__11 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ConnectionRequiredPopupController <>4__this; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <HandleReconnectAsync>d__12 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ConnectionRequiredPopupController <>4__this; //Field offset: 0x28
		private ValueTaskAwaiter <>u__1; //Field offset: 0x30
		[Nullable(0)]
		private Awaiter<SyncResult> <>u__2; //Field offset: 0x40
		private Awaiter <>u__3; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IContentManager _content; //Field offset: 0x88
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x90
	private readonly IErrorDetails _error; //Field offset: 0x98
	private readonly string _message; //Field offset: 0xA0
	private readonly ISupportService _supportService; //Field offset: 0xA8
	[Nullable(2)]
	private readonly IChoreographManager _choreograph; //Field offset: 0xB0
	private readonly IErrorDialogBuilder _errorDialogBuilder; //Field offset: 0xB8
	private readonly ButtonCommandBuilder _buttonCommandBuilder; //Field offset: 0xC0

	public ConnectionRequiredPopupController(IContentManager content, IStagingContainer stagingContainer, IUISystem uiSystem, IErrorDetails error, string message, ISupportService supportService, IChoreographManager choreograph, IErrorDialogBuilder errorDialogBuilder) { }

	[CompilerGenerated]
	private void <OnViewLoaded>b__10_0() { }

	[AsyncStateMachine(typeof(<HandleCloseAsync>d__11))]
	private ValueTask HandleCloseAsync() { }

	[AsyncStateMachine(typeof(<HandleReconnectAsync>d__12))]
	private ValueTask HandleReconnectAsync() { }

	protected virtual void OnViewLoaded() { }

	protected virtual IAsyncInitializable<IConnectionRequiredPopup> ViewFactory() { }

}

