namespace Client.Core.Dialogs;

public class ChromaLossConfirmation : IChromaLossConfirmation
{
	private readonly ChoreographManager _choreograph; //Field offset: 0x10
	private readonly StaticModalPopupFactory _popupFactory; //Field offset: 0x18

	public ChromaLossConfirmation(ChoreographManager choreograph, StaticModalPopupFactory popupFactory) { }

	public override UniTask<Boolean> ConfirmAnimaLossAsync(IReadOnlyCollection<Int32> animaInventoryIds) { }

	public override UniTask<Boolean> ConfirmHeroLossAsync(IReadOnlyCollection<Int32> heroInventoryIds) { }

	public bool IsAnimaChroma(int animaInventoryId) { }

	public bool IsHeroChroma(int heroInventoryId) { }

	private UniTask<Boolean> ShowWarningAsync() { }

}

