namespace Client;

public static class BundlesBuildTimeStamp
{
	public const string FILE_NAME = "bundles-build-time-stamp"; //Field offset: 0x0
	public const string FORMAT = "yyyy-MM-dd_HH-mm-ss"; //Field offset: 0x0

	public static bool TryLoadFromResource(out Nullable<DateTime>& timeStamp) { }

	public static bool TryParse(string text, out DateTime result) { }

}

