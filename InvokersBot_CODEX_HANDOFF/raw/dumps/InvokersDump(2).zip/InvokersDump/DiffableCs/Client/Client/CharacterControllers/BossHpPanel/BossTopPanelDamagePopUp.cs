namespace Client.CharacterControllers.BossHpPanel;

public class BossTopPanelDamagePopUp : MonoBehaviour
{
	[SerializeField]
	private float _hideDelay; //Field offset: 0x20
	[SerializeField]
	private float _crearStateAfterHideCallDelay; //Field offset: 0x24
	[SerializeField]
	private UIContainer _hideShowAnimator; //Field offset: 0x28
	[SerializeField]
	private Vector3 _damageMaxScaleDiff; //Field offset: 0x30
	[SerializeField]
	private TextMeshProUGUI _damageText; //Field offset: 0x40
	[SerializeField]
	private UIAnimator _damageAnimator; //Field offset: 0x48
	[SerializeField]
	private Color _damageTextHalfColor; //Field offset: 0x50
	[SerializeField]
	private Color _damageTextMaxColor; //Field offset: 0x60
	[SerializeField]
	private Image _damageAccumulatedGlow; //Field offset: 0x70
	[SerializeField]
	private GameObject _damageFx; //Field offset: 0x78
	[SerializeField]
	private GameObject _critFx; //Field offset: 0x80
	[SerializeField]
	private float _damageTitleHideAnimationDelay; //Field offset: 0x88
	[SerializeField]
	private ParticleImage _critStrikeParticleImage; //Field offset: 0x90
	[SerializeField]
	private UIAnimator _critStrikeAnimator; //Field offset: 0x98
	[SerializeField]
	private CanvasGroup _critCanvasGroup; //Field offset: 0xA0
	private long _maxHealth; //Field offset: 0xA8
	private long _accumulatedDamage; //Field offset: 0xB0
	private Color _baseDamageTextColor; //Field offset: 0xB8
	private Vector3 _baseScale; //Field offset: 0xC8
	private float _lastDamageReceivedTime; //Field offset: 0xD4
	private ModelEntityKey _targetEntity; //Field offset: 0xD8
	private DamagePopupMode _mode; //Field offset: 0xE8
	private Func<Int64> _getCounterValue; //Field offset: 0xF0
	private long _displayedValue; //Field offset: 0xF8
	private bool _hideAnimationCalled; //Field offset: 0x100
	private bool _hideOnNextUpdate; //Field offset: 0x101

	public BossTopPanelDamagePopUp() { }

	private void Awake() { }

	public void Init(long maxHealth) { }

	private void PlayHitAnimation(bool isCritical) { }

	public void SetMode(DamagePopupMode mode, Func<Int64> getCounterValue) { }

	private void TakeCounterDamage(bool isCritical) { }

	public void TakeDamage(ModelEntityKey targetEntity, int damage, bool isCritical) { }

	private void TakeNormalDamage(ModelEntityKey targetEntity, int damage, bool isCritical) { }

	private void Update() { }

	private void UpdateCounterDamage() { }

	private void UpdateDamageDisplay(long damage) { }

	private void UpdateNormalDamage() { }

}

