namespace Client.CharacterControllers;

[UsedAsInjection]
public class DestructibleUiInstanceProvider : ScopedGameObjectsPool<DestructibleUIPool, DestructibleUI>
{
	private readonly DestructibleUIPool _pool; //Field offset: 0x60

	public DestructibleUiInstanceProvider(DestructibleUIPool pool) { }

	public DestructibleUI CreateDestructibleUI(Transform targetTransform) { }

	private static void OnDead(DestructibleUI instance) { }

}

