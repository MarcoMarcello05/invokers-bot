namespace Client.Common.UI;

public class HZTabGroup : IDisposable
{
	[CompilerGenerated]
	private struct <SelectTabInternal>d__16 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x0
		public HZTabGroup<TValue, TButton> <>4__this; //Field offset: 0x0
		public TValue arg; //Field offset: 0x0
		private TValue <previousTab>5__2; //Field offset: 0x0
		private ValueTaskAwaiter <>u__1; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly ILogger Log; //Field offset: 0x0
	private static readonly EqualityComparer<TValue> Comparer; //Field offset: 0x0
	private readonly IReadOnlyList<TButton> _tabButtons; //Field offset: 0x0
	private readonly TabCommandsGroup<TValue> _tabGroup; //Field offset: 0x0
	private readonly IReadOnlyList<TValue> _tabTypes; //Field offset: 0x0
	private readonly Func<TValue, ValueTask> _selectTab; //Field offset: 0x0
	private readonly bool _allowDeselect; //Field offset: 0x0
	private TValue _selectedTab; //Field offset: 0x0

	public IReadOnlyList<TButton> Buttons
	{
		 get { } //Length: 40
	}

	public TValue SelectedTab
	{
		 get { } //Length: 64
	}

	private static HZTabGroup`2() { }

	public HZTabGroup`2(ButtonCommandBuilder buttonCommandBuilder, IReadOnlyList<TValue> tabTypes, IReadOnlyList<TButton> tabButtons, Func<TValue, ValueTask> selectTab, BlockingContext blockingContext, Func<TValue, Boolean> canExecuteFn = null, bool allowSelectAgain = false, bool allowDeselect = false) { }

	public ValueTask DeselectAsync() { }

	public override void Dispose() { }

	public IReadOnlyList<TButton> get_Buttons() { }

	public TValue get_SelectedTab() { }

	public ValueTask SelectTabAsync(TValue arg) { }

	public ValueTask SelectTabIgnoringBlockingContextAsync(TValue arg) { }

	[AsyncStateMachine(typeof(<SelectTabInternal>d__16))]
	private ValueTask SelectTabInternal(TValue arg) { }

}

