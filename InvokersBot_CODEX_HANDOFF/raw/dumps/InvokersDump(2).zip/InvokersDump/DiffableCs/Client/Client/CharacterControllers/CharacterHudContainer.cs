namespace Client.CharacterControllers;

[DefaultMember("Item")]
[UsedAsInjection]
public class CharacterHudContainer : IDisposable
{
	private readonly IScopedAssetProvider _assetProvider; //Field offset: 0x10
	private readonly IReadOnlyDictionary<Int64, CustomStatusEffectPresentation> _customStatusEffectPresentations; //Field offset: 0x18
	private readonly TeamPanelController _playerTeamPanelController; //Field offset: 0x20
	private readonly OpponentTeamPanelController _opponentTeamPanelController; //Field offset: 0x28
	private CompositeStaticData _staticData; //Field offset: 0x30
	private HUDScreen _hudScreen; //Field offset: 0x38
	private readonly Dictionary<ModelEntityKey, CharacterHudController> _characterHudControllers; //Field offset: 0x40
	private readonly Dictionary<ModelEntityKey, AnimaCardButton> _animaCardsByCharacter; //Field offset: 0x48
	private HUDSkillCooldownContainer _hudSkillCooldownContainer; //Field offset: 0x50
	private HudCastBarView _hudCastBar; //Field offset: 0x58
	private ModelEntity _selectedEntity; //Field offset: 0x60
	private AnimaManaView _animaMana; //Field offset: 0x70
	private ComboButton _comboButton; //Field offset: 0x78
	private DashButton _dashButton; //Field offset: 0x80
	private bool _titanChargeSoundPlayed; //Field offset: 0x88
	[CompilerGenerated]
	private bool <Initialized>k__BackingField; //Field offset: 0x89

	public AnimaManaView AnimaManaView
	{
		 get { } //Length: 8
	}

	public HUDSkillCooldownContainer HudSkillCooldownContainer
	{
		 get { } //Length: 8
	}

	public private bool Initialized
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public CharacterHudController Item
	{
		 get { } //Length: 116
	}

	public ModelEntity SelectedEntity
	{
		 get { } //Length: 12
	}

	public CharacterHudContainer(IScopedAssetProvider assetProvider, ICustomStatusEffectPresentationProvider customStatusEffectPresentationProvider, TeamPanelController playerTeamPanelController, OpponentTeamPanelController opponentTeamPanelController) { }

	public void BlockAnimaCardSkill(ModelEntityKey characterEntity, bool needBlock) { }

	public void BlockCombo(bool needBlock = true) { }

	public void BlockDash(bool needBlock) { }

	public void BlockSkill(Entity entity, SkillType skillType, bool needBlock) { }

	public void ChangeAnimaCardsVisibility(bool isVisible) { }

	public void ChangeCharacter(ModelEntity character) { }

	public void CreateCharacterHud(ModelEntity character, CharacterStaticData characterStaticData, CharacterStaticData animaStaticData, int hudIndex, bool playerTeam) { }

	public override void Dispose() { }

	public AnimaManaView get_AnimaManaView() { }

	public HUDSkillCooldownContainer get_HudSkillCooldownContainer() { }

	[CompilerGenerated]
	public bool get_Initialized() { }

	public CharacterHudController get_Item(ModelEntityKey entity) { }

	public ModelEntity get_SelectedEntity() { }

	public bool HasEntity(ModelEntityKey entity) { }

	public void InitCharacterViews(CompositeStaticData staticData, HUDScreen hudScreen) { }

	public void PlayTitanChargedSound(ModelEntityKey entity) { }

	public void ResetCastBar() { }

	public void ResetCastFill(ModelEntity entity, SkillType skillType) { }

	public void ResetCooldown(Entity entity, SkillType skillType) { }

	private void ResetQueue() { }

	public void Select(ModelEntity entity) { }

	[CompilerGenerated]
	private void set_Initialized(bool value) { }

	public void SetAnimaCardCooldown(ModelEntityKey characterEntity, F64 cooldown, F64 timeLeft, bool anyAnimaInProgress) { }

	public void SetAnimaCardDuration(ModelEntityKey characterEntity, F64 duration, F64 timeLeft) { }

	public void SetAnimaMana(int manaChange, int currentMana, int defaultManaAmount, int maxMana) { }

	public void SetAnimaManaRange(int defaultManaAmount, int maxManaAmount) { }

	public void SetCastFill(ModelEntity entity, SkillType skillType, float fillAmount) { }

	public void SetCooldown(Entity entity, SkillType skillType, F64 cooldown, F64 timeLeft) { }

	public void SetDead(ModelEntityKey entity, bool isDead = true) { }

	public void SetMoveToCastGlow(ModelEntity entity, SkillType skillType) { }

	private void SetupAnimaCard(AnimaCardButton animaCard, CharacterStaticData animaStaticData, CharacterStaticData characterStaticData) { }

	public void TurnOffMoveToCastGlow() { }

	public void UnlockTitanChargeSound() { }

	public void UpdateAnimaCardHiddenState(ModelEntity characterEntity) { }

	public void UpdateCastBar(float firstMarkerTime, float lastMarkerTime, float timer) { }

	public void UpdateUltimateMana(int manaChange, ModelEntityKey entity, F64 currentMana, F64 maxMana, bool isInstant = false) { }

}

