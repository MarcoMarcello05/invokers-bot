namespace Client.CharacterControllers;

public class HudSkillData
{
	public Sprite ComboAttackSprite; //Field offset: 0x10
	public List<HudActiveOrUltSkillData> ActiveAndUltSkillsData; //Field offset: 0x18

	public HudSkillData() { }

}

