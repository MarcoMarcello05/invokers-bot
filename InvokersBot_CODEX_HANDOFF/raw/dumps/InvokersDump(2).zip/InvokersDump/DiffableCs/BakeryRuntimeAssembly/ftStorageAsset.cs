//Type is in global namespace

public class ftStorageAsset : ScriptableObject
{
	[SerializeField]
	public List<Texture2D> maps; //Field offset: 0x18
	[SerializeField]
	public List<Texture2D> masks; //Field offset: 0x20
	[SerializeField]
	public List<Texture2D> dirMaps; //Field offset: 0x28
	[SerializeField]
	public List<Texture2D> rnmMaps0; //Field offset: 0x30
	[SerializeField]
	public List<Texture2D> rnmMaps1; //Field offset: 0x38
	[SerializeField]
	public List<Texture2D> rnmMaps2; //Field offset: 0x40
	[SerializeField]
	public List<Int32> mapsMode; //Field offset: 0x48
	[SerializeField]
	public List<Int32> bakedIDs; //Field offset: 0x50
	[SerializeField]
	public List<Vector4> bakedScaleOffset; //Field offset: 0x58
	[SerializeField]
	public List<Mesh> bakedVertexColorMesh; //Field offset: 0x60
	[SerializeField]
	public List<Int32> bakedLightChannels; //Field offset: 0x68
	[SerializeField]
	public List<Int32> bakedIDsTerrain; //Field offset: 0x70
	[SerializeField]
	public List<Vector4> bakedScaleOffsetTerrain; //Field offset: 0x78
	[SerializeField]
	public List<String> assetList; //Field offset: 0x80
	[SerializeField]
	public List<Int32> uvOverlapAssetList; //Field offset: 0x88
	[SerializeField]
	public Int32[] idremap; //Field offset: 0x90

	public ftStorageAsset() { }

}

