namespace Client.CharacterControllers;

public class ComboButton : MonoBehaviour
{
	[Inject]
	private readonly HapticsService _haptics; //Field offset: 0x20
	[SerializeField]
	private GameObject _blockedState; //Field offset: 0x28
	[SerializeField]
	private UIButton _uiButton; //Field offset: 0x30

	public ComboButton() { }

	private void Awake() { }

	private void OnDestroy() { }

	private void PlayHapticEffect() { }

	public void SetBlocked(bool needBlock) { }

	private void Start() { }

}

