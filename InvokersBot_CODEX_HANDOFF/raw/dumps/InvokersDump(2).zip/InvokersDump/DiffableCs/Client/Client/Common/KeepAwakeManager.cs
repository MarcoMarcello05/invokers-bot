namespace Client.Common;

[UsedAsInjection]
public class KeepAwakeManager : IKeepAwakeManager
{
	private readonly ILogger _logger; //Field offset: 0x10
	private KeepAwakeReason _activeReasons; //Field offset: 0x18

	public override bool KeepAwake
	{
		 get { } //Length: 16
	}

	public KeepAwakeManager() { }

	public override void Acquire(KeepAwakeReason reason) { }

	protected override void ApplyKeepAwake(bool keepAwake) { }

	public override bool get_KeepAwake() { }

	public override void Reapply() { }

	public override void Release(KeepAwakeReason reason) { }

}

