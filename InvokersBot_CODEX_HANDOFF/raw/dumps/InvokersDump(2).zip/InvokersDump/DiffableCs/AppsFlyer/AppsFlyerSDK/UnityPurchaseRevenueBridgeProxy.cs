namespace AppsFlyerSDK;

public class UnityPurchaseRevenueBridgeProxy : AndroidJavaProxy
{

	public UnityPurchaseRevenueBridgeProxy() { }

	public string getAdditionalParameters(string productsJson, string transactionsJson) { }

}

