namespace Client.Authentication;

public interface ICredentialManagerBridge : IDisposable
{

	public void CancelSignIn() { }

	public string GetAndroidId() { }

	public void Initialize(Action<String> onSuccess, Action<String> onError) { }

	public void StartGoogleSignIn(string serverClientId, bool filterAuthorizedAccountsOnly, bool autoSelectEnabled, string nonce) { }

}

