namespace Client.Authentication.ExternalAuth.Providers;

public sealed class AppleGameCenterExternalAuthProvider : IExternalAuthProvider
{
	[CompilerGenerated]
	private struct <TryAuthenticateAsync>d__7 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder<ExternalAuthResult> <>t__builder; //Field offset: 0x8
		public AppleGameCenterExternalAuthProvider <>4__this; //Field offset: 0x40
		public ExternalAuthMode mode; //Field offset: 0x48
		public CancellationToken ct; //Field offset: 0x50
		private ValueTaskAwaiter<AppleGameCenterAuthStatus> <>u__1; //Field offset: 0x58
		[Nullable(new IL2CPP_TYPE_U1[] {0, 2})]
		private ValueTaskAwaiter<AppleGameCenterIdentityVerificationPayload> <>u__2; //Field offset: 0x68

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[Nullable(1)]
	private readonly ILogger<AppleGameCenterExternalAuthProvider> _logger; //Field offset: 0x10
	[Nullable(1)]
	private readonly IAppleGameCenterService _appleGameCenterService; //Field offset: 0x18

	public override bool IsAvailable
	{
		 get { } //Length: 160
	}

	public override ExternalLoginProvider Provider
	{
		 get { } //Length: 8
	}

	[NullableContext(1)]
	public AppleGameCenterExternalAuthProvider(IAppleGameCenterService appleGameCenterService) { }

	public override bool get_IsAvailable() { }

	public override ExternalLoginProvider get_Provider() { }

	[NullableContext(2)]
	public override string GetCurrentUserName() { }

	[AsyncStateMachine(typeof(<TryAuthenticateAsync>d__7))]
	public override ValueTask<ExternalAuthResult> TryAuthenticateAsync(ExternalAuthMode mode, CancellationToken ct = null) { }

}

