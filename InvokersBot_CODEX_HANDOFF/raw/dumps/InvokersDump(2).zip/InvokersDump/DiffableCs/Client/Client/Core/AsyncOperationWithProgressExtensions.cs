namespace Client.Core;

[Extension]
public static class AsyncOperationWithProgressExtensions
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass0_0
	{
		private sealed class <<JoinWithCallback>g__AllTasks|0>d : IEnumerable<UniTask>, IEnumerable, IEnumerator<UniTask>, IEnumerator, IDisposable
		{
			private int <>1__state; //Field offset: 0x10
			private UniTask <>2__current; //Field offset: 0x18
			private int <>l__initialThreadId; //Field offset: 0x28
			public <>c__DisplayClass0_0 <>4__this; //Field offset: 0x30
			private IAsyncOperationWithProgress[] <>7__wrap1; //Field offset: 0x38
			private int <>7__wrap2; //Field offset: 0x40

			private override UniTask System.Collections.Generic.IEnumerator<Cysharp.Threading.Tasks.UniTask>.Current
			{
				[DebuggerHidden]
				private get { } //Length: 12
			}

			private override object System.Collections.IEnumerator.Current
			{
				[DebuggerHidden]
				private get { } //Length: 92
			}

			[DebuggerHidden]
			public <<JoinWithCallback>g__AllTasks|0>d(int <>1__state) { }

			private override bool MoveNext() { }

			[DebuggerHidden]
			private override IEnumerator<UniTask> System.Collections.Generic.IEnumerable<Cysharp.Threading.Tasks.UniTask>.GetEnumerator() { }

			[DebuggerHidden]
			private override UniTask System.Collections.Generic.IEnumerator<Cysharp.Threading.Tasks.UniTask>.get_Current() { }

			[DebuggerHidden]
			private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

			[DebuggerHidden]
			private override object System.Collections.IEnumerator.get_Current() { }

			[DebuggerHidden]
			private override void System.Collections.IEnumerator.Reset() { }

			[DebuggerHidden]
			private override void System.IDisposable.Dispose() { }

		}

		public IAsyncOperationWithProgress operation; //Field offset: 0x10
		public IAsyncOperationWithProgress[] others; //Field offset: 0x18

		public <>c__DisplayClass0_0() { }

		[IteratorStateMachine(typeof(<<JoinWithCallback>g__AllTasks|0>d))]
		internal IEnumerable<UniTask> <JoinWithCallback>g__AllTasks|0() { }

	}

	[CompilerGenerated]
	private struct <JoinWithCallback>d__0 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncVoidMethodBuilder <>t__builder; //Field offset: 0x8
		public IAsyncOperationWithProgress operation; //Field offset: 0x28
		public IAsyncOperationWithProgress[] others; //Field offset: 0x30
		public Action onAllSuccess; //Field offset: 0x38
		private <>c__DisplayClass0_0 <>8__1; //Field offset: 0x40
		private Awaiter <>u__1; //Field offset: 0x48

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}


	[AsyncStateMachine(typeof(<JoinWithCallback>d__0))]
	[Extension]
	public static void JoinWithCallback(IAsyncOperationWithProgress operation, Action onAllSuccess, IAsyncOperationWithProgress[] others) { }

}

