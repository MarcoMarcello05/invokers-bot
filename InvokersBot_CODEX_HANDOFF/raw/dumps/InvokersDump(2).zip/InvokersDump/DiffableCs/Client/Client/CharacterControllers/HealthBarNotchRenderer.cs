namespace Client.CharacterControllers;

[RequireComponent(typeof(CanvasRenderer))]
public class HealthBarNotchRenderer : MaskableGraphic
{
	internal struct NotchLevelVisuals
	{
		public Color Color; //Field offset: 0x0
		public Vector2 Size; //Field offset: 0x10
		public float YOffset; //Field offset: 0x18

	}

	[SerializeField]
	[Tooltip("Order of levels matters! Must match the order in Tweaks.HealthBarTweaksItem.Levels")]
	private List<NotchLevelVisuals> _levelVisuals; //Field offset: 0xD8
	private int _currentMaxHealth; //Field offset: 0xE0
	private bool _isDirty; //Field offset: 0xE4
	private readonly List<ValueTuple`2<Single, Int32>> _calculatedNotches; //Field offset: 0xE8
	private readonly UIVertex[] _quadVertices; //Field offset: 0xF0

	public virtual Texture mainTexture
	{
		 get { } //Length: 88
	}

	public HealthBarNotchRenderer() { }

	public virtual Texture get_mainTexture() { }

	protected virtual void OnPopulateMesh(VertexHelper vh) { }

	public void Redraw(int maxHealth) { }

}

