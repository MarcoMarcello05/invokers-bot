namespace Client.Core.GameServices;

[MemoryPackable(GenerateType::Object (0))]
public struct BattleTapeHeroSnapshot : IMemoryPackable<BattleTapeHeroSnapshot>, IMemoryPackFormatterRegister, IEquatable<BattleTapeHeroSnapshot>
{
	[Preserve]
	private sealed class BattleTapeHeroSnapshotFormatter : MemoryPackFormatter<BattleTapeHeroSnapshot>
	{

		public BattleTapeHeroSnapshotFormatter() { }

		[Preserve]
		public virtual void Deserialize(ref MemoryPackReader reader, ref BattleTapeHeroSnapshot value) { }

		[NullableContext(1)]
		[Preserve]
		public virtual void Serialize(ref MemoryPackWriter<TBufferWriter>& writer, ref BattleTapeHeroSnapshot value) { }

	}

	[CompilerGenerated]
	private FormationSlotPosition <Position>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private long <ConfigId>k__BackingField; //Field offset: 0x8
	[CompilerGenerated]
	private int <Level>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private AscensionRank <Rank>k__BackingField; //Field offset: 0x14

	public long ConfigId
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public int Level
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public FormationSlotPosition Position
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public AscensionRank Rank
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	private static BattleTapeHeroSnapshot() { }

	public BattleTapeHeroSnapshot(FormationSlotPosition Position, long ConfigId, int Level, AscensionRank Rank) { }

	[CompilerGenerated]
	public void Deconstruct(out FormationSlotPosition Position, out long ConfigId, out int Level, out AscensionRank Rank) { }

	[Preserve]
	public static void Deserialize(ref MemoryPackReader reader, ref BattleTapeHeroSnapshot value) { }

	[CompilerGenerated]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	public override bool Equals(BattleTapeHeroSnapshot other) { }

	[CompilerGenerated]
	public long get_ConfigId() { }

	[CompilerGenerated]
	public int get_Level() { }

	[CompilerGenerated]
	public FormationSlotPosition get_Position() { }

	[CompilerGenerated]
	public AscensionRank get_Rank() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	public static bool op_Equality(BattleTapeHeroSnapshot left, BattleTapeHeroSnapshot right) { }

	[CompilerGenerated]
	public static bool op_Inequality(BattleTapeHeroSnapshot left, BattleTapeHeroSnapshot right) { }

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder) { }

	[Preserve]
	public static void RegisterFormatter() { }

	[NullableContext(1)]
	[Preserve]
	public static void Serialize(ref MemoryPackWriter<TBufferWriter>& writer, ref BattleTapeHeroSnapshot value) { }

	[CompilerGenerated]
	public void set_ConfigId(long value) { }

	[CompilerGenerated]
	public void set_Level(int value) { }

	[CompilerGenerated]
	public void set_Position(FormationSlotPosition value) { }

	[CompilerGenerated]
	public void set_Rank(AscensionRank value) { }

	[CompilerGenerated]
	public virtual string ToString() { }

}

