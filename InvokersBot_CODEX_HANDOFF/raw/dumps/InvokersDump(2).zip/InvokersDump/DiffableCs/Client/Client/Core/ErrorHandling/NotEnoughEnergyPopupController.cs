namespace Client.Core.ErrorHandling;

[UsedAsInjection]
public class NotEnoughEnergyPopupController : AwaitableDialogController<NotEnoughEnergyPopup>
{
	[CompilerGenerated]
	private struct <HandleBuyButtonClick>d__17 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public NotEnoughEnergyPopupController <>4__this; //Field offset: 0x28
		private List<GameItemViewModel> <rewards>5__2; //Field offset: 0x30
		private Exception <exception>5__3; //Field offset: 0x38
		private Awaiter <>u__1; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <HandleCloseButtonClick>d__16 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public NotEnoughEnergyPopupController <>4__this; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IContentManager _content; //Field offset: 0x88
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x90
	private readonly ButtonCommandBuilder _buttonCommandBuilder; //Field offset: 0x98
	private readonly IChoreographManager _choreographManager; //Field offset: 0xA0
	private readonly BlockingContext _blockingContext; //Field offset: 0xA8
	private readonly RewardReceivedPopup _rewardReceived; //Field offset: 0xB0
	private readonly PurchaseFailedPopup _purchaseFailedPopup; //Field offset: 0xB8
	private readonly LoadingScreenService _loadingScreenService; //Field offset: 0xC0
	private readonly GameRewardCache _gameRewardCache; //Field offset: 0xC8
	private ShopItem _selectedShopItem; //Field offset: 0xD0

	public NotEnoughEnergyPopupController(IUISystem uiSystem, IContentManager content, IStagingContainer stagingContainer, ButtonCommandBuilder buttonCommandBuilder, IChoreographManager choreographManager, RewardReceivedPopup rewardReceived, PurchaseFailedPopup purchaseFailedPopup, LoadingScreenService loadingScreenService, GameRewardCache gameRewardCache) { }

	private List<GameItemViewModel> GetAllRewards() { }

	[AsyncStateMachine(typeof(<HandleBuyButtonClick>d__17))]
	private ValueTask HandleBuyButtonClick() { }

	[AsyncStateMachine(typeof(<HandleCloseButtonClick>d__16))]
	private ValueTask HandleCloseButtonClick() { }

	protected virtual void OnViewClose() { }

	protected virtual void OnViewLoaded() { }

	private void SelectAndApplyPack() { }

	private void SetBalance() { }

	protected virtual IAsyncInitializable<NotEnoughEnergyPopup> ViewFactory() { }

}

