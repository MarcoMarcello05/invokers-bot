//Type is in global namespace

public class BakerySectorCapture : ScriptableObject
{

	public BakerySectorCapture() { }

}

