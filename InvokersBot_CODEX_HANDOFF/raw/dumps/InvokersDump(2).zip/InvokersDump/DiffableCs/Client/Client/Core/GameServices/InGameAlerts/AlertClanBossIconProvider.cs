namespace Client.Core.GameServices.InGameAlerts;

internal sealed class AlertClanBossIconProvider : IAlertClanBossIconProvider
{
	[CompilerGenerated]
	private struct <AwaitLoadAsync>d__11 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public IAssetRequest<Sprite> request; //Field offset: 0x18
		public RegionId regionId; //Field offset: 0x20
		public AlertClanBossIconProvider <>4__this; //Field offset: 0x28
		public UniTaskCompletionSource<Boolean> completionSource; //Field offset: 0x30
		private Awaiter<Sprite> <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IChoreographManager _choreographManager; //Field offset: 0x10
	private readonly IContentManager _contentManager; //Field offset: 0x18
	private readonly Dictionary<RegionId, IAssetRequest`1<Sprite>> _requestByRegion; //Field offset: 0x20
	private readonly Dictionary<RegionId, Sprite> _loadedByRegion; //Field offset: 0x28
	private readonly Dictionary<RegionId, UniTaskCompletionSource`1<Boolean>> _pendingLoadByRegion; //Field offset: 0x30

	public AlertClanBossIconProvider(IChoreographManager choreographManager, IContentManager contentManager) { }

	[AsyncStateMachine(typeof(<AwaitLoadAsync>d__11))]
	private UniTask AwaitLoadAsync(RegionId regionId, IAssetRequest<Sprite> request, UniTaskCompletionSource<Boolean> completionSource) { }

	private void CancelPendingLoad(RegionId regionId) { }

	public override void Clear() { }

	private void CompleteIfCurrent(RegionId regionId, UniTaskCompletionSource<Boolean> completionSource, bool result) { }

	public override UniTask<Boolean> EnsureLoadedAsync(RegionId regionId) { }

	public override Sprite Get(RegionId regionId) { }

	public override void Release(RegionId regionId) { }

	internal static CharacterConfig ResolveBossConfig(CompositeStaticData staticData, RegionId regionId) { }

}

