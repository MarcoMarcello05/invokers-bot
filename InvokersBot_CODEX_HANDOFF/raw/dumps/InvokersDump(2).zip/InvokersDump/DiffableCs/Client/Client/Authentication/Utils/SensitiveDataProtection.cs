namespace Client.Authentication.Utils;

public static class SensitiveDataProtection
{

	[NullableContext(1)]
	public static string Mask(string value) { }

}

