namespace Client.Characters;

[Extension]
public static class JiggleExtensions
{

	[Extension]
	public static Quaternion Append(Quaternion source, Quaternion quaternion) { }

	[Extension]
	public static float Clamp01(float source) { }

	[Extension]
	public static Quaternion FromToRotation(Quaternion source, Quaternion target) { }

	[Extension]
	public static List<Vector3> GetOrthogonalVectors(Vector3 source, int numVectors) { }

	[Extension]
	public static Quaternion Scale(Quaternion source, float scale) { }

}

