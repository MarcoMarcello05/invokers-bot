namespace AppsFlyerSDK;

public interface IAppsFlyerConversionData
{

}

