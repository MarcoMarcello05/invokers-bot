namespace Client.Authentication.ExternalAuth;

public enum DebugAuthOutcome : int
{
	Fail = 0,
	Cancel = 1,
}

