namespace Ara;

[RequireComponent(typeof(AraTrail))]
public class ColorFromSpeed : MonoBehaviour
{
	private AraTrail trail; //Field offset: 0x20
	[Tooltip("Maps trail speed to color. Control how much speed is transferred to the trail by setting inertia > 0. The trail will be colorized even if physics are disabled. ")]
	public Gradient colorFromSpeed; //Field offset: 0x28
	[Tooltip("Min speed used to map speed to color.")]
	public float minSpeed; //Field offset: 0x30
	[Tooltip("Max speed used to map speed to color.")]
	public float maxSpeed; //Field offset: 0x34

	public ColorFromSpeed() { }

	private void OnDisable() { }

	private void OnEnable() { }

	private void SetColorFromSpeed() { }

}

