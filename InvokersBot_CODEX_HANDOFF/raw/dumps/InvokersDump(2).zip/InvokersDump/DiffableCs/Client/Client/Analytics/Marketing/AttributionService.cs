namespace Client.Analytics.Marketing;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public class AttributionService : IDisposable
{
	[Nullable(0)]
	private sealed class AppsFlyerInitContext : IEquatable<AppsFlyerInitContext>
	{
		[CompilerGenerated]
		private readonly string <DevKey>k__BackingField; //Field offset: 0x10
		[CompilerGenerated]
		private readonly string <IosAppId>k__BackingField; //Field offset: 0x18
		[CompilerGenerated]
		private readonly bool <Debug>k__BackingField; //Field offset: 0x20

		public bool Debug
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public string DevKey
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		[CompilerGenerated]
		private Type EqualityContract
		{
			[CompilerGenerated]
			private get { } //Length: 96
		}

		public string IosAppId
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public AppsFlyerInitContext(string DevKey, string IosAppId, bool Debug) { }

		[CompilerGenerated]
		private AppsFlyerInitContext(AppsFlyerInitContext original) { }

		[CompilerGenerated]
		public AppsFlyerInitContext <Clone>$() { }

		[CompilerGenerated]
		public void Deconstruct(out string DevKey, out string IosAppId, out bool Debug) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public virtual bool Equals(object obj) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public override bool Equals(AppsFlyerInitContext other) { }

		[CompilerGenerated]
		public bool get_Debug() { }

		[CompilerGenerated]
		public string get_DevKey() { }

		[CompilerGenerated]
		private Type get_EqualityContract() { }

		[CompilerGenerated]
		public string get_IosAppId() { }

		[CompilerGenerated]
		public virtual int GetHashCode() { }

		[CompilerGenerated]
		[NullableContext(2)]
		public static bool op_Equality(AppsFlyerInitContext left, AppsFlyerInitContext right) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public static bool op_Inequality(AppsFlyerInitContext left, AppsFlyerInitContext right) { }

		[CompilerGenerated]
		private bool PrintMembers(StringBuilder builder) { }

		[CompilerGenerated]
		public void set_Debug(bool value) { }

		[CompilerGenerated]
		public void set_DevKey(string value) { }

		[CompilerGenerated]
		public void set_IosAppId(string value) { }

		[CompilerGenerated]
		public virtual string ToString() { }

	}

	[NullableContext(0)]
	public struct DmaConsentFlags
	{
		[CompilerGenerated]
		private readonly bool <SubjectToGdpr>k__BackingField; //Field offset: 0x0
		[CompilerGenerated]
		private readonly Nullable<Boolean> <AdUserData>k__BackingField; //Field offset: 0x1
		[CompilerGenerated]
		private readonly Nullable<Boolean> <AdPersonalization>k__BackingField; //Field offset: 0x3
		[CompilerGenerated]
		private readonly Nullable<Boolean> <AdStorage>k__BackingField; //Field offset: 0x5

		public Nullable<Boolean> AdPersonalization
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		public Nullable<Boolean> AdStorage
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		public Nullable<Boolean> AdUserData
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		public bool SubjectToGdpr
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		public DmaConsentFlags(bool subjectToGdpr, Nullable<Boolean> adUserData, Nullable<Boolean> adPersonalization, Nullable<Boolean> adStorage) { }

		[CompilerGenerated]
		public Nullable<Boolean> get_AdPersonalization() { }

		[CompilerGenerated]
		public Nullable<Boolean> get_AdStorage() { }

		[CompilerGenerated]
		public Nullable<Boolean> get_AdUserData() { }

		[CompilerGenerated]
		public bool get_SubjectToGdpr() { }

	}

	private static readonly ILogger Logger; //Field offset: 0x0
	private const string CuidTypeKey = "cuid_type"; //Field offset: 0x0
	private const string CuidTypeAccountId = "account_id"; //Field offset: 0x0
	private readonly IOptionsMonitor<ClientAppSettings> _appSettings; //Field offset: 0x10
	private readonly IUserTrackingService _userTrackingService; //Field offset: 0x18
	private readonly FirebaseService _firebaseService; //Field offset: 0x20
	private readonly IConsentService _consentService; //Field offset: 0x28
	[Nullable(2)]
	private IClientAnalytics _clientAnalytics; //Field offset: 0x30
	private readonly AttributionEventsStateStore _eventsState; //Field offset: 0x38
	private readonly AttributionEventMapper _eventMapper; //Field offset: 0x40
	[Nullable(2)]
	private GameObject _afGameObject; //Field offset: 0x48
	[Nullable(2)]
	private AppsFlyerCallbacksProxy _callbacksProxy; //Field offset: 0x50
	private bool _attributionEventSent; //Field offset: 0x58
	private bool _sdkUnavailable; //Field offset: 0x59
	private bool _initialized; //Field offset: 0x5A
	private bool _sdkStarted; //Field offset: 0x5B
	[Nullable(2)]
	private string _pendingAccountId; //Field offset: 0x60
	[Nullable(2)]
	private string _accountId; //Field offset: 0x68
	[Nullable(2)]
	private string _pendingUninstallToken; //Field offset: 0x70
	[Nullable(2)]
	private Byte[] _lastApnsDeviceToken; //Field offset: 0x78
	[CompilerGenerated]
	private string <AppsflyerId>k__BackingField; //Field offset: 0x80
	[CompilerGenerated]
	private string <IsOutOfStore>k__BackingField; //Field offset: 0x88
	[CompilerGenerated]
	[Nullable(2)]
	private AppsFlyerLinkParameters <ConversionData>k__BackingField; //Field offset: 0x90
	[Nullable(new IL2CPP_TYPE_U1[] {1, 2})]
	private readonly BehaviorSubject<AppsFlyerLinkParameters> _onAttributedSubject; //Field offset: 0x98
	private readonly IDisposable _consentChangedSubscription; //Field offset: 0xA0

	public string AppsflyerId
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	[Nullable(2)]
	public private AppsFlyerLinkParameters ConversionData
	{
		[CompilerGenerated]
		[NullableContext(2)]
		 get { } //Length: 8
		[CompilerGenerated]
		[NullableContext(2)]
		private set { } //Length: 8
	}

	internal bool IsInitializedForTests
	{
		internal get { } //Length: 8
	}

	public string IsOutOfStore
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	internal bool IsSdkUnavailableForTests
	{
		internal get { } //Length: 8
	}

	[Nullable(new IL2CPP_TYPE_U1[] {1, 2})]
	public Observable<AppsFlyerLinkParameters> OnAttributed
	{
		 get { } //Length: 8
	}

	[Nullable(2)]
	internal string PendingUninstallTokenForTests
	{
		[NullableContext(2)]
		internal get { } //Length: 8
	}

	private static AttributionService() { }

	public AttributionService(IOptionsMonitor<ClientAppSettings> appSettings, IUserTrackingService userTrackingService, FirebaseService firebaseService, IConsentService consentService) { }

	[CompilerGenerated]
	private void <.ctor>b__42_0(Unit _) { }

	private void ApplyDmaConsent() { }

	internal static DmaConsentFlags BuildDmaConsentFlags(bool subjectToGdpr, bool adConsent) { }

	[NullableContext(2)]
	private static void DestroyGameObject(GameObject gameObject) { }

	public override void Dispose() { }

	[CompilerGenerated]
	public string get_AppsflyerId() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public AppsFlyerLinkParameters get_ConversionData() { }

	internal bool get_IsInitializedForTests() { }

	[CompilerGenerated]
	public string get_IsOutOfStore() { }

	internal bool get_IsSdkUnavailableForTests() { }

	public Observable<AppsFlyerLinkParameters> get_OnAttributed() { }

	[NullableContext(2)]
	internal string get_PendingUninstallTokenForTests() { }

	public UniTask InitAsync() { }

	private void InitializeSdk(AppsFlyerInitContext context) { }

	private void InitializeUninstallTracking() { }

	public void LogEvent(IClientBiEvent biEvent, string name, IReadOnlyCollection<EventParam> parameters = null) { }

	[NullableContext(2)]
	public void OnAccountResolved(string accountId) { }

	private void OnApnsDeviceTokenReceived(Byte[] deviceToken) { }

	private void OnConsentChanged() { }

	internal void OnConversionDataFail(string conversionData) { }

	private void OnConversionDataSuccess(string conversionData) { }

	public void OnPushTokenReceived(string token) { }

	private void OnRequestResponse(object sender, EventArgs eventArgs) { }

	private static AppsFlyerLinkParameters ParseConversionData(string conversionData) { }

	private void ReadAppsflyerId() { }

	private void SendEventInternal(AttributionEvent attributionEvent) { }

	[CompilerGenerated]
	public void set_AppsflyerId(string value) { }

	[CompilerGenerated]
	[NullableContext(2)]
	private void set_ConversionData(AppsFlyerLinkParameters value) { }

	[CompilerGenerated]
	public void set_IsOutOfStore(string value) { }

	public void SetAnalytics(IClientAnalytics clientAnalytics) { }

	private void StartSdk(string reason) { }

	private bool TryBuildInitContext(AttributionSettings settings, out AppsFlyerInitContext context) { }

	private void TryLogPlayerAttributedEvent() { }

	private void TryRegisterUninstallDeviceToken(Byte[] deviceToken) { }

	private void TryUpdateUninstallToken(string token) { }

}

