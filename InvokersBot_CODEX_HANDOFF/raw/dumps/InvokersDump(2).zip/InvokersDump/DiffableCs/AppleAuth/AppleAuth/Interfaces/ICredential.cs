namespace AppleAuth.Interfaces;

public interface ICredential
{

}

