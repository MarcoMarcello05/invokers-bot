namespace Client.Core;

[UsedAsInjection]
public class CollectionPool : GameObjectsPool<CollectionPoolItem>
{
	[CompilerGenerated]
	private sealed class <get_RequiredAssets>d__7 : IEnumerable<AssetKey>, IEnumerable, IEnumerator<AssetKey>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private AssetKey <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public CollectionPool <>4__this; //Field offset: 0x28
		private TemplateKey[] <>7__wrap1; //Field offset: 0x30
		private int <>7__wrap2; //Field offset: 0x38

		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <get_RequiredAssets>d__7(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<AssetKey> System.Collections.Generic.IEnumerable<Client.AssetKey>.GetEnumerator() { }

		[DebuggerHidden]
		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private struct <Init>d__8 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public CollectionPool <>4__this; //Field offset: 0x18
		private Awaiter<GameObject[]> <>u__1; //Field offset: 0x20

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <RentAsync>d__5 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder<T> <>t__builder; //Field offset: 0x0
		public CollectionPool <>4__this; //Field offset: 0x0
		public AssetKey key; //Field offset: 0x0
		private Awaiter<CollectionPoolItem> <>u__1; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private struct TemplateKey : IEquatable<TemplateKey>
	{
		[CompilerGenerated]
		private readonly AssetKey <Key>k__BackingField; //Field offset: 0x0
		[CompilerGenerated]
		private readonly GameObject <Prefab>k__BackingField; //Field offset: 0x8
		[CompilerGenerated]
		private readonly CollectionPoolItem <Component>k__BackingField; //Field offset: 0x10

		public CollectionPoolItem Component
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public AssetKey Key
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public GameObject Prefab
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public TemplateKey(AssetKey Key, GameObject Prefab, CollectionPoolItem Component) { }

		[CompilerGenerated]
		public void Deconstruct(out AssetKey Key, out GameObject Prefab, out CollectionPoolItem Component) { }

		[CompilerGenerated]
		public virtual bool Equals(object obj) { }

		[CompilerGenerated]
		public override bool Equals(TemplateKey other) { }

		[CompilerGenerated]
		public CollectionPoolItem get_Component() { }

		[CompilerGenerated]
		public AssetKey get_Key() { }

		[CompilerGenerated]
		public GameObject get_Prefab() { }

		[CompilerGenerated]
		public virtual int GetHashCode() { }

		[CompilerGenerated]
		public static bool op_Equality(TemplateKey left, TemplateKey right) { }

		[CompilerGenerated]
		public static bool op_Inequality(TemplateKey left, TemplateKey right) { }

		[CompilerGenerated]
		private bool PrintMembers(StringBuilder builder) { }

		[CompilerGenerated]
		public void set_Component(CollectionPoolItem value) { }

		[CompilerGenerated]
		public void set_Key(AssetKey value) { }

		[CompilerGenerated]
		public void set_Prefab(GameObject value) { }

		[CompilerGenerated]
		public virtual string ToString() { }

	}

	private readonly IAssetProvider _assetProvider; //Field offset: 0x70
	private readonly TemplateKey[] _templates; //Field offset: 0x78

	protected virtual IEnumerable<AssetKey> RequiredAssets
	{
		[IteratorStateMachine(typeof(<get_RequiredAssets>d__7))]
		 get { } //Length: 128
	}

	public CollectionPool(IBootstrap bootstrap, IAssetProvider assetProvider, IReadOnlyList<AssetKey> keys) { }

	[IteratorStateMachine(typeof(<get_RequiredAssets>d__7))]
	protected virtual IEnumerable<AssetKey> get_RequiredAssets() { }

	protected virtual int GetMaxCachedInstances(CollectionPoolItem prefab) { }

	protected override int GetMaxCachedInstances(AssetKey key) { }

	private T GetTemplate(AssetKey key) { }

	[AsyncStateMachine(typeof(<Init>d__8))]
	protected virtual UniTask Init(IOperationProgressObserver onProgressChange) { }

	public T Rent(AssetKey key) { }

	[AsyncStateMachine(typeof(<RentAsync>d__5`1))]
	public UniTask<T> RentAsync(AssetKey key) { }

}

