namespace Client.Characters;

public interface ICharacterController : IDisposable
{

	public void Bind(CharacterView view) { }

	public void Tick(float deltaTime) { }

	public void Unbind() { }

}

