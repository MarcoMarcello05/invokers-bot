namespace Client.Configuration;

[Nullable(0)]
[NullableContext(1)]
public class AbExperimentsConfigurationProvider : ConfigurationProvider, IKeyEnumerator
{
	[CompilerGenerated]
	private sealed class <>c
	{
		[Nullable(0)]
		public static readonly <>c <>9; //Field offset: 0x0
		[Nullable(0)]
		public static Func<AbExperimentAssignment, Boolean> <>9__2_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		[NullableContext(0)]
		internal bool <Load>b__2_0(AbExperimentAssignment x) { }

	}

	private readonly AbExperimentsConfigurationSource _source; //Field offset: 0x20

	public AbExperimentsConfigurationProvider(AbExperimentsConfigurationSource source) { }

	public override IEnumerable<String> GetAllKeys() { }

	public virtual void Load() { }

}

