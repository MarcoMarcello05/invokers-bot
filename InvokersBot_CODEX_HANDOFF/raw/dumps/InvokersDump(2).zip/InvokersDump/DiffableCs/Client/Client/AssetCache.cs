namespace Client;

[Nullable(0)]
[NullableContext(1)]
internal sealed class AssetCache : IDisposable
{
	[Nullable(0)]
	private struct CachedEntry
	{
		[CompilerGenerated]
		private readonly AssetKey <Key>k__BackingField; //Field offset: 0x0
		[CompilerGenerated]
		[Nullable(2)]
		private IAssetRequest <Request>k__BackingField; //Field offset: 0x8
		[CompilerGenerated]
		private int <Prev>k__BackingField; //Field offset: 0x10
		[CompilerGenerated]
		private int <Next>k__BackingField; //Field offset: 0x14

		public AssetKey Key
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		internal int Next
		{
			[CompilerGenerated]
			internal get { } //Length: 8
			[CompilerGenerated]
			internal set { } //Length: 8
		}

		internal int Prev
		{
			[CompilerGenerated]
			internal get { } //Length: 8
			[CompilerGenerated]
			internal set { } //Length: 8
		}

		[Nullable(2)]
		internal IAssetRequest Request
		{
			[CompilerGenerated]
			[NullableContext(2)]
			internal get { } //Length: 8
			[CompilerGenerated]
			[NullableContext(2)]
			private set { } //Length: 8
		}

		internal CachedEntry(AssetKey key, IAssetRequest request) { }

		public void Clear() { }

		public void Dispose() { }

		[CompilerGenerated]
		public AssetKey get_Key() { }

		[CompilerGenerated]
		internal int get_Next() { }

		[CompilerGenerated]
		internal int get_Prev() { }

		[CompilerGenerated]
		[NullableContext(2)]
		internal IAssetRequest get_Request() { }

		[CompilerGenerated]
		internal void set_Next(int value) { }

		[CompilerGenerated]
		internal void set_Prev(int value) { }

		[CompilerGenerated]
		[NullableContext(2)]
		private void set_Request(IAssetRequest value) { }

	}

	private readonly int _capacity; //Field offset: 0x10
	private readonly Dictionary<AssetKey, Int32> _indexByKey; //Field offset: 0x18
	private readonly CachedEntry[] _entries; //Field offset: 0x20
	private readonly Int32[] _freeStack; //Field offset: 0x28
	private int _freeCount; //Field offset: 0x30
	private int _head; //Field offset: 0x34
	private int _tail; //Field offset: 0x38
	private int _count; //Field offset: 0x3C

	public AssetCache(int capacity) { }

	public void AddOrTouch(AssetKey key, IAssetLoadingTask<T> loadingTask, AddressableAssetProvider assetProvider) { }

	private int AllocateIndex() { }

	public void AppendDiagnostics(StringBuilder builder, AssetCacheGroup group) { }

	public void Clear() { }

	public bool Contains(AssetKey key) { }

	public AssetCacheSnapshot CreateSnapshot(AssetCacheGroup group) { }

	private void Detach(int index) { }

	public override void Dispose() { }

	private static string GetStatus(IAssetRequest request) { }

	private void InsertAtHead(int index) { }

	private void MoveToHead(int index) { }

	public void Remove(AssetKey key, bool dispose) { }

	private void RemoveIndex(int index, bool dispose) { }

	public void Touch(AssetKey key) { }

}

