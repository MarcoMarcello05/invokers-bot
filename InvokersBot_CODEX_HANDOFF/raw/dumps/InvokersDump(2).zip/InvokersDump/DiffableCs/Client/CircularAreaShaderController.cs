//Type is in global namespace

public class CircularAreaShaderController : MonoBehaviour
{
	private static readonly int RadiusInner; //Field offset: 0x0
	private static readonly int Progress; //Field offset: 0x4
	private static readonly int GlobalOpacity; //Field offset: 0x8
	[SerializeField]
	protected MeshRenderer meshRenderer; //Field offset: 0x20

	public float FillProgress
	{
		 set { } //Length: 148
	}

	public float InnerRadiusPart
	{
		 set { } //Length: 148
	}

	public float Opacity
	{
		 set { } //Length: 148
	}

	private static CircularAreaShaderController() { }

	public CircularAreaShaderController() { }

	public void set_FillProgress(float value) { }

	public void set_InnerRadiusPart(float value) { }

	public void set_Opacity(float value) { }

}

