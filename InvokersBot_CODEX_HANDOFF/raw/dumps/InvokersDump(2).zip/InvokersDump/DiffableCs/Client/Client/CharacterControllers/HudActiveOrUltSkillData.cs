namespace Client.CharacterControllers;

public class HudActiveOrUltSkillData
{
	public SkillConfig Config; //Field offset: 0x10
	public List<SkillConfig> Skills; //Field offset: 0x18
	public SkillLevelInfo SkillInfo; //Field offset: 0x20
	public SkillAssets Assets; //Field offset: 0x38
	public BattleStats BattleStats; //Field offset: 0x40
	public long CharacterGDID; //Field offset: 0x48
	public string LocalizationKey; //Field offset: 0x50
	public string CharacterName; //Field offset: 0x58
	public CharacterKind Kind; //Field offset: 0x60
	public bool IsTopPanelSkillData; //Field offset: 0x61
	public bool DisableDescription; //Field offset: 0x62
	public IReadOnlyDictionary<Int64, CustomStatusEffectPresentation> CustomStatusEffectPresentations; //Field offset: 0x68

	public HudActiveOrUltSkillData() { }

}

