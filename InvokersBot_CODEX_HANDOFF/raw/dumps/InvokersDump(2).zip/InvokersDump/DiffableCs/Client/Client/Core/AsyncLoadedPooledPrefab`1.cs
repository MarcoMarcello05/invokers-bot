namespace Client.Core;

internal sealed class AsyncLoadedPooledPrefab : AsyncInitializableBase, IAssetHolder, IAsyncInitializable<TComponent>, IAsyncInitializable, IDisposable
{
	[CompilerGenerated]
	private sealed class <get_RequiredAssets>d__10 : IEnumerable<AssetKey>, IEnumerable, IEnumerator<AssetKey>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private AssetKey <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		public AsyncLoadedPooledPrefab<TComponent> <>4__this; //Field offset: 0x0

		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <get_RequiredAssets>d__10(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<AssetKey> System.Collections.Generic.IEnumerable<Client.AssetKey>.GetEnumerator() { }

		[DebuggerHidden]
		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private sealed class <InitFactory>d__21 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		public AsyncLoadedPooledPrefab<TComponent> <>4__this; //Field offset: 0x0

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <InitFactory>d__21(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private struct <LoadAsync>d__22 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x0
		public AsyncLoadedPooledPrefab<TComponent> <>4__this; //Field offset: 0x0
		private AutoScope <_>5__2; //Field offset: 0x0
		private Awaiter<TComponent> <>u__1; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity AssetLoad; //Field offset: 0x0
	private readonly AssetKey _assetKey; //Field offset: 0x0
	private readonly IPrefabInstantiationStrategy _instantiationStrategy; //Field offset: 0x0
	private readonly UiViewCache _cache; //Field offset: 0x0
	private readonly string _instanceName; //Field offset: 0x0
	[CompilerGenerated]
	private TComponent <Value>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private readonly string <OwnerCallerLabel>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private readonly string <OwnerCallerFilePath>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private readonly int <OwnerCallerLine>k__BackingField; //Field offset: 0x0

	private string OwnerCallerFilePath
	{
		[CompilerGenerated]
		private get { } //Length: 8
	}

	private string OwnerCallerLabel
	{
		[CompilerGenerated]
		private get { } //Length: 8
	}

	private int OwnerCallerLine
	{
		[CompilerGenerated]
		private get { } //Length: 8
	}

	public override IEnumerable<AssetKey> RequiredAssets
	{
		[IteratorStateMachine(typeof(<get_RequiredAssets>d__10))]
		 get { } //Length: 124
	}

	public private override TComponent Value
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	private static AsyncLoadedPooledPrefab`1() { }

	public AsyncLoadedPooledPrefab`1(AssetKey assetKey, IPrefabInstantiationStrategy instantiationStrategy, UiViewCache cache, string instanceName = null, string ownerLabelOverride = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	protected virtual void DisposeInternal() { }

	[CompilerGenerated]
	private string get_OwnerCallerFilePath() { }

	[CompilerGenerated]
	private string get_OwnerCallerLabel() { }

	[CompilerGenerated]
	private int get_OwnerCallerLine() { }

	[IteratorStateMachine(typeof(<get_RequiredAssets>d__10))]
	public override IEnumerable<AssetKey> get_RequiredAssets() { }

	[CompilerGenerated]
	public override TComponent get_Value() { }

	[IteratorStateMachine(typeof(<InitFactory>d__21))]
	protected virtual IEnumerable<IAsyncOperationWithProgress> InitFactory() { }

	[AsyncStateMachine(typeof(<LoadAsync>d__22))]
	private UniTask LoadAsync(IOperationProgressObserver onProgressChange = null) { }

	[CompilerGenerated]
	private void set_Value(TComponent value) { }

}

