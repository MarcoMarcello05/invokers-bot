namespace Client.CameraShake;

public class CameraShakeViewData
{
	public ScheduledCameraShake ScheduledShake; //Field offset: 0x10
	public Optional<CameraShakeInstance> Instance; //Field offset: 0x40
	public Optional<BlockFx> BlockLink; //Field offset: 0x80
	public Optional<SkillPhaseFx> SkillPhaseLink; //Field offset: 0x98

	public CameraShakeViewData() { }

	public void Reset() { }

}

