namespace Client.Characters;

public sealed class CharacterJiggleModule : ICharacterModule, IDisposable
{
	private readonly IJiggleScheduler _scheduler; //Field offset: 0x10
	private IDisposable _registration; //Field offset: 0x18

	public CharacterJiggleModule(IJiggleScheduler scheduler) { }

	public override void Bind(CharacterView view) { }

	public override void Dispose() { }

	public override void Tick(float deltaTime) { }

	public override void Unbind() { }

}

