namespace Client.Common;

public static class UnityStreamingAssetsLoader
{
	[CompilerGenerated]
	private struct <DeserializeAsync>d__6 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder<T> <>t__builder; //Field offset: 0x0
		public ReadOnly<Byte> data; //Field offset: 0x0
		public bool compressed; //Field offset: 0x0
		private ReturnToSynchronizationContext <>7__wrap1; //Field offset: 0x0
		private object <>7__wrap2; //Field offset: 0x0
		private int <>7__wrap3; //Field offset: 0x0
		private T <>7__wrap4; //Field offset: 0x0
		private Awaiter <>u__1; //Field offset: 0x0
		private Awaiter <>u__2; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <Load>d__3 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder<T> <>t__builder; //Field offset: 0x0
		public string fileName; //Field offset: 0x0
		public bool compressed; //Field offset: 0x0
		private AutoScope <_>5__2; //Field offset: 0x0
		private string <path>5__3; //Field offset: 0x0
		private UnityWebRequest <request>5__4; //Field offset: 0x0
		private UnityWebRequestAsyncOperationAwaiter <>u__1; //Field offset: 0x0
		private Awaiter<T> <>u__2; //Field offset: 0x0
		private NativeArray<Byte> <dst>5__5; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <LoadFile>d__7 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder<ValueTuple`2<String, Boolean>> <>t__builder; //Field offset: 0x8
		public string fileName; //Field offset: 0x28
		private AutoScope <_>5__2; //Field offset: 0x30
		private string <path>5__3; //Field offset: 0x48
		private bool <fileIsFound>5__4; //Field offset: 0x50
		private UnityWebRequest <request>5__5; //Field offset: 0x58
		private UnityWebRequestAsyncOperationAwaiter <>u__1; //Field offset: 0x60

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <LoadTextAsync>d__4 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder<String> <>t__builder; //Field offset: 0x8
		public string fileName; //Field offset: 0x20
		private AutoScope <_>5__2; //Field offset: 0x28
		private string <path>5__3; //Field offset: 0x40
		private UnityWebRequest <request>5__4; //Field offset: 0x48
		private UnityWebRequestAsyncOperationAwaiter <>u__1; //Field offset: 0x50
		private TaskAwaiter<String> <>u__2; //Field offset: 0x60

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity LoadActivity; //Field offset: 0x0

	private static UnityStreamingAssetsLoader() { }

	public static void CopyToStream(string fileName, Stream destinationStream) { }

	private static T Deserialize(ReadOnlySpan<Byte> data, bool compressed) { }

	[AsyncStateMachine(typeof(<DeserializeAsync>d__6`1))]
	private static UniTask<T> DeserializeAsync(ReadOnly<Byte> data, bool compressed) { }

	[AsyncStateMachine(typeof(<Load>d__3`1))]
	public static UniTask<T> Load(string fileName, bool compressed = false) { }

	[AsyncStateMachine(typeof(<LoadFile>d__7))]
	internal static UniTask<ValueTuple`2<String, Boolean>> LoadFile(string fileName) { }

	[AsyncStateMachine(typeof(<LoadTextAsync>d__4))]
	public static UniTask<String> LoadTextAsync(string fileName) { }

	private static void WriteNativeArray(ReadOnly<Byte> array, Stream stream) { }

}

