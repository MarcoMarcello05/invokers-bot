namespace Client.Authentication;

public class ExternalAccountsService
{
	[CompilerGenerated]
	private struct <>c__DisplayClass10_0
	{
		public List<PlayerExternalAccount> linkedAccounts; //Field offset: 0x0

	}

	[CompilerGenerated]
	private struct <GetExternalAccounts>d__5 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncTaskMethodBuilder<List`1<PlayerExternalAccount>> <>t__builder; //Field offset: 0x8
		public ExternalAccountsService <>4__this; //Field offset: 0x20
		public bool forceRefresh; //Field offset: 0x28
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private TaskAwaiter<PlayerExternalAccountsResponse> <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <LoadLinkedExternalAccounts>d__8 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder<List`1<PlayerExternalAccount>> <>t__builder; //Field offset: 0x8
		public ExternalAccountsService <>4__this; //Field offset: 0x30
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private List<PlayerExternalAccount> <linkedExternalAccounts>5__2; //Field offset: 0x38
		private ValueTaskAwaiter <>u__1; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <SaveLinkedExternalAccounts>d__9 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public ExternalAccountsService <>4__this; //Field offset: 0x28
		public List<PlayerExternalAccount> linkResponseAccounts; //Field offset: 0x30
		private ValueTaskAwaiter <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <UpdateExternalLinkStatus>d__10 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public List<PlayerExternalAccount> linkedAccounts; //Field offset: 0x28
		public ExternalAccountsService <>4__this; //Field offset: 0x30
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		private ValueTaskAwaiter<IEventData[]> <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly ChoreographManager _choreographManager; //Field offset: 0x10
	private readonly IClientKeyValueStore _keyValueStore; //Field offset: 0x18
	private readonly ILogger _logger; //Field offset: 0x20

	public ExternalAccountsService(ChoreographManager choreographManager, IClientKeyValueStore keyValueStore, ILogger logger) { }

	[CompilerGenerated]
	internal static ExternalLinkStatus <UpdateExternalLinkStatus>g__GetLinkStatus|10_0(ref <>c__DisplayClass10_0 unnamed_param_0) { }

	public string BuildLinkedAccountsReport() { }

	[AsyncStateMachine(typeof(<GetExternalAccounts>d__5))]
	public Task<List`1<PlayerExternalAccount>> GetExternalAccounts(bool forceRefresh = false) { }

	public static bool HasAnySocialAccount(IReadOnlyCollection<PlayerExternalAccount> accounts) { }

	[AsyncStateMachine(typeof(<LoadLinkedExternalAccounts>d__8))]
	public ValueTask<List`1<PlayerExternalAccount>> LoadLinkedExternalAccounts() { }

	public void ResetLocalCache() { }

	[AsyncStateMachine(typeof(<SaveLinkedExternalAccounts>d__9))]
	public ValueTask SaveLinkedExternalAccounts(List<PlayerExternalAccount> linkResponseAccounts) { }

	[AsyncStateMachine(typeof(<UpdateExternalLinkStatus>d__10))]
	private ValueTask UpdateExternalLinkStatus(List<PlayerExternalAccount> linkedAccounts) { }

}

