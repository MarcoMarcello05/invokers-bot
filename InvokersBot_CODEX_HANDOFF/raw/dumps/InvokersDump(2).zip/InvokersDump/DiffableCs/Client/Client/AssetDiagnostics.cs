namespace Client;

[Nullable(0)]
[NullableContext(1)]
public sealed class AssetDiagnostics
{
	[Nullable(0)]
	internal sealed class DiagnosticOwner
	{
		[CompilerGenerated]
		private readonly string <Label>k__BackingField; //Field offset: 0x10
		[CompilerGenerated]
		[Nullable(2)]
		private readonly string <DiagnosticScopeTag>k__BackingField; //Field offset: 0x18
		[CompilerGenerated]
		private readonly double <RegisteredAt>k__BackingField; //Field offset: 0x20
		[CompilerGenerated]
		private bool <IsActive>k__BackingField; //Field offset: 0x28

		[Nullable(2)]
		public string DiagnosticScopeTag
		{
			[CompilerGenerated]
			[NullableContext(2)]
			 get { } //Length: 8
		}

		public bool IsActive
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public string Label
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		public double RegisteredAt
		{
			[CompilerGenerated]
			 get { } //Length: 8
		}

		public DiagnosticOwner(string label, string diagnosticScopeTag = null) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public string get_DiagnosticScopeTag() { }

		[CompilerGenerated]
		public bool get_IsActive() { }

		[CompilerGenerated]
		public string get_Label() { }

		[CompilerGenerated]
		public double get_RegisteredAt() { }

		[CompilerGenerated]
		public void set_IsActive(bool value) { }

	}

	[CompilerGenerated]
	private string <AssetTypeName>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly Dictionary<Int32, DiagnosticOwner> <Owners>k__BackingField; //Field offset: 0x18
	public int NextOwnerId; //Field offset: 0x20
	[CompilerGenerated]
	[Nullable(2)]
	private IAssetLoadingTask <AssetLoadingTask>k__BackingField; //Field offset: 0x28

	[Nullable(2)]
	public IAssetLoadingTask AssetLoadingTask
	{
		[CompilerGenerated]
		[NullableContext(2)]
		 get { } //Length: 8
		[CompilerGenerated]
		[NullableContext(2)]
		 set { } //Length: 8
	}

	public string AssetTypeName
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public Dictionary<Int32, DiagnosticOwner> Owners
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public AssetDiagnostics() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public IAssetLoadingTask get_AssetLoadingTask() { }

	[CompilerGenerated]
	public string get_AssetTypeName() { }

	[CompilerGenerated]
	public Dictionary<Int32, DiagnosticOwner> get_Owners() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public void set_AssetLoadingTask(IAssetLoadingTask value) { }

	[CompilerGenerated]
	public void set_AssetTypeName(string value) { }

}

