namespace Client.CharacterControllers;

public struct HealthBarState
{
	public float HealthRatio; //Field offset: 0x0
	public float ShieldRatio; //Field offset: 0x4
	public float DestroyedRatio; //Field offset: 0x8
	public int TotalMaximum; //Field offset: 0xC

}

