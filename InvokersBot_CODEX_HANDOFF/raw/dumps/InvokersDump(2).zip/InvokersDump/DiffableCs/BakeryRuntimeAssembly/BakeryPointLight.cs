//Type is in global namespace

[DisallowMultipleComponent]
[ExecuteInEditMode]
[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Point_Light")]
public class BakeryPointLight : MonoBehaviour
{
	internal enum Direction : int
	{
		NegativeY = 0,
		PositiveZ = 1,
	}

	internal enum ftLightProjectionMode : int
	{
		Omni = 0,
		Cookie = 1,
		Cubemap = 2,
		IES = 3,
		Cone = 4,
	}

	private const float GIZMO_SCALE = 0,01; //Field offset: 0x0
	private const float GIZMO_MAXSIZE = 0,1; //Field offset: 0x0
	public static int lightsChanged; //Field offset: 0x0
	private static GameObject objShownError; //Field offset: 0x8
	public int UID; //Field offset: 0x20
	public Color color; //Field offset: 0x24
	public float intensity; //Field offset: 0x34
	public float shadowSpread; //Field offset: 0x38
	public float cutoff; //Field offset: 0x3C
	public bool realisticFalloff; //Field offset: 0x40
	public bool legacySampling; //Field offset: 0x41
	public int samples; //Field offset: 0x44
	public ftLightProjectionMode projMode; //Field offset: 0x48
	public Texture2D cookie; //Field offset: 0x50
	public float angle; //Field offset: 0x58
	public float innerAngle; //Field offset: 0x5C
	public Cubemap cubemap; //Field offset: 0x60
	public object iesFile; //Field offset: 0x68
	public int bitmask; //Field offset: 0x70
	public bool bakeToIndirect; //Field offset: 0x74
	public bool shadowmask; //Field offset: 0x75
	public bool shadowmaskFalloff; //Field offset: 0x76
	public float indirectIntensity; //Field offset: 0x78
	public float falloffMinRadius; //Field offset: 0x7C
	public int shadowmaskGroupID; //Field offset: 0x80
	public bool correctCookieDistortion; //Field offset: 0x84
	public Direction directionMode; //Field offset: 0x88
	public int maskChannel; //Field offset: 0x8C

	public BakeryPointLight() { }

}

