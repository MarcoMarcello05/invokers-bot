namespace Client.Configuration;

[Extension]
public static class IConfigurationRootExtensions
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<String, String> <>9__4_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal string <GetAllKeys>b__4_0(string k) { }

	}


	[Extension]
	public static IEnumerable<String> GetAllKeys(IConfigurationRoot root) { }

	private static PlayerPrefsConfigurationProvider PlayerPrefs(IConfigurationRoot root) { }

	[Extension]
	public static void ResetPlayerPrefsSection(IConfigurationRoot root, string prefix) { }

	[Extension]
	public static void SetToPlayerPrefs(IConfigurationRoot root, string key, string value) { }

	[Extension]
	public static void SetToPlayerPrefs(IConfigurationRoot root, IDictionary<String, String> values) { }

}

