namespace AppleAuth;

public class AppleAuthManager : IAppleAuthManager
{

	private static AppleAuthManager() { }

	public AppleAuthManager(IPayloadDeserializer payloadDeserializer) { }

	public override void LoginWithAppleId(AppleAuthLoginArgs loginArgs, Action<ICredential> successCallback, Action<IAppleError> errorCallback) { }

	public override void Update() { }

}

