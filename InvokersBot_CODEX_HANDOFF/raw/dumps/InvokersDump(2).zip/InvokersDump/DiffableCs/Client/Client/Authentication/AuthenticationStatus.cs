namespace Client.Authentication;

public enum AuthenticationStatus : int
{
	Unknown = 0,
	Success = 1,
	UserCancelled = 3,
	UserFault = 100,
	DeveloperFault = 200,
	SystemFault = 300,
	Failure = 999,
}

