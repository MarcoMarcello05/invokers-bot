//Type is in global namespace

public class AutoHide : MonoBehaviour
{

	public AutoHide() { }

	private void Start() { }

}

