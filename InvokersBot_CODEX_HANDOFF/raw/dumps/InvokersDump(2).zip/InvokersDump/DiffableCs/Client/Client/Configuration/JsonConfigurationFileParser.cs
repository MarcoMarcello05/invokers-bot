namespace Client.Configuration;

public sealed class JsonConfigurationFileParser
{
	private const string KeyDelimiter = ":"; //Field offset: 0x0
	private readonly Dictionary<String, String> _data; //Field offset: 0x10
	private readonly Stack<String> _paths; //Field offset: 0x18

	private JsonConfigurationFileParser() { }

	private void EnterContext(string context) { }

	private void ExitContext() { }

	public static IDictionary<String, String> Parse(Stream input) { }

	private Dictionary<String, String> ParseStream(Stream input) { }

	private void SetNullIfElementIsEmpty(bool isEmpty) { }

	private void VisitArrayElement(JsonElement element) { }

	private void VisitObjectElement(JsonElement element) { }

	private void VisitValue(JsonElement value) { }

}

