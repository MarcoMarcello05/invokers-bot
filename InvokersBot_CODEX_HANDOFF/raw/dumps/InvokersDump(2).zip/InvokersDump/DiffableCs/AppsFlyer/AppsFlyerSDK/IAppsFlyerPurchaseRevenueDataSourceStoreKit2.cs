namespace AppsFlyerSDK;

public interface IAppsFlyerPurchaseRevenueDataSourceStoreKit2
{

}

