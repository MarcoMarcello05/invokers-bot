namespace Client.Authentication.ExternalAuth;

public interface IExternalAuthManager
{

	public ValueTask<AuthenticationParameters> AcquireParametersAsync(ExternalLoginProvider provider, ExternalAuthMode mode) { }

	public ValueTask<ExternalAuthResult> AuthenticateAsync(ExternalLoginProvider provider, ExternalAuthMode mode, CancellationToken ct = null) { }

	[NullableContext(2)]
	public string GetCurrentUserName(ExternalLoginProvider provider) { }

	public bool IsAvailable(ExternalLoginProvider provider) { }

}

