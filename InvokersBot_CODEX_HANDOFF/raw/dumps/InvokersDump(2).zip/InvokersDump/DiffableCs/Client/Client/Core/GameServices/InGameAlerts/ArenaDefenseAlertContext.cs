namespace Client.Core.GameServices.InGameAlerts;

public sealed class ArenaDefenseAlertContext : IAlertContext, IEquatable<ArenaDefenseAlertContext>
{
	[CompilerGenerated]
	private readonly ArenaOpponent <Opponent>k__BackingField; //Field offset: 0x10
	private readonly StringBuilder _sb; //Field offset: 0x18

	[CompilerGenerated]
	[Nullable(1)]
	private Type EqualityContract
	{
		[CompilerGenerated]
		[NullableContext(1)]
		private get { } //Length: 96
	}

	public ArenaOpponent Opponent
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public ArenaDefenseAlertContext(ArenaOpponent Opponent) { }

	[CompilerGenerated]
	private ArenaDefenseAlertContext(ArenaDefenseAlertContext original) { }

	[CompilerGenerated]
	[NullableContext(1)]
	public ArenaDefenseAlertContext <Clone>$() { }

	[CompilerGenerated]
	public void Deconstruct(out ArenaOpponent Opponent) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public override bool Equals(ArenaDefenseAlertContext other) { }

	[CompilerGenerated]
	[NullableContext(1)]
	private Type get_EqualityContract() { }

	[CompilerGenerated]
	public ArenaOpponent get_Opponent() { }

	public string GetArenaBiContent() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Equality(ArenaDefenseAlertContext left, ArenaDefenseAlertContext right) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Inequality(ArenaDefenseAlertContext left, ArenaDefenseAlertContext right) { }

	[CompilerGenerated]
	[NullableContext(1)]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	public void set_Opponent(ArenaOpponent value) { }

	public virtual string ToString() { }

}

