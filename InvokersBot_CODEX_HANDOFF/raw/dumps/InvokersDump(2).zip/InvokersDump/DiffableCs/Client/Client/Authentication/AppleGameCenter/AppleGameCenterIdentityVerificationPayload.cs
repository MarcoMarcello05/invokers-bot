namespace Client.Authentication.AppleGameCenter;

[Nullable(0)]
[NullableContext(1)]
public sealed class AppleGameCenterIdentityVerificationPayload : IEquatable<AppleGameCenterIdentityVerificationPayload>
{
	[CompilerGenerated]
	private readonly string <BundleId>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly string <TeamPlayerId>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly string <PublicKeyUrl>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private readonly ulong <Timestamp>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private readonly string <SignatureBase64>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private readonly string <SaltBase64>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	[Nullable(2)]
	private readonly string <DisplayName>k__BackingField; //Field offset: 0x40

	public string BundleId
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	[Nullable(2)]
	public string DisplayName
	{
		[CompilerGenerated]
		[NullableContext(2)]
		 get { } //Length: 8
		[CompilerGenerated]
		[NullableContext(2)]
		 set { } //Length: 8
	}

	[CompilerGenerated]
	private Type EqualityContract
	{
		[CompilerGenerated]
		private get { } //Length: 96
	}

	public string PublicKeyUrl
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string SaltBase64
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string SignatureBase64
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string TeamPlayerId
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public ulong Timestamp
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public AppleGameCenterIdentityVerificationPayload(string BundleId, string TeamPlayerId, string PublicKeyUrl, ulong Timestamp, string SignatureBase64, string SaltBase64, string DisplayName) { }

	[CompilerGenerated]
	private AppleGameCenterIdentityVerificationPayload(AppleGameCenterIdentityVerificationPayload original) { }

	[CompilerGenerated]
	public AppleGameCenterIdentityVerificationPayload <Clone>$() { }

	[CompilerGenerated]
	public void Deconstruct(out string BundleId, out string TeamPlayerId, out string PublicKeyUrl, out ulong Timestamp, out string SignatureBase64, out string SaltBase64, out string DisplayName) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public override bool Equals(AppleGameCenterIdentityVerificationPayload other) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	public string get_BundleId() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public string get_DisplayName() { }

	[CompilerGenerated]
	private Type get_EqualityContract() { }

	[CompilerGenerated]
	public string get_PublicKeyUrl() { }

	[CompilerGenerated]
	public string get_SaltBase64() { }

	[CompilerGenerated]
	public string get_SignatureBase64() { }

	[CompilerGenerated]
	public string get_TeamPlayerId() { }

	[CompilerGenerated]
	public ulong get_Timestamp() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Equality(AppleGameCenterIdentityVerificationPayload left, AppleGameCenterIdentityVerificationPayload right) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Inequality(AppleGameCenterIdentityVerificationPayload left, AppleGameCenterIdentityVerificationPayload right) { }

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	public void set_BundleId(string value) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public void set_DisplayName(string value) { }

	[CompilerGenerated]
	public void set_PublicKeyUrl(string value) { }

	[CompilerGenerated]
	public void set_SaltBase64(string value) { }

	[CompilerGenerated]
	public void set_SignatureBase64(string value) { }

	[CompilerGenerated]
	public void set_TeamPlayerId(string value) { }

	[CompilerGenerated]
	public void set_Timestamp(ulong value) { }

	[CompilerGenerated]
	public virtual string ToString() { }

}

