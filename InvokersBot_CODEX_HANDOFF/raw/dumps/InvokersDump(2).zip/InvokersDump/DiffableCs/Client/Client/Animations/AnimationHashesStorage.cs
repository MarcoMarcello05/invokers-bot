namespace Client.Animations;

public static class AnimationHashesStorage
{
	public static readonly int Intro; //Field offset: 0x0
	public static readonly int PlayIntro; //Field offset: 0x4
	public static readonly int Reveal; //Field offset: 0x8
	public static readonly int FTUEIntro; //Field offset: 0xC
	public static readonly int Idle; //Field offset: 0x10
	public static readonly int IdleIn; //Field offset: 0x14
	public static readonly int IdleBreak; //Field offset: 0x18
	public static readonly int Move; //Field offset: 0x1C
	public static readonly int Walk; //Field offset: 0x20
	public static readonly int Run; //Field offset: 0x24
	public static readonly int Death; //Field offset: 0x28
	public static readonly int Stun; //Field offset: 0x2C
	public static readonly int Shock; //Field offset: 0x30
	public static readonly int Sleep; //Field offset: 0x34
	public static readonly int Freeze; //Field offset: 0x38
	public static readonly int Paralyze; //Field offset: 0x3C
	public static readonly int LaunchPhase; //Field offset: 0x40
	public static readonly int InteractMid; //Field offset: 0x44
	public static readonly int InteractBot; //Field offset: 0x48
	public static readonly int EffectTrigger; //Field offset: 0x4C
	public static readonly int Morph; //Field offset: 0x50
	public static readonly int UnMorph; //Field offset: 0x54
	public static readonly int Skill; //Field offset: 0x58
	public static readonly int SkillPhase; //Field offset: 0x5C
	public static readonly int ComboAttack; //Field offset: 0x60
	public static readonly int Dash; //Field offset: 0x64
	public static readonly int TurnBlend; //Field offset: 0x68
	public static readonly int IdleTeamAnimationHash; //Field offset: 0x6C
	public static readonly int IdleHomeAnimationHash; //Field offset: 0x70
	public static readonly int DisableIdleBreakAnimationHash; //Field offset: 0x74
	public static readonly int StartComboHash; //Field offset: 0x78
	public static readonly int Flinch; //Field offset: 0x7C

	private static AnimationHashesStorage() { }

}

