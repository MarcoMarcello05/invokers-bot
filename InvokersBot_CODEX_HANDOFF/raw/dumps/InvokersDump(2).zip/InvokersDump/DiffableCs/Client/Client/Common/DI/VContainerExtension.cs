namespace Client.Common.DI;

[Extension]
public static class VContainerExtension
{

	[Extension]
	public static IContainerBuilder AutoRegisterInterfaceTypesFromAssembly(IContainerBuilder builder, Type[] interfaceType, Assembly assembly, Lifetime lifetime = 1) { }

}

