namespace Client.Authentication.ExternalAuth;

[Nullable(0)]
[NullableContext(1)]
public sealed class ExternalAuthManager : IExternalAuthManager
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass11_0
	{
		[Nullable(0)]
		public ExternalAuthManager <>4__this; //Field offset: 0x10
		[Nullable(0)]
		public CancellationTokenSource cancellationTokenSource; //Field offset: 0x18

		public <>c__DisplayClass11_0() { }

		[NullableContext(0)]
		internal void <CreateGoogleBrowserAuthPopup>b__0(StaticModalPopupController controller, StaticModalPopup view) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass11_1
	{
		private struct <<CreateGoogleBrowserAuthPopup>b__1>d : IAsyncStateMachine
		{
			public int <>1__state; //Field offset: 0x0
			public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
			[Nullable(0)]
			public <>c__DisplayClass11_1 <>4__this; //Field offset: 0x28
			private Awaiter <>u__1; //Field offset: 0x30

			private override void MoveNext() { }

			[DebuggerHidden]
			private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

		}

		[Nullable(0)]
		public StaticModalPopupController controller; //Field offset: 0x10
		[Nullable(0)]
		public <>c__DisplayClass11_0 CS$<>8__locals1; //Field offset: 0x18

		public <>c__DisplayClass11_1() { }

		[AsyncStateMachine(typeof(<<CreateGoogleBrowserAuthPopup>b__1>d))]
		internal ValueTask <CreateGoogleBrowserAuthPopup>b__1() { }

	}

	[CompilerGenerated]
	private struct <AcquireParametersAsync>d__7 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncValueTaskMethodBuilder<AuthenticationParameters> <>t__builder; //Field offset: 0x8
		public ExternalLoginProvider provider; //Field offset: 0x30
		[Nullable(0)]
		public ExternalAuthManager <>4__this; //Field offset: 0x38
		public ExternalAuthMode mode; //Field offset: 0x40
		[Nullable(0)]
		private CancellationTokenSource <cancellationTokenSource>5__2; //Field offset: 0x48
		[Nullable(0)]
		private StaticModalPopupController <popupController>5__3; //Field offset: 0x50
		private ExternalLoginProvider <>7__wrap3; //Field offset: 0x58
		[Nullable(0)]
		private ValueTaskAwaiter<ExternalAuthResult> <>u__1; //Field offset: 0x60
		[Nullable(0)]
		private object <>7__wrap4; //Field offset: 0x88
		private int <>7__wrap5; //Field offset: 0x90
		[Nullable(0)]
		private AuthenticationParameters <>7__wrap6; //Field offset: 0x98
		private Awaiter <>u__2; //Field offset: 0xA0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	public static Nullable<DebugAuthOutcome> DebugForcedOutcome; //Field offset: 0x0
	private readonly Dictionary<ExternalLoginProvider, IExternalAuthProvider> _providers; //Field offset: 0x10
	private readonly StaticModalPopupFactory _modalPopupFactory; //Field offset: 0x18
	private readonly ButtonCommandBuilder _buttonCommandBuilder; //Field offset: 0x20

	public ExternalAuthManager(IEnumerable<IExternalAuthProvider> providers, StaticModalPopupFactory modalPopupFactory, ButtonCommandBuilder buttonCommandBuilder) { }

	[AsyncStateMachine(typeof(<AcquireParametersAsync>d__7))]
	public override ValueTask<AuthenticationParameters> AcquireParametersAsync(ExternalLoginProvider provider, ExternalAuthMode mode) { }

	[NullableContext(0)]
	public override ValueTask<ExternalAuthResult> AuthenticateAsync(ExternalLoginProvider provider, ExternalAuthMode mode, CancellationToken ct = null) { }

	private StaticModalPopupController CreateGoogleBrowserAuthPopup(CancellationTokenSource cancellationTokenSource) { }

	[NullableContext(2)]
	public override string GetCurrentUserName(ExternalLoginProvider provider) { }

	public override bool IsAvailable(ExternalLoginProvider provider) { }

	private static bool RequiresGoogleBrowserAuthPopup(ExternalLoginProvider provider) { }

	[NullableContext(2)]
	private static AuthenticationParameters Unwrap(ExternalLoginProvider provider, ExternalAuthResult result) { }

}

