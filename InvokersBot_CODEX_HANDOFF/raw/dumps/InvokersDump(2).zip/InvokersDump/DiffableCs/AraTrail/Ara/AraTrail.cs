namespace Ara;

[ExecuteInEditMode]
[RequireComponent(typeof(MeshRenderer))]
[RequireComponent(typeof(MeshFilter))]
public class AraTrail : MonoBehaviour
{
	internal struct CurveFrame
	{
		public Vector3 position; //Field offset: 0x0
		public Vector3 normal; //Field offset: 0xC
		public Vector3 bitangent; //Field offset: 0x18
		public Vector3 tangent; //Field offset: 0x24

		public CurveFrame(Vector3 position, Vector3 normal, Vector3 bitangent, Vector3 tangent) { }

		public Vector3 Transport(Vector3 newTangent, Vector3 newPosition) { }

	}

	internal struct Point
	{
		public Vector3 position; //Field offset: 0x0
		public Vector3 velocity; //Field offset: 0xC
		public Vector3 tangent; //Field offset: 0x18
		public Vector3 normal; //Field offset: 0x24
		public Color color; //Field offset: 0x30
		public float thickness; //Field offset: 0x40
		public float life; //Field offset: 0x44
		public float texcoord; //Field offset: 0x48
		public bool discontinuous; //Field offset: 0x4C

		public Point(Vector3 position, Vector3 velocity, Vector3 tangent, Vector3 normal, Color color, float thickness, float texcoord, float lifetime) { }

		public static float CatmullRom(float p0, float p1, float p2, float p3, float t) { }

	}

	internal enum TextureMode : int
	{
		Stretch = 0,
		Tile = 1,
		WorldTile = 2,
	}

	internal enum Timescale : int
	{
		Normal = 0,
		Unscaled = 1,
	}

	internal enum TrailAlignment : int
	{
		View = 0,
		Velocity = 1,
		Local = 2,
	}

	internal enum TrailSorting : int
	{
		OlderOnTop = 0,
		NewerOnTop = 1,
	}

	internal enum TrailSpace : int
	{
		World = 0,
		Self = 1,
		Custom = 2,
	}

	public const float epsilon = 1E-05; //Field offset: 0x0
	[Tooltip("Trail cross-section asset, determines the shape of the emitted trail. If no asset is specified, the trail will be a simple strip.")]
	public TrailSection section; //Field offset: 0x20
	[Tooltip("Whether to use world or local space to generate and simulate the trail.")]
	public TrailSpace space; //Field offset: 0x28
	[Tooltip("Custom space to use when generating and simulating the trail")]
	public Transform customSpace; //Field offset: 0x30
	[Tooltip("Whether to use regular time.")]
	public Timescale timescale; //Field offset: 0x38
	[Tooltip("How to align the trail geometry: facing the camera (view) of using the transform's rotation (local).")]
	public TrailAlignment alignment; //Field offset: 0x3C
	[Tooltip("Determines the order in which trail points will be rendered.")]
	public TrailSorting sorting; //Field offset: 0x40
	[Tooltip("Thickness multiplier, in meters.")]
	public float thickness; //Field offset: 0x44
	[Tooltip("Amount of smoothing iterations applied to the trail shape.")]
	public int smoothness; //Field offset: 0x48
	[Tooltip("Calculate accurate thickness at sharp corners.")]
	public bool highQualityCorners; //Field offset: 0x4C
	public int cornerRoundness; //Field offset: 0x50
	[FormerlySerializedAs("thicknessOverLenght")]
	[Tooltip("How should the thickness of the curve evolve over its lenght. The horizontal axis is normalized lenght (in the [0,1] range) and the vertical axis is a thickness multiplier.")]
	public AnimationCurve thicknessOverLength; //Field offset: 0x58
	[FormerlySerializedAs("colorOverLenght")]
	[Tooltip("How should vertex color evolve over the trail's length.")]
	public Gradient colorOverLength; //Field offset: 0x60
	[Tooltip("How should the thickness of the curve evolve with its lifetime. The horizontal axis is normalized lifetime (in the [0,1] range) and the vertical axis is a thickness multiplier.")]
	public AnimationCurve thicknessOverTime; //Field offset: 0x68
	[Tooltip("How should vertex color evolve over the trail's lifetime.")]
	public Gradient colorOverTime; //Field offset: 0x70
	public bool emit; //Field offset: 0x78
	[Tooltip("Initial thickness of trail points when they are first spawned.")]
	public float initialThickness; //Field offset: 0x7C
	[Tooltip("Initial color of trail points when they are first spawned.")]
	public Color initialColor; //Field offset: 0x80
	[Tooltip("Initial velocity of trail points when they are first spawned.")]
	public Vector3 initialVelocity; //Field offset: 0x90
	[Tooltip("Minimum amount of time (in seconds) that must pass before spawning a new point.")]
	public float timeInterval; //Field offset: 0x9C
	[Tooltip("Minimum distance (in meters) that must be left between consecutive points in the trail.")]
	public float minDistance; //Field offset: 0xA0
	[Tooltip("Duration of the trail (in seconds).")]
	public float time; //Field offset: 0xA4
	[Tooltip("Toggles trail physics.")]
	public bool enablePhysics; //Field offset: 0xA8
	[Tooltip("Amount of seconds pre-simulated before the trail appears. Useful when you want a trail to be already simulating when the game starts.")]
	public float warmup; //Field offset: 0xAC
	[Tooltip("Gravity affecting the trail.")]
	public Vector3 gravity; //Field offset: 0xB0
	[Tooltip("Amount of speed transferred from the transform to the trail. 0 means no velocity is transferred, 1 means 100% of the velocity is transferred.")]
	public float inertia; //Field offset: 0xBC
	[Tooltip("Amount of temporal smoothing applied to the velocity transferred from the transform to the trail.")]
	public float velocitySmoothing; //Field offset: 0xC0
	[Tooltip("Amount of damping applied to the trail's velocity. Larger values will slow down the trail more as time passes.")]
	public float damping; //Field offset: 0xC4
	public Material[] materials; //Field offset: 0xC8
	public ShadowCastingMode castShadows; //Field offset: 0xD0
	public bool receiveShadows; //Field offset: 0xD4
	public bool useLightProbes; //Field offset: 0xD5
	[Tooltip("Quad mapping will send the shader an extra coordinate for each vertex, that can be used to correct UV distortion using tex2Dproj.")]
	public bool quadMapping; //Field offset: 0xD6
	[Tooltip("How to apply the texture over the trail: stretch it all over its lenght, or tile it.")]
	public TextureMode textureMode; //Field offset: 0xD8
	[Tooltip("Defines how many times are U coords repeated across the length of the trail.")]
	public float uvFactor; //Field offset: 0xDC
	[Tooltip("Defines how many times are V coords repeated trough the width of the trail.")]
	public float uvWidthFactor; //Field offset: 0xE0
	[Tooltip("When the texture mode is set to 'Tile', defines where to begin tiling from: 0 means the start of the trail, 1 means the end.")]
	public float tileAnchor; //Field offset: 0xE4
	public bool clearOnDisable; //Field offset: 0xE8
	[CompilerGenerated]
	private Action onUpdatePoints; //Field offset: 0xF0
	[HideInInspector]
	public ElasticArray<Point> points; //Field offset: 0xF8
	private ElasticArray<Point> renderablePoints; //Field offset: 0x100
	private List<Int32> discontinuities; //Field offset: 0x108
	private GameObject _go; //Field offset: 0x110
	private Mesh mesh_; //Field offset: 0x118
	private MeshRenderer _meshRenderer; //Field offset: 0x120
	private MeshFilter _meshFilter; //Field offset: 0x128
	private Vector3 velocity; //Field offset: 0x130
	private Vector3 prevPosition; //Field offset: 0x13C
	private float accumTime; //Field offset: 0x148
	private List<Vector3> vertices; //Field offset: 0x150
	private List<Vector3> normals; //Field offset: 0x158
	private List<Vector4> tangents; //Field offset: 0x160
	private List<Vector4> uvs; //Field offset: 0x168
	private List<Color> vertColors; //Field offset: 0x170
	private List<Int32> tris; //Field offset: 0x178
	private Vector3 nextV; //Field offset: 0x180
	private Vector3 prevV; //Field offset: 0x18C
	private Vector3 vertex; //Field offset: 0x198
	private Vector3 normal; //Field offset: 0x1A4
	private Vector3 bitangent; //Field offset: 0x1B0
	private Vector4 tangent; //Field offset: 0x1BC
	private Vector4 texTangent; //Field offset: 0x1CC
	private Vector4 uv; //Field offset: 0x1DC
	private Color color; //Field offset: 0x1EC
	private bool _freezeTrailUpdate; //Field offset: 0x1FC

	public event Action onUpdatePoints
	{
		[CompilerGenerated]
		 add { } //Length: 156
		[CompilerGenerated]
		 remove { } //Length: 156
	}

	public float DeltaTime
	{
		 get { } //Length: 28
	}

	public bool Emit
	{
		 get { } //Length: 8
		 set { } //Length: 8
	}

	private float FixedDeltaTime
	{
		private get { } //Length: 28
	}

	public bool FreezeUpdate
	{
		 get { } //Length: 8
		 set { } //Length: 8
	}

	public Mesh mesh
	{
		 get { } //Length: 8
	}

	public Vector3 Velocity
	{
		 get { } //Length: 16
	}

	public Matrix4x4 worldToTrail
	{
		 get { } //Length: 260
	}

	public AraTrail() { }

	public void ActivateEmit() { }

	[CompilerGenerated]
	public void add_onUpdatePoints(Action value) { }

	private void AppendFlatTrail(Point[] data, ref CurveFrame frame, int i, int count, float sectionThickness, float vCoord, ref int va, ref int vb) { }

	private void AppendSection(Point[] data, ref CurveFrame frame, int i, int count, float sectionThickness, float vCoord) { }

	private void AttachToCameraRendering() { }

	public void Awake() { }

	[ContextMenu("Clear")]
	public void Clear() { }

	private void ClearMeshData() { }

	private void CommitMeshData() { }

	private void CreateMesh() { }

	public void DeactivateEmit() { }

	private void DetachFromCameraRendering() { }

	public void EmissionStep(float time) { }

	public void EmitPoint(Vector3 position, float lifetime) { }

	public void EmitPoint(Vector3 position) { }

	private void FixedUpdate() { }

	public float get_DeltaTime() { }

	public bool get_Emit() { }

	private float get_FixedDeltaTime() { }

	public bool get_FreezeUpdate() { }

	public Mesh get_mesh() { }

	public Vector3 get_Velocity() { }

	public Matrix4x4 get_worldToTrail() { }

	public float GetLenght(ElasticArray<Point> input) { }

	private ElasticArray<Point> GetRenderablePoints(int start, int end) { }

	private void GetRendererAndFilter() { }

	private CurveFrame InitializeCurveFrame(Vector3 point, Vector3 nextPoint) { }

	private void LateUpdate() { }

	private void OnDestroy() { }

	private void OnDisable() { }

	private void OnEnable() { }

	public void OnValidate() { }

	private void PhysicsStep(float timestep) { }

	[CompilerGenerated]
	public void remove_onUpdatePoints(Action value) { }

	private void RenderMesh(Camera cam) { }

	private void Reset() { }

	public void set_Emit(bool value) { }

	public void set_FreezeUpdate(bool value) { }

	public void SnapLastPointToTransform() { }

	public void UpdatePointsLifecycle(float time) { }

	private void UpdateRendererSettings() { }

	private void UpdateSegmentMesh(int start, int end, Vector3 localCamPosition) { }

	private void UpdateTrailMesh(ScriptableRenderContext ctx, Camera cam) { }

	private void UpdateTrailMesh(Camera cam) { }

	public void UpdateVelocity() { }

	private void Warmup() { }

}

