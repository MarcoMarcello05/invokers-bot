//Type is in global namespace

[RequireComponent(typeof(TextMeshProUGUI))]
[RequireComponent(typeof(LayoutElement))]
public class TMPReachBoundaries : MonoBehaviour
{
	[CompilerGenerated]
	private sealed class <CalculateNextFrame>d__9 : IEnumerator<Object>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private object <>2__current; //Field offset: 0x18
		public TMPReachBoundaries <>4__this; //Field offset: 0x20

		private override object System.Collections.Generic.IEnumerator<System.Object>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <CalculateNextFrame>d__9(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	public bool limitWidth; //Field offset: 0x20
	public float maxWidth; //Field offset: 0x24
	public bool limitHeight; //Field offset: 0x28
	public float maxHeight; //Field offset: 0x2C
	private TextMeshProUGUI _tmp; //Field offset: 0x30
	private LayoutElement _layoutElement; //Field offset: 0x38
	private RectTransform _rectTransform; //Field offset: 0x40

	public TMPReachBoundaries() { }

	private void Awake() { }

	[IteratorStateMachine(typeof(<CalculateNextFrame>d__9))]
	private IEnumerator CalculateNextFrame() { }

	private void OnEnable() { }

	[ContextMenu("Force Update Bounds")]
	public void UpdateBounds() { }

}

