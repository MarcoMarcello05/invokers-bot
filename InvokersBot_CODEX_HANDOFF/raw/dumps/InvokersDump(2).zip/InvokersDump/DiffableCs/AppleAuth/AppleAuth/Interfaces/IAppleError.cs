namespace AppleAuth.Interfaces;

public interface IAppleError
{

	public int Code
	{
		 get { } //Length: 0
	}

	public int get_Code() { }

}

