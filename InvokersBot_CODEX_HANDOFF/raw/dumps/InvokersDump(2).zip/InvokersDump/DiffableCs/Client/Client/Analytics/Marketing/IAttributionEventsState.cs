namespace Client.Analytics.Marketing;

[NullableContext(1)]
public interface IAttributionEventsState
{

	public bool HasEvent(string key) { }

	public void MarkSent(string key) { }

	public void Reset(string key) { }

}

