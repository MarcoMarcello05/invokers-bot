namespace Client.Configuration;

public enum EditorPlatformMemoryTier : int
{
	None = 0,
	LowMemory = 1,
	MediumMemory = 2,
	HighMemory = 3,
}

