namespace Client.Authentication.GooglePlayGames;

public enum GooglePlayGamesServerAuthCodeStatus : int
{
	Success = 0,
	InsufficientScopes = 1,
	EmptyCode = 2,
	Unavailable = 3,
	Unauthenticated = 4,
	Failed = 5,
}

