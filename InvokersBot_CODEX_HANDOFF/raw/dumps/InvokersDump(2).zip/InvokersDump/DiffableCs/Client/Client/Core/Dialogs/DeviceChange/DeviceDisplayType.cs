namespace Client.Core.Dialogs.DeviceChange;

public enum DeviceDisplayType : int
{
	Other = 0,
	Mobile = 1,
	Tablet = 2,
	Desktop = 3,
}

