namespace Client.Common.DI;

[Nullable(0)]
[NullableContext(1)]
public class ClientProviderPlayerActionMediator : IPlayerActionMediator
{
	private readonly IObjectResolver _resolver; //Field offset: 0x10
	private readonly ITimeProvider _timeProvider; //Field offset: 0x18
	private readonly Dictionary<Type, IPlayerActionExecutor> _executorsByActionType; //Field offset: 0x20

	public ClientProviderPlayerActionMediator(IObjectResolver resolver, IEnumerable<IPlayerActionExecutor> executors, ITimeProvider timeProvider) { }

	public override Result ExecuteAction(TAction action, bool useValidation = true, string actionId = null) { }

	public override IPlayerActionExecutor GetExecutor(Type actionType) { }

	public override IDeterministicActionHandler<TAction> GetHandler() { }

	public override IPlayerActionValidator<TAction> GetValidator() { }

}

