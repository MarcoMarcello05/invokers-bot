namespace Client.Core;

public class BootstrapScope : LifetimeScope
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<IObjectResolver, BackgroundMultiBattleSessionRunner> <>9__9_1; //Field offset: 0x8
		public static Func<IObjectResolver, Func`1<IErrorDialogBuilder>> <>9__9_2; //Field offset: 0x10
		public static Func<IObjectResolver, BlockingContext> <>9__9_3; //Field offset: 0x18
		public static Func<IObjectResolver, FakeStoreTransactionsStorage> <>9__9_4; //Field offset: 0x20
		public static Func<IObjectResolver, FakeStoreSettingsStorage> <>9__9_5; //Field offset: 0x28
		public static Func<IObjectResolver, Func`1<RewardReceivedPopup>> <>9__15_0; //Field offset: 0x30
		public static Func<IObjectResolver, Func`1<NotEnoughResourcesPopupController>> <>9__15_1; //Field offset: 0x38
		public static Func<IObjectResolver, Func`1<NotEnoughEnergyPopupController>> <>9__15_2; //Field offset: 0x40
		public static Func<IObjectResolver, Func`1<CollectionLimitReachedPopupController>> <>9__15_3; //Field offset: 0x48
		public static Func<IObjectResolver, Func`1<PurchaseResourceDialogController>> <>9__15_4; //Field offset: 0x50
		public static Func<IObjectResolver, Func`1<IBoostersDialogController>> <>9__15_5; //Field offset: 0x58
		public static Func<IObjectResolver, Func`1<SoftUpdateDialogController>> <>9__15_6; //Field offset: 0x60
		public static Func<IObjectResolver, Func`1<HardUpdateDialogController>> <>9__15_7; //Field offset: 0x68
		public static Func<IObjectResolver, Func`1<ILocalNotificationPermitPopup>> <>9__15_8; //Field offset: 0x70

		private static <>c() { }

		public <>c() { }

		internal BackgroundMultiBattleSessionRunner <Configure>b__9_1(IObjectResolver c) { }

		internal Func<IErrorDialogBuilder> <Configure>b__9_2(IObjectResolver resolver) { }

		internal BlockingContext <Configure>b__9_3(IObjectResolver x) { }

		internal FakeStoreTransactionsStorage <Configure>b__9_4(IObjectResolver _) { }

		internal FakeStoreSettingsStorage <Configure>b__9_5(IObjectResolver _) { }

		internal Func<RewardReceivedPopup> <RegisterScreens>b__15_0(IObjectResolver resolver) { }

		internal Func<NotEnoughResourcesPopupController> <RegisterScreens>b__15_1(IObjectResolver resolver) { }

		internal Func<NotEnoughEnergyPopupController> <RegisterScreens>b__15_2(IObjectResolver resolver) { }

		internal Func<CollectionLimitReachedPopupController> <RegisterScreens>b__15_3(IObjectResolver resolver) { }

		internal Func<PurchaseResourceDialogController> <RegisterScreens>b__15_4(IObjectResolver resolver) { }

		internal Func<IBoostersDialogController> <RegisterScreens>b__15_5(IObjectResolver resolver) { }

		internal Func<SoftUpdateDialogController> <RegisterScreens>b__15_6(IObjectResolver resolver) { }

		internal Func<HardUpdateDialogController> <RegisterScreens>b__15_7(IObjectResolver resolver) { }

		internal Func<ILocalNotificationPermitPopup> <RegisterScreens>b__15_8(IObjectResolver resolver) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass9_0
	{
		public IAppEnvironmentProvider appEnvironmentProvider; //Field offset: 0x10

		public <>c__DisplayClass9_0() { }

		internal IAppEnvironmentProvider <Configure>b__0(IObjectResolver _) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass9_1
	{
		public IObjectResolver c; //Field offset: 0x10

		public <>c__DisplayClass9_1() { }

		[NullableContext(2)]
		internal ClientSession <Configure>b__6() { }

		[NullableContext(2)]
		internal BattleMemory <Configure>b__7() { }

	}

	private readonly ILogger _logger; //Field offset: 0x68
	[SerializeField]
	private StagingContainer _stagingContainer; //Field offset: 0x70
	[SerializeField]
	private UISystem _uiSystem; //Field offset: 0x78
	[SerializeField]
	private GlobalCamera _globalCamera; //Field offset: 0x80
	[SerializeField]
	private Bootstrap _bootstrap; //Field offset: 0x88
	private bool _offlineMode; //Field offset: 0x90
	private GameLifeCycleMonitorService _lifeCycleMonitorService; //Field offset: 0x98
	private IDisposable _firebaseActivity; //Field offset: 0xA0

	public BootstrapScope() { }

	protected virtual void Configure(IContainerBuilder builder) { }

	private void OnApplicationFocus(bool hasFocus) { }

	private void OnApplicationPause(bool paused) { }

	private void OnApplicationQuit() { }

	private void OnContainerCreated(IObjectResolver resolver) { }

	protected virtual void OnDestroy() { }

	private void OnValidate() { }

	private static void RegisterPools(IContainerBuilder builder) { }

	private void RegisterScreens(IContainerBuilder builder) { }

	private void RegisterServices(IContainerBuilder builder) { }

	private void RegisterShop(IContainerBuilder builder) { }

	private static void RegisterSpecialEventsPopupsFactories(IContainerBuilder builder) { }

	private static void RegisterStates(IContainerBuilder builder) { }

}

