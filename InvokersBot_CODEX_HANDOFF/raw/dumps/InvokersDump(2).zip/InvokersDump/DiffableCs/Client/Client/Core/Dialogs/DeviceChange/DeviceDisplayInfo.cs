namespace Client.Core.Dialogs.DeviceChange;

[Nullable(0)]
[NullableContext(2)]
public struct DeviceDisplayInfo : IEquatable<DeviceDisplayInfo>
{
	public static readonly DeviceDisplayInfo Unknown; //Field offset: 0x0
	[CompilerGenerated]
	private readonly DeviceDisplayType <Type>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private readonly string <Name>k__BackingField; //Field offset: 0x8

	public string Name
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public DeviceDisplayType Type
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	private static DeviceDisplayInfo() { }

	public DeviceDisplayInfo(DeviceDisplayType Type, string Name) { }

	[CompilerGenerated]
	public void Deconstruct(out DeviceDisplayType Type, out string Name) { }

	[CompilerGenerated]
	[NullableContext(0)]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	public override bool Equals(DeviceDisplayInfo other) { }

	[CompilerGenerated]
	public string get_Name() { }

	[CompilerGenerated]
	public DeviceDisplayType get_Type() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	public static bool op_Equality(DeviceDisplayInfo left, DeviceDisplayInfo right) { }

	[CompilerGenerated]
	public static bool op_Inequality(DeviceDisplayInfo left, DeviceDisplayInfo right) { }

	[CompilerGenerated]
	[NullableContext(0)]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	public void set_Name(string value) { }

	[CompilerGenerated]
	public void set_Type(DeviceDisplayType value) { }

	[CompilerGenerated]
	[NullableContext(0)]
	public virtual string ToString() { }

}

