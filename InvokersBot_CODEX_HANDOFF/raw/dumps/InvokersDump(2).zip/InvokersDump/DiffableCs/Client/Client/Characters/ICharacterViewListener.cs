namespace Client.Characters;

public interface ICharacterViewListener
{

	public void OnAnimationEvent(CharacterAnimationEvent animationEvent) { }

	public void OnIdleAnimationStarted() { }

	public void OnIdleBreak(int idleBreakIndex) { }

	public void OnVfxEvent(string vfxId) { }

	public void OnViewDisabled() { }

	public void OnViewEnabled() { }

}

