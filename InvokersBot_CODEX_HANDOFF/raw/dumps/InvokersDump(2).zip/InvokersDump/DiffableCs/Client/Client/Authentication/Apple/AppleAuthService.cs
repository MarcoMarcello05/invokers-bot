namespace Client.Authentication.Apple;

[UsedAsInjection]
public class AppleAuthService : IAppleAuthService
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass2_0
	{
		public AppleAuthService <>4__this; //Field offset: 0x10
		public UniTaskCompletionSource<IAppleIDCredential> tcs; //Field offset: 0x18

		public <>c__DisplayClass2_0() { }

		internal void <Authenticate>b__0(Unit _) { }

		internal void <Authenticate>b__1(ICredential credential) { }

		internal void <Authenticate>b__2(IAppleError error) { }

	}

	[CompilerGenerated]
	private struct <Authenticate>d__2 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder<String> <>t__builder; //Field offset: 0x8
		public AppleAuthService <>4__this; //Field offset: 0x30
		public AppleAuthLoginArgs loginArgs; //Field offset: 0x38
		private IDisposable <updateLoop>5__2; //Field offset: 0x50
		private Awaiter<IAppleIDCredential> <>u__1; //Field offset: 0x58

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IAppleAuthManager _appleAuthManager; //Field offset: 0x10

	public AppleAuthService() { }

	[AsyncStateMachine(typeof(<Authenticate>d__2))]
	public override ValueTask<String> Authenticate(AppleAuthLoginArgs loginArgs) { }

}

