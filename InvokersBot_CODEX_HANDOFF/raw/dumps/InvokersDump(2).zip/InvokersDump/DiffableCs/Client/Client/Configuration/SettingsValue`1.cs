namespace Client.Configuration;

public abstract class SettingsValue : ISettingsValues<T>
{
	private const string Root = "GameSettings"; //Field offset: 0x0
	protected static IDeviceStorage _deviceStorage; //Field offset: 0x0
	protected string _key; //Field offset: 0x0
	protected T _value; //Field offset: 0x0

	protected SettingsValue`1() { }

	public abstract T GetValue() { }

	public static void InitializeDeviceStorage(IDeviceStorage deviceStorage) { }

	public abstract void SetValue(T value) { }

	public override void SetValueRootKey(string value) { }

}

