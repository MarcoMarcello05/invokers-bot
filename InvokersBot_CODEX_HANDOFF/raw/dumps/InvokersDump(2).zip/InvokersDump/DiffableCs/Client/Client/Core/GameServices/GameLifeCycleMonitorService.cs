namespace Client.Core.GameServices;

[UsedAsInjection]
public sealed class GameLifeCycleMonitorService : IGameService, IGameLifeCycleObserver
{
	private static readonly TimeSpan ProfilerFlush; //Field offset: 0x0
	private static readonly Group LifeCycleGroup; //Field offset: 0x8
	private static readonly Activity ActiveActivity; //Field offset: 0x18
	private static readonly Activity FocusedActivity; //Field offset: 0x28
	private readonly Subject<Unit> _onAppQuitSubject; //Field offset: 0x10
	private readonly Subject<Boolean> _onAppFocusSubject; //Field offset: 0x18
	private readonly Subject<Boolean> _onAppPauseSubject; //Field offset: 0x20
	private readonly CancellationTokenSource _appQuitCts; //Field offset: 0x28
	private AutoScope _activeActivityScope; //Field offset: 0x30
	private AutoScope _focusedActivityScope; //Field offset: 0x48

	public override CancellationToken AppQuitCancellationToken
	{
		 get { } //Length: 24
	}

	private override Observable<Boolean> Client.Core.GameServices.IGameLifeCycleObserver.OnApplicationFocus
	{
		private get { } //Length: 8
	}

	private override Observable<Boolean> Client.Core.GameServices.IGameLifeCycleObserver.OnApplicationPause
	{
		private get { } //Length: 8
	}

	private override Observable<Unit> Client.Core.GameServices.IGameLifeCycleObserver.OnApplicationQuit
	{
		private get { } //Length: 8
	}

	public override string ServiceName
	{
		 get { } //Length: 64
	}

	public override bool SilentInitializationMode
	{
		 get { } //Length: 8
	}

	private static GameLifeCycleMonitorService() { }

	public GameLifeCycleMonitorService() { }

	private override Observable<Boolean> Client.Core.GameServices.IGameLifeCycleObserver.get_OnApplicationFocus() { }

	private override Observable<Boolean> Client.Core.GameServices.IGameLifeCycleObserver.get_OnApplicationPause() { }

	private override Observable<Unit> Client.Core.GameServices.IGameLifeCycleObserver.get_OnApplicationQuit() { }

	public override CancellationToken get_AppQuitCancellationToken() { }

	public override string get_ServiceName() { }

	public override bool get_SilentInitializationMode() { }

	public override UniTask InitAsync() { }

	public void OnApplicationFocus(bool focused) { }

	public void OnApplicationPause(bool paused) { }

	public void OnApplicationQuit() { }

}

