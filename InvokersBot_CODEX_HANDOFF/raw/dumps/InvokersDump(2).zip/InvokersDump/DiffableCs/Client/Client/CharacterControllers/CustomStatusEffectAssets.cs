namespace Client.CharacterControllers;

public class CustomStatusEffectAssets
{
	public long Type; //Field offset: 0x10
	public Sprite Sprite; //Field offset: 0x18

	public CustomStatusEffectAssets() { }

}

