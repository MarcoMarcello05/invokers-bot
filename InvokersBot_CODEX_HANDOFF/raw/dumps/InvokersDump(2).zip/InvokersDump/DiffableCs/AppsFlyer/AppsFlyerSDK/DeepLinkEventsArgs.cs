namespace AppsFlyerSDK;

public class DeepLinkEventsArgs : EventArgs
{
	public Dictionary<String, Object> deepLink; //Field offset: 0x10
	[CompilerGenerated]
	private readonly DeepLinkStatus <status>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly DeepLinkError <error>k__BackingField; //Field offset: 0x1C

	public DeepLinkEventsArgs(string str) { }

}

