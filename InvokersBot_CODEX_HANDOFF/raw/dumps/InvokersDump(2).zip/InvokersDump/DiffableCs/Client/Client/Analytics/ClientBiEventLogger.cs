namespace Client.Analytics;

[Nullable(0)]
[NullableContext(1)]
internal static class ClientBiEventLogger
{
	private const string LoggerCategory = "Client.Analytics.BI"; //Field offset: 0x0
	private static readonly ILogger Logger; //Field offset: 0x0

	public static bool IsEnabled
	{
		 get { } //Length: 208
	}

	private static ClientBiEventLogger() { }

	public static bool get_IsEnabled() { }

	public static void Log(IClientBiEvent biEvent, EventParamCollection parameters) { }

}

