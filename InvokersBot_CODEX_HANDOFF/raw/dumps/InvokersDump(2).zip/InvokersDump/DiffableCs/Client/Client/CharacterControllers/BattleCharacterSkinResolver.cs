namespace Client.CharacterControllers;

public static class BattleCharacterSkinResolver
{

	private static BattleCharacterSetup FindCharacterSetup(MetaBattleSetup metaSetup, HzGuid teamOwnerId, int inventoryId, bool isAnima) { }

	public static CharacterSkin Resolve(BattleSetup battleSetup, HzGuid teamOwnerId, CharacterStaticData character, bool inPlayerTeam) { }

}

