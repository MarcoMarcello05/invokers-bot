//Type is in global namespace

public sealed class CategoryPrioritySortFilter : IPopupFilter
{
	private readonly Dictionary<PopupCategory, Int32> _categoryOrder; //Field offset: 0x10

	public CategoryPrioritySortFilter(Dictionary<PopupCategory, Int32> categoryLimits) { }

	public override List<IPopupRequestParam> Apply(List<IPopupRequestParam> popups, ILogger logger) { }

	private int Compare(IPopupRequestParam a, IPopupRequestParam b) { }

	private int GetCategoryOrder(PopupCategory cat) { }

}

