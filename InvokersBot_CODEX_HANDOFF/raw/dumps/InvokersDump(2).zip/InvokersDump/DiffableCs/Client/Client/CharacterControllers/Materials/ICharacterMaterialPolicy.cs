namespace Client.CharacterControllers.Materials;

public interface ICharacterMaterialPolicy
{

	public void Configure(Material clone, Material source) { }

	public bool ShouldConvert(Material source) { }

	public bool ShouldConvert(SkinnedMeshRenderer renderer) { }

}

