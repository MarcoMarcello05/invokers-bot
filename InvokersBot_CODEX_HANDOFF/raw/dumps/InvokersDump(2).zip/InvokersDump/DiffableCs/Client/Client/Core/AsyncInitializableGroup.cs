namespace Client.Core;

public class AsyncInitializableGroup : AsyncInitializableBase
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass11_0
	{
		public IAsyncOperationWithProgress softInitOperation; //Field offset: 0x10

		public <>c__DisplayClass11_0() { }

		internal UniTask <OnInitialised>b__0(CancellationToken _) { }

	}

	[CompilerGenerated]
	private sealed class <GetInitOperationsByMode>d__16 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public AsyncInitializableGroup <>4__this; //Field offset: 0x28
		private InitMode mode; //Field offset: 0x30
		public InitMode <>3__mode; //Field offset: 0x34
		private IEnumerator<IAsyncInitializable> <>7__wrap1; //Field offset: 0x38

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <GetInitOperationsByMode>d__16(int <>1__state) { }

		private void <>m__Finally1() { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private sealed class <GetOperationByMode>d__15 : IEnumerable<IAsyncInitializable>, IEnumerable, IEnumerator<IAsyncInitializable>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private IAsyncInitializable <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public AsyncInitializableGroup <>4__this; //Field offset: 0x28
		private InitMode mode; //Field offset: 0x30
		public InitMode <>3__mode; //Field offset: 0x34
		private Enumerator<Operation> <>7__wrap1; //Field offset: 0x38

		private override IAsyncInitializable System.Collections.Generic.IEnumerator<Client.Core.IAsyncInitializable>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <GetOperationByMode>d__15(int <>1__state) { }

		private void <>m__Finally1() { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncInitializable> System.Collections.Generic.IEnumerable<Client.Core.IAsyncInitializable>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncInitializable System.Collections.Generic.IEnumerator<Client.Core.IAsyncInitializable>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private sealed class <InitFactory>d__12 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public AsyncInitializableGroup <>4__this; //Field offset: 0x28
		private List<IAsyncOperationWithProgress> <hardInitOperations>5__2; //Field offset: 0x30

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <InitFactory>d__12(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	private class Operation : IEquatable<Operation>
	{
		[CompilerGenerated]
		private readonly IAsyncInitializable <asyncInitializable>k__BackingField; //Field offset: 0x10
		[CompilerGenerated]
		private readonly InitMode <Mode>k__BackingField; //Field offset: 0x18

		public IAsyncInitializable asyncInitializable
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		[CompilerGenerated]
		[Nullable(1)]
		protected override Type EqualityContract
		{
			[CompilerGenerated]
			[NullableContext(1)]
			 get { } //Length: 96
		}

		public InitMode Mode
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public Operation(IAsyncInitializable asyncInitializable, InitMode Mode) { }

		[CompilerGenerated]
		protected Operation(Operation original) { }

		[CompilerGenerated]
		[NullableContext(1)]
		public override Operation <Clone>$() { }

		[CompilerGenerated]
		public void Deconstruct(out IAsyncInitializable asyncInitializable, out InitMode Mode) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public virtual bool Equals(object obj) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public override bool Equals(Operation other) { }

		[CompilerGenerated]
		public IAsyncInitializable get_asyncInitializable() { }

		[CompilerGenerated]
		[NullableContext(1)]
		protected override Type get_EqualityContract() { }

		[CompilerGenerated]
		public InitMode get_Mode() { }

		[CompilerGenerated]
		public virtual int GetHashCode() { }

		[CompilerGenerated]
		[NullableContext(2)]
		public static bool op_Equality(Operation left, Operation right) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public static bool op_Inequality(Operation left, Operation right) { }

		[CompilerGenerated]
		[NullableContext(1)]
		protected override bool PrintMembers(StringBuilder builder) { }

		[CompilerGenerated]
		public void set_asyncInitializable(IAsyncInitializable value) { }

		[CompilerGenerated]
		public void set_Mode(InitMode value) { }

		[CompilerGenerated]
		[NullableContext(1)]
		public virtual string ToString() { }

	}

	private readonly UniTaskFiber _fiber; //Field offset: 0x58
	private readonly List<Operation> _operations; //Field offset: 0x60
	private readonly List<AssetKey> _requiredAssetHolder; //Field offset: 0x68
	private readonly bool _addSoftAssetsToRequired; //Field offset: 0x70
	private IAsyncOperationsGroup _hardInitializationOperationGroup; //Field offset: 0x78
	private List<IAsyncOperationWithProgress> _softInitOperations; //Field offset: 0x80

	public AsyncInitializableGroup(bool addSoftAssetsToRequired = true) { }

	public AsyncInitializableGroup AddOperation(IAsyncInitializable operation, InitMode mode) { }

	public T FindFirstOperationOfType() { }

	[IteratorStateMachine(typeof(<GetInitOperationsByMode>d__16))]
	private IEnumerable<IAsyncOperationWithProgress> GetInitOperationsByMode(InitMode mode) { }

	[IteratorStateMachine(typeof(<GetOperationByMode>d__15))]
	private IEnumerable<IAsyncInitializable> GetOperationByMode(InitMode mode) { }

	[IteratorStateMachine(typeof(<InitFactory>d__12))]
	protected virtual IEnumerable<IAsyncOperationWithProgress> InitFactory() { }

	protected virtual void OnInitialised() { }

	public void SetPause(bool pause) { }

	public void StartSoftOperations(int maxConcurrency = 1) { }

	public UniTask StopAsync() { }

	public void StopSoftOperations() { }

	public void SubscribeToProgress(IOperationProgressObserver operationProgressObserver) { }

}

