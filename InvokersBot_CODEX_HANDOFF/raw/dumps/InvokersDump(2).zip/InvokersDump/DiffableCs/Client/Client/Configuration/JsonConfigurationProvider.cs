namespace Client.Configuration;

public class JsonConfigurationProvider : ConfigurationProvider, IKeyEnumerator
{
	private readonly JsonConfigurationSource _source; //Field offset: 0x20

	public JsonConfigurationProvider(JsonConfigurationSource source) { }

	public override IEnumerable<String> GetAllKeys() { }

	public virtual void Load() { }

}

