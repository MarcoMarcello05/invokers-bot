namespace Client.Core;

public class CollectionPoolItem : GameObjectsPoolItem<CollectionPoolItem>
{

	public CollectionPoolItem() { }

}

