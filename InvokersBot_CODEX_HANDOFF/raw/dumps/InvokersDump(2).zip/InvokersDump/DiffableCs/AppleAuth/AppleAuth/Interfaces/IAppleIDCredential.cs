namespace AppleAuth.Interfaces;

public interface IAppleIDCredential : ICredential
{

	public Byte[] IdentityToken
	{
		 get { } //Length: 0
	}

	public Byte[] get_IdentityToken() { }

}

