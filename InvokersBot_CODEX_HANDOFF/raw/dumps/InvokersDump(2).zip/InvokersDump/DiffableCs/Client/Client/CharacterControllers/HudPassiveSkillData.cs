namespace Client.CharacterControllers;

public class HudPassiveSkillData
{
	public Graph CharacterScriptGraph; //Field offset: 0x10
	public int Level; //Field offset: 0x18
	public Sprite Icon; //Field offset: 0x20
	public long CharacterGDID; //Field offset: 0x28
	public string LocalizationKey; //Field offset: 0x30
	public string CharacterName; //Field offset: 0x38
	public CharacterKind Kind; //Field offset: 0x40
	public EnemyType EnemyType; //Field offset: 0x41
	public ImmunityFlags Immunities; //Field offset: 0x44
	public ulong ImmunitiesToStatusEffects; //Field offset: 0x48

	public HudPassiveSkillData() { }

}

