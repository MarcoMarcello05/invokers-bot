namespace Client.Authentication.GooglePlayGames;

public enum GooglePlayGamesAuthStatus : int
{
	Success = 0,
	Canceled = 1,
	Failed = 2,
	NotSupported = 3,
}

