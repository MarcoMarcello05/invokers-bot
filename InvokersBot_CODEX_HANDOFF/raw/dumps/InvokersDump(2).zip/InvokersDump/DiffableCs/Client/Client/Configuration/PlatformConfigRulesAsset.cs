namespace Client.Configuration;

public class PlatformConfigRulesAsset : ScriptableObject
{
	internal class Config
	{
		[SerializeField]
		public List<Rule> Rules; //Field offset: 0x10
		[SerializeField]
		public string ConfigFile; //Field offset: 0x18
		[SerializeField]
		public QualityTier QualityTier; //Field offset: 0x20

		public Config() { }

	}

	internal class Rule
	{
		[SerializeField]
		public string DeviceModel; //Field offset: 0x10
		[SerializeField]
		public string ProcessorType; //Field offset: 0x18
		[SerializeField]
		public string RamSize; //Field offset: 0x20
		[SerializeField]
		public string GfxDeviceName; //Field offset: 0x28
		[SerializeField]
		public string GfxVendor; //Field offset: 0x30
		[SerializeField]
		public string GfxApiName; //Field offset: 0x38
		[SerializeField]
		public string DeviceType; //Field offset: 0x40
		[SerializeField]
		public string OsVersion; //Field offset: 0x48
		[SerializeField]
		public string Platform; //Field offset: 0x50
		[SerializeField]
		public string RequiresConfig; //Field offset: 0x58

		public Rule() { }

		public virtual string ToString() { }

	}

	[SerializeField]
	public List<Config> Configs; //Field offset: 0x18

	public PlatformConfigRulesAsset() { }

}

