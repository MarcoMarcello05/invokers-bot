namespace Client.Characters;

public sealed class CharacterSoundModule : ICharacterModule, IDisposable
{
	private readonly CharacterSoundController _sound; //Field offset: 0x10
	private IEnumerable<CharacterSoundSettings> _settings; //Field offset: 0x18

	public CharacterSoundModule() { }

	public void AnimaIn(bool suppressMoveLoop = true) { }

	public void AnimaOut(bool suppressMoveLoop = false) { }

	public override void Bind(CharacterView view) { }

	public void Damage() { }

	public void Dash() { }

	public void Dead() { }

	public override void Dispose() { }

	public void EventCustom() { }

	public void Freeze() { }

	public void Hit() { }

	public void Idle() { }

	public void IdleBreakStart(int idleBreakIndex) { }

	public void IdleHit() { }

	public void InterruptMetaSounds() { }

	public void IntroStart() { }

	public void IntroStop() { }

	public void LobbyIdle() { }

	public void Move(bool run) { }

	public override void OnViewDisabled() { }

	public override void OnViewEnabled() { }

	public void RevealStart() { }

	public void RevealStop() { }

	public void SetMetaSoundsEnabled(bool enabled, bool immediate) { }

	public void SkillAndCombo(SkillType skill) { }

	public void SkillPhaseInterrupt() { }

	public void Step() { }

	public void StopIdleBreak() { }

	public void StopMove() { }

	public void StunInterrupt() { }

	public override void Tick(float deltaTime) { }

	public override void Unbind() { }

	public void UseSettings(IEnumerable<CharacterSoundSettings> settings) { }

}

