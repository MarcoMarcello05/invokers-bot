namespace Client.Characters;

public sealed class CharacterControllerHost : IViewSystem
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Predicate<ICharacterController> <>9__9_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal bool <CompactHoles>b__9_0(ICharacterController controller) { }

	}

	private readonly ICharacterControllerFactory _factory; //Field offset: 0x10
	private readonly List<ICharacterController> _controllers; //Field offset: 0x18
	private bool _iterating; //Field offset: 0x20
	private bool _hasHoles; //Field offset: 0x21

	public CharacterControllerHost(ICharacterControllerFactory factory) { }

	private void CompactHoles() { }

	public TController Create() { }

	public override void Dispose() { }

	public void Release(ICharacterController controller) { }

	public override void Tick() { }

}

