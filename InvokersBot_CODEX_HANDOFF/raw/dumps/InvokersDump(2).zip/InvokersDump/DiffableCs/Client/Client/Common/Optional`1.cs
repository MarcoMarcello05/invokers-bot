namespace Client.Common;

public struct Optional
{
	public bool HasValue; //Field offset: 0x0
	public T Value; //Field offset: 0x0

	public Optional`1(T value) { }

	public static Optional<T> op_Implicit(T value) { }

}

