namespace AppsFlyerSDK;

public class AFAdRevenueData
{
	[CompilerGenerated]
	private string <monetizationNetwork>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private MediationNetwork <mediationNetwork>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private string <currencyIso4217Code>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private double <eventRevenue>k__BackingField; //Field offset: 0x28

	public string currencyIso4217Code
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public double eventRevenue
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public MediationNetwork mediationNetwork
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string monetizationNetwork
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	[CompilerGenerated]
	public string get_currencyIso4217Code() { }

	[CompilerGenerated]
	public double get_eventRevenue() { }

	[CompilerGenerated]
	public MediationNetwork get_mediationNetwork() { }

	[CompilerGenerated]
	public string get_monetizationNetwork() { }

}

