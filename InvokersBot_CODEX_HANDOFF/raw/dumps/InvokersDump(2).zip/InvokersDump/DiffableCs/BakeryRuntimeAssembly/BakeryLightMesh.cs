//Type is in global namespace

[DisallowMultipleComponent]
[ExecuteInEditMode]
[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Light_Mesh")]
public class BakeryLightMesh : MonoBehaviour
{
	public static int lightsChanged; //Field offset: 0x0
	private static GameObject objShownError; //Field offset: 0x8
	public int UID; //Field offset: 0x20
	public Color color; //Field offset: 0x24
	public float intensity; //Field offset: 0x34
	public Texture2D texture; //Field offset: 0x38
	public float cutoff; //Field offset: 0x40
	public int samples; //Field offset: 0x44
	public int samples2; //Field offset: 0x48
	public int samples2_previous; //Field offset: 0x4C
	public int bitmask; //Field offset: 0x50
	public bool selfShadow; //Field offset: 0x54
	public bool bakeToIndirect; //Field offset: 0x55
	public bool shadowmask; //Field offset: 0x56
	public float indirectIntensity; //Field offset: 0x58
	public bool shadowmaskFalloff; //Field offset: 0x5C
	public int maskChannel; //Field offset: 0x60
	public int lmid; //Field offset: 0x64

	public BakeryLightMesh() { }

	private void OnDrawGizmosSelected() { }

}

