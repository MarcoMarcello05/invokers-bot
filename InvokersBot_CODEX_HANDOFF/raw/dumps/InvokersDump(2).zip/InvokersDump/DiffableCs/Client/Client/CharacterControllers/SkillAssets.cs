namespace Client.CharacterControllers;

public class SkillAssets
{
	public long ID; //Field offset: 0x10
	public SkillType Type; //Field offset: 0x18
	public Sprite Sprite; //Field offset: 0x20

	public SkillAssets() { }

}

