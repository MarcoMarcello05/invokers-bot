namespace Client.Analytics;

[Nullable(0)]
[NullableContext(1)]
public class AnalyticEventRouter
{
	private readonly IOptionsMonitor<ClientAnalyticsSettings> _analyticsSettings; //Field offset: 0x10

	public AnalyticEventRouter(IOptionsMonitor<ClientAnalyticsSettings> analyticsSettings) { }

	public bool ShouldRouteToAttribution(IClientBiEvent biEvent) { }

	public bool ShouldRouteToFirebase(IClientBiEvent biEvent) { }

	public bool ShouldRouteToServer(IClientBiEvent biEvent) { }

}

