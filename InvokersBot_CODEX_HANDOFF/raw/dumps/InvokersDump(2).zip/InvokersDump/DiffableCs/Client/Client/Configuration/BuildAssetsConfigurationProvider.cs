namespace Client.Configuration;

public class BuildAssetsConfigurationProvider : ConfigurationProvider, IKeyEnumerator
{
	private readonly BuildAssetsConfigurationSource _source; //Field offset: 0x20

	public BuildAssetsConfigurationProvider(BuildAssetsConfigurationSource source) { }

	public override IEnumerable<String> GetAllKeys() { }

	public virtual void Load() { }

}

