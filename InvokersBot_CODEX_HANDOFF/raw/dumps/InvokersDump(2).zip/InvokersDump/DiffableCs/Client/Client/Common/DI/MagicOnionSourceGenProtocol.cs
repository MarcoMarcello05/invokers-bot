namespace Client.Common.DI;

public class MagicOnionSourceGenProtocol
{
	private static class MagicOnionGeneratedClient
	{
		[Ignore]
		internal class Shared_Choreograph_HttpClients_MetaGrpcServiceClient : MagicOnionClientBase<IMetaGrpcService>, IMetaGrpcService, IService<IMetaGrpcService>, IServiceMarker
		{
			private class ClientCore
			{
				public RawMethodInvoker<SignInRequest, Result`1<SignInResponse>> SignIn; //Field offset: 0x10
				public RawMethodInvoker<GetStaticDataRequest, Result`1<GetStaticDataResponse>> GetStaticData; //Field offset: 0x18
				public RawMethodInvoker<GetPlayerAggregateRequest, Result`1<GetPlayerAggregateResponse>> GetPlayerAggregate; //Field offset: 0x20
				public RawMethodInvoker<ActualizePlayerRequest, Result`1<ActualizePlayerResponse>> ActualizePlayer; //Field offset: 0x28
				public RawMethodInvoker<CommitPlayerActionsRequest, Result`1<ICommitPlayerActionsResult>> CommitDeterministicPlayerActions; //Field offset: 0x30
				public RawMethodInvoker<PlayerActionDto, Result`1<ExecutePlayerActionResponse>> ExecutePlayerAction; //Field offset: 0x38
				public RawMethodInvoker<GetShopPacksRequest, Result`1<GetShopPacksResponse>> GetShopPacks; //Field offset: 0x40
				public RawMethodInvoker<GetShopSkusRequest, Result`1<GetShopSkusResponse>> GetShopSkus; //Field offset: 0x48
				public RawMethodInvoker<GetStripeShopCatalogRequest, Result`1<GetStripeShopCatalogResponse>> GetStripeShopCatalog; //Field offset: 0x50
				public RawMethodInvoker<CreateStripeCheckoutSessionRequest, Result`1<CreateStripeCheckoutSessionResponse>> CreateStripeCheckoutSession; //Field offset: 0x58
				public RawMethodInvoker<GetStripeCheckoutSessionStatusRequest, Result`1<GetStripeCheckoutSessionStatusResponse>> GetStripeCheckoutSessionStatus; //Field offset: 0x60
				public RawMethodInvoker<ExpireStripeCheckoutSessionRequest, Result`1<ExpireStripeCheckoutSessionResponse>> ExpireStripeCheckoutSession; //Field offset: 0x68
				public RawMethodInvoker<GetTournamentsRequest, Result`1<GetTournamentsResponse>> GetTournaments; //Field offset: 0x70
				public RawMethodInvoker<GetPlayerTournamentBracketLeaderboardRequest, Result`1<GetTournamentBracketLeaderboardResponse>> GetPlayerTournamentBracketLeaderboard; //Field offset: 0x78
				public RawMethodInvoker<GetPlayerTournamentGlobalLeaderboardRequest, Result`1<GetTournamentGlobalLeaderboardResponse>> GetPlayerTournamentGlobalLeaderboard; //Field offset: 0x80
				public RawMethodInvoker<GetTournamentMilestoneRewardsRequest, Result`1<GetTournamentMilestoneRewardsResponse>> GetTournamentMilestoneRewards; //Field offset: 0x88
				public RawMethodInvoker<GetPlayerTowerLeaderboardRequest, Result`1<GetTowerLeaderboardResponse>> GetPlayerTowerLeaderboard; //Field offset: 0x90
				public RawMethodInvoker<GetDailyBestScoreTournamentLeaderboardRequest, Result`1<GetDailyBestScoreTournamentLeaderboardResponse>> GetDailyBestScoreTournamentLeaderboard; //Field offset: 0x98
				public RawMethodInvoker<GetClanPublicProfileRequest, Result`1<GetClanPublicProfileResponse>> GetClanPublicProfile; //Field offset: 0xA0
				public RawMethodInvoker<GetMyClanOverviewRequest, Result`1<GetMyClanOverviewResponse>> GetMyClanOverview; //Field offset: 0xA8
				public RawMethodInvoker<GetClanMembersRequest, Result`1<GetClanMembersResponse>> GetClanMembers; //Field offset: 0xB0
				public RawMethodInvoker<GetMyClanActivityRequest, Result`1<GetMyClanActivityResponse>> GetMyClanActivity; //Field offset: 0xB8
				public RawMethodInvoker<GetMyClanJewelryBossStateRequest, Result`1<GetMyClanJewelryBossStateResponse>> GetMyClanJewelryBossState; //Field offset: 0xC0
				public RawMethodInvoker<GetMyClanBoss2StateRequest, Result`1<GetMyClanBoss2StateResponse>> GetMyClanBoss2State; //Field offset: 0xC8
				public RawMethodInvoker<GetPlayerJoinClanRequestsRequest, Result`1<GetPlayerJoinClanRequestsResponse>> GetPlayerJoinClanRequests; //Field offset: 0xD0
				public RawMethodInvoker<SearchClansRequest, Result`1<SearchClansResponse>> SearchClans; //Field offset: 0xD8
				public RawMethodInvoker<GetFastJoinClanCandidatesRequest, Result`1<GetFastJoinClanCandidatesResponse>> GetFastJoinClanCandidates; //Field offset: 0xE0
				public RawMethodInvoker<GetClanReceivedJoinRequestsRequest, Result`1<GetClanReceivedJoinRequestsResponse>> GetClanReceivedJoinRequests; //Field offset: 0xE8
				public RawMethodInvoker<GetPlayerReceivedClanInvitesRequest, Result`1<GetPlayerReceivedClanInvitesResponse>> GetPlayerReceivedClanInvites; //Field offset: 0xF0
				public RawMethodInvoker<GetClanSentInvitesRequest, Result`1<GetClanSentInvitesResponse>> GetClanSentInvites; //Field offset: 0xF8
				public RawMethodInvoker<GetExternalPlayerProfileRequest, Result`1<GetExternalPlayerProfileResponse>> GetExternalPlayerProfile; //Field offset: 0x100
				public RawMethodInvoker<List`1<String>, Result`1<List`1<PublicProfileInfo>>> GetPublicProfileInfos; //Field offset: 0x108
				public RawMethodInvoker<String, Result`1<String>> DeleteMyProfile; //Field offset: 0x110
				public RawMethodInvoker<GetChatHistoryRequest, Result`1<ChatHistoryResponse>> GetChatHistory; //Field offset: 0x118
				public RawMethodInvoker<GetChatSendersRequest, Result`1<GetChatSendersResponse>> GetChatSenders; //Field offset: 0x120
				public RawMethodInvoker<Nil, Result`1<GetHeroRatingsResponse>> GetHeroRatings; //Field offset: 0x128
				public RawMethodInvoker<String, Result`1<PerfTraceUploadUrlResponse>> UploadPerfTrace; //Field offset: 0x130
				public RawMethodInvoker<List`1<ClientBiEventDto>, Result> UploadBiEvents; //Field offset: 0x138
				public RawMethodInvoker<MeasureGrpcRequest, MeasureGrpcResponse> MeasureGrpc; //Field offset: 0x140
				public RawMethodInvoker<Nil, ServerInfo> GetServerInfo; //Field offset: 0x148
				public RawMethodInvoker<String, String> RestorePlayerDump; //Field offset: 0x150
				public RawMethodInvoker<ThrowExceptionRequest, Result> ThrowException; //Field offset: 0x158

				public ClientCore(IMagicOnionSerializerProvider serializerProvider) { }

			}

			private readonly ClientCore core; //Field offset: 0x18

			public Shared_Choreograph_HttpClients_MetaGrpcServiceClient(MagicOnionClientOptions options, IMagicOnionSerializerProvider serializerProvider) { }

			private Shared_Choreograph_HttpClients_MetaGrpcServiceClient(MagicOnionClientOptions options, ClientCore core) { }

			public override UnaryResult<Result`1<ActualizePlayerResponse>> ActualizePlayer(ActualizePlayerRequest request) { }

			protected virtual MagicOnionClientBase<IMetaGrpcService> Clone(MagicOnionClientOptions options) { }

			public override UnaryResult<Result`1<ICommitPlayerActionsResult>> CommitDeterministicPlayerActions(CommitPlayerActionsRequest request) { }

			public override UnaryResult<Result`1<CreateStripeCheckoutSessionResponse>> CreateStripeCheckoutSession(CreateStripeCheckoutSessionRequest request) { }

			public override UnaryResult<Result`1<String>> DeleteMyProfile(string profileId) { }

			public override UnaryResult<Result`1<ExecutePlayerActionResponse>> ExecutePlayerAction(PlayerActionDto request) { }

			public override UnaryResult<Result`1<ExpireStripeCheckoutSessionResponse>> ExpireStripeCheckoutSession(ExpireStripeCheckoutSessionRequest request) { }

			public override UnaryResult<Result`1<ChatHistoryResponse>> GetChatHistory(GetChatHistoryRequest request) { }

			public override UnaryResult<Result`1<GetChatSendersResponse>> GetChatSenders(GetChatSendersRequest request) { }

			public override UnaryResult<Result`1<GetClanMembersResponse>> GetClanMembers(GetClanMembersRequest request) { }

			public override UnaryResult<Result`1<GetClanPublicProfileResponse>> GetClanPublicProfile(GetClanPublicProfileRequest request) { }

			public override UnaryResult<Result`1<GetClanReceivedJoinRequestsResponse>> GetClanReceivedJoinRequests(GetClanReceivedJoinRequestsRequest request) { }

			public override UnaryResult<Result`1<GetClanSentInvitesResponse>> GetClanSentInvites(GetClanSentInvitesRequest request) { }

			public override UnaryResult<Result`1<GetDailyBestScoreTournamentLeaderboardResponse>> GetDailyBestScoreTournamentLeaderboard(GetDailyBestScoreTournamentLeaderboardRequest request) { }

			public override UnaryResult<Result`1<GetExternalPlayerProfileResponse>> GetExternalPlayerProfile(GetExternalPlayerProfileRequest request) { }

			public override UnaryResult<Result`1<GetFastJoinClanCandidatesResponse>> GetFastJoinClanCandidates(GetFastJoinClanCandidatesRequest request) { }

			public override UnaryResult<Result`1<GetHeroRatingsResponse>> GetHeroRatings() { }

			public override UnaryResult<Result`1<GetMyClanActivityResponse>> GetMyClanActivity(GetMyClanActivityRequest request) { }

			public override UnaryResult<Result`1<GetMyClanBoss2StateResponse>> GetMyClanBoss2State(GetMyClanBoss2StateRequest request) { }

			public override UnaryResult<Result`1<GetMyClanJewelryBossStateResponse>> GetMyClanJewelryBossState(GetMyClanJewelryBossStateRequest request) { }

			public override UnaryResult<Result`1<GetMyClanOverviewResponse>> GetMyClanOverview(GetMyClanOverviewRequest request) { }

			public override UnaryResult<Result`1<GetPlayerAggregateResponse>> GetPlayerAggregate(GetPlayerAggregateRequest request) { }

			public override UnaryResult<Result`1<GetPlayerJoinClanRequestsResponse>> GetPlayerJoinClanRequests(GetPlayerJoinClanRequestsRequest request) { }

			public override UnaryResult<Result`1<GetPlayerReceivedClanInvitesResponse>> GetPlayerReceivedClanInvites(GetPlayerReceivedClanInvitesRequest request) { }

			public override UnaryResult<Result`1<GetTournamentBracketLeaderboardResponse>> GetPlayerTournamentBracketLeaderboard(GetPlayerTournamentBracketLeaderboardRequest request) { }

			public override UnaryResult<Result`1<GetTournamentGlobalLeaderboardResponse>> GetPlayerTournamentGlobalLeaderboard(GetPlayerTournamentGlobalLeaderboardRequest request) { }

			public override UnaryResult<Result`1<GetTowerLeaderboardResponse>> GetPlayerTowerLeaderboard(GetPlayerTowerLeaderboardRequest request) { }

			public override UnaryResult<Result`1<List`1<PublicProfileInfo>>> GetPublicProfileInfos(List<String> playerIds) { }

			public override UnaryResult<ServerInfo> GetServerInfo() { }

			public override UnaryResult<Result`1<GetShopPacksResponse>> GetShopPacks(GetShopPacksRequest request) { }

			public override UnaryResult<Result`1<GetShopSkusResponse>> GetShopSkus(GetShopSkusRequest request) { }

			public override UnaryResult<Result`1<GetStaticDataResponse>> GetStaticData(GetStaticDataRequest request) { }

			public override UnaryResult<Result`1<GetStripeCheckoutSessionStatusResponse>> GetStripeCheckoutSessionStatus(GetStripeCheckoutSessionStatusRequest request) { }

			public override UnaryResult<Result`1<GetStripeShopCatalogResponse>> GetStripeShopCatalog(GetStripeShopCatalogRequest request) { }

			public override UnaryResult<Result`1<GetTournamentMilestoneRewardsResponse>> GetTournamentMilestoneRewards(GetTournamentMilestoneRewardsRequest request) { }

			public override UnaryResult<Result`1<GetTournamentsResponse>> GetTournaments(GetTournamentsRequest request) { }

			public override UnaryResult<MeasureGrpcResponse> MeasureGrpc(MeasureGrpcRequest request) { }

			public override UnaryResult<String> RestorePlayerDump(string dumpPath) { }

			public override UnaryResult<Result`1<SearchClansResponse>> SearchClans(SearchClansRequest request) { }

			public override UnaryResult<Result`1<SignInResponse>> SignIn(SignInRequest request) { }

			public override UnaryResult<Result> ThrowException(ThrowExceptionRequest request) { }

			public override UnaryResult<Result> UploadBiEvents(List<ClientBiEventDto> events) { }

			public override UnaryResult<Result`1<PerfTraceUploadUrlResponse>> UploadPerfTrace(string traceKey) { }

		}

		[Ignore]
		internal class Shared_Choreograph_MetaGame_MetaPresenceHubClient : StreamingHubClientBase<IMetaPresenceHub, IMetaClientCallbacks>, IMetaPresenceHub, IStreamingHub<IMetaPresenceHub, IMetaClientCallbacks>, IStreamingHubMarker, IServiceMarker
		{
			[Ignore]
			private class FireAndForgetClient : IMetaPresenceHub, IStreamingHub<IMetaPresenceHub, IMetaClientCallbacks>, IStreamingHubMarker, IServiceMarker
			{
				private readonly Shared_Choreograph_MetaGame_MetaPresenceHubClient parent; //Field offset: 0x10

				public FireAndForgetClient(Shared_Choreograph_MetaGame_MetaPresenceHubClient parent) { }

				public override Task<Result> BanChatPlayerAsync(string targetPlayerId, string flaggedMessageId, TimeSpan sinceInterval, TimeSpan duration) { }

				public override Task DisposeAsync() { }

				public override IMetaPresenceHub FireAndForget() { }

				public override Task<ServerInfo> GetServerInfo() { }

				public override Task<ChatJoinResult> JoinChatAsync(IChatJoinSelector selector) { }

				public override Task<Result> LeaveChatAsync(ChatLeaveRequest request) { }

				public override Task<Result`1<ChatChannelEntry>> SendChatMessageAsync(ChatSendMessageRequest request) { }

				public override Task<Result`1<ChatReactionSnapshot>> SetChatReactionAsync(SetChatReactionRequest request) { }

				public override Task WaitForDisconnect() { }

			}


			public Shared_Choreograph_MetaGame_MetaPresenceHubClient(IMetaClientCallbacks receiver, CallInvoker callInvoker, StreamingHubClientOptions options) { }

			public override Task<Result> BanChatPlayerAsync(string targetPlayerId, string flaggedMessageId, TimeSpan sinceInterval, TimeSpan duration) { }

			public override IMetaPresenceHub FireAndForget() { }

			public override Task<ServerInfo> GetServerInfo() { }

			public override Task<ChatJoinResult> JoinChatAsync(IChatJoinSelector selector) { }

			public override Task<Result> LeaveChatAsync(ChatLeaveRequest request) { }

			private override Task MagicOnion.IStreamingHub<Shared.Choreograph.MetaGame.IMetaPresenceHub,Shared.Choreograph.MetaGame.IMetaClientCallbacks>.DisposeAsync() { }

			private override Task MagicOnion.IStreamingHub<Shared.Choreograph.MetaGame.IMetaPresenceHub,Shared.Choreograph.MetaGame.IMetaClientCallbacks>.WaitForDisconnect() { }

			protected virtual void OnBroadcastEvent(int methodId, ReadOnlyMemory<Byte> data) { }

			protected virtual void OnClientResultEvent(int methodId, Guid messageId, ReadOnlyMemory<Byte> data) { }

			protected virtual void OnResponseEvent(int methodId, object taskSource, ReadOnlyMemory<Byte> data) { }

			public override Task<Result`1<ChatChannelEntry>> SendChatMessageAsync(ChatSendMessageRequest request) { }

			public override Task<Result`1<ChatReactionSnapshot>> SetChatReactionAsync(SetChatReactionRequest request) { }

		}

		[Ignore]
		internal class Shared_Choreograph_Multiplayer_BattleHubClient : StreamingHubClientBase<IBattleHub, IBattleCallbacks>, IBattleHub, IStreamingHub<IBattleHub, IBattleCallbacks>, IStreamingHubMarker, IServiceMarker
		{
			[Ignore]
			private class FireAndForgetClient : IBattleHub, IStreamingHub<IBattleHub, IBattleCallbacks>, IStreamingHubMarker, IServiceMarker
			{
				private readonly Shared_Choreograph_Multiplayer_BattleHubClient parent; //Field offset: 0x10

				public FireAndForgetClient(Shared_Choreograph_Multiplayer_BattleHubClient parent) { }

				public override Task DisposeAsync() { }

				public override IBattleHub FireAndForget() { }

				public override ValueTask<String> GetOrCreateBattleRoom(string searchKey, int debugServerFrameDeltaMs) { }

				public override ValueTask JoinBattleRoom(string battleRoomId, MetaBattleSetup playerSetup) { }

				public override ValueTask LeaveBattleRoom() { }

				public override ValueTask PlayerInput(SerializedPlayerInput playerInput) { }

				public override ValueTask StartBattleInCurrentRoom() { }

				public override Task WaitForDisconnect() { }

			}


			public Shared_Choreograph_Multiplayer_BattleHubClient(IBattleCallbacks receiver, CallInvoker callInvoker, StreamingHubClientOptions options) { }

			public override IBattleHub FireAndForget() { }

			public override ValueTask<String> GetOrCreateBattleRoom(string searchKey, int debugServerFrameDeltaMs) { }

			public override ValueTask JoinBattleRoom(string battleRoomId, MetaBattleSetup playerSetup) { }

			public override ValueTask LeaveBattleRoom() { }

			private override Task MagicOnion.IStreamingHub<Shared.Choreograph.Multiplayer.IBattleHub,Shared.Choreograph.Multiplayer.IBattleCallbacks>.DisposeAsync() { }

			private override Task MagicOnion.IStreamingHub<Shared.Choreograph.Multiplayer.IBattleHub,Shared.Choreograph.Multiplayer.IBattleCallbacks>.WaitForDisconnect() { }

			protected virtual void OnBroadcastEvent(int methodId, ReadOnlyMemory<Byte> data) { }

			protected virtual void OnClientResultEvent(int methodId, Guid messageId, ReadOnlyMemory<Byte> data) { }

			protected virtual void OnResponseEvent(int methodId, object taskSource, ReadOnlyMemory<Byte> data) { }

			public override ValueTask PlayerInput(SerializedPlayerInput playerInput) { }

			public override ValueTask StartBattleInCurrentRoom() { }

		}


	}

	private class MagicOnionGeneratedClientFactoryProvider : IMagicOnionClientFactoryProvider, IStreamingHubClientFactoryProvider
	{
		private static class MagicOnionClientFactoryCache
		{
			[CompilerGenerated]
			private sealed class <>c
			{
				public static readonly <>c<T> <>9; //Field offset: 0x0

				private static <>c() { }

				public <>c() { }

				[NullableContext(1)]
				internal IMetaGrpcService <.cctor>b__1_0(MagicOnionClientOptions x, IMagicOnionSerializerProvider y) { }

			}

			public static readonly MagicOnionClientFactoryDelegate<T> Factory; //Field offset: 0x0

			private static MagicOnionClientFactoryCache`1() { }

		}

		private static class StreamingHubClientFactoryCache
		{
			[CompilerGenerated]
			private sealed class <>c
			{
				public static readonly <>c<TStreamingHub, TReceiver> <>9; //Field offset: 0x0

				private static <>c() { }

				public <>c() { }

				internal IMetaPresenceHub <.cctor>b__1_0(IMetaClientCallbacks a, CallInvoker b, StreamingHubClientOptions c) { }

				internal IBattleHub <.cctor>b__1_1(IBattleCallbacks a, CallInvoker b, StreamingHubClientOptions c) { }

			}

			public static readonly StreamingHubClientFactoryDelegate<TStreamingHub, TReceiver> Factory; //Field offset: 0x0

			private static StreamingHubClientFactoryCache`2() { }

		}


		public MagicOnionGeneratedClientFactoryProvider() { }

		private override bool global::MagicOnion.Client.IMagicOnionClientFactoryProvider.TryGetFactory(out MagicOnionClientFactoryDelegate<T>& factory) { }

		private override bool global::MagicOnion.Client.IStreamingHubClientFactoryProvider.TryGetFactory(out StreamingHubClientFactoryDelegate<TStreamingHub, TReceiver>& factory) { }

	}

	private static bool isRegistered; //Field offset: 0x0
	private static readonly MagicOnionGeneratedClientFactoryProvider provider; //Field offset: 0x8

	public static IMagicOnionClientFactoryProvider ClientFactoryProvider
	{
		 get { } //Length: 88
	}

	public static IStreamingHubClientFactoryProvider StreamingHubClientFactoryProvider
	{
		 get { } //Length: 88
	}

	private static MagicOnionSourceGenProtocol() { }

	public MagicOnionSourceGenProtocol() { }

	public static IMagicOnionClientFactoryProvider get_ClientFactoryProvider() { }

	public static IStreamingHubClientFactoryProvider get_StreamingHubClientFactoryProvider() { }

	[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType::BeforeSceneLoad (1))]
	internal static void Register() { }

	public static void RegisterMemoryPackFormatters() { }

	public static bool TryRegisterProviderFactory() { }

}

