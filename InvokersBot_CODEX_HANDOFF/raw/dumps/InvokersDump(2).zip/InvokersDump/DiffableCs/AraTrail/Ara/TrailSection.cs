namespace Ara;

public class TrailSection : ScriptableObject
{
	[HideInInspector]
	public List<Vector2> vertices; //Field offset: 0x18
	public int snapX; //Field offset: 0x20
	public int snapY; //Field offset: 0x24

	public int Segments
	{
		 get { } //Length: 76
	}

	public TrailSection() { }

	public void CirclePreset(int segments) { }

	public int get_Segments() { }

	public void OnEnable() { }

	public static int SnapTo(float val, int snapInterval, int threshold) { }

}

