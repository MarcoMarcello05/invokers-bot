namespace Client.BackgroundDownloading;

public enum BackgroundDownloadingServiceStatus : int
{
	Disabled = 0,
	Idle = 1,
	CheckingDownloads = 2,
	WaitForNoActiveDownloads = 3,
	WaitForPerformanceSections = 4,
	WaitForConnection = 5,
	Downloading = 6,
	Completed = 7,
}

