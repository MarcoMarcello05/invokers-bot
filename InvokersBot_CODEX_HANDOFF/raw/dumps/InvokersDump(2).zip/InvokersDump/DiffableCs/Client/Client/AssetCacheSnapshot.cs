namespace Client;

[Nullable(0)]
[NullableContext(1)]
public sealed class AssetCacheSnapshot : IEquatable<AssetCacheSnapshot>
{
	[CompilerGenerated]
	private readonly AssetCacheGroup <Group>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly int <Capacity>k__BackingField; //Field offset: 0x14
	[CompilerGenerated]
	private readonly int <Count>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly IReadOnlyList<AssetCacheEntrySnapshot> <Entries>k__BackingField; //Field offset: 0x20

	public int Capacity
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public int Count
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public IReadOnlyList<AssetCacheEntrySnapshot> Entries
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	[CompilerGenerated]
	private Type EqualityContract
	{
		[CompilerGenerated]
		private get { } //Length: 96
	}

	public AssetCacheGroup Group
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public AssetCacheSnapshot(AssetCacheGroup Group, int Capacity, int Count, IReadOnlyList<AssetCacheEntrySnapshot> Entries) { }

	[CompilerGenerated]
	private AssetCacheSnapshot(AssetCacheSnapshot original) { }

	[CompilerGenerated]
	public AssetCacheSnapshot <Clone>$() { }

	[CompilerGenerated]
	public void Deconstruct(out AssetCacheGroup Group, out int Capacity, out int Count, out IReadOnlyList<AssetCacheEntrySnapshot>& Entries) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public override bool Equals(AssetCacheSnapshot other) { }

	[CompilerGenerated]
	public int get_Capacity() { }

	[CompilerGenerated]
	public int get_Count() { }

	[CompilerGenerated]
	public IReadOnlyList<AssetCacheEntrySnapshot> get_Entries() { }

	[CompilerGenerated]
	private Type get_EqualityContract() { }

	[CompilerGenerated]
	public AssetCacheGroup get_Group() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Equality(AssetCacheSnapshot left, AssetCacheSnapshot right) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Inequality(AssetCacheSnapshot left, AssetCacheSnapshot right) { }

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	public void set_Capacity(int value) { }

	[CompilerGenerated]
	public void set_Count(int value) { }

	[CompilerGenerated]
	public void set_Entries(IReadOnlyList<AssetCacheEntrySnapshot> value) { }

	[CompilerGenerated]
	public void set_Group(AssetCacheGroup value) { }

	[CompilerGenerated]
	public virtual string ToString() { }

}

