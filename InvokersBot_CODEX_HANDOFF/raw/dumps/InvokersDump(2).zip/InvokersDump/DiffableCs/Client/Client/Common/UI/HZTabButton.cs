namespace Client.Common.UI;

public class HZTabButton : MonoBehaviour, ITabButton, IPointerClickHandler, IEventSystemHandler
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass16_0
	{
		public HZTabButton <>4__this; //Field offset: 0x10
		public ITabButtonCommand command; //Field offset: 0x18

		public <>c__DisplayClass16_0() { }

		internal void <Bind>b__0(Unit unit) { }

	}

	private readonly Subject<Unit> _onClick; //Field offset: 0x20
	private readonly SerialDisposable _binding; //Field offset: 0x28
	[SerializeField]
	private bool _useCustomDecorator; //Field offset: 0x30
	[SerializeField]
	private ButtonStateDecorator _buttonStateDecorator; //Field offset: 0x38
	[SerializeField]
	protected GameObject _prefabActive; //Field offset: 0x40
	[SerializeField]
	protected GameObject _prefabInactive; //Field offset: 0x48
	[SerializeField]
	private ButtonSoundReference _clickSoundRef; //Field offset: 0x50
	[SerializeField]
	private bool _needToReportAnalytics; //Field offset: 0x58
	[AnalyticsEvent]
	[SerializeField]
	private string _eventButtonName; //Field offset: 0x60
	private bool _selected; //Field offset: 0x68

	public Observable<Unit> OnClick
	{
		 get { } //Length: 8
	}

	public HZTabButton() { }

	public override void Bind(ITabButtonCommand command, bool earlySelection = false) { }

	public Observable<Unit> get_OnClick() { }

	private void OnDestroy() { }

	public override void OnPointerClick(PointerEventData eventData) { }

	private void ReportAnalyticsIfNeeded() { }

	private void Reset() { }

	public void ResetBinding() { }

	public override void SetSelected(bool selected) { }

}

