namespace Client.Authentication;

[Nullable(0)]
[NullableContext(1)]
public sealed class AuthenticationError
{
	[CompilerGenerated]
	private string <Code>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private string <Message>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private string <Suggestion>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private string <DebugMessage>k__BackingField; //Field offset: 0x28

	public string Code
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string DebugMessage
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string Message
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string Suggestion
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public AuthenticationError() { }

	public AuthenticationError(string code, string message, string suggestion, string debugMessage) { }

	[CompilerGenerated]
	public string get_Code() { }

	[CompilerGenerated]
	public string get_DebugMessage() { }

	[CompilerGenerated]
	public string get_Message() { }

	[CompilerGenerated]
	public string get_Suggestion() { }

	[CompilerGenerated]
	public void set_Code(string value) { }

	[CompilerGenerated]
	public void set_DebugMessage(string value) { }

	[CompilerGenerated]
	public void set_Message(string value) { }

	[CompilerGenerated]
	public void set_Suggestion(string value) { }

	public virtual string ToString() { }

}

