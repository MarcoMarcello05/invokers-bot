namespace Client.CharacterControllers;

[UsedAsInjection]
public class CharacterUIPool : SharedGameObjectsPool<CharacterUI>
{
	[CompilerGenerated]
	private struct <AddTemplate>d__10 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public CharacterUIPool <>4__this; //Field offset: 0x18
		public AssetKey key; //Field offset: 0x20
		public TemplateId id; //Field offset: 0x28
		private IAssetRequest<GameObject> <request>5__2; //Field offset: 0x30
		private Awaiter<GameObject> <>u__1; //Field offset: 0x38
		private Awaiter <>u__2; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private sealed class <get_RequiredAssets>d__7 : IEnumerable<AssetKey>, IEnumerable, IEnumerator<AssetKey>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private AssetKey <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20

		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <get_RequiredAssets>d__7(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<AssetKey> System.Collections.Generic.IEnumerable<Client.AssetKey>.GetEnumerator() { }

		[DebuggerHidden]
		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private struct <Init>d__8 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public CharacterUIPool <>4__this; //Field offset: 0x18
		private AutoScope <_>5__2; //Field offset: 0x20
		private Awaiter <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <LoadWeaponIcons>d__9 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public CharacterUIPool <>4__this; //Field offset: 0x18
		private IAssetRequest<CharacterWeaponToIconList> <weaponIconsRequest>5__2; //Field offset: 0x20
		private Awaiter<CharacterWeaponToIconList> <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	internal enum TemplateId : int
	{
		Character = 0,
		Boss = 1,
		MiniBoss = 2,
		Elite = 3,
		Enemy = 4,
	}

	private static readonly Activity InitActivity; //Field offset: 0x0
	private readonly IAssetProvider _assetProvider; //Field offset: 0x80
	private readonly CharacterUI[] _templates; //Field offset: 0x88

	protected virtual IEnumerable<AssetKey> RequiredAssets
	{
		[IteratorStateMachine(typeof(<get_RequiredAssets>d__7))]
		 get { } //Length: 108
	}

	private static CharacterUIPool() { }

	public CharacterUIPool(IBootstrap bootstrap, IAssetProvider assetProvider, IOptionsMonitor<ContentSettings> settings) { }

	[AsyncStateMachine(typeof(<AddTemplate>d__10))]
	private UniTask AddTemplate(TemplateId id, AssetKey key) { }

	[IteratorStateMachine(typeof(<get_RequiredAssets>d__7))]
	protected virtual IEnumerable<AssetKey> get_RequiredAssets() { }

	[AsyncStateMachine(typeof(<Init>d__8))]
	protected virtual UniTask Init(IOperationProgressObserver onProgressChange) { }

	[AsyncStateMachine(typeof(<LoadWeaponIcons>d__9))]
	private UniTask LoadWeaponIcons() { }

	public CharacterUI Rent(TemplateId id) { }

}

