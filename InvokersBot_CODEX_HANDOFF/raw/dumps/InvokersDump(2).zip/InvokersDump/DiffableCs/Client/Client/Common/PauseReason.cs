namespace Client.Common;

[Flags]
public enum PauseReason : int
{
	None = 0,
	BattleMenu = 1,
	BattleTape = 2,
	MultiBattleInLevelScreen = 4,
	Debug = 1073741824,
}

