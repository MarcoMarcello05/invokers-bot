//Type is in global namespace

[ExecuteInEditMode]
[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Volume")]
public class BakeryVolume : MonoBehaviour
{
	internal enum Encoding : int
	{
		Half4 = 0,
		RGBA8 = 1,
		RGBA8Mono = 2,
	}

	internal enum ShadowmaskEncoding : int
	{
		RGBA8 = 0,
		A8 = 1,
	}

	public static BakeryVolume globalVolume; //Field offset: 0x0
	public static bool showAll; //Field offset: 0x8
	public bool enableBaking; //Field offset: 0x20
	public Bounds bounds; //Field offset: 0x24
	public bool adaptiveRes; //Field offset: 0x3C
	public float voxelsPerUnit; //Field offset: 0x40
	public int resolutionX; //Field offset: 0x44
	public int resolutionY; //Field offset: 0x48
	public int resolutionZ; //Field offset: 0x4C
	public Encoding encoding; //Field offset: 0x50
	public ShadowmaskEncoding shadowmaskEncoding; //Field offset: 0x54
	public bool firstLightIsAlwaysAlpha; //Field offset: 0x58
	public bool denoise; //Field offset: 0x59
	public bool isGlobal; //Field offset: 0x5A
	public Texture3D bakedTexture0; //Field offset: 0x60
	public Texture3D bakedTexture1; //Field offset: 0x68
	public Texture3D bakedTexture2; //Field offset: 0x70
	public Texture3D bakedTexture3; //Field offset: 0x78
	public Texture3D bakedMask; //Field offset: 0x80
	public bool supportRotationAfterBake; //Field offset: 0x88
	public bool rotateAroundY; //Field offset: 0x89
	public bool _rotateAroundXYZ; //Field offset: 0x8A
	public int multiVolumePriority; //Field offset: 0x8C
	private Transform tform; //Field offset: 0x90

	public BakeryVolume() { }

	public Vector3 GetInvSize() { }

	public Matrix4x4 GetMatrix() { }

	public Vector3 GetMax() { }

	public Vector3 GetMaxXMinZ() { }

	public Vector3 GetMin() { }

	public Vector2 GetRotationY() { }

	public Vector4 GetWorldXZMinMax() { }

	private void OnDrawGizmos() { }

	public void OnEnable() { }

	public void SetGlobalParams() { }

	private Vector3 TransformPoint(Vector3 p, Vector3 center, Vector2 sc) { }

	public void UpdateBounds() { }

}

