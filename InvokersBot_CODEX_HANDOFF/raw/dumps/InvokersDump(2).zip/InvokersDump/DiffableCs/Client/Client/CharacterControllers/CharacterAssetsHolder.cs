namespace Client.CharacterControllers;

public class CharacterAssetsHolder : ScriptableObject
{
	public Sprite Icon; //Field offset: 0x18
	public Sprite SchematicIcon; //Field offset: 0x20
	[Tooltip("Tint the schematic icon with the ally/enemy health-bar color instead of preserving its original colors.")]
	public bool UseTeamColorForSchematicIcon; //Field offset: 0x28
	public Sprite PassiveSkillIcon; //Field offset: 0x30
	public List<SkillAssets> SkillAssets; //Field offset: 0x38
	[HideInInspector]
	public List<CustomStatusEffectAssets> CustomStatusEffectAssets; //Field offset: 0x40

	public CharacterAssetsHolder() { }

}

