namespace Client.Analytics;

public static class UIElementsNames
{
	internal static class AnimaOverviewButtonNames
	{
		public const string AscendButton = "AnimaOverview/TabAscension/AscendButton"; //Field offset: 0x0
		public const string QuickLevelUpAndAscendButton = "AnimaOverview/TabAscension/QuickLevelUpAndAscendButton"; //Field offset: 0x0
		public const string QuickAscensionButton = "AnimaOverview/TabAscension/QuickAscensionButton"; //Field offset: 0x0
		public const string QuickAscensionBackButton = "AnimaOverview/TabAscension/QuickAscensionBackButton"; //Field offset: 0x0

	}

	internal static class ArenaScreenButtonNames
	{
		public const string RefreshOpponentsButton = "ArenaScreen/TabBattle/RefreshOpponentsButton"; //Field offset: 0x0

	}

	internal static class HeroOverviewButtonNames
	{
		public const string AscendButton = "HeroOverview/TabAscension/AscendButton"; //Field offset: 0x0
		public const string QuickLevelUpAndAscendButton = "HeroOverview/TabAscension/QuickLevelUpAndAscendButton"; //Field offset: 0x0
		public const string QuickAscensionButton = "HeroOverview/TabAscension/QuickAscensionButton"; //Field offset: 0x0
		public const string QuickAscensionBackButton = "HeroOverview/TabAscension/QuickAscensionBackButton"; //Field offset: 0x0

	}

	internal static class LobbyScreenButtonNames
	{
		public const string YoutubeButton = "LobbyScreen/BurgerMenu/YoutubeButton"; //Field offset: 0x0
		public const string SummonPortal = "LobbyScreen/SummonPortal"; //Field offset: 0x0
		public const string ClansButton = "LobbyScreen/ClansButton"; //Field offset: 0x0
		public const string FuseButton = "LobbyScreen/FuseButton"; //Field offset: 0x0
		public const string IndexButton = "LobbyScreen/IndexButton"; //Field offset: 0x0
		public const string AnimasButton = "LobbyScreen/AnimasButton"; //Field offset: 0x0
		public const string SummonButton = "LobbyScreen/SummonButton"; //Field offset: 0x0
		public const string HeroesButton = "LobbyScreen/HeroesButton"; //Field offset: 0x0
		public const string ClansTower = "LobbyScreen/ClansTower"; //Field offset: 0x0
		public const string QuestsButton = "LobbyScreen/QuestsButton"; //Field offset: 0x0
		public const string ChatButton = "LobbyScreen/ChatButton"; //Field offset: 0x0
		public const string ClaimBookQuestButton = "LobbyScreen/ClaimBookQuestButton"; //Field offset: 0x0
		public const string InventoryButton = "LobbyScreen/InventoryButton"; //Field offset: 0x0
		public const string GearButton = "LobbyScreen/GearButton"; //Field offset: 0x0
		public const string ShopButton = "LobbyScreen/ShopButton"; //Field offset: 0x0
		public const string DiscordButton = "LobbyScreen/BurgerMenu/DiscordButton"; //Field offset: 0x0
		public const string FaceBookButton = "LobbyScreen/BurgerMenu/FaceBookButton"; //Field offset: 0x0
		public const string EventsButton = "LobbyScreen/EventsButton"; //Field offset: 0x0
		public const string MarketTower = "LobbyScreen/MarketTower"; //Field offset: 0x0

	}

	internal static class MultiBattleButtonNames
	{
		public const string StartMultiBattleButton = "MultiBattle/StartMultiBattleButton"; //Field offset: 0x0
		public const string StartBackgroundMultiBattleButton = "MultiBattle/StartBackgroundMultiBattleButton"; //Field offset: 0x0

	}

	internal static class PlayerProfileButtonNames
	{
		public const string SummaryTab = "PlayerProfile/TabButtons/SummaryButton"; //Field offset: 0x0
		public const string AvatarTab = "PlayerProfile/TabButtons/AvatarButton"; //Field offset: 0x0
		public const string StatisticsTab = "PlayerProfile/TabButtons/StatisticsButton"; //Field offset: 0x0
		public const string BackButton = "PlayerProfile/BackButton"; //Field offset: 0x0
		public const string ChangeNameButton = "PlayerProfile/ChangeNameButton"; //Field offset: 0x0
		public const string VipStatusBadgeButton = "PlayerProfile/VipStatusBadgeButton"; //Field offset: 0x0

	}

	internal static class ShopTabsButtonNames
	{
		public const string ExclusiveTab = "ShopScreen/ExclusiveTab"; //Field offset: 0x0
		public const string RetentionPacksTab = "ShopScreen/RetentionPacksTab"; //Field offset: 0x0
		public const string SpecialOffersTab = "ShopScreen/SpecialOffersTab"; //Field offset: 0x0
		public const string CurrencyTab = "ShopScreen/CurrencyTab"; //Field offset: 0x0
		public const string GemsTab = "ShopScreen/GemsTab"; //Field offset: 0x0
		public const string HotDealsTab = "ShopScreen/HotDealsTab"; //Field offset: 0x0

	}

	internal static class TeamSelectionButtonNames
	{
		public const string HeroesTab = "TeamSelectionScreen/TabButtons/HeroesButton"; //Field offset: 0x0
		public const string AnimasTab = "TeamSelectionScreen/TabButtons/AnimasButton"; //Field offset: 0x0
		public const string FormationsTab = "TeamSelectionScreen/TabButtons/FormationsButton"; //Field offset: 0x0
		public const string StarsHelpButton = "TeamSelectionScreen/StarsHelpButton"; //Field offset: 0x0
		public const string FactionHelpButton = "TeamSelectionScreen/FactionHelpButton"; //Field offset: 0x0
		public const string CorruptionsHelpButton = "TeamSelectionScreen/CorruptionsHelpButton"; //Field offset: 0x0
		public const string AnimaFilterButton = "TeamSelectionScreen/AnimaFilterButton"; //Field offset: 0x0
		public const string HeroFilterButton = "TeamSelectionScreen/HeroFilterButton"; //Field offset: 0x0
		public const string LeadHeroChangeButton = "TeamSelectionScreen/LeadHeroChangeButton"; //Field offset: 0x0
		public const string BackButton = "TeamSelectionScreen/BackButton"; //Field offset: 0x0
		public const string HomeButton = "TeamSelectionScreen/HomeButton"; //Field offset: 0x0

	}

	public static readonly HashSet<String> HzButtonsNames; //Field offset: 0x0

	private static UIElementsNames() { }

}

