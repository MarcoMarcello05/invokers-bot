namespace Client.CameraShake;

public struct CameraShakeInstance
{
	public CameraShakePreset Preset; //Field offset: 0x0
	public float TotalTimeLeft; //Field offset: 0x8
	public float CurrentFadeProgress; //Field offset: 0xC
	public float Tick; //Field offset: 0x10
	public Vector3 Shift; //Field offset: 0x14
	public float FOVShift; //Field offset: 0x20
	public bool IsInterrupting; //Field offset: 0x24
	public float FadeInTime; //Field offset: 0x28
	public float FadeOutTime; //Field offset: 0x2C
	public float SpeedFactor; //Field offset: 0x30

	public bool IsFadingOut
	{
		 get { } //Length: 40
	}

	public bool get_IsFadingOut() { }

}

