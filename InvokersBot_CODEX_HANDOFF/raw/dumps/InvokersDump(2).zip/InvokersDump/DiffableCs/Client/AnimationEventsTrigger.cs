//Type is in global namespace

public class AnimationEventsTrigger : MonoBehaviour
{
	public const string OnAnimationEventName = "OnVFX"; //Field offset: 0x0
	[FormerlySerializedAs("_gameObjectActivation")]
	[SerializeField]
	public List<AnimationEventProcessor> AnimationEvents; //Field offset: 0x20
	private readonly List<ValueTuple`2<AnimationEventProcessor, Single>> _processingEvents; //Field offset: 0x28
	private readonly List<AnimationEventProcessor> _restoringEvents; //Field offset: 0x30

	public AnimationEventsTrigger() { }

	private bool HasSameAraTrailTarget(AnimationEventProcessor processor, AnimationEventProcessor otherProcessor) { }

	private bool IsSameTargetProcessor(AnimationEventProcessor processor, AnimationEventProcessor otherProcessor) { }

	private void OnEnable() { }

	private void OnVFX(string eventName) { }

	private void ResetStates() { }

	private void Restore() { }

	private void RestoreEvent(AnimationEventProcessor processor) { }

	private void StopSameTargetProcessors(AnimationEventProcessor processor) { }

	private void Update() { }

}

