namespace Client.Characters;

[DisallowMultipleComponent]
public sealed class LobbyStagePart : MonoBehaviour, ICharacterViewPart
{
	public const string LIGHT_CONTAINER_NAME = "__Lights__"; //Field offset: 0x0
	[SerializeField]
	private bool _hidePlatform; //Field offset: 0x20
	[SerializeField]
	private bool _supportsFovInIntro; //Field offset: 0x21
	[SerializeField]
	private Transform _introCamera; //Field offset: 0x28
	[SerializeField]
	private Transform _followerRootBone; //Field offset: 0x30
	[SerializeField]
	private GameObject _customLight; //Field offset: 0x38
	private Transform _customLightParent; //Field offset: 0x40
	private Vector3 _customLightLocalPosition; //Field offset: 0x48
	private Quaternion _customLightLocalRotation; //Field offset: 0x54
	private string _customLightName; //Field offset: 0x68
	private bool _customLightExtracted; //Field offset: 0x70
	[SerializeField]
	private CharacterStandSide _battleResultStandSide; //Field offset: 0x74
	[SerializeField]
	private CharacterModelSize _lobbyModelSize; //Field offset: 0x78
	[SerializeField]
	private InfoPosition _revealShortInfoPosition; //Field offset: 0x7C

	public CharacterStandSide BattleResultStandSide
	{
		 get { } //Length: 8
	}

	public GameObject CustomLight
	{
		 get { } //Length: 8
	}

	public Transform FollowerRootBone
	{
		 get { } //Length: 8
	}

	public bool HidePlatform
	{
		 get { } //Length: 8
	}

	public Transform IntroCamera
	{
		 get { } //Length: 8
	}

	public CharacterModelSize LobbyModelSize
	{
		 get { } //Length: 8
	}

	public InfoPosition RevealShortInfoPosition
	{
		 get { } //Length: 8
	}

	public bool SupportsFovInIntro
	{
		 get { } //Length: 8
	}

	public LobbyStagePart() { }

	public void ExtractCustomLight() { }

	public CharacterStandSide get_BattleResultStandSide() { }

	public GameObject get_CustomLight() { }

	public Transform get_FollowerRootBone() { }

	public bool get_HidePlatform() { }

	public Transform get_IntroCamera() { }

	public CharacterModelSize get_LobbyModelSize() { }

	public InfoPosition get_RevealShortInfoPosition() { }

	public bool get_SupportsFovInIntro() { }

	private void OnValidate() { }

	public override void ResetForReuse() { }

	public void RestoreCustomLight() { }

	public void SetCustomLightVisible(bool visible) { }

}

