namespace Client.Core.Dialogs;

public class ButtonView : MonoBehaviour
{
	[SerializeField]
	private TextMeshProUGUI _labelText; //Field offset: 0x20
	[SerializeField]
	private Button _button; //Field offset: 0x28
	[SerializeField]
	private Image _image; //Field offset: 0x30

	public Button Button
	{
		 get { } //Length: 8
	}

	public ButtonView() { }

	public Button get_Button() { }

	public void SetText(string text) { }

}

