//Type is in global namespace

public class ftLightmaps
{
	private struct LightmapAdditionalData
	{
		public Texture2D rnm0; //Field offset: 0x0
		public Texture2D rnm1; //Field offset: 0x8
		public Texture2D rnm2; //Field offset: 0x10
		public int mode; //Field offset: 0x18

	}

	private static List<Int32> lightmapRefCount; //Field offset: 0x0
	private static List<LightmapAdditionalData> globalMapsAdditional; //Field offset: 0x8
	private static int directionalMode; //Field offset: 0x10

	private static ftLightmaps() { }

	public static GameObject FindInScene(string nm, Scene scn) { }

	private static Texture2D GetEmptyDirectionTex(ftLightmapsStorage storage) { }

	private static void OnSceneChangedPlay(Scene prev, Scene next) { }

	public static void RefreshScene(Scene scene, ftLightmapsStorage storage = null, bool updateNonBaked = false, bool incrementRefcount = false) { }

	public static void RefreshScene2(Scene scene, ftLightmapsStorage storage) { }

	private static void SetDirectionalMode() { }

	public static void UnloadScene(ftLightmapsStorage storage) { }

}

