namespace HitZone.ApnsDeviceToken;

public static class ApnsDeviceTokenBridge
{
	[CompilerGenerated]
	private static Action<Byte[]> DeviceTokenReceived; //Field offset: 0x0
	[CompilerGenerated]
	private static Byte[] <LastDeviceToken>k__BackingField; //Field offset: 0x8

	public static event Action<Byte[]> DeviceTokenReceived
	{
		[CompilerGenerated]
		 add { } //Length: 204
		[CompilerGenerated]
		 remove { } //Length: 204
	}

	public static Byte[] LastDeviceToken
	{
		[CompilerGenerated]
		 get { } //Length: 72
	}

	[CompilerGenerated]
	public static void add_DeviceTokenReceived(Action<Byte[]> value) { }

	[CompilerGenerated]
	public static Byte[] get_LastDeviceToken() { }

	[CompilerGenerated]
	public static void remove_DeviceTokenReceived(Action<Byte[]> value) { }

}

