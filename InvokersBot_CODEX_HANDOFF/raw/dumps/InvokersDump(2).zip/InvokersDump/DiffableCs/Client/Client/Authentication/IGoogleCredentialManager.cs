namespace Client.Authentication;

public interface IGoogleCredentialManager
{

	public ValueTask<AuthenticationResult> Authenticate(string nonce, CancellationToken ct = null) { }

	public void CancelSignIn() { }

}

