namespace Client.Common.UI;

public class HZTabGroup : HZTabGroup<TValue, HZTabButton>
{

	public HZTabGroup`1(ButtonCommandBuilder buttonCommandBuilder, IReadOnlyList<TValue> tabTypes, IReadOnlyList<HZTabButton> tabButtons, Func<TValue, ValueTask> selectTab, BlockingContext blockingContext = null, Func<TValue, Boolean> canExecuteFn = null, bool allowSelectAgain = false, bool allowDeselect = false) { }

}

