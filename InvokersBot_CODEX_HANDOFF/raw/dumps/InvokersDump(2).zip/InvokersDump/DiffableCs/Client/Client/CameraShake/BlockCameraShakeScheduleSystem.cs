namespace Client.CameraShake;

public class BlockCameraShakeScheduleSystem : IViewSystem
{
	private static readonly ILogger Log; //Field offset: 0x0
	private readonly FxConfigsProvider _configsProvider; //Field offset: 0x10
	private readonly CameraShakeViewDataPool _pool; //Field offset: 0x18
	private readonly SharedViewData _shared; //Field offset: 0x20

	private static BlockCameraShakeScheduleSystem() { }

	public BlockCameraShakeScheduleSystem(SharedViewData shared, FxConfigsProvider configsProvider, CameraShakeViewDataPool pool) { }

	private void ScheduleShakeForBlock(ModelEntity blockDataEntity, ModelEntity producerEntity, float speedFactor, BlockCameraShakeSlot shakeSlot) { }

	public override void Tick() { }

}

