namespace Client.Analytics.Marketing;

[Nullable(0)]
[NullableContext(1)]
internal sealed class AttributionEventsStateStore : IAttributionEventsState
{
	private static readonly Scope EnsureLoadedScope; //Field offset: 0x0
	private readonly SimpleFileStore<AttributionEventsState> _fileStore; //Field offset: 0x10
	private AttributionEventsState _state; //Field offset: 0x18
	private bool _isLoaded; //Field offset: 0x20

	private static AttributionEventsStateStore() { }

	public AttributionEventsStateStore(string filePath) { }

	public void EnsureLoaded() { }

	public override bool HasEvent(string key) { }

	public override void MarkSent(string key) { }

	public override void Reset(string key) { }

}

