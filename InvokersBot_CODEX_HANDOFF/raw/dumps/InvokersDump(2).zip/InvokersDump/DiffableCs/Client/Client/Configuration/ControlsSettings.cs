namespace Client.Configuration;

public static class ControlsSettings
{
	private const string ROOT = "ControlsSettings"; //Field offset: 0x0
	private static readonly ISettingsValues<Boolean> SwapMouseButtonsValue; //Field offset: 0x0
	private static readonly ISettingsValues<Boolean> CameraShakesEnabledValue; //Field offset: 0x8

	private static ControlsSettings() { }

	public static ISettingsValues<Boolean> CameraShakesEnabled() { }

	public static ISettingsValues<Boolean> SwapMouseButtons() { }

}

