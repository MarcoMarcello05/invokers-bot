namespace Client.CharacterControllers;

public class LookAtCamera : MonoBehaviour
{
	private Camera _camera; //Field offset: 0x20

	public LookAtCamera() { }

	public void Init(Camera mainCamera) { }

	private void LateUpdate() { }

}

