namespace Client.Authentication;

public class MobileGoogleAuthenticator : IGoogleAuthenticator
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass7_0
	{
		public MobileGoogleAuthenticator <>4__this; //Field offset: 0x10
		public CancellationToken cancellationToken; //Field offset: 0x18

		public <>c__DisplayClass7_0() { }

		internal void <AuthenticateAsync>b__0() { }

	}

	[CompilerGenerated]
	private struct <AuthenticateAsync>d__7 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncTaskMethodBuilder<AuthorizationCodeResponse> <>t__builder; //Field offset: 0x8
		public MobileGoogleAuthenticator <>4__this; //Field offset: 0x20
		public CancellationToken cancellationToken; //Field offset: 0x28
		public string stateForThisAuthAttempt; //Field offset: 0x30
		public string authorizationUrl; //Field offset: 0x38
		private <>c__DisplayClass7_0 <>8__1; //Field offset: 0x40
		private CancellationTokenRegistration <cancellationRegistration>5__2; //Field offset: 0x48
		private bool <isSubscribed>5__3; //Field offset: 0x60
		private object <>7__wrap3; //Field offset: 0x68
		private int <>7__wrap4; //Field offset: 0x70
		private AuthorizationCodeResponse <>7__wrap5; //Field offset: 0x78
		private CancellationTokenSource <timeoutCts>5__7; //Field offset: 0x80
		private Task <delayTask>5__8; //Field offset: 0x88
		private TaskAwaiter<Task> <>u__1; //Field offset: 0x90
		private TaskAwaiter<AuthorizationCodeResponse> <>u__2; //Field offset: 0x98
		private ValueTaskAwaiter <>u__3; //Field offset: 0xA0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly ILogger Log; //Field offset: 0x0
	private readonly IOptionsMonitor<GoogleAuthOptions> _options; //Field offset: 0x10
	private readonly DeepLinkService _deepLinkService; //Field offset: 0x18
	private TaskCompletionSource<AuthorizationCodeResponse> _currentAuthenticationAttemptTcs; //Field offset: 0x20
	private string _currentExpectedState; //Field offset: 0x28
	private string _deepLInkUrl; //Field offset: 0x30

	private static MobileGoogleAuthenticator() { }

	public MobileGoogleAuthenticator(IOptionsMonitor<GoogleAuthOptions> options, DeepLinkService deepLinkService) { }

	[AsyncStateMachine(typeof(<AuthenticateAsync>d__7))]
	public override Task<AuthorizationCodeResponse> AuthenticateAsync(string authorizationUrl, string expectedRedirectUri, string stateForThisAuthAttempt, CancellationToken cancellationToken) { }

	private bool HasTaskCanceledWithToken(AggregateException agg, CancellationToken token) { }

	private void OnDeepLinkReceived(DeepLink deepLink) { }

}

