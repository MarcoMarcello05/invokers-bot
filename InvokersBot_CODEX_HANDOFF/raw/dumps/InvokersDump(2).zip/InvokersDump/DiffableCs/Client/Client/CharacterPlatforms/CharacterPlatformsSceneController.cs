namespace Client.CharacterPlatforms;

[UsedAsInjection]
public class CharacterPlatformsSceneController : BaseViewController<CharacterPlatformsSceneView>
{
	[CompilerGenerated]
	private sealed class <ParallelInitFactory>d__15 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public CharacterPlatformsSceneController <>4__this; //Field offset: 0x28

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <ParallelInitFactory>d__15(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private sealed class <SequentialInitFactory>d__14 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public CharacterPlatformsSceneController <>4__this; //Field offset: 0x28
		private Enumerator<CharacterFaction, CharacterPlatform3dController> <>7__wrap1; //Field offset: 0x30
		private Enumerator<String, CharacterPlatform3dController> <>7__wrap2; //Field offset: 0x58

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <SequentialInitFactory>d__14(int <>1__state) { }

		private void <>m__Finally1() { }

		private void <>m__Finally2() { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	protected readonly IChoreographManager Choreograph; //Field offset: 0x68
	protected readonly IContentManager Content; //Field offset: 0x70
	private readonly IGameStateLifecycle _stateLifecycle; //Field offset: 0x78
	protected readonly Dictionary<CharacterFaction, CharacterPlatform3dController> FactionPlatformControllers; //Field offset: 0x80
	protected readonly Dictionary<String, CharacterPlatform3dController> NamedPlatformControllers; //Field offset: 0x88
	protected readonly LobbyCharacterPreviewLoader CharacterPreviewLoader; //Field offset: 0x90
	protected Nullable<CharacterVariant> CurrentVariant; //Field offset: 0x98

	protected override CameraPosition CameraPreset
	{
		 get { } //Length: 8
	}

	private static bool NeedToUseParallelInit
	{
		private get { } //Length: 8
	}

	public CharacterPlatformsSceneController(IChoreographManager choreograph, IContentManager content, IAssetProvider assetProvider, IJiggleScheduler jiggleScheduler, IGameStateLifecycle stateLifecycle, IStagingContainer stagingContainer) { }

	protected override CameraPosition get_CameraPreset() { }

	private static bool get_NeedToUseParallelInit() { }

	protected CharacterFaction GetFactionForBackground(CharacterFaction faction) { }

	protected virtual IEnumerable<IAsyncOperationWithProgress> InitFactory() { }

	private void OnCharacterLoadedHandle(CharacterFaction faction, LobbyCharacterController character) { }

	protected virtual void OnDisposing() { }

	protected virtual void OnViewLoaded() { }

	[IteratorStateMachine(typeof(<ParallelInitFactory>d__15))]
	private IEnumerable<IAsyncOperationWithProgress> ParallelInitFactory() { }

	[IteratorStateMachine(typeof(<SequentialInitFactory>d__14))]
	private IEnumerable<IAsyncOperationWithProgress> SequentialInitFactory() { }

	protected void SetBackgroundForCharacter(CharacterFaction faction, ICharacterPlatformsSceneView sceneView) { }

	protected void SetBackgroundForController(CharacterPlatform3dController toShow, ICharacterPlatformsSceneView sceneView) { }

	public void SetSwipeRect(RectTransform swipeRect) { }

	protected virtual IAsyncInitializable<CharacterPlatformsSceneView> ViewFactory() { }

}

