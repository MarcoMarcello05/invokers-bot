namespace Client.Common.UI;

public class HZRepeatableButton : HZButton
{
	[SerializeField]
	private float _velocity; //Field offset: 0x164
	[SerializeField]
	private float _minSpeed; //Field offset: 0x168
	[SerializeField]
	private float _maxSpeed; //Field offset: 0x16C
	[SerializeField]
	private ButtonSoundReference _pressSoundRef; //Field offset: 0x170
	[SerializeField]
	private ButtonSoundReference _repeatingSoundRef; //Field offset: 0x178
	private float _speed; //Field offset: 0x180
	private float _counter; //Field offset: 0x184
	private readonly Subject<Unit> _onLongPressSubject; //Field offset: 0x188

	public Observable<Unit> LongPressTriggered
	{
		 get { } //Length: 8
	}

	public HZRepeatableButton() { }

	public Observable<Unit> get_LongPressTriggered() { }

	public virtual void OnPointerDown(PointerEventData eventData) { }

	private void Update() { }

}

