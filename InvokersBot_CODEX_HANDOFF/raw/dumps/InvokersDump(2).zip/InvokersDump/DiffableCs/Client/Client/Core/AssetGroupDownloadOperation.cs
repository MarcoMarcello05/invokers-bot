namespace Client.Core;

[Nullable(0)]
[NullableContext(1)]
public class AssetGroupDownloadOperation : IAsyncOperationWithProgress
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass27_0
	{
		[Nullable(0)]
		public AssetGroupDownloadOperation <>4__this; //Field offset: 0x10
		[Nullable(0)]
		public IOperationProgressObserver onProgressChange; //Field offset: 0x18

		public <>c__DisplayClass27_0() { }

		internal void <Download>b__0(DownloadStatus status) { }

	}

	[CompilerGenerated]
	private struct <Download>d__27 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public AssetGroupDownloadOperation <>4__this; //Field offset: 0x18
		[Nullable(0)]
		public IOperationProgressObserver onProgressChange; //Field offset: 0x20
		[Nullable(0)]
		private <>c__DisplayClass27_0 <>8__1; //Field offset: 0x28
		private AutoScope <_>5__2; //Field offset: 0x30
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private Awaiter<AssetListDownloadRequest> <>u__1; //Field offset: 0x48

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <TrackDownloadSpeedAsync>d__29 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public AssetGroupDownloadOperation <>4__this; //Field offset: 0x18
		private long <previousDownloadedSize>5__2; //Field offset: 0x20
		private Awaiter <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity DownloadActivity; //Field offset: 0x0
	private static readonly ILogger Logger; //Field offset: 0x10
	private readonly IReadOnlyCollection<AssetKey> _assetsToDownload; //Field offset: 0x10
	private readonly IContentManager _content; //Field offset: 0x18
	private readonly AsyncOperationWithProgress _operation; //Field offset: 0x20
	private readonly CancellationToken _ct; //Field offset: 0x28
	private UniTaskCompletionSource _statsRetrievedTcs; //Field offset: 0x30
	private DownloadStatus _status; //Field offset: 0x38
	private double _currentDownloadSpeedMb; //Field offset: 0x50
	[CompilerGenerated]
	private long <DownloadedContentBytes>k__BackingField; //Field offset: 0x58
	[CompilerGenerated]
	private long <TotalContentBytes>k__BackingField; //Field offset: 0x60

	public IReadOnlyCollection<AssetKey> AssetKeys
	{
		 get { } //Length: 8
	}

	public override UniTask CompletedTask
	{
		 get { } //Length: 36
	}

	public private long DownloadedContentBytes
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public override string OperationId
	{
		 get { } //Length: 24
	}

	public UniTask StatsRetrievedTask
	{
		 get { } //Length: 24
	}

	public private long TotalContentBytes
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	private static AssetGroupDownloadOperation() { }

	public AssetGroupDownloadOperation(string operationId, IReadOnlyCollection<AssetKey> assetKeys, IContentManager content, CancellationToken ct = null) { }

	public AssetGroupDownloadOperation(string operationId, AssetKey assetKey, IContentManager content, CancellationToken ct = null) { }

	public override bool AttachProgressObserver(IOperationProgressObserver progressObserver) { }

	[AsyncStateMachine(typeof(<Download>d__27))]
	private UniTask Download(IOperationProgressObserver onProgressChange) { }

	[NullableContext(2)]
	public override UniTask ExecuteOperationAsync(IOperationProgressObserver onProgressChange = null) { }

	public IReadOnlyCollection<AssetKey> get_AssetKeys() { }

	public override UniTask get_CompletedTask() { }

	[CompilerGenerated]
	public long get_DownloadedContentBytes() { }

	public override string get_OperationId() { }

	public UniTask get_StatsRetrievedTask() { }

	[CompilerGenerated]
	public long get_TotalContentBytes() { }

	[NullableContext(0)]
	public UniTask<Int64> GetDownloadSizeAsync() { }

	[NullableContext(2)]
	private void OnDownloadProgress(DownloadStatus downloadStatus, IOperationProgressObserver onProgressChange) { }

	[NullableContext(2)]
	protected override void ReportCompletion(IOperationProgressObserver onProgressChange) { }

	[CompilerGenerated]
	private void set_DownloadedContentBytes(long value) { }

	[CompilerGenerated]
	private void set_TotalContentBytes(long value) { }

	public virtual string ToString() { }

	[AsyncStateMachine(typeof(<TrackDownloadSpeedAsync>d__29))]
	private UniTask TrackDownloadSpeedAsync() { }

}

