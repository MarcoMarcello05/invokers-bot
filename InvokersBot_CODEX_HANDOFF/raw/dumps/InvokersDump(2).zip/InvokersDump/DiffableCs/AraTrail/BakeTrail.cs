//Type is in global namespace

[RequireComponent(typeof(AraTrail))]
public class BakeTrail : MonoBehaviour
{
	private AraTrail trail; //Field offset: 0x20

	public BakeTrail() { }

	private void Awake() { }

	private void Bake() { }

	private void Update() { }

}

