namespace Client.CharacterPlatforms;

public interface ICharacterPlatform3dView
{

	public Transform Back
	{
		 get { } //Length: 0
	}

	public CharacterFaction CharacterFaction
	{
		 get { } //Length: 0
	}

	public Transform Container
	{
		 get { } //Length: 0
	}

	public GameObject Platform
	{
		 get { } //Length: 0
	}

	public Transform get_Back() { }

	public CharacterFaction get_CharacterFaction() { }

	public Transform get_Container() { }

	public GameObject get_Platform() { }

}

