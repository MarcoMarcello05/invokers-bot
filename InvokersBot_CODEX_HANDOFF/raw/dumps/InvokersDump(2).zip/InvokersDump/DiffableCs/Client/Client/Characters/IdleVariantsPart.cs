namespace Client.Characters;

[DisallowMultipleComponent]
public sealed class IdleVariantsPart : MonoBehaviour, ICharacterViewPart
{
	[SerializeField]
	private bool _hasIdleTeam; //Field offset: 0x20
	[SerializeField]
	private bool _hasIdleHome; //Field offset: 0x21

	public bool HasIdleHome
	{
		 get { } //Length: 8
	}

	public bool HasIdleTeam
	{
		 get { } //Length: 8
	}

	public IdleVariantsPart() { }

	public bool get_HasIdleHome() { }

	public bool get_HasIdleTeam() { }

	public override void ResetForReuse() { }

}

