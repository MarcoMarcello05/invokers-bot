namespace Client.Common.DI;

[Extension]
public static class AssemblyExtension
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<Type, Boolean> <>9__0_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal bool <GetTypesImplementingInterface>b__0_0(Type type) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass0_0
	{
		public Type[] interfaceType; //Field offset: 0x10

		public <>c__DisplayClass0_0() { }

		internal bool <GetTypesImplementingInterface>b__1(Type type) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass0_1
	{
		public Type type; //Field offset: 0x10

		public <>c__DisplayClass0_1() { }

		internal bool <GetTypesImplementingInterface>b__2(Type x) { }

	}


	[Extension]
	public static IEnumerable<Type> GetTypesImplementingInterface(Assembly assembly, Type[] interfaceType) { }

}

