//Type is in global namespace

public class ftGlobalStorage : ScriptableObject
{

	public ftGlobalStorage() { }

}

