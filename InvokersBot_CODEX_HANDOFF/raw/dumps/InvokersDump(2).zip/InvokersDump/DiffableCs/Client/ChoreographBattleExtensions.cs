//Type is in global namespace

[Extension]
public static class ChoreographBattleExtensions
{
	[CompilerGenerated]
	private struct <ExecuteArenaBattleAction>d__2 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public HzGuid opponentId; //Field offset: 0x18
		public TeamFormation playerTeamFormation; //Field offset: 0x28
		public Guid battleId; //Field offset: 0x30
		public DateTime now; //Field offset: 0x40
		public IChoreographManager choreograph; //Field offset: 0x48
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		private ValueTaskAwaiter<IEventData[]> <>u__1; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ExecuteBattleOfflineAction>d__1 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public LevelInfo levelConfig; //Field offset: 0x18
		public TeamFormation teamFormation; //Field offset: 0x20
		public Guid battleId; //Field offset: 0x28
		public DateTime now; //Field offset: 0x38
		public IChoreographManager choreograph; //Field offset: 0x40
		public int multiBattleNumber; //Field offset: 0x48
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		private ValueTaskAwaiter<IEventData[]> <>u__1; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <StartBattle>d__3 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder<MetaBattleSetup> <>t__builder; //Field offset: 0x8
		public IChoreographManager choreograph; //Field offset: 0x20
		public LevelInfo levelConfig; //Field offset: 0x28
		public TeamFormation teamFormation; //Field offset: 0x30
		public int multiBattleNumber; //Field offset: 0x38
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 1})]
		private ValueTaskAwaiter<IEventData[]> <>u__1; //Field offset: 0x40
		private Awaiter <>u__2; //Field offset: 0x58

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly ILogger Logger; //Field offset: 0x0

	private static ChoreographBattleExtensions() { }

	[AsyncStateMachine(typeof(<ExecuteArenaBattleAction>d__2))]
	[Extension]
	public static UniTask ExecuteArenaBattleAction(IChoreographManager choreograph, HzGuid opponentId, TeamFormation playerTeamFormation, Guid battleId, DateTime now) { }

	[AsyncStateMachine(typeof(<ExecuteBattleOfflineAction>d__1))]
	[Extension]
	public static UniTask ExecuteBattleOfflineAction(IChoreographManager choreograph, LevelInfo levelConfig, TeamFormation teamFormation, Guid battleId, DateTime now, int multiBattleNumber) { }

	[AsyncStateMachine(typeof(<StartBattle>d__3))]
	[Extension]
	public static UniTask<MetaBattleSetup> StartBattle(IChoreographManager choreograph, LevelInfo levelConfig, TeamFormation teamFormation, int multiBattleNumber) { }

	[Extension]
	public static bool ValidateBattleLevelAvailable(IChoreographManager choreograph, IStartLevelBattleValidator validator, IErrorDialogBuilder dialogBuilder, long levelConfigId, int multiBattleNumber = 0) { }

}

