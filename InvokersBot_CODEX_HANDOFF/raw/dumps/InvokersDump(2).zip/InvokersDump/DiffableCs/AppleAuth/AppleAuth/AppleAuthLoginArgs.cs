namespace AppleAuth;

public struct AppleAuthLoginArgs
{
	public readonly LoginOptions Options; //Field offset: 0x0
	public readonly string Nonce; //Field offset: 0x8
	public readonly string State; //Field offset: 0x10

	public AppleAuthLoginArgs(LoginOptions options, string nonce = null, string state = null) { }

}

