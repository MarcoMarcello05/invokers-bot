namespace AppsFlyerSDK;

public enum AFPurchaseType : int
{
	Subscription = 0,
	OneTimePurchase = 1,
}

