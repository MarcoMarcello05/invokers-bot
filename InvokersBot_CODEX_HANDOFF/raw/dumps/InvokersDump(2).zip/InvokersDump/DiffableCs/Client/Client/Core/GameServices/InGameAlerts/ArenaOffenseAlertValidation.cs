namespace Client.Core.GameServices.InGameAlerts;

public struct ArenaOffenseAlertValidation : IEquatable<ArenaOffenseAlertValidation>
{
	private const ResourceTypeId ARENA_BATTLE_PRICE_RESOURCE_TYPE_ID = 21; //Field offset: 0x0
	private readonly IChoreographManager _choreographManager; //Field offset: 0x0
	private readonly IClientServerTimeProvider _clientServerTimeProvider; //Field offset: 0x8

	public ArenaOffenseAlertValidation(IChoreographManager choreographManager, IClientServerTimeProvider clientServerTimeProvider) { }

	[CompilerGenerated]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	public override bool Equals(ArenaOffenseAlertValidation other) { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	public ValidationResult IsValidToShow(InGameAlert alert) { }

	[CompilerGenerated]
	public static bool op_Equality(ArenaOffenseAlertValidation left, ArenaOffenseAlertValidation right) { }

	[CompilerGenerated]
	public static bool op_Inequality(ArenaOffenseAlertValidation left, ArenaOffenseAlertValidation right) { }

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	public virtual string ToString() { }

}

