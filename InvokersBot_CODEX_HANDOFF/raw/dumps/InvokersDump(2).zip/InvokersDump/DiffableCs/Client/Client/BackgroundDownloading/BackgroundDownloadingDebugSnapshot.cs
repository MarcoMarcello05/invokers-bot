namespace Client.BackgroundDownloading;

public struct BackgroundDownloadingDebugSnapshot : IEquatable<BackgroundDownloadingDebugSnapshot>
{
	[CompilerGenerated]
	private readonly BackgroundDownloadingServiceStatus <ServiceStatus>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private readonly BackgroundDownloadingProgress <Progress>k__BackingField; //Field offset: 0x8
	[CompilerGenerated]
	private readonly int <ActiveOperationsCount>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly int <ActiveTrackedKeysCount>k__BackingField; //Field offset: 0x14
	[CompilerGenerated]
	private readonly long <ActiveDownloadedBytes>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly long <ActiveTotalBytes>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private readonly string <DebugDownloadName>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private readonly bool <IsDebugDownloadRunning>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private readonly bool <DebugDownloadCanceled>k__BackingField; //Field offset: 0x31
	[CompilerGenerated]
	private readonly long <DebugDownloadedBytes>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private readonly long <DebugTotalBytes>k__BackingField; //Field offset: 0x40
	[CompilerGenerated]
	private readonly long <DebugRequestedBytes>k__BackingField; //Field offset: 0x48

	public long ActiveDownloadedBytes
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public DownloadStatus ActiveDownloadStatus
	{
		 get { } //Length: 48
	}

	public int ActiveOperationsCount
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public long ActiveTotalBytes
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public int ActiveTrackedKeysCount
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public bool DebugDownloadCanceled
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public long DebugDownloadedBytes
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string DebugDownloadName
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public long DebugRequestedBytes
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public long DebugTotalBytes
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public bool HasActiveDownloads
	{
		 get { } //Length: 36
	}

	public bool IsDebugDownloadRunning
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public BackgroundDownloadingProgress Progress
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public BackgroundDownloadingServiceStatus ServiceStatus
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public BackgroundDownloadingDebugSnapshot(BackgroundDownloadingServiceStatus ServiceStatus, BackgroundDownloadingProgress Progress, int ActiveOperationsCount, int ActiveTrackedKeysCount, long ActiveDownloadedBytes, long ActiveTotalBytes, string DebugDownloadName, bool IsDebugDownloadRunning, bool DebugDownloadCanceled, long DebugDownloadedBytes, long DebugTotalBytes, long DebugRequestedBytes) { }

	[CompilerGenerated]
	public void Deconstruct(out BackgroundDownloadingServiceStatus ServiceStatus, out BackgroundDownloadingProgress Progress, out int ActiveOperationsCount, out int ActiveTrackedKeysCount, out long ActiveDownloadedBytes, out long ActiveTotalBytes, out string DebugDownloadName, out bool IsDebugDownloadRunning, out bool DebugDownloadCanceled, out long DebugDownloadedBytes, out long DebugTotalBytes, out long DebugRequestedBytes) { }

	[CompilerGenerated]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	public override bool Equals(BackgroundDownloadingDebugSnapshot other) { }

	[CompilerGenerated]
	public long get_ActiveDownloadedBytes() { }

	public DownloadStatus get_ActiveDownloadStatus() { }

	[CompilerGenerated]
	public int get_ActiveOperationsCount() { }

	[CompilerGenerated]
	public long get_ActiveTotalBytes() { }

	[CompilerGenerated]
	public int get_ActiveTrackedKeysCount() { }

	[CompilerGenerated]
	public bool get_DebugDownloadCanceled() { }

	[CompilerGenerated]
	public long get_DebugDownloadedBytes() { }

	[CompilerGenerated]
	public string get_DebugDownloadName() { }

	[CompilerGenerated]
	public long get_DebugRequestedBytes() { }

	[CompilerGenerated]
	public long get_DebugTotalBytes() { }

	public bool get_HasActiveDownloads() { }

	[CompilerGenerated]
	public bool get_IsDebugDownloadRunning() { }

	[CompilerGenerated]
	public BackgroundDownloadingProgress get_Progress() { }

	[CompilerGenerated]
	public BackgroundDownloadingServiceStatus get_ServiceStatus() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	public static bool op_Equality(BackgroundDownloadingDebugSnapshot left, BackgroundDownloadingDebugSnapshot right) { }

	[CompilerGenerated]
	public static bool op_Inequality(BackgroundDownloadingDebugSnapshot left, BackgroundDownloadingDebugSnapshot right) { }

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	public void set_ActiveDownloadedBytes(long value) { }

	[CompilerGenerated]
	public void set_ActiveOperationsCount(int value) { }

	[CompilerGenerated]
	public void set_ActiveTotalBytes(long value) { }

	[CompilerGenerated]
	public void set_ActiveTrackedKeysCount(int value) { }

	[CompilerGenerated]
	public void set_DebugDownloadCanceled(bool value) { }

	[CompilerGenerated]
	public void set_DebugDownloadedBytes(long value) { }

	[CompilerGenerated]
	public void set_DebugDownloadName(string value) { }

	[CompilerGenerated]
	public void set_DebugRequestedBytes(long value) { }

	[CompilerGenerated]
	public void set_DebugTotalBytes(long value) { }

	[CompilerGenerated]
	public void set_IsDebugDownloadRunning(bool value) { }

	[CompilerGenerated]
	public void set_Progress(BackgroundDownloadingProgress value) { }

	[CompilerGenerated]
	public void set_ServiceStatus(BackgroundDownloadingServiceStatus value) { }

	public virtual string ToString() { }

}

