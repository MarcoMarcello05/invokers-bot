namespace Client.CharacterPlatforms;

public sealed class CharacterPlatformsSceneView : BaseView, ICharacterPlatformsSceneView
{
	[SerializeField]
	private Transform _platformsRoot; //Field offset: 0x58
	[SerializeField]
	private LobbyCameraController _camera; //Field offset: 0x60
	[SerializeField]
	private Transform _visibleLocation; //Field offset: 0x68
	[SerializeField]
	private Transform _hiddenLocation; //Field offset: 0x70
	[SerializeField]
	private GameObject _loadingVfxObject; //Field offset: 0x78
	[SerializeField]
	private GameObject _lightsRoot; //Field offset: 0x80

	public override ICharacterPlatformsCamera Camera
	{
		 get { } //Length: 8
	}

	public override Vector3 HiddenPosition
	{
		 get { } //Length: 24
	}

	public GameObject LightsRoot
	{
		 get { } //Length: 8
	}

	public override Transform LoadingVfxTransform
	{
		 get { } //Length: 24
	}

	public override Transform PlatformsRoot
	{
		 get { } //Length: 8
	}

	public override Vector3 VisiblePosition
	{
		 get { } //Length: 24
	}

	public CharacterPlatformsSceneView() { }

	public override ICharacterPlatformsCamera get_Camera() { }

	public override Vector3 get_HiddenPosition() { }

	public GameObject get_LightsRoot() { }

	public override Transform get_LoadingVfxTransform() { }

	public override Transform get_PlatformsRoot() { }

	public override Vector3 get_VisiblePosition() { }

	public void Init() { }

	private void LateUpdate() { }

	public static AsyncLoadedScene<CharacterPlatformsSceneView> Load(IContentManager content, IGameStateLifecycle stateLifecycle) { }

	private void OnValidate() { }

}

