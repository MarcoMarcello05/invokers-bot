namespace Client.Core;

public static class AsyncOperationConstants
{
	public const int LOAD_FROM_LOCAL_CACHE_WEIGHT = 5; //Field offset: 0x0
	public const int SERVICE_DEFAULT_WEIGHT = 1; //Field offset: 0x0

	public static int ConvertRequiredBytesToWeight(long bytes) { }

}

