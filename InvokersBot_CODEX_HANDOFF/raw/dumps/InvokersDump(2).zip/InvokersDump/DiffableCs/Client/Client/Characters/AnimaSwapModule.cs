namespace Client.Characters;

public sealed class AnimaSwapModule : ICharacterModule, IDisposable
{
	[CompilerGenerated]
	private struct <HideAfterAsync>d__14 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskVoidMethodBuilder <>t__builder; //Field offset: 0x8
		public float duration; //Field offset: 0x10
		public CancellationToken token; //Field offset: 0x18
		public AnimaSwapModule <>4__this; //Field offset: 0x20
		private Awaiter<Boolean> <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly CharacterAnimationModule _animation; //Field offset: 0x10
	private readonly CharacterSoundModule _sound; //Field offset: 0x18
	private CancellationTokenSource _hideCts; //Field offset: 0x20
	private CharacterView _view; //Field offset: 0x28
	private Transform _defaultParent; //Field offset: 0x30

	public AnimaSwapModule(CharacterAnimationModule animation, CharacterSoundModule sound) { }

	public override void Bind(CharacterView view) { }

	private void CancelPendingHide() { }

	public override void Dispose() { }

	public void FollowTransform(Transform followerTransform) { }

	public void HeroAnimaIn(float duration) { }

	public void HeroAnimaOut() { }

	[AsyncStateMachine(typeof(<HideAfterAsync>d__14))]
	private UniTaskVoid HideAfterAsync(float duration, CancellationToken token) { }

	public void PlayAnimaSound(SkillType type) { }

	public void StopFollowing() { }

	public override void Unbind() { }

}

