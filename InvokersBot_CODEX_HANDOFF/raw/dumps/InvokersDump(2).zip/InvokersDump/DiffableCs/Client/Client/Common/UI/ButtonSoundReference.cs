namespace Client.Common.UI;

public class ButtonSoundReference
{
	internal enum ButtonSoundType : int
	{
		None = 0,
		Default = 1,
		ClickTab = 2,
		ButtonLocked = 3,
		Bottle = 4,
		ClickAdd = 5,
		ClickBack = 6,
		ClickBattle = 7,
		ClickLeave = 8,
		ClickLevelUp = 9,
		ExpandIn = 10,
		ExpandOut = 11,
		Custom = 12,
	}

	private static readonly Dictionary<ButtonSoundType, String> SoundLookup; //Field offset: 0x0
	public ButtonSoundType SoundType; //Field offset: 0x10
	public string CustomSoundPath; //Field offset: 0x18
	private EventInstance _event; //Field offset: 0x20

	private static ButtonSoundReference() { }

	public ButtonSoundReference() { }

	public void PlaySound() { }

	public void Stop() { }

}

