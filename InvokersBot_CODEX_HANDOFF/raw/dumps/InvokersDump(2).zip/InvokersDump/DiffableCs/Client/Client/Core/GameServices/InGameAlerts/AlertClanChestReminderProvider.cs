namespace Client.Core.GameServices.InGameAlerts;

internal sealed class AlertClanChestReminderProvider : IAlertClanChestReminderProvider
{
	[CompilerGenerated]
	private struct <AwaitLoadAsync>d__10 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public IAssetRequest<SpritePresetList> request; //Field offset: 0x18
		public ClanChestReminderSource source; //Field offset: 0x20
		public AlertClanChestReminderProvider <>4__this; //Field offset: 0x28
		public UniTaskCompletionSource<Boolean> completionSource; //Field offset: 0x30
		private Awaiter<SpritePresetList> <>u__1; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IContentManager _contentManager; //Field offset: 0x10
	private readonly Dictionary<ClanChestReminderSource, IAssetRequest`1<SpritePresetList>> _requestBySource; //Field offset: 0x18
	private readonly Dictionary<ClanChestReminderSource, SpritePresetList> _loadedBySource; //Field offset: 0x20
	private readonly Dictionary<ClanChestReminderSource, UniTaskCompletionSource`1<Boolean>> _pendingLoadBySource; //Field offset: 0x28

	public AlertClanChestReminderProvider(IContentManager contentManager) { }

	[AsyncStateMachine(typeof(<AwaitLoadAsync>d__10))]
	private UniTask AwaitLoadAsync(ClanChestReminderSource source, IAssetRequest<SpritePresetList> request, UniTaskCompletionSource<Boolean> completionSource) { }

	private void CancelPendingLoad(ClanChestReminderSource source) { }

	public override void Clear() { }

	private void CompleteIfCurrent(ClanChestReminderSource source, UniTaskCompletionSource<Boolean> completionSource, bool result) { }

	public override UniTask<Boolean> EnsureLoadedAsync(ClanChestReminderSource source) { }

	public override Sprite Get(ClanChestReminderSource source, int tier) { }

	public override void Release(ClanChestReminderSource source) { }

	private static AssetKey ResolveKey(ClanChestReminderSource source) { }

}

