namespace Client.Core.Dialogs;

public class StaticModalPopupController : AwaitableDialogController<StaticModalPopup>
{
	private readonly IContentManager _content; //Field offset: 0x88
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x90
	private readonly AssetKey _assetKey; //Field offset: 0x98
	private readonly Action<StaticModalPopupController, StaticModalPopup> _configurePopup; //Field offset: 0xA0

	public StaticModalPopupController(IContentManager content, IStagingContainer stagingContainer, IUISystem uiSystem, AssetKey assetKey, Action<StaticModalPopupController, StaticModalPopup> configurePopup) { }

	protected virtual void OnViewLoaded() { }

	protected virtual IAsyncInitializable<StaticModalPopup> ViewFactory() { }

}

