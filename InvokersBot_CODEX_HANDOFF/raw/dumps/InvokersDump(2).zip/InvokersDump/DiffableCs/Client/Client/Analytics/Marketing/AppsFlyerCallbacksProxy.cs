namespace Client.Analytics.Marketing;

[Nullable(0)]
[NullableContext(1)]
public class AppsFlyerCallbacksProxy : MonoBehaviour, IAppsFlyerConversionData, IAppsFlyerPurchaseValidation, IAppsFlyerPurchaseRevenueDataSourceStoreKit2
{
	private static readonly ILogger Log; //Field offset: 0x0
	[Nullable(new IL2CPP_TYPE_U1[] {2, 1})]
	private Action<String> _conversionDataSuccess; //Field offset: 0x20
	[Nullable(new IL2CPP_TYPE_U1[] {2, 1})]
	private Action<String> _conversionDataFail; //Field offset: 0x28
	private bool _isSandbox; //Field offset: 0x30
	private Dictionary<String, Object> _purchaseRevenueAdditionalParameters; //Field offset: 0x38

	private static AppsFlyerCallbacksProxy() { }

	public AppsFlyerCallbacksProxy() { }

	private void ConfigurePurchaseConnector() { }

	public override void didReceivePurchaseRevenueError(string error) { }

	public override void didReceivePurchaseRevenueValidationInfo(string validationInfo) { }

	public void Initialize(Action<String> conversionDataSuccess, Action<String> conversionDataFail, bool isSandbox) { }

	public override void onAppOpenAttribution(string attributionData) { }

	public override void onAppOpenAttributionFailure(string error) { }

	public override void onConversionDataFail(string error) { }

	public override void onConversionDataSuccess(string conversionData) { }

	public Dictionary<String, Object> PurchaseRevenueAdditionalParametersForProducts(HashSet<Object> products, HashSet<Object> transactions) { }

	public override Dictionary<String, Object> PurchaseRevenueAdditionalParametersStoreKit2ForProducts(HashSet<Object> products, HashSet<Object> transactions) { }

}

