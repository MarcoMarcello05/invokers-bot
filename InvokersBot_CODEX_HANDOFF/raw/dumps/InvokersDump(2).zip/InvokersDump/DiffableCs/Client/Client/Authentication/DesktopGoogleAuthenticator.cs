namespace Client.Authentication;

public class DesktopGoogleAuthenticator : IGoogleAuthenticator
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass3_0
	{
		public TaskCompletionSource<AuthorizationCodeResponse> tcs; //Field offset: 0x10
		public CancellationToken cancellationToken; //Field offset: 0x18

		public <>c__DisplayClass3_0() { }

		internal void <AuthenticateAsync>b__0() { }

	}

	[CompilerGenerated]
	private struct <AuthenticateAsync>d__3 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncTaskMethodBuilder<AuthorizationCodeResponse> <>t__builder; //Field offset: 0x8
		public CancellationToken cancellationToken; //Field offset: 0x20
		public DesktopGoogleAuthenticator <>4__this; //Field offset: 0x28
		public string expectedState; //Field offset: 0x30
		public string expectedRedirectUriPrefix; //Field offset: 0x38
		public string authorizationUrl; //Field offset: 0x40
		private <>c__DisplayClass3_0 <>8__1; //Field offset: 0x48
		private HttpListener <httpListener>5__2; //Field offset: 0x50
		private CancellationTokenRegistration <cancellationRegistration>5__3; //Field offset: 0x58
		private object <>7__wrap3; //Field offset: 0x70
		private int <>7__wrap4; //Field offset: 0x78
		private AuthorizationCodeResponse <>7__wrap5; //Field offset: 0x80
		private Task<HttpListenerContext> <getContextTask>5__7; //Field offset: 0x88
		private TaskAwaiter<Task> <>u__1; //Field offset: 0x90
		private TaskAwaiter<AuthorizationCodeResponse> <>u__2; //Field offset: 0x98
		private ValueTaskAwaiter <>u__3; //Field offset: 0xA0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly ILogger Log; //Field offset: 0x0
	private readonly IOptionsMonitor<GoogleAuthOptions> _options; //Field offset: 0x10

	private static DesktopGoogleAuthenticator() { }

	public DesktopGoogleAuthenticator(IOptionsMonitor<GoogleAuthOptions> options) { }

	[AsyncStateMachine(typeof(<AuthenticateAsync>d__3))]
	public override Task<AuthorizationCodeResponse> AuthenticateAsync(string authorizationUrl, string expectedRedirectUriPrefix, string expectedState, CancellationToken cancellationToken) { }

	private static string GenerateBrowserResponseHtml(string error) { }

}

