//Type is in global namespace

[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Shared_LOD_UV")]
public class BakerySharedLodUv : MonoBehaviour
{

	public BakerySharedLodUv() { }

}

