namespace Client.Configuration;

[Nullable(0)]
[NullableContext(2)]
public class EnvironmentVariablesConfigurationSource : IConfigurationSource
{
	[CompilerGenerated]
	private string <Prefix>k__BackingField; //Field offset: 0x10

	public string Prefix
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public EnvironmentVariablesConfigurationSource() { }

	[NullableContext(1)]
	public override IConfigurationProvider Build(IConfigurationBuilder builder) { }

	[CompilerGenerated]
	public string get_Prefix() { }

	[CompilerGenerated]
	public void set_Prefix(string value) { }

}

