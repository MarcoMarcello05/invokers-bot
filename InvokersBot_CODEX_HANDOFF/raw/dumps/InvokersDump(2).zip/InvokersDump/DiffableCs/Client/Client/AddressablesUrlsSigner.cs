namespace Client;

public sealed class AddressablesUrlsSigner
{
	public const string CDN_BUNDLES_SIGNATURE_FILE_NAME = "cdn-bundles-signature"; //Field offset: 0x0
	public const string CDN_BUNDLES_SIGNATURE_FILE_PATH = "Assets/Resources/cdn-bundles-signature.txt"; //Field offset: 0x0
	private readonly string _catalogJsonFileName; //Field offset: 0x10
	private readonly string _catalogBinaryFileName; //Field offset: 0x18
	private readonly string _catalogHashFileName; //Field offset: 0x20
	private string _cdnUrlSignedQuery; //Field offset: 0x28

	private static bool UseDebugLogs
	{
		private get { } //Length: 8
	}

	public AddressablesUrlsSigner() { }

	private void EditWebRequestURL(UnityWebRequest request) { }

	private static bool get_UseDebugLogs() { }

	public void Init(IResourcesApi resourcesApi) { }

}

