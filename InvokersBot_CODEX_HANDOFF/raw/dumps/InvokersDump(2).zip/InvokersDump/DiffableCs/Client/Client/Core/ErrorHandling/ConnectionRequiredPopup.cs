namespace Client.Core.ErrorHandling;

[Nullable(0)]
[NullableContext(1)]
public sealed class ConnectionRequiredPopup : BaseDialogView, IConnectionRequiredPopup, IDialogView, IView
{
	[SerializeField]
	private TextMeshProUGUI _title; //Field offset: 0x58
	[SerializeField]
	private TextMeshProUGUI _description; //Field offset: 0x60
	[SerializeField]
	private TextMeshProUGUI _sessionDebugInfo; //Field offset: 0x68
	[SerializeField]
	private HZButton _confirmButton; //Field offset: 0x70
	[SerializeField]
	private HZButton _supportButton; //Field offset: 0x78
	[SerializeField]
	private HZButton _tryReconnectNowButton; //Field offset: 0x80

	public override IButton CloseButton
	{
		 get { } //Length: 8
	}

	public override IButton SupportButton
	{
		 get { } //Length: 8
	}

	public override IButton TryReconnectNowButton
	{
		 get { } //Length: 8
	}

	public ConnectionRequiredPopup() { }

	public override IButton get_CloseButton() { }

	public override IButton get_SupportButton() { }

	public override IButton get_TryReconnectNowButton() { }

	private void OnValidate() { }

	public override void SetActionsInteractable(bool interactable) { }

	public override void SetContent(string description) { }

	public override void SetReconnectButtonActive(bool isActive) { }

	public override void SetSessionDebugInfo(string sessionDebugInfo) { }

	public override void SetSupportButtonActive(bool isActive) { }

}

