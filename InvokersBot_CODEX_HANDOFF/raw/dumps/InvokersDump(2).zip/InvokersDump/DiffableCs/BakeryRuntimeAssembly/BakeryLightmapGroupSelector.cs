//Type is in global namespace

[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Lightmap_Group_Selector")]
public class BakeryLightmapGroupSelector : MonoBehaviour
{
	public bool active; //Field offset: 0x20
	public object lmgroupAsset; //Field offset: 0x28
	public bool instanceResolutionOverride; //Field offset: 0x30
	public int instanceResolution; //Field offset: 0x34

	public BakeryLightmapGroupSelector() { }

}

