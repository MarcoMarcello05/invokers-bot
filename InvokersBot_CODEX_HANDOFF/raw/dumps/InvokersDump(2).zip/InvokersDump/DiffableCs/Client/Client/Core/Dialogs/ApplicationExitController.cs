namespace Client.Core.Dialogs;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public sealed class ApplicationExitController : IGameService, IDisposable
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass23_0
	{
		[Nullable(0)]
		public ApplicationExitController <>4__this; //Field offset: 0x10
		[Nullable(0)]
		public UniTaskCompletionSource<Boolean> tcs; //Field offset: 0x18

		public <>c__DisplayClass23_0() { }

		[NullableContext(0)]
		internal void <ConfirmExitAsync>b__0(StaticModalPopupController ctrl, StaticModalPopup popup) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass23_1
	{
		private struct <<ConfirmExitAsync>b__1>d : IAsyncStateMachine
		{
			public int <>1__state; //Field offset: 0x0
			public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
			[Nullable(0)]
			public <>c__DisplayClass23_1 <>4__this; //Field offset: 0x28
			private Awaiter <>u__1; //Field offset: 0x30

			private override void MoveNext() { }

			[DebuggerHidden]
			private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

		}

		private struct <<ConfirmExitAsync>b__2>d : IAsyncStateMachine
		{
			public int <>1__state; //Field offset: 0x0
			public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
			[Nullable(0)]
			public <>c__DisplayClass23_1 <>4__this; //Field offset: 0x28
			private Awaiter <>u__1; //Field offset: 0x30

			private override void MoveNext() { }

			[DebuggerHidden]
			private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

		}

		[Nullable(0)]
		public StaticModalPopupController ctrl; //Field offset: 0x10
		[Nullable(0)]
		public <>c__DisplayClass23_0 CS$<>8__locals1; //Field offset: 0x18

		public <>c__DisplayClass23_1() { }

		[AsyncStateMachine(typeof(<<ConfirmExitAsync>b__1>d))]
		internal ValueTask <ConfirmExitAsync>b__1() { }

		[AsyncStateMachine(typeof(<<ConfirmExitAsync>b__2>d))]
		internal ValueTask <ConfirmExitAsync>b__2() { }

	}

	[CompilerGenerated]
	private struct <ConfirmExitAsync>d__23 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<Boolean> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ApplicationExitController <>4__this; //Field offset: 0x20
		[Nullable(0)]
		private <>c__DisplayClass23_0 <>8__1; //Field offset: 0x28
		[Nullable(0)]
		private StaticModalPopupController <controller>5__2; //Field offset: 0x30
		private Awaiter <>u__1; //Field offset: 0x38
		[Nullable(0)]
		private Awaiter<Boolean> <>u__2; //Field offset: 0x48

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <RequestExitAsync>d__20 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ApplicationExitController <>4__this; //Field offset: 0x18
		[Nullable(0)]
		private Awaiter<Boolean> <>u__1; //Field offset: 0x20

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <RunFinalizerThenQuitAsync>d__22 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskVoidMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ApplicationExitController <>4__this; //Field offset: 0x10
		[Nullable(0)]
		public Func<UniTask> finalizer; //Field offset: 0x18
		private Awaiter <>u__1; //Field offset: 0x20

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private bool <IsQuitAuthorized>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	[Nullable(2)]
	private Func<UniTask> <PreQuitFinalizer>k__BackingField; //Field offset: 0x18
	private readonly StaticModalPopupFactory _popupFactory; //Field offset: 0x20
	private readonly ButtonCommandBuilder _buttonCommandBuilder; //Field offset: 0x28
	private readonly ISingleInstanceLock _singleInstanceLock; //Field offset: 0x30
	private bool _confirmationInProgress; //Field offset: 0x38
	private bool _preQuitFinalizeStarted; //Field offset: 0x39

	public private bool IsQuitAuthorized
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	[Nullable(2)]
	public Func<UniTask> PreQuitFinalizer
	{
		[CompilerGenerated]
		[NullableContext(2)]
		 get { } //Length: 8
		[CompilerGenerated]
		[NullableContext(2)]
		 set { } //Length: 8
	}

	public override string ServiceName
	{
		 get { } //Length: 64
	}

	public override bool SilentInitializationMode
	{
		 get { } //Length: 8
	}

	public ApplicationExitController(StaticModalPopupFactory popupFactory, ButtonCommandBuilder buttonCommandBuilder, ISingleInstanceLock singleInstanceLock) { }

	public void AuthorizeQuit() { }

	[AsyncStateMachine(typeof(<ConfirmExitAsync>d__23))]
	[NullableContext(0)]
	private UniTask<Boolean> ConfirmExitAsync() { }

	public override void Dispose() { }

	[CompilerGenerated]
	public bool get_IsQuitAuthorized() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public Func<UniTask> get_PreQuitFinalizer() { }

	public override string get_ServiceName() { }

	public override bool get_SilentInitializationMode() { }

	public override UniTask InitAsync() { }

	private bool OnWantsToQuit() { }

	private void Quit() { }

	[AsyncStateMachine(typeof(<RequestExitAsync>d__20))]
	public UniTask RequestExitAsync() { }

	[AsyncStateMachine(typeof(<RunFinalizerThenQuitAsync>d__22))]
	private UniTaskVoid RunFinalizerThenQuitAsync(Func<UniTask> finalizer) { }

	[CompilerGenerated]
	private void set_IsQuitAuthorized(bool value) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public void set_PreQuitFinalizer(Func<UniTask> value) { }

}

