//Type is in global namespace

[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Always_Render")]
public class BakeryAlwaysRender : MonoBehaviour
{

	public BakeryAlwaysRender() { }

}

