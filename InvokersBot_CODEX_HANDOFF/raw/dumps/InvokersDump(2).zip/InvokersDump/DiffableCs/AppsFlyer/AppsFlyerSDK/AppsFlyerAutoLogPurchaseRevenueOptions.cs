namespace AppsFlyerSDK;

public enum AppsFlyerAutoLogPurchaseRevenueOptions : int
{
	AppsFlyerAutoLogPurchaseRevenueOptionsDisabled = 0,
	AppsFlyerAutoLogPurchaseRevenueOptionsAutoRenewableSubscriptions = 1,
	AppsFlyerAutoLogPurchaseRevenueOptionsInAppPurchases = 2,
}

