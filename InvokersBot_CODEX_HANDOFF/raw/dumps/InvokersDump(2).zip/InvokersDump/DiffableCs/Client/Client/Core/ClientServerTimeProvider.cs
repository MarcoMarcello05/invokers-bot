namespace Client.Core;

public sealed class ClientServerTimeProvider : IClientServerTimeProvider
{
	private const string KEY_OFFSET = "server_time_offset"; //Field offset: 0x0
	private double _offsetSeconds; //Field offset: 0x10
	private DateTime _serverTimeAtSyncUtc; //Field offset: 0x18
	private double _realtimeAtSync; //Field offset: 0x20
	private bool _syncedThisSession; //Field offset: 0x28

	public override DateTime ServerUtcNow
	{
		 get { } //Length: 200
	}

	public ClientServerTimeProvider() { }

	public override DateTime get_ServerUtcNow() { }

	public override void Sync(DateTime serverUtcTime) { }

}

