namespace Client.Core.Dialogs.DeviceChange;

public static class DeviceModelPresentation
{

	[NullableContext(2)]
	public static DeviceDisplayInfo DescribeDeviceModel(string deviceModel) { }

	[NullableContext(1)]
	public static DeviceDisplayInfo DescribeLocalDevice(ClientDeviceInfo deviceInfo) { }

}

