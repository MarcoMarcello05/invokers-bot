namespace Client.CharacterControllers.Materials;

public struct BattleCharacterMaterialPolicy : ICharacterMaterialPolicy
{
	private const string ALPHA_TEST_KEYWORD = "ALPHA_TEST"; //Field offset: 0x0
	private readonly Shader _shinyShader; //Field offset: 0x0

	public static BattleCharacterMaterialPolicy KeepSourceShader
	{
		 get { } //Length: 28
	}

	public BattleCharacterMaterialPolicy(Shader shinyShader) { }

	public override void Configure(Material clone, Material source) { }

	public static BattleCharacterMaterialPolicy get_KeepSourceShader() { }

	public override bool ShouldConvert(SkinnedMeshRenderer renderer) { }

	public override bool ShouldConvert(Material source) { }

}

