//Type is in global namespace

public class VfxPolygonUi : MonoBehaviour
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass4_0
	{
		public float timeScale; //Field offset: 0x10
		public int stateLocal; //Field offset: 0x14
		public VfxPolygonUi <>4__this; //Field offset: 0x18

		public <>c__DisplayClass4_0() { }

		internal void <Start>b__1() { }

	}

	public bool Enabled; //Field offset: 0x20
	public Button PauseButton; //Field offset: 0x28
	private int _state; //Field offset: 0x30
	private bool _paused; //Field offset: 0x34

	public VfxPolygonUi() { }

	[CompilerGenerated]
	private void <Start>b__4_0() { }

	private void Start() { }

}

