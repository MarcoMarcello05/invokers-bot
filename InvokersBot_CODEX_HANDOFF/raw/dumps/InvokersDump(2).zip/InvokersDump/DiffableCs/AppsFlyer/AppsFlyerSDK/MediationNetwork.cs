namespace AppsFlyerSDK;

public enum MediationNetwork : ulong
{
	GoogleAdMob = 1,
	IronSource = 2,
	ApplovinMax = 3,
	Fyber = 4,
	Appodeal = 5,
	Admost = 6,
	Topon = 7,
	Tradplus = 8,
	Yandex = 9,
	ChartBoost = 10,
	Unity = 11,
	ToponPte = 12,
	Custom = 13,
	DirectMonetization = 14,
}

