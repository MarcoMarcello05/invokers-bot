namespace Client.Configuration;

public class PlayerPrefsConfigurationProvider : ConfigurationProvider, IKeyEnumerator
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Predicate<String> <>9__7_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal bool <Load>b__7_0(string key) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass15_0
	{
		public string key; //Field offset: 0x10

		public <>c__DisplayClass15_0() { }

		internal bool <RemoveKey>b__0(string x) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass9_0
	{
		public string prefix; //Field offset: 0x10

		public <>c__DisplayClass9_0() { }

		internal bool <RemoveSection>b__0(string key) { }

	}

	private const string ALL_KEYS = "ALL_KEYS"; //Field offset: 0x0
	private readonly PlayerPrefsConfigurationSource _source; //Field offset: 0x20
	private List<String> _knownKeys; //Field offset: 0x28

	private string AllKeyName
	{
		private get { } //Length: 24
	}

	public PlayerPrefsConfigurationProvider(PlayerPrefsConfigurationSource source) { }

	public static string AllKeysKeyFor(string prefixKey) { }

	private string get_AllKeyName() { }

	public override IEnumerable<String> GetAllKeys() { }

	private void ImportLegacyOverrides() { }

	public virtual void Load() { }

	private void LoadAllKeys() { }

	private void RemoveKey(string key) { }

	public void RemoveSection(string prefix) { }

	private void SaveNewKey(string key, string value) { }

	public virtual void Set(string key, string value) { }

	public void Set(IDictionary<String, String> dictionary) { }

	private bool TryRemoveIfValueNull(string key, string value, bool reload = true) { }

}

