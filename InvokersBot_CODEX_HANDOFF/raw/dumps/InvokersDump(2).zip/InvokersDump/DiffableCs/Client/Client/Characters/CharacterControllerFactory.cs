namespace Client.Characters;

public sealed class CharacterControllerFactory : ICharacterControllerFactory
{
	private readonly IObjectResolver _resolver; //Field offset: 0x10

	public CharacterControllerFactory(IObjectResolver resolver) { }

	public override TController Create() { }

}

