namespace Client.Core;

[Extension]
public static class AsyncInitializableExtensions
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass0_0
	{
		public Action<T1, T2> onSuccess; //Field offset: 0x0
		public IAsyncInitializable<T1> initializable1; //Field offset: 0x0
		public IAsyncInitializable<T2> initializable2; //Field offset: 0x0

		public <>c__DisplayClass0_0`2() { }

		internal void <JoinWithCallback>b__0() { }

	}


	[Extension]
	public static void JoinWithCallback(IAsyncInitializable<T1> initializable1, IAsyncInitializable<T2> initializable2, Action<T1, T2> onSuccess) { }

}

