namespace Client.ContentManagement;

[Extension]
public static class ScopedAssetProviderExtensions
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass0_0
	{
		public IScopedAssetProvider provider; //Field offset: 0x0
		public AssetKey assetKey; //Field offset: 0x0

		public <>c__DisplayClass0_0`1() { }

		internal UniTask <GetLoadOperation>b__0(IOperationProgressObserver _) { }

	}


	[Extension]
	public static AssetLoadingAsyncOperation GetLoadOperation(IScopedAssetProvider provider, AssetKey assetKey) { }

}

