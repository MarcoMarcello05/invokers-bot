//Type is in global namespace

public class AnimationEventProcessor
{
	internal enum AnimationEventProcessorType : int
	{
		GameObjectActivation = 0,
		ParticleSystemPlay = 1,
		ParticleSystemStop = 2,
		GameObjectDeactivation = 3,
		VfxRootPlay = 4,
		VfxRootStop = 5,
		AraTrailClear = 6,
		AraTrailActivateEmit = 7,
		AraTrailDeactivateEmit = 8,
	}

	public string Name; //Field offset: 0x10
	public GameObject Target; //Field offset: 0x18
	public ParticleSystem ParticleSystem; //Field offset: 0x20
	public VfxRootBehaviour VfxRoot; //Field offset: 0x28
	public List<AraTrail> AraTrails; //Field offset: 0x30
	public float ActivityDuration; //Field offset: 0x38
	public AnimationEventProcessorType Type; //Field offset: 0x3C
	public bool RestoreOnEnable; //Field offset: 0x40

	private bool ShowAraTrailTarget
	{
		private get { } //Length: 20
	}

	private bool ShowDurationWarning
	{
		private get { } //Length: 16
	}

	private bool ShowGameObjectTarget
	{
		private get { } //Length: 20
	}

	private bool ShowParticleSystemTarget
	{
		private get { } //Length: 20
	}

	private bool ShowVfxRootTarget
	{
		private get { } //Length: 20
	}

	public AnimationEventProcessor() { }

	public AnimationEventProcessor(AnimationEventProcessor other) { }

	private void ClearAraTrailTargets() { }

	private bool get_ShowAraTrailTarget() { }

	private bool get_ShowDurationWarning() { }

	private bool get_ShowGameObjectTarget() { }

	private bool get_ShowParticleSystemTarget() { }

	private bool get_ShowVfxRootTarget() { }

	public bool HasAraTrailTargets() { }

	private void OnTypeChange() { }

}

