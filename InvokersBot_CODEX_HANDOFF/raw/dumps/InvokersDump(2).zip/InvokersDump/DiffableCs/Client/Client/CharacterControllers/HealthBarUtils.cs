namespace Client.CharacterControllers;

public static class HealthBarUtils
{
	public const int HARD_NOTCHES_ITEMS_LIMIT = 32; //Field offset: 0x0
	private const int HARD_NOTCHES_LEVELS_LIMIT = 32; //Field offset: 0x0

	public static void CalculateNotches(int maxHealth, HealthBarTweaksItem config, List<ValueTuple`2<Single, Int32>> results) { }

	public static HealthBarState CalculateState(ModelEntity characterEntity) { }

	public static HealthBarState CalculateState(long currentHealth, long maxHealth, int destroyedAmount, int shieldAmount) { }

	public static long CalculateTotalMaximum(long maxHealth, int shieldAmount, int destroyedAmount) { }

	private static int FindSmallestNotchesStep(HealthBarTweaksItem config, int renderMask) { }

	public static TopPanelHealth GetTopPanelHealth(ModelEntity characterEntity, MetaBattleSetup setup, BattleStatistics statistics) { }

	private static void InternalCalc(int targetHealth, HealthBarTweaksItem config, List<ValueTuple`2<Single, Int32>> results) { }

}

