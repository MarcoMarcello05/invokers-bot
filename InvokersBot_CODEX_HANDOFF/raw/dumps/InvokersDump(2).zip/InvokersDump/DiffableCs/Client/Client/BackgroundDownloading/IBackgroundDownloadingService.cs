namespace Client.BackgroundDownloading;

public interface IBackgroundDownloadingService
{

	public Observable<BackgroundDownloadingProgress> Progress
	{
		 get { } //Length: 0
	}

	public Observable<BackgroundDownloadingServiceStatus> ServiceStatus
	{
		 get { } //Length: 0
	}

	public void CancelDownloads() { }

	public UniTask DownloadAllBundles() { }

	public UniTask DownloadAllQueue() { }

	public Observable<BackgroundDownloadingProgress> get_Progress() { }

	public Observable<BackgroundDownloadingServiceStatus> get_ServiceStatus() { }

	public BackgroundDownloadingDebugSnapshot GetDebugSnapshot() { }

	public BackgroundDownloadingProgress GetProgress() { }

	public BackgroundDownloadingServiceStatus GetServiceStatus() { }

	public void ResetDownloadedSettings() { }

	public void TraceProgress() { }

}

