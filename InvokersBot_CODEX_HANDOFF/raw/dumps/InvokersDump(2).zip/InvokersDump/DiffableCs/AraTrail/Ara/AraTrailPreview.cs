namespace Ara;

[ExecuteAlways]
public class AraTrailPreview : MonoBehaviour
{
	public static float TargetFps; //Field offset: 0x0
	public AraTrail[] Trails; //Field offset: 0x20
	public float Duration; //Field offset: 0x28
	public float Speed; //Field offset: 0x2C
	private Vector3 _cachedTransformPosition; //Field offset: 0x30
	private Quaternion _cachedTransformRotation; //Field offset: 0x3C
	public bool PathGizmo; //Field offset: 0x4C
	public Color PathColor; //Field offset: 0x50
	private bool _previewIsActive; //Field offset: 0x60

	public float FakeDeltaTime
	{
		 get { } //Length: 128
	}

	public static float MaxFpsDelta
	{
		 get { } //Length: 108
	}

	public float PathLength
	{
		 get { } //Length: 12
	}

	public bool PreviewIsActive
	{
		 get { } //Length: 8
		 set { } //Length: 8
	}

	private static AraTrailPreview() { }

	public AraTrailPreview() { }

	private void EmmitPoint(float timeDelta) { }

	public float get_FakeDeltaTime() { }

	public static float get_MaxFpsDelta() { }

	public float get_PathLength() { }

	public bool get_PreviewIsActive() { }

	public void GetAllTrailsInChildren() { }

	private void LateUpdate() { }

	private void OnDrawGizmos() { }

	public void set_PreviewIsActive(bool value) { }

	public void SetTrailsFreeze(bool value) { }

	public void UpdateTrailsPreviewSnapshot() { }

}

