namespace Client.CharacterControllers;

public class HudSkillsView : UIWidget
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass9_0
	{
		public HudSkillData skillsData; //Field offset: 0x10

		public <>c__DisplayClass9_0() { }

		internal bool <ChangeIcons>b__0(HudRadialSkillsView view) { }

	}

	internal class SkillTypeToControlPath
	{
		[SerializeField]
		private SkillType _skillType; //Field offset: 0x10
		[InputControl(layout = "Button")]
		[SerializeField]
		private string _controlPath; //Field offset: 0x18

		public string ControlPath
		{
			 get { } //Length: 8
		}

		public SkillType SkillType
		{
			 get { } //Length: 8
		}

		public SkillTypeToControlPath() { }

		public string get_ControlPath() { }

		public SkillType get_SkillType() { }

	}

	[SerializeField]
	private Image _comboAttackImage; //Field offset: 0x20
	[SerializeField]
	private List<HudRadialSkillsView> hudRadialSkillsViews; //Field offset: 0x28
	[SerializeField]
	private List<SkillTypeToControlPath> _skillTypeToControlPaths; //Field offset: 0x30
	private HudRadialSkillsView _currentSkillView; //Field offset: 0x38
	private DashButton _dashButton; //Field offset: 0x40

	public HudRadialSkillsView CurrentSkillView
	{
		 get { } //Length: 8
	}

	public HudSkillsView() { }

	private void Awake() { }

	public void ChangeIcons(HudSkillData skillsData) { }

	public HudRadialSkillsView get_CurrentSkillView() { }

	public void UpdateDashProgress(float progress) { }

	public void UpdateDashVisibility(bool isVisible) { }

}

