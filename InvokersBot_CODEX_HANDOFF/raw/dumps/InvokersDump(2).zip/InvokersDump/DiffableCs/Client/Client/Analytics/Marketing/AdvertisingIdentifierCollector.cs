namespace Client.Analytics.Marketing;

[Nullable(0)]
[NullableContext(1)]
public static class AdvertisingIdentifierCollector
{
	[CompilerGenerated]
	private struct <CollectAsync>d__6 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<AdvertisingIdentifiers> <>t__builder; //Field offset: 0x8
		public bool idfaAuthorized; //Field offset: 0x20
		[Nullable(0)]
		private Stopwatch <stopwatch>5__2; //Field offset: 0x28
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private Awaiter<AdvertisingIdentifiers> <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <CollectCoreAsync>d__7 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<AdvertisingIdentifiers> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		private Awaiter<AdvertisingIdentifiers> <>u__1; //Field offset: 0x20

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private const string ZeroUuid = "00000000-0000-0000-0000-000000000000"; //Field offset: 0x0
	private const string OutcomeOk = "ok"; //Field offset: 0x0
	private const string OutcomeError = "error"; //Field offset: 0x0
	private const string OutcomeNotMobile = "not_mobile"; //Field offset: 0x0
	private const string OutcomeAttNotAuthorized = "att_not_authorized"; //Field offset: 0x0
	private const string OutcomeUnavailable = "unavailable"; //Field offset: 0x0

	private static AdvertisingIdentifiers CollectAndroid() { }

	[AsyncStateMachine(typeof(<CollectAsync>d__6))]
	public static UniTask<AdvertisingIdentifiers> CollectAsync(bool idfaAuthorized) { }

	[AsyncStateMachine(typeof(<CollectCoreAsync>d__7))]
	private static UniTask<AdvertisingIdentifiers> CollectCoreAsync(bool idfaAuthorized) { }

	private static AndroidJavaObject GetCurrentActivity() { }

	[NullableContext(2)]
	private static string Normalize(string value) { }

}

