namespace Client.AutoBattle;

[DisallowMultipleComponent]
[ExecuteAlways]
public class WaypointsHolder : MonoBehaviour
{
	public List<Waypoint> AllWaypoints; //Field offset: 0x20
	public Waypoint First; //Field offset: 0x28

	public WaypointsHolder() { }

}

