//Type is in global namespace

[DisallowMultipleComponent]
[ExecuteInEditMode]
[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Sky_Light")]
public class BakerySkyLight : MonoBehaviour
{
	public static int lightsChanged; //Field offset: 0x0
	private static GameObject objShownError; //Field offset: 0x8
	public string texName; //Field offset: 0x20
	public Color color; //Field offset: 0x28
	public float intensity; //Field offset: 0x38
	public int samples; //Field offset: 0x3C
	public bool hemispherical; //Field offset: 0x40
	public int bitmask; //Field offset: 0x44
	public bool bakeToIndirect; //Field offset: 0x48
	public float indirectIntensity; //Field offset: 0x4C
	public bool tangentSH; //Field offset: 0x50
	public bool correctRotation; //Field offset: 0x51
	public Cubemap cubemap; //Field offset: 0x58
	public int UID; //Field offset: 0x60

	public BakerySkyLight() { }

}

