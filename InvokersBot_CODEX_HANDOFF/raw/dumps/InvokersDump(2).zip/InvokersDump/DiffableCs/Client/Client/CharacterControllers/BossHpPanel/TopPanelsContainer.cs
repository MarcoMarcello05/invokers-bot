namespace Client.CharacterControllers.BossHpPanel;

[UsedAsInjection]
public class TopPanelsContainer : IDisposable
{
	private readonly IScopedAssetProvider _assetProvider; //Field offset: 0x10
	private readonly IReadOnlyDictionary<Int64, CustomStatusEffectPresentation> _customStatusEffectPresentations; //Field offset: 0x18
	private readonly IObjectsPool<BuffView> _buffViewPool; //Field offset: 0x20
	[CompilerGenerated]
	private bool <Initialized>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private bool <Disabled>k__BackingField; //Field offset: 0x29
	private Dictionary<TopPanelViewTarget, TopPanelItemContainer> _panels; //Field offset: 0x30
	private TopPanelItemContainer _activePanel; //Field offset: 0x38

	public ModelEntity CurrentOwner
	{
		 get { } //Length: 104
	}

	public Nullable<TopPanelViewTarget> CurrentOwnerType
	{
		 get { } //Length: 136
	}

	public ModelEntityKey CurrentTarget
	{
		 get { } //Length: 104
	}

	public CharacterKind CurrentTargetKind
	{
		 get { } //Length: 24
	}

	public bool Disabled
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public private bool Initialized
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public TopPanelsContainer(IScopedAssetProvider assetProvider, ICustomStatusEffectPresentationProvider customStatusEffectPresentationProvider, IObjectsPool<BuffView> buffViewPool) { }

	public void AddCustomStatusEffect(ModelEntityKey characterEntity, ref CustomStatusEffectHudData customStatusEffectHudData) { }

	public void AddMovementEffect(ModelEntityKey characterEntity, ref MovementEffectHudData movementEffectHudData) { }

	public void AddStatusEffect(ModelEntityKey characterEntity, ref StatusEffectHudData statusEffectHudData) { }

	public static bool CanShow(LevelInfo levelInfo) { }

	public void Disable() { }

	public override void Dispose() { }

	public ModelEntity get_CurrentOwner() { }

	public Nullable<TopPanelViewTarget> get_CurrentOwnerType() { }

	public ModelEntityKey get_CurrentTarget() { }

	public CharacterKind get_CurrentTargetKind() { }

	[CompilerGenerated]
	public bool get_Disabled() { }

	[CompilerGenerated]
	public bool get_Initialized() { }

	public void Hide() { }

	public void Init(Transform hudTransform, LevelInfo levelInfo) { }

	public void RemoveCustomStatusEffect(ModelEntityKey characterEntity, long effectType, uint effectUniqueId) { }

	public void RemoveMovementEffect(ModelEntityKey characterEntity, MovementEffectType type) { }

	public void RemoveStatusEffect(ModelEntityKey characterEntity, StatusEffectType type, uint effectId) { }

	public void ResetCastFill(CharacterType2 characterType, SkillType skillType) { }

	public void ResetCooldown(ModelEntityKey characterEntity, SkillType skillType) { }

	public void ResetPassiveCooldown(ModelEntityKey characterEntity) { }

	public void Set(CharacterType2 type, ref TopPanelData data) { }

	[CompilerGenerated]
	public void set_Disabled(bool value) { }

	[CompilerGenerated]
	private void set_Initialized(bool value) { }

	public void SetCastFill(ModelEntity entity, CharacterType2 characterType, SkillType type, float percent) { }

	public void SetCooldown(ModelEntityKey characterEntity, SkillType skillType, F64 cooldown, F64 timeLeft, bool showCooldownNumbers = true) { }

	public void SetDamagePopupMode(DamagePopupMode mode, Func<Int64> getCounterValue) { }

	public void SetPassiveCooldown(ModelEntityKey characterEntity, F64 timeLeft, bool blocked) { }

	public void TakeDamage(ModelEntity characterEntity, int damage, bool isCritical) { }

	public void UpdateCustomStatusEffect(ModelEntityKey characterEntity, ref CustomStatusEffectHudData customStatusEffectHudData) { }

	public void UpdateHealthBar(TopPanelHealth ownerHealth) { }

	public void UpdateMovementEffect(ModelEntityKey characterEntity, ref MovementEffectHudData movementEffectHudData) { }

	public void UpdateStatusEffect(ModelEntityKey characterEntity, ref StatusEffectHudData statusEffectHudData) { }

	public void UpdateTarget(ModelEntity newTarget) { }

}

