namespace Client.Core;

public class AssetLoadingAsyncOperation : AsyncOperationWithProgress, IAssetHolder
{
	[CompilerGenerated]
	private readonly IEnumerable<AssetKey> <RequiredAssets>k__BackingField; //Field offset: 0x60

	public override IEnumerable<AssetKey> RequiredAssets
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public AssetLoadingAsyncOperation(string operationId, Func<IOperationProgressObserver, UniTask> action, IEnumerable<AssetKey> requiredAssets) { }

	[CompilerGenerated]
	public override IEnumerable<AssetKey> get_RequiredAssets() { }

}

