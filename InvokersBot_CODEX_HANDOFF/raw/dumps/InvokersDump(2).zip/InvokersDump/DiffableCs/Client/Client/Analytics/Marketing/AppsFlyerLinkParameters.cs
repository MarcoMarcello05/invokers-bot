namespace Client.Analytics.Marketing;

[Nullable(0)]
[NullableContext(2)]
public sealed class AppsFlyerLinkParameters
{
	[Nullable(0)]
	[NullableContext(1)]
	internal static class Keys
	{
		public const string MediaSource = "pid"; //Field offset: 0x0
		public const string WebRedirectUrl = "af_web_dp"; //Field offset: 0x0
		public const string DeepLink = "af_dp"; //Field offset: 0x0
		public const string InstallTime = "install_time"; //Field offset: 0x0
		public const string IsRetargeting = "is_retargeting"; //Field offset: 0x0
		public const string Partner = "af_prt"; //Field offset: 0x0
		public const string ClickId = "clickid"; //Field offset: 0x0
		public const string Sub5 = "af_sub5"; //Field offset: 0x0
		public const string Sub4 = "af_sub4"; //Field offset: 0x0
		public const string Sub3 = "af_sub3"; //Field offset: 0x0
		public const string Sub2 = "af_sub2"; //Field offset: 0x0
		public const string Sub1 = "af_sub1"; //Field offset: 0x0
		public const string SiteId = "af_siteid"; //Field offset: 0x0
		public const string Channel = "af_channel"; //Field offset: 0x0
		public const string Ad = "af_ad"; //Field offset: 0x0
		public const string Adset = "af_adset"; //Field offset: 0x0
		public const string CampaignId = "af_c_id"; //Field offset: 0x0
		public const string Campaign = "c"; //Field offset: 0x0
		public const string ForceDeepLink = "af_force_deeplink"; //Field offset: 0x0
		public const string Referrer = "af_ref"; //Field offset: 0x0

	}

	[Nullable(1)]
	private static readonly Dictionary<String, String[]> KeyAliases; //Field offset: 0x0
	[CompilerGenerated]
	[Nullable(1)]
	private readonly IReadOnlyDictionary<String, Object> <Parameters>k__BackingField; //Field offset: 0x10

	public string Ad
	{
		 get { } //Length: 72
	}

	public string Adset
	{
		 get { } //Length: 72
	}

	public string Campaign
	{
		 get { } //Length: 72
	}

	public string CampaignId
	{
		 get { } //Length: 72
	}

	public string Channel
	{
		 get { } //Length: 72
	}

	public string ClickId
	{
		 get { } //Length: 72
	}

	public string DeepLink
	{
		 get { } //Length: 72
	}

	[Nullable(1)]
	public static AppsFlyerLinkParameters Empty
	{
		[NullableContext(1)]
		 get { } //Length: 268
	}

	public string ForceDeepLink
	{
		 get { } //Length: 72
	}

	public string InstallTime
	{
		 get { } //Length: 72
	}

	public string IsRetargeting
	{
		 get { } //Length: 72
	}

	public string MediaSource
	{
		 get { } //Length: 72
	}

	[Nullable(1)]
	public IReadOnlyDictionary<String, Object> Parameters
	{
		[CompilerGenerated]
		[NullableContext(1)]
		 get { } //Length: 8
	}

	public string Partner
	{
		 get { } //Length: 72
	}

	public string Referrer
	{
		 get { } //Length: 72
	}

	public string SiteId
	{
		 get { } //Length: 72
	}

	public string Sub1
	{
		 get { } //Length: 72
	}

	public string Sub2
	{
		 get { } //Length: 72
	}

	public string Sub3
	{
		 get { } //Length: 72
	}

	public string Sub4
	{
		 get { } //Length: 72
	}

	public string Sub5
	{
		 get { } //Length: 72
	}

	public string WebRedirectUrl
	{
		 get { } //Length: 72
	}

	private static AppsFlyerLinkParameters() { }

	[NullableContext(1)]
	public AppsFlyerLinkParameters(Dictionary<String, Object> parameters) { }

	public string get_Ad() { }

	public string get_Adset() { }

	public string get_Campaign() { }

	public string get_CampaignId() { }

	public string get_Channel() { }

	public string get_ClickId() { }

	public string get_DeepLink() { }

	[NullableContext(1)]
	public static AppsFlyerLinkParameters get_Empty() { }

	public string get_ForceDeepLink() { }

	public string get_InstallTime() { }

	public string get_IsRetargeting() { }

	public string get_MediaSource() { }

	[CompilerGenerated]
	[NullableContext(1)]
	public IReadOnlyDictionary<String, Object> get_Parameters() { }

	public string get_Partner() { }

	public string get_Referrer() { }

	public string get_SiteId() { }

	public string get_Sub1() { }

	public string get_Sub2() { }

	public string get_Sub3() { }

	public string get_Sub4() { }

	public string get_Sub5() { }

	public string get_WebRedirectUrl() { }

	[NullableContext(1)]
	private string GetValue(string key) { }

}

