namespace Client.Core;

public class AsyncLoadSoundBank : AsyncInitializableBase, IAssetHolder, IAsyncInitializable<SoundBank>, IAsyncInitializable, IDisposable
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass15_0
	{
		public IOperationProgressObserver onProgressChange; //Field offset: 0x10

		public <>c__DisplayClass15_0() { }

		internal void <LoadAsync>g__OnStatusChanged|0(DownloadStatus downloadStatus) { }

	}

	[CompilerGenerated]
	private sealed class <get_RequiredAssets>d__12 : IEnumerable<AssetKey>, IEnumerable, IEnumerator<AssetKey>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private AssetKey <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public AsyncLoadSoundBank <>4__this; //Field offset: 0x28

		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <get_RequiredAssets>d__12(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<AssetKey> System.Collections.Generic.IEnumerable<Client.AssetKey>.GetEnumerator() { }

		[DebuggerHidden]
		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private sealed class <InitFactory>d__14 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public AsyncLoadSoundBank <>4__this; //Field offset: 0x28

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <InitFactory>d__14(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private struct <LoadAsync>d__15 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public IOperationProgressObserver onProgressChange; //Field offset: 0x18
		public AsyncLoadSoundBank <>4__this; //Field offset: 0x20
		private AutoScope <_>5__2; //Field offset: 0x28
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1, 0})]
		private Awaiter<IAssetRequest<SoundBank>> <>u__1; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity AssetLoad; //Field offset: 0x0
	private readonly AssetKey _assetKey; //Field offset: 0x58
	private readonly IAssetProvider _assetProvider; //Field offset: 0x60
	private readonly string _ownerCallerLabel; //Field offset: 0x68
	private readonly string _ownerCallerFilePath; //Field offset: 0x70
	private readonly int _ownerCallerLine; //Field offset: 0x78
	private IAssetRequest<SoundBank> _assetRequest; //Field offset: 0x80
	[CompilerGenerated]
	private SoundBank <Value>k__BackingField; //Field offset: 0x88

	public override IEnumerable<AssetKey> RequiredAssets
	{
		[IteratorStateMachine(typeof(<get_RequiredAssets>d__12))]
		 get { } //Length: 128
	}

	public private override SoundBank Value
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	private static AsyncLoadSoundBank() { }

	public AsyncLoadSoundBank(AssetKey assetKey, IAssetProvider assetProvider, string ownerLabelOverride = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	[IteratorStateMachine(typeof(<get_RequiredAssets>d__12))]
	public override IEnumerable<AssetKey> get_RequiredAssets() { }

	[CompilerGenerated]
	public override SoundBank get_Value() { }

	[IteratorStateMachine(typeof(<InitFactory>d__14))]
	protected virtual IEnumerable<IAsyncOperationWithProgress> InitFactory() { }

	[AsyncStateMachine(typeof(<LoadAsync>d__15))]
	private UniTask LoadAsync(IOperationProgressObserver onProgressChange = null) { }

	[CompilerGenerated]
	private void set_Value(SoundBank value) { }

}

