namespace Client.Battle.Mvc;

public class BattleModelAccessor
{
	[CompilerGenerated]
	private EcsWorld <World>k__BackingField; //Field offset: 0x10

	public EcsWorld World
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public BattleModelAccessor() { }

	public EcsFilter Filter() { }

	public EcsFilter Filter() { }

	[CompilerGenerated]
	public EcsWorld get_World() { }

	[CompilerGenerated]
	public void set_World(EcsWorld value) { }

}

