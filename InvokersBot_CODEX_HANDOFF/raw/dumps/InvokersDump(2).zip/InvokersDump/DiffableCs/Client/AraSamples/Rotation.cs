namespace AraSamples;

public class Rotation : MonoBehaviour
{
	public float speed; //Field offset: 0x20
	public Vector3 axis; //Field offset: 0x24

	public Rotation() { }

	private void Update() { }

}

