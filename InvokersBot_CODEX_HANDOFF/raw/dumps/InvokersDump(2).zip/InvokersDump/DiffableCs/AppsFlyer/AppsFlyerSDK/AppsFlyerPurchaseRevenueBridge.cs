namespace AppsFlyerSDK;

public class AppsFlyerPurchaseRevenueBridge : MonoBehaviour
{
	private static IAppsFlyerPurchaseRevenueDataSource _dataSource; //Field offset: 0x0
	private static IAppsFlyerPurchaseRevenueDataSourceStoreKit2 _dataSourceSK2; //Field offset: 0x8

	public AppsFlyerPurchaseRevenueBridge() { }

	public static Dictionary<String, Object> GetAdditionalParametersForAndroid(HashSet<Object> products, HashSet<Object> transactions) { }

	public static void RegisterDataSource(IAppsFlyerPurchaseRevenueDataSource dataSource) { }

}

