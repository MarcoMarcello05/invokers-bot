namespace Client.Characters;

[DisallowMultipleComponent]
public sealed class CharacterView : MonoBehaviour, IView, IObjectsPoolItem<CharacterView>
{
	private readonly GameObjectsPoolItemBase<CharacterView> _itemBase; //Field offset: 0x20
	[SerializeField]
	private Animator _animator; //Field offset: 0x28
	[SerializeField]
	private MonoBehaviour[] _resettableParts; //Field offset: 0x30
	private ICharacterViewListener _listener; //Field offset: 0x38
	private int _generation; //Field offset: 0x40
	private IdleAnimationTimerHandler _idleHandler; //Field offset: 0x48
	private Vector3 _initialLocalScale; //Field offset: 0x50
	private float _initialAnimatorSpeed; //Field offset: 0x5C
	private bool _awake; //Field offset: 0x60
	[CompilerGenerated]
	private Transform <Root>k__BackingField; //Field offset: 0x68

	public Animator Animator
	{
		 get { } //Length: 8
	}

	public private Transform Root
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public override CharacterView Template
	{
		 get { } //Length: 72
	}

	public CharacterView() { }

	private void AcquireIdleHandler() { }

	public CharacterViewBinding Attach(ICharacterViewListener listener) { }

	private void Awake() { }

	public void Damage() { }

	internal void Detach(int generation) { }

	private void EnsureAwake() { }

	public void EventCustom() { }

	public void Flinch() { }

	public Animator get_Animator() { }

	[CompilerGenerated]
	public Transform get_Root() { }

	public override CharacterView get_Template() { }

	public override UniTask Hide() { }

	public void Hit() { }

	public void IdleHit() { }

	public override bool IsViewVisible() { }

	private void OnDisable() { }

	private void OnEnable() { }

	private void OnIdleAnimationStarted() { }

	private void OnIdleBreak(int idleBreakIndex) { }

	public override void OnInstantiate(IObjectsPool<CharacterView> ownerPool, CharacterView template) { }

	private void OnValidate() { }

	public void OnVFX(string vfxId) { }

	public void RebindAnimator() { }

	private void ReleaseIdleHandler() { }

	public override void ResetBeforeRent() { }

	public void ResetView() { }

	public override void ReturnToPool() { }

	[CompilerGenerated]
	private void set_Root(Transform value) { }

	public override void SetParent(Transform parent, bool worldPositionStays = false) { }

	public void SetVisible(bool visible) { }

	public override UniTask Show() { }

	public void Step() { }

}

