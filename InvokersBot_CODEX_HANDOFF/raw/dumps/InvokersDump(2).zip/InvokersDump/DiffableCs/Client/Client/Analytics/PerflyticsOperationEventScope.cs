namespace Client.Analytics;

[Nullable(0)]
[NullableContext(1)]
public class PerflyticsOperationEventScope : IDisposable
{
	[CompilerGenerated]
	private readonly string <Name>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly string <Category>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly string <Id>k__BackingField; //Field offset: 0x20
	private readonly bool _logEvents; //Field offset: 0x28
	private readonly double _startTime; //Field offset: 0x30
	[Nullable(2)]
	private readonly ISpan _sentrySpan; //Field offset: 0x38

	public string Category
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string Id
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string Name
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public PerflyticsOperationEventScope(string name, string category, bool logEvents, ISpan sentrySpan) { }

	public override void Dispose() { }

	[CompilerGenerated]
	public string get_Category() { }

	[CompilerGenerated]
	public string get_Id() { }

	[CompilerGenerated]
	public string get_Name() { }

}

