namespace Client.Core.Dialogs.DeviceChange;

[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
[NullableContext(1)]
public class DeviceChangeDialogController : AwaitableDialogController<DeviceChangeDialogView>
{
	private readonly IContentManager _content; //Field offset: 0x88
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x90
	private readonly AssetKey _assetKey; //Field offset: 0x98
	private readonly bool _allowKeyDismiss; //Field offset: 0xA0
	private readonly Action<DeviceChangeDialogController, DeviceChangeDialogView> _configurePopup; //Field offset: 0xA8

	public DeviceChangeDialogController(IContentManager content, IStagingContainer stagingContainer, IUISystem uiSystem, AssetKey assetKey, bool allowKeyDismiss, Action<DeviceChangeDialogController, DeviceChangeDialogView> configurePopup) { }

	protected virtual void OnViewLoaded() { }

	protected virtual IAsyncInitializable<DeviceChangeDialogView> ViewFactory() { }

}

