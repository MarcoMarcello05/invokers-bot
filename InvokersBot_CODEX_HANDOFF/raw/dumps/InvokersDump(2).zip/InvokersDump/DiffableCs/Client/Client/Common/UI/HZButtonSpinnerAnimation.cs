namespace Client.Common.UI;

public class HZButtonSpinnerAnimation : BaseHZButtonProcessAnimation
{
	[SerializeField]
	private Transform _spinnerTransform; //Field offset: 0x20
	[SerializeField]
	private TweenSettings<Vector3> _tweenSettings; //Field offset: 0x28
	private Tween _rotationTween; //Field offset: 0x78

	public HZButtonSpinnerAnimation() { }

	public virtual void CommandCompleted(bool isSuccess) { }

	public virtual void CommandStarted() { }

	private void OnDestroy() { }

}

