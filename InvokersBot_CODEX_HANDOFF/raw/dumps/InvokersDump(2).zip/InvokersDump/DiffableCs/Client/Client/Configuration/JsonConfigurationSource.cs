namespace Client.Configuration;

public class JsonConfigurationSource : IConfigurationSource
{
	[CompilerGenerated]
	private readonly string <JsonFilePath>k__BackingField; //Field offset: 0x10

	public string JsonFilePath
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public JsonConfigurationSource(string jsonFilePath) { }

	public override IConfigurationProvider Build(IConfigurationBuilder builder) { }

	[CompilerGenerated]
	public string get_JsonFilePath() { }

}

