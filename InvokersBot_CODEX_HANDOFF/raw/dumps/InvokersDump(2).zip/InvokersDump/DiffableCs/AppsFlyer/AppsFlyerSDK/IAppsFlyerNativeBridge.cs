namespace AppsFlyerSDK;

public interface IAppsFlyerNativeBridge
{

	public bool isInit
	{
		 get { } //Length: 0
		 set { } //Length: 0
	}

	public void addPushNotificationDeepLinkPath(String[] paths) { }

	public void anonymizeUser(bool shouldAnonymizeUser) { }

	public void attributeAndOpenStore(string appID, string campaign, Dictionary<String, String> userParams, MonoBehaviour gameObject) { }

	public void enableTCFDataCollection(bool shouldCollectTcfData) { }

	public void generateUserInviteLink(Dictionary<String, String> parameters, MonoBehaviour gameObject) { }

	public bool get_isInit() { }

	public string getAppsFlyerId() { }

	public void getConversionData(string objectName) { }

	public string getSdkVersion() { }

	public bool isSDKStopped() { }

	public void logAdRevenue(AFAdRevenueData adRevenueData, Dictionary<String, String> additionalParameters) { }

	public void recordCrossPromoteImpression(string appID, string campaign, Dictionary<String, String> parameters) { }

	public void recordLocation(double latitude, double longitude) { }

	public void sendEvent(string eventName, Dictionary<String, String> eventValues, bool onInAppResponse, string CallBackObjectName) { }

	public void set_isInit(bool value) { }

	public void setAdditionalData(Dictionary<String, String> customData) { }

	public void setAppInviteOneLinkID(string oneLinkId) { }

	public void setConsentData(AppsFlyerConsent appsFlyerConsent) { }

	public void setCurrencyCode(string currencyCode) { }

	public void setCustomerUserId(string id) { }

	public void setDeepLinkTimeout(long deepLinkTimeout) { }

	public void setHost(string hostPrefixName, string hostName) { }

	public void setIsDebug(bool shouldEnable) { }

	public void setMinTimeBetweenSessions(int seconds) { }

	public void setOneLinkCustomDomain(String[] domains) { }

	public void setPartnerData(string partnerId, Dictionary<String, String> partnerInfo) { }

	public void setPhoneNumber(string phoneNumber) { }

	public void setResolveDeepLinkURLs(String[] urls) { }

	public void setSharingFilter(String[] partners) { }

	public void setSharingFilterForAllPartners() { }

	public void setUserEmails(EmailCryptType cryptType, String[] userEmails) { }

	public void startSDK(bool onRequestResponse, string CallBackObjectName) { }

	public void stopSDK(bool isSDKStopped) { }

	public void subscribeForDeepLink(string objectName) { }

}

