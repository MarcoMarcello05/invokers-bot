namespace Ara;

[DefaultMember("Item")]
public class ElasticArray : IList<T>, ICollection<T>, IEnumerable<T>, IEnumerable
{
	[CompilerGenerated]
	private sealed class <GetEnumerator>d__2 : IEnumerator<T>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private T <>2__current; //Field offset: 0x0
		public ElasticArray<T> <>4__this; //Field offset: 0x0
		private int <i>5__2; //Field offset: 0x0

		private override T System.Collections.Generic.IEnumerator<T>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 68
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 164
		}

		[DebuggerHidden]
		public <GetEnumerator>d__2(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override T System.Collections.Generic.IEnumerator<T>.get_Current() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	private T[] data; //Field offset: 0x0
	private int count; //Field offset: 0x0

	public override int Count
	{
		 get { } //Length: 8
	}

	public T[] Data
	{
		 get { } //Length: 8
	}

	public override bool IsReadOnly
	{
		 get { } //Length: 8
	}

	public override T Item
	{
		 get { } //Length: 88
		 set { } //Length: 336
	}

	public ElasticArray`1() { }

	public override void Add(T item) { }

	public override void Clear() { }

	public override bool Contains(T item) { }

	public override void CopyTo(T[] array, int arrayIndex) { }

	public void EnsureCapacity(int capacity) { }

	public override int get_Count() { }

	public T[] get_Data() { }

	public override bool get_IsReadOnly() { }

	public override T get_Item(int index) { }

	[IteratorStateMachine(typeof(<GetEnumerator>d__2))]
	public override IEnumerator<T> GetEnumerator() { }

	public override int IndexOf(T item) { }

	public override void Insert(int index, T item) { }

	public override bool Remove(T item) { }

	public override void RemoveAt(int index) { }

	public void Reverse() { }

	public override void set_Item(int index, T value) { }

	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

