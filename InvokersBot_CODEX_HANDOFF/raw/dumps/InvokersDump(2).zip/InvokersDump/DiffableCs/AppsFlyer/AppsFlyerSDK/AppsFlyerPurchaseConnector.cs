namespace AppsFlyerSDK;

public class AppsFlyerPurchaseConnector : MonoBehaviour
{
	private static AppsFlyerPurchaseConnector instance; //Field offset: 0x0
	private static AndroidJavaClass appsFlyerAndroidConnector; //Field offset: 0x8
	private Dictionary<String, Object> pendingParameters; //Field offset: 0x20
	private Action<Dictionary`2<String, Object>> pendingCallback; //Field offset: 0x28

	public static AppsFlyerPurchaseConnector Instance
	{
		 get { } //Length: 368
	}

	private static AppsFlyerPurchaseConnector() { }

	public AppsFlyerPurchaseConnector() { }

	private void Awake() { }

	public static void build() { }

	public static AppsFlyerPurchaseConnector get_Instance() { }

	public static void init(MonoBehaviour unityObject, Store s) { }

	private static int mapStoreToInt(Store s) { }

	public static void setAutoLogPurchaseRevenue(AppsFlyerAutoLogPurchaseRevenueOptions[] autoLogPurchaseRevenueOptions) { }

	public static void setIsSandbox(bool isSandbox) { }

	public static void setPurchaseRevenueDataSource(IAppsFlyerPurchaseRevenueDataSource dataSource) { }

	public static void setPurchaseRevenueDataSourceStoreKit2(IAppsFlyerPurchaseRevenueDataSourceStoreKit2 dataSourceSK2) { }

	public static void setPurchaseRevenueValidationListeners(bool enableCallbacks) { }

	public static void setStoreKitVersion(StoreKitVersion storeKitVersion) { }

	public static void startObservingTransactions() { }

	public static void stopObservingTransactions() { }

}

