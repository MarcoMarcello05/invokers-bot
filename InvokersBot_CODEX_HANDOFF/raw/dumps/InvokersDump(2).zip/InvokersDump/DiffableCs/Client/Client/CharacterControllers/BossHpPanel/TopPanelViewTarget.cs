namespace Client.CharacterControllers.BossHpPanel;

public enum TopPanelViewTarget : int
{
	Regular = 0,
	Boss = 1,
	MiniBoss = 2,
	Elite = 3,
}

