namespace Client.Analytics.Marketing;

[Nullable(0)]
[NullableContext(1)]
public sealed class AttributionEventMapper
{
	private const string StartTutorialEventName = "tutorial_started"; //Field offset: 0x0
	private const string CompleteRegistrationEventName = "registration"; //Field offset: 0x0
	private const string LevelStartedEventPrefix = "level_started_"; //Field offset: 0x0
	private const string LevelFinishedEventPrefix = "level_completed_"; //Field offset: 0x0
	private const string TutorialStepCompletedEventName = "tutorial_step_completed"; //Field offset: 0x0
	private const string TutorialCompletedEventName = "tutorial_completed"; //Field offset: 0x0
	private const string TutorialStepIdParam = "step_id"; //Field offset: 0x0
	private const string TutorialStepNameParam = "step_name"; //Field offset: 0x0

	public AttributionEventMapper() { }

	private static int CalculateLevelValue(RegionId regionId, int levelNumber) { }

	private AttributionEvent CreateLevelFinishedEvent(FirstChapterLevelPassedBiEvent finishLevel) { }

	private AttributionEvent CreateLevelStartedEvent(FirstChapterLevelStartedBiEvent startLevelBattle) { }

	private AttributionEvent CreateRegistrationEvent(GameStartedBiEvent loginCompleted) { }

	private AttributionEvent CreateSingleFireEvent(string originalEventName, IReadOnlyCollection<EventParam> originalParameters) { }

	private static AttributionEvent CreateSingleFireEvent(string eventName, IReadOnlyCollection<EventParam> parameters, string stateKey = null) { }

	private AttributionEvent CreateTutorialStepEvent(TutorialStepCompletedBiEvent tutorialEvent) { }

	public AttributionEvent MapExistingBiEvent(IClientBiEvent biEvent, string originalEventName, IReadOnlyCollection<EventParam> originalParameters) { }

}

