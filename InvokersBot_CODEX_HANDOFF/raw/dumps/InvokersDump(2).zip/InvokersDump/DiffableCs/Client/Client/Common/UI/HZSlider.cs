namespace Client.Common.UI;

public class HZSlider : Slider, ISlider
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Action<Unit, HZSlider> <>9__32_0; //Field offset: 0x8
		public static Action<Unit, HZSlider> <>9__32_1; //Field offset: 0x10
		public static Action<Single, HZSlider> <>9__32_2; //Field offset: 0x18
		public static Action<Single, HZSlider> <>9__39_0; //Field offset: 0x20

		private static <>c() { }

		public <>c() { }

		internal void <Awake>b__32_0(Unit _, HZSlider self) { }

		internal void <Awake>b__32_1(Unit _, HZSlider self) { }

		internal void <Awake>b__32_2(float val, HZSlider self) { }

		internal void <Bind>b__39_0(float _, HZSlider self) { }

	}

	[SerializeField]
	private TextMeshProUGUI _label; //Field offset: 0x168
	[SerializeField]
	private HZRepeatableButton _minusButton; //Field offset: 0x170
	[SerializeField]
	private HZRepeatableButton _plusButton; //Field offset: 0x178
	[SerializeField]
	private ButtonSoundReference _handlePressSoundRef; //Field offset: 0x180
	[SerializeField]
	private bool _stopPressSoundOnRelease; //Field offset: 0x188
	[SerializeField]
	private ButtonSoundReference _handleMoveSoundRef; //Field offset: 0x190
	[SerializeField]
	private ButtonSoundReference _handleReleaseSoundRef; //Field offset: 0x198
	[SerializeField]
	private bool _playReleaseSoundOnlyIfMoved; //Field offset: 0x1A0
	public float Step; //Field offset: 0x1A4
	public float ClickStep; //Field offset: 0x1A8
	[SerializeField]
	private uint _debounceMs; //Field offset: 0x1AC
	[SerializeField]
	private BaseHZButtonProcessAnimation _stateVisualizer; //Field offset: 0x1B0
	[SerializeField]
	private bool _useStateVisualiser; //Field offset: 0x1B8
	private IButtonCommand _command; //Field offset: 0x1C0
	private IDisposable _commandDisposable; //Field offset: 0x1C8
	private readonly Subject<Single> _valueChangedSubject; //Field offset: 0x1D0
	private bool _moved; //Field offset: 0x1D8
	[CompilerGenerated]
	private bool <ShowSpinnerOnLongExecution>k__BackingField; //Field offset: 0x1D9

	public override bool ActiveSelf
	{
		 get { } //Length: 32
		 set { } //Length: 40
	}

	public override uint DebounceMs
	{
		 get { } //Length: 8
		 set { } //Length: 8
	}

	public override bool Interactable
	{
		 get { } //Length: 8
		 set { } //Length: 8
	}

	public override bool ShowSpinnerOnLongExecution
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public Observable<Single> ValueChanged
	{
		 get { } //Length: 8
	}

	public HZSlider() { }

	protected virtual void Awake() { }

	public override void Bind(IButtonCommand command) { }

	public override bool get_ActiveSelf() { }

	public override uint get_DebounceMs() { }

	public override bool get_Interactable() { }

	[CompilerGenerated]
	public override bool get_ShowSpinnerOnLongExecution() { }

	public Observable<Single> get_ValueChanged() { }

	public void Init(float input) { }

	protected virtual void OnDestroy() { }

	public virtual void OnDrag(PointerEventData eventData) { }

	public virtual void OnPointerDown(PointerEventData eventData) { }

	public virtual void OnPointerUp(PointerEventData eventData) { }

	protected virtual void Set(float input, bool sendCallback = true) { }

	public override void set_ActiveSelf(bool value) { }

	public override void set_DebounceMs(uint value) { }

	public override void set_Interactable(bool value) { }

	[CompilerGenerated]
	public override void set_ShowSpinnerOnLongExecution(bool value) { }

	private void UpdateButtonsInteractable() { }

}

