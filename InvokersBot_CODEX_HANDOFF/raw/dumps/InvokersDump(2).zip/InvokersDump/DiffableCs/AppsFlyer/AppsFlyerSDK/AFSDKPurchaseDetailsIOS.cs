namespace AppsFlyerSDK;

public class AFSDKPurchaseDetailsIOS
{

}

