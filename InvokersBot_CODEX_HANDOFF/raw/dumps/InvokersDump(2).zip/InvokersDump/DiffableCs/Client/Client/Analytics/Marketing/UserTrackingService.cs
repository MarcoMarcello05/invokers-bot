namespace Client.Analytics.Marketing;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public sealed class UserTrackingService : IUserTrackingService, IDisposable
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass52_0
	{
		private struct <<RunGuardedAttRefresh>b__0>d : IAsyncStateMachine
		{
			public int <>1__state; //Field offset: 0x0
			public AsyncUniTaskVoidMethodBuilder <>t__builder; //Field offset: 0x8
			[Nullable(0)]
			public <>c__DisplayClass52_0 <>4__this; //Field offset: 0x10
			private Awaiter <>u__1; //Field offset: 0x18

			private override void MoveNext() { }

			[DebuggerHidden]
			private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

		}

		[Nullable(0)]
		public Func<UniTask> refreshAsync; //Field offset: 0x10
		[Nullable(0)]
		public string failureLogMessage; //Field offset: 0x18
		[Nullable(0)]
		public UserTrackingService <>4__this; //Field offset: 0x20

		public <>c__DisplayClass52_0() { }

		[AsyncStateMachine(typeof(<<RunGuardedAttRefresh>b__0>d))]
		internal UniTaskVoid <RunGuardedAttRefresh>b__0() { }

	}

	[CompilerGenerated]
	private struct <CollectAdvertisingIdentifiersAsync>d__46 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public UserTrackingService <>4__this; //Field offset: 0x18
		[Nullable(0)]
		private Awaiter<AdvertisingIdentifiers> <>u__1; //Field offset: 0x20

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <InitializeAsync>d__45 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public UserTrackingService <>4__this; //Field offset: 0x18
		private Awaiter <>u__1; //Field offset: 0x20

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <PollAttStatusAsync>d__54 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public UserTrackingService <>4__this; //Field offset: 0x18
		public float requestStartRealtime; //Field offset: 0x20
		private float <startTime>5__2; //Field offset: 0x24
		private Awaiter <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <RefreshAttAuthorizationOnForegroundAsync>d__56 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public UserTrackingService <>4__this; //Field offset: 0x18
		private Awaiter <>u__1; //Field offset: 0x20

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <RequestTrackingAuthorizationAsync>d__53 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public UserTrackingService <>4__this; //Field offset: 0x18
		private Awaiter <>u__1; //Field offset: 0x20
		private Awaiter <>u__2; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[NullableContext(0)]
	private static class AttPlatform
	{

		public static bool IsAvailable
		{
			 get { } //Length: 8
		}

		public static bool get_IsAvailable() { }

		public static AttStatus GetStatus() { }

		public static bool IsIosAppOnMac() { }

		[NullableContext(1)]
		public static void RequestAuthorization(Action<Int32> onCompleted) { }

	}

	[NullableContext(0)]
	private enum AttStatus : int
	{
		NotDetermined = 0,
		Authorized = 1,
		Denied = 2,
		Restricted = 3,
	}

	private const int AttAuthorizationTimeoutSeconds = 60; //Field offset: 0x0
	private static readonly ILogger _log; //Field offset: 0x0
	private const string AttOutcomePromptNotPresented = "prompt_not_presented"; //Field offset: 0x0
	private const string AttOutcomeSkippedNoConsent = "skipped_no_consent"; //Field offset: 0x0
	private const string AttOutcomeConsentPending = "consent_pending"; //Field offset: 0x0
	private const string AttOutcomeNotIos = "not_ios"; //Field offset: 0x0
	private const string AttOutcomeSkippedNonHandheld = "skipped_non_handheld"; //Field offset: 0x0
	private const string AttOutcomeSkippedMac = "skipped_macos_compat"; //Field offset: 0x0
	private const string AttOutcomeSkippedPromptDisabled = "prompt_disabled"; //Field offset: 0x0
	private const string AttOutcomeRequestError = "request_error"; //Field offset: 0x0
	private const string AttOutcomeNotDetermined = "not_determined"; //Field offset: 0x0
	private const string AttOutcomeTimeoutNotDetermined = "timeout_not_determined"; //Field offset: 0x0
	private const string AttOutcomeRestricted = "restricted"; //Field offset: 0x0
	private const string AttOutcomeDenied = "denied"; //Field offset: 0x0
	private const string AttOutcomeUnavailableAssumedAuthorized = "sdk_unavailable_assumed_authorized"; //Field offset: 0x0
	private const string AttOutcomeAuthorized = "authorized"; //Field offset: 0x0
	private const int AdvertisingIdCollectionTimeoutSeconds = 3; //Field offset: 0x0
	private readonly IDisposable _focusSubscription; //Field offset: 0x10
	private readonly IDisposable _consentChangedSubscription; //Field offset: 0x18
	private readonly IConsentService _consentService; //Field offset: 0x20
	private readonly IOptionsMonitor<ClientAppSettings> _appSettings; //Field offset: 0x28
	private readonly UniTaskCompletionSource _initializationCompletion; //Field offset: 0x30
	private bool _initializationStarted; //Field offset: 0x38
	private bool _attRefreshInProgress; //Field offset: 0x39
	private bool _attRequestCompletedNotDetermined; //Field offset: 0x3A
	private bool _attAuthorized; //Field offset: 0x3B
	private bool _attAuthorizationResolved; //Field offset: 0x3C
	private string _attAuthorizationOutcome; //Field offset: 0x40
	[CompilerGenerated]
	private readonly string <DeviceId>k__BackingField; //Field offset: 0x48
	private readonly Subject<Unit> _attStateChanged; //Field offset: 0x50

	public override string AttAuthorizationOutcome
	{
		 get { } //Length: 8
	}

	public override Observable<Unit> AttStateChanged
	{
		 get { } //Length: 8
	}

	public override string DeviceId
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public override bool IsAttAuthorizationResolved
	{
		 get { } //Length: 8
	}

	public override bool IsAttAuthorized
	{
		 get { } //Length: 8
	}

	private static UserTrackingService() { }

	public UserTrackingService(IGameLifeCycleObserver lifeCycleObserver, IConsentService consentService, IOptionsMonitor<ClientAppSettings> appSettings) { }

	[CompilerGenerated]
	private void <.ctor>b__42_0(Unit _) { }

	private void ApplyAttStatus(AttStatus status) { }

	[AsyncStateMachine(typeof(<CollectAdvertisingIdentifiersAsync>d__46))]
	private UniTask CollectAdvertisingIdentifiersAsync() { }

	public override void Dispose() { }

	public override string get_AttAuthorizationOutcome() { }

	public override Observable<Unit> get_AttStateChanged() { }

	[CompilerGenerated]
	public override string get_DeviceId() { }

	public override bool get_IsAttAuthorizationResolved() { }

	public override bool get_IsAttAuthorized() { }

	public override UniTask InitAsync() { }

	[AsyncStateMachine(typeof(<InitializeAsync>d__45))]
	private UniTask InitializeAsync() { }

	private bool IsAttAuthorizationUnknown() { }

	private static string LoadDeviceIdOrCreate() { }

	private void OnApplicationFocus(bool focused) { }

	private void OnAttRequestCompleted(int status) { }

	private void OnConsentChanged() { }

	[AsyncStateMachine(typeof(<PollAttStatusAsync>d__54))]
	private UniTask PollAttStatusAsync(float requestStartRealtime) { }

	[AsyncStateMachine(typeof(<RefreshAttAuthorizationOnForegroundAsync>d__56))]
	private UniTask RefreshAttAuthorizationOnForegroundAsync() { }

	[AsyncStateMachine(typeof(<RequestTrackingAuthorizationAsync>d__53))]
	private UniTask RequestTrackingAuthorizationAsync() { }

	private void RunGuardedAttRefresh(Func<UniTask> refreshAsync, string failureLogMessage) { }

	private void SetAttAuthorizationState(bool isAuthorized, bool isResolved, string outcome) { }

}

