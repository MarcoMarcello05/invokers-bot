namespace Client.Animations;

[Extension]
public static class AnimationUtils
{

	public static List<KeyValuePair`2<AnimationClip, AnimationClip>> GetAnimationOverrides(GameObject prefab) { }

	[Extension]
	public static void PlayReverse(Animation anim) { }

	[Extension]
	public static void Reset(Animation anim) { }

	[Extension]
	public static void SetLastFrame(Animation anim) { }

	[Extension]
	public static void UpdateImmediately(Animator animator) { }

}

