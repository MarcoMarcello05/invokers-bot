namespace Client.Core.ErrorHandling;

[UsedAsInjection]
public class CollectionLimitReachedPopupController : AwaitableDialogController<CollectionLimitReachedPopup>
{
	[CompilerGenerated]
	private struct <HandleCloseAsync>d__17 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public CollectionLimitReachedPopupController <>4__this; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <HandleDismissAsync>d__16 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncValueTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public CollectionLimitReachedPopupController <>4__this; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ShowUntilClosedAsync>d__10 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder<Boolean> <>t__builder; //Field offset: 0x8
		public CollectionLimitReachedPopupController <>4__this; //Field offset: 0x20
		public string title; //Field offset: 0x28
		public string description; //Field offset: 0x30
		public CollectionLimitType collectionLimitType; //Field offset: 0x38
		public Nullable<Int32> requiredSlots; //Field offset: 0x3C
		private Awaiter <>u__1; //Field offset: 0x48

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IContentManager _content; //Field offset: 0x88
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x90
	private readonly ButtonCommandBuilder _buttonCommandBuilder; //Field offset: 0x98
	private readonly IChoreographManager _choreographManager; //Field offset: 0xA0
	private string _title; //Field offset: 0xA8
	private string _description; //Field offset: 0xB0
	private CollectionLimitType _collectionLimitType; //Field offset: 0xB8
	private Nullable<Int32> _requiredSlots; //Field offset: 0xBC
	private bool _shouldOpenDismissal; //Field offset: 0xC4

	public CollectionLimitReachedPopupController(IUISystem uiSystem, IContentManager content, IStagingContainer stagingContainer, ButtonCommandBuilder buttonCommandBuilder, IChoreographManager choreographManager) { }

	[CompilerGenerated]
	[DebuggerHidden]
	private UniTask <>n__0(DialogSubLayer dialogSubLayer, bool forceShow, bool showBlocker, CancellationToken cancellationToken) { }

	private ValueTuple<Int32, Int32> GetCapacity() { }

	private static ValueTuple<Single, Single> GetCapacityRatios(int current, int requiredSlots) { }

	private string GetRequiredSlotsLabel(int requiredSlots) { }

	[AsyncStateMachine(typeof(<HandleCloseAsync>d__17))]
	private ValueTask HandleCloseAsync() { }

	[AsyncStateMachine(typeof(<HandleDismissAsync>d__16))]
	private ValueTask HandleDismissAsync() { }

	protected virtual void OnViewLoaded() { }

	[AsyncStateMachine(typeof(<ShowUntilClosedAsync>d__10))]
	public UniTask<Boolean> ShowUntilClosedAsync(string title, string description, CollectionLimitType collectionLimitType, Nullable<Int32> requiredSlots = null) { }

	protected virtual IAsyncInitializable<CollectionLimitReachedPopup> ViewFactory() { }

}

