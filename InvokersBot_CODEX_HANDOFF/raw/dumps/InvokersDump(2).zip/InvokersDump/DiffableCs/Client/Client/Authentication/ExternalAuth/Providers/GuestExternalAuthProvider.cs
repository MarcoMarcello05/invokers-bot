namespace Client.Authentication.ExternalAuth.Providers;

[Nullable(0)]
[NullableContext(1)]
public sealed class GuestExternalAuthProvider : IExternalAuthProvider
{
	private readonly ILogger<GuestExternalAuthProvider> _logger; //Field offset: 0x10
	private readonly IClientKeyValueStore _clientKeyValueStore; //Field offset: 0x18
	private readonly IOptionsMonitor<ClientAppSettings> _appSettings; //Field offset: 0x20

	public override bool IsAvailable
	{
		 get { } //Length: 8
	}

	public override ExternalLoginProvider Provider
	{
		 get { } //Length: 8
	}

	public GuestExternalAuthProvider(IClientKeyValueStore clientKeyValueStore, IOptionsMonitor<ClientAppSettings> appSettings) { }

	public override bool get_IsAvailable() { }

	public override ExternalLoginProvider get_Provider() { }

	[NullableContext(2)]
	public override string GetCurrentUserName() { }

	[NullableContext(2)]
	private static bool IsInvalidStableGuestKey(string value) { }

	private string ResolveStableGuestKey() { }

	[NullableContext(0)]
	public override ValueTask<ExternalAuthResult> TryAuthenticateAsync(ExternalAuthMode mode, CancellationToken ct = null) { }

}

