namespace Ara;

[RequireComponent(typeof(AraTrail))]
public class ElectricalArc : MonoBehaviour
{
	private AraTrail trail; //Field offset: 0x20
	public Transform source; //Field offset: 0x28
	public Transform target; //Field offset: 0x30
	public int points; //Field offset: 0x38
	public float burstInterval; //Field offset: 0x3C
	public float burstRandom; //Field offset: 0x40
	public float speedRandom; //Field offset: 0x44
	public float positionRandom; //Field offset: 0x48
	private float accum; //Field offset: 0x4C

	public ElectricalArc() { }

	private void ChangeArc() { }

	private void OnEnable() { }

	private void Update() { }

}

