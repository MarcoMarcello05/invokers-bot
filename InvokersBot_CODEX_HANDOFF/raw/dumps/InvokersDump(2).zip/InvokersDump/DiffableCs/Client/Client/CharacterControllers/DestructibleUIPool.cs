namespace Client.CharacterControllers;

[UsedAsInjection]
public class DestructibleUIPool : SharedGameObjectsPool<DestructibleUI>
{
	[CompilerGenerated]
	private sealed class <get_RequiredAssets>d__5 : IEnumerable<AssetKey>, IEnumerable, IEnumerator<AssetKey>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private AssetKey <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20

		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <get_RequiredAssets>d__5(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<AssetKey> System.Collections.Generic.IEnumerable<Client.AssetKey>.GetEnumerator() { }

		[DebuggerHidden]
		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private struct <Init>d__6 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public DestructibleUIPool <>4__this; //Field offset: 0x18
		private IAssetRequest<GameObject> <request>5__2; //Field offset: 0x20
		private Awaiter<GameObject> <>u__1; //Field offset: 0x28
		private Awaiter <>u__2; //Field offset: 0x40

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IContentManager _content; //Field offset: 0x80
	private DestructibleUI _template; //Field offset: 0x88

	protected virtual IEnumerable<AssetKey> RequiredAssets
	{
		[IteratorStateMachine(typeof(<get_RequiredAssets>d__5))]
		 get { } //Length: 108
	}

	public DestructibleUIPool(IBootstrap bootstrap, IContentManager content, IOptionsMonitor<ContentSettings> settings) { }

	[IteratorStateMachine(typeof(<get_RequiredAssets>d__5))]
	protected virtual IEnumerable<AssetKey> get_RequiredAssets() { }

	[AsyncStateMachine(typeof(<Init>d__6))]
	protected virtual UniTask Init(IOperationProgressObserver onProgressChange) { }

	public DestructibleUI Rent() { }

}

