namespace Client;

[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
[NullableContext(1)]
public class AssetLoadingTask : BaseAssetLoadingTask<T>
{
	[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
	protected AsyncOperationHandle<T> Operation; //Field offset: 0x0

	public virtual DownloadStatus DownloadStatus
	{
		 get { } //Length: 152
	}

	public virtual bool Ready
	{
		 get { } //Length: 180
	}

	public AssetLoadingTask`1(AssetKey key, AddressableAssetProvider assetProvider, bool errorOnDownload = false) { }

	[CompilerGenerated]
	private void <StartLoad>b__6_0(AsyncOperationHandle<T> op) { }

	protected override AsyncOperationHandle<T> CreateLoadOperation() { }

	public virtual void DecrementRefCount() { }

	public virtual void Dispose() { }

	public virtual DownloadStatus get_DownloadStatus() { }

	public virtual bool get_Ready() { }

	public virtual void IncrementRefCount() { }

	public virtual void StartLoad(IDownloadsTracker downloadsTracker) { }

	public virtual void SubscribeToProgress(Action<DownloadStatus> onProgress) { }

}

