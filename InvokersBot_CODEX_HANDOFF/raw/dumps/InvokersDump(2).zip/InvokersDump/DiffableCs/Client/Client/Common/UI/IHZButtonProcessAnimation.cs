namespace Client.Common.UI;

public interface IHZButtonProcessAnimation
{

	public void CommandCompleted(bool isSuccess) { }

	public void CommandStarted() { }

}

