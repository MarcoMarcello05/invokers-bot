namespace Client.Common.UI;

public class AnimationClipDictionary : SerializableDictionary<String, AnimationClip>
{

	public AnimationClipDictionary() { }

}

