namespace Client;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public class AddressableAssetProvider : IAssetProvider, IDisposable
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass23_0
	{
		[Nullable(0)]
		public IAssetRequest<T> request; //Field offset: 0x0

		public <>c__DisplayClass23_0`1() { }

		internal void <LoadAsync>b__0() { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass33_0
	{
		[Nullable(0)]
		public IAssetLoadingTask<T> assetTask; //Field offset: 0x0
		[Nullable(0)]
		public Action<T> onSuccess; //Field offset: 0x0

		public <>c__DisplayClass33_0`1() { }

		[NullableContext(0)]
		internal void <AttachCallbacksForSharedRequest>b__0(T asset) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass35_0
	{
		[Nullable(0)]
		public AssetRequest<T> request; //Field offset: 0x0
		[Nullable(0)]
		public Action<T> onCompleted; //Field offset: 0x0

		public <>c__DisplayClass35_0`1() { }

		[NullableContext(0)]
		internal void <LoadInternalWithCallback>b__0(T asset) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass36_0
	{
		[Nullable(0)]
		public AddressableAssetProvider <>4__this; //Field offset: 0x0
		[Nullable(0)]
		public AssetRequest<T> request; //Field offset: 0x0
		[Nullable(0)]
		public Action<T> onCompleted; //Field offset: 0x0
		[Nullable(0)]
		public Action<DownloadStatus> onProgress; //Field offset: 0x0

		public <>c__DisplayClass36_0`1() { }

		internal void <DownloadAndLoadInternalWithCallback>b__0() { }

	}

	[CompilerGenerated]
	private struct <InitializeAsync>d__20 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public AddressableAssetProvider <>4__this; //Field offset: 0x18
		[Nullable(0)]
		public IResourcesApi resourcesApi; //Field offset: 0x20
		private AutoScope <_>5__2; //Field offset: 0x28
		[Nullable(0)]
		private Stopwatch <timer>5__3; //Field offset: 0x40
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private AsyncOperationHandle<IResourceLocator> <initOpHandle>5__4; //Field offset: 0x48
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private TaskAwaiter<IResourceLocator> <>u__1; //Field offset: 0x60

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <LoadAsync>d__23 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<IAssetRequest`1<T>> <>t__builder; //Field offset: 0x0
		[Nullable(0)]
		public AddressableAssetProvider <>4__this; //Field offset: 0x0
		[Nullable(0)]
		public AssetKey key; //Field offset: 0x0
		[Nullable(0)]
		public Action<DownloadStatus> onProgress; //Field offset: 0x0
		public bool errorOnDownload; //Field offset: 0x0
		[Nullable(0)]
		public string diagnosticScopeTag; //Field offset: 0x0
		[Nullable(0)]
		public string callerMemberName; //Field offset: 0x0
		[Nullable(0)]
		public string callerFilePath; //Field offset: 0x0
		public int callerLineNumber; //Field offset: 0x0
		public CancellationToken cancellation; //Field offset: 0x0
		[Nullable(0)]
		private <>c__DisplayClass23_0<T> <>8__1; //Field offset: 0x0
		private CancellationTokenRegistration <registration>5__2; //Field offset: 0x0
		[Nullable(0)]
		private Awaiter<T> <>u__1; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <LoadInternalWithCallback>d__35 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x0
		[Nullable(0)]
		public AssetRequest<T> request; //Field offset: 0x0
		[Nullable(0)]
		public Action<T> onCompleted; //Field offset: 0x0
		[Nullable(0)]
		public AddressableAssetProvider <>4__this; //Field offset: 0x0
		[Nullable(0)]
		private <>c__DisplayClass35_0<T> <>8__1; //Field offset: 0x0
		[Nullable(0)]
		public Action<DownloadStatus> onProgress; //Field offset: 0x0
		private Awaiter <>u__1; //Field offset: 0x0
		[Nullable(0)]
		private Awaiter<T> <>u__2; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <LoadSceneAsync>d__24 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<IAssetRequest`1<SceneInstance>> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public AddressableAssetProvider <>4__this; //Field offset: 0x20
		[Nullable(0)]
		public AssetKey key; //Field offset: 0x28
		public LoadSceneMode mode; //Field offset: 0x30
		public bool activateOnLoad; //Field offset: 0x34
		[Nullable(0)]
		public Action<DownloadStatus> onProgress; //Field offset: 0x38
		[Nullable(0)]
		public string diagnosticScopeTag; //Field offset: 0x40
		[Nullable(0)]
		public string callerMemberName; //Field offset: 0x48
		[Nullable(0)]
		public string callerFilePath; //Field offset: 0x50
		public int callerLineNumber; //Field offset: 0x58
		[Nullable(0)]
		private IAssetRequest<SceneInstance> <request>5__2; //Field offset: 0x60
		[Nullable(0)]
		private Awaiter<SceneInstance> <>u__1; //Field offset: 0x68

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <TrackCacheOnSuccess>d__32 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x0
		[Nullable(0)]
		public AddressableAssetProvider <>4__this; //Field offset: 0x0
		[Nullable(0)]
		public AssetKey key; //Field offset: 0x0
		[Nullable(0)]
		public IAssetLoadingTask<T> loadingTask; //Field offset: 0x0
		[Nullable(0)]
		private AssetCache <cache>5__2; //Field offset: 0x0
		private int <generation>5__3; //Field offset: 0x0
		[Nullable(0)]
		private Awaiter<T> <>u__1; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[Nullable(0)]
	private class PendingAssetLoadRequest : IEquatable<PendingAssetLoadRequest>
	{
		[CompilerGenerated]
		private readonly AssetKey <Key>k__BackingField; //Field offset: 0x10
		[CompilerGenerated]
		private readonly IAssetLoadingTask <AssetLoadingTask>k__BackingField; //Field offset: 0x18
		[CompilerGenerated]
		private readonly Action <StartLoading>k__BackingField; //Field offset: 0x20

		public IAssetLoadingTask AssetLoadingTask
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		[CompilerGenerated]
		protected override Type EqualityContract
		{
			[CompilerGenerated]
			 get { } //Length: 96
		}

		public AssetKey Key
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public Action StartLoading
		{
			[CompilerGenerated]
			 get { } //Length: 8
			[CompilerGenerated]
			 set { } //Length: 8
		}

		public PendingAssetLoadRequest(AssetKey Key, IAssetLoadingTask AssetLoadingTask, Action StartLoading) { }

		[CompilerGenerated]
		protected PendingAssetLoadRequest(PendingAssetLoadRequest original) { }

		[CompilerGenerated]
		public override PendingAssetLoadRequest <Clone>$() { }

		[CompilerGenerated]
		public void Deconstruct(out AssetKey Key, out IAssetLoadingTask AssetLoadingTask, out Action StartLoading) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public virtual bool Equals(object obj) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public override bool Equals(PendingAssetLoadRequest other) { }

		[CompilerGenerated]
		public IAssetLoadingTask get_AssetLoadingTask() { }

		[CompilerGenerated]
		protected override Type get_EqualityContract() { }

		[CompilerGenerated]
		public AssetKey get_Key() { }

		[CompilerGenerated]
		public Action get_StartLoading() { }

		[CompilerGenerated]
		public virtual int GetHashCode() { }

		[CompilerGenerated]
		[NullableContext(2)]
		public static bool op_Equality(PendingAssetLoadRequest left, PendingAssetLoadRequest right) { }

		[CompilerGenerated]
		[NullableContext(2)]
		public static bool op_Inequality(PendingAssetLoadRequest left, PendingAssetLoadRequest right) { }

		[CompilerGenerated]
		protected override bool PrintMembers(StringBuilder builder) { }

		[CompilerGenerated]
		public void set_AssetLoadingTask(IAssetLoadingTask value) { }

		[CompilerGenerated]
		public void set_Key(AssetKey value) { }

		[CompilerGenerated]
		public void set_StartLoading(Action value) { }

		[CompilerGenerated]
		public virtual string ToString() { }

	}

	private static readonly Activity AddressablesInitializeActivityMarker; //Field offset: 0x0
	public const int MAX_DOWNLOAD_CONCURRENCY = 2; //Field offset: 0x0
	private readonly AddressablesUrlsSigner _urlsSigner; //Field offset: 0x10
	private readonly IDownloadsTracker _downloadsTracker; //Field offset: 0x18
	private readonly IDownloadManager _downloadManager; //Field offset: 0x20
	private readonly Stack<PendingAssetLoadRequest> _loadingStack; //Field offset: 0x28
	private readonly ContentSettings _config; //Field offset: 0x30
	private readonly CompositeDisposable _disposableBag; //Field offset: 0x38
	private readonly Dictionary<AssetKey, IAssetLoadingTask> _assetRegistry; //Field offset: 0x40
	private readonly Dictionary<AssetCacheGroup, AssetCache> _assetCaches; //Field offset: 0x48
	private readonly Dictionary<AssetKey, AssetDiagnostics> _diagnostics; //Field offset: 0x50
	private int _cacheGeneration; //Field offset: 0x58

	private bool DiagnosticsEnabled
	{
		private get { } //Length: 204
	}

	private static AddressableAssetProvider() { }

	public AddressableAssetProvider(IDownloadsTracker downloadsTracker, IDownloadManager downloadManager, IGameStateManagerObserver gameStateManagerObserver, IOptionsMonitor<ContentSettings> contentSettings) { }

	[CompilerGenerated]
	[NullableContext(0)]
	private void <.ctor>b__15_0(Type _) { }

	[NullableContext(2)]
	private void AttachCallbacksForSharedRequest(IAssetLoadingTask<T> assetTask, Action<T> onSuccess, Action<DownloadStatus> onProgress) { }

	public void CheckForLeakedRequests(string diagnosticScopeTag) { }

	public override void ClearCaches() { }

	private void ClearDiagnosticsFor(AssetKey key) { }

	private static Dictionary<AssetCacheGroup, AssetCache> CreateAssetCaches(ContentSettings config) { }

	private IAssetLoadingTask<T> CreateAssetLoadingTask(AssetKey key, AddressableAssetProvider assetProvider, bool errorOnDownload = false) { }

	public override void Dispose() { }

	[NullableContext(2)]
	private void DownloadAndLoadInternalWithCallback(AssetRequest<T> request, Action<T> onCompleted, Action<DownloadStatus> onProgress) { }

	private void DumpCacheDiagnostics() { }

	public void DumpDiagnostics() { }

	private static string FormatOwnerLabel(string callerMemberName, string callerFilePath, int callerLineNumber) { }

	private bool get_DiagnosticsEnabled() { }

	public IReadOnlyList<AssetCacheSnapshot> GetAssetCacheSnapshots() { }

	public IReadOnlyList<AssetProviderAssetSnapshot> GetLoadedAssetSnapshots() { }

	private static string GetStatus(IAssetLoadingTask task) { }

	[AsyncStateMachine(typeof(<InitializeAsync>d__20))]
	public UniTask InitializeAsync(IResourcesApi resourcesApi) { }

	public override IAssetRequest<T> Load(AssetKey key, Action<T> onSuccess = null, Action<DownloadStatus> onProgress = null, bool errorOnDownload = false, string diagnosticScopeTag = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	[AsyncStateMachine(typeof(<LoadAsync>d__23`1))]
	public override UniTask<IAssetRequest`1<T>> LoadAsync(AssetKey key, Action<DownloadStatus> onProgress = null, CancellationToken cancellation = null, bool errorOnDownload = false, string diagnosticScopeTag = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	[AsyncStateMachine(typeof(<LoadInternalWithCallback>d__35`1))]
	[NullableContext(2)]
	private UniTask LoadInternalWithCallback(AssetRequest<T> request, Action<T> onCompleted = null, Action<DownloadStatus> onProgress = null) { }

	public override IAssetRequest<SceneInstance> LoadScene(AssetKey key, LoadSceneMode mode = 0, bool activateOnLoad = true, Action<DownloadStatus> onProgress = null, string diagnosticScopeTag = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	[AsyncStateMachine(typeof(<LoadSceneAsync>d__24))]
	public override UniTask<IAssetRequest`1<SceneInstance>> LoadSceneAsync(AssetKey key, LoadSceneMode mode = 0, bool activateOnLoad = true, Action<DownloadStatus> onProgress = null, string diagnosticScopeTag = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	internal void OnAssetTaskDisposing(IAssetLoadingTask assetLoadingTask) { }

	private void ProcessLoadingQueue(Unit _) { }

	[NullableContext(2)]
	private int RegisterDiagnosticsOwner(AssetKey key, string ownerLabel, IAssetLoadingTask assetLoadingTask, string gameStateName = null) { }

	internal void ReleaseDiagnosticsOwner(AssetKey key, int ownerId) { }

	private void RemoveFromCache(AssetKey key) { }

	[NullableContext(2)]
	private void StartLoadingInternal(AssetRequest<T> request, Action<T> onSuccess = null, Action<DownloadStatus> onProgress = null) { }

	private void TouchCache(AssetKey key) { }

	[AsyncStateMachine(typeof(<TrackCacheOnSuccess>d__32`1))]
	private UniTask TrackCacheOnSuccess(AssetKey key, IAssetLoadingTask<T> loadingTask) { }

	private bool TryGetCache(AssetCacheGroup group, out AssetCache cache) { }

}

