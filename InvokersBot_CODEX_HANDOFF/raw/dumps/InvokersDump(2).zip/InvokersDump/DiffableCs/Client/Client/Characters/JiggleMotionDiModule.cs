namespace Client.Characters;

[Extension]
public static class JiggleMotionDiModule
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Action<IObjectResolver> <>9__0_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal void <AddJiggleMotion>b__0_0(IObjectResolver resolver) { }

	}


	[Extension]
	public static IContainerBuilder AddJiggleMotion(IContainerBuilder builder) { }

}

