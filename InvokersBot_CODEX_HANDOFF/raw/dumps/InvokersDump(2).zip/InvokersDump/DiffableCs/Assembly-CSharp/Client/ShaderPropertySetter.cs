namespace Client;

[ExecuteAlways]
public class ShaderPropertySetter : MonoBehaviour
{
	private struct Original
	{
		public Material mat; //Field offset: 0x0
		public int propId; //Field offset: 0x8
		public bool isVector; //Field offset: 0xC
		public Vector4 vec; //Field offset: 0x10
		public float flt; //Field offset: 0x20

	}

	[Tooltip("Shader property name (e.g. _MainTex_Tiling or _Cutoff)")]
	public string property; //Field offset: 0x20
	[Tooltip(" write float")]
	public bool isFloat; //Field offset: 0x28
	[Tooltip("0..3: write X/Y/Z/W of a Vector/Color.")]
	public int component; //Field offset: 0x2C
	public float floatValue; //Field offset: 0x30
	private readonly List<Material> _targets; //Field offset: 0x38
	private readonly HashSet<Material> _seen; //Field offset: 0x40
	private readonly List<Original> _originals; //Field offset: 0x48
	private int _propId; //Field offset: 0x50
	private bool _propIdValid; //Field offset: 0x54
	private bool _captured; //Field offset: 0x55

	public ShaderPropertySetter() { }

	private void Apply() { }

	private void CachePropId() { }

	private void CaptureMissingOriginals() { }

	private void CollectMaterialsOnThisObject() { }

	private bool HasOriginal(Material m, int propId, bool isVector) { }

	private void OnDidApplyAnimationProperties() { }

	private void OnDisable() { }

	private void OnEnable() { }

	private void OnValidate() { }

	private void RestoreOriginals() { }

	private void Update() { }

}

