namespace Client.Core.GameServices;

public interface ILoadingScreenService
{

	public ILoadingScreenController ActiveLoadingScreen
	{
		 get { } //Length: 0
	}

	public ILoadingScreenController get_ActiveLoadingScreen() { }

	public ILoadingScreenController GetLoadingScreenByType(LoadingScreenType loadingScreenType) { }

	public LoadingWithSpinnerScreenController GetSpinnerLoadingScreen(bool showBackground, bool showLoadingText) { }

	public UniTask HideActiveLoadingScreen() { }

	public bool IsAnyLoadingScreenVisible() { }

	public UniTask ShowAsLoadingScreenAsync(LoadingScreenType loadingScreenType) { }

	public UniTask ShowAsLoadingScreenAsync(ILoadingScreenController loadingScreenController) { }

	public UniTask ShowAsLoadingScreenAsync(ILoadingScreenController loadingScreenController, WaitScope relatedWait) { }

}

