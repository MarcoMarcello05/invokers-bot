namespace Client.CharacterControllers.OwnerHpPanel;

public struct TopPanelHealth
{
	public long Health; //Field offset: 0x0
	public long MaxHealth; //Field offset: 0x8
	public int Shield; //Field offset: 0x10
	public int HealthDestroyed; //Field offset: 0x14

}

