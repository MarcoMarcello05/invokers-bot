namespace Client.Configuration;

[Extension]
public static class IConfigurationBuilderExtensions
{
	private const string EDITOR_MEMORY_SETTING_KEY = "EditorPlatformMemoryLevel"; //Field offset: 0x0
	private static readonly string ConfigPathTemplate; //Field offset: 0x0

	private static IConfigurationBuilderExtensions() { }

	[Extension]
	public static IConfigurationBuilder AddEditorAppSettings(IConfigurationBuilder builder, Nullable<AppEnvironment> environment) { }

	[Extension]
	public static IConfigurationBuilder AddEditorMemoryConfig(IConfigurationBuilder builder) { }

	[Extension]
	public static IConfigurationBuilder AddPlatformConfig(IConfigurationBuilder builder, QualityTier deviceQualityOverride = 0) { }

	public static EditorPlatformMemoryTier GetEditorSettingsMemoryTier() { }

	public static void SetEditorSettingsMemoryTier(EditorPlatformMemoryTier tier) { }

}

