namespace Client.CharacterControllers;

public enum CharacterStandSide : int
{
	Any = 0,
	Right = 1,
	Left = 2,
}

