namespace Client.Common.UI;

public abstract class BaseHZButtonProcessAnimation : MonoBehaviour, IHZButtonProcessAnimation
{

	protected BaseHZButtonProcessAnimation() { }

	public abstract void CommandCompleted(bool isSuccess) { }

	public abstract void CommandStarted() { }

}

