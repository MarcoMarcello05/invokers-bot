namespace Client.Lobby;

[DisallowMultipleComponent]
[ExecuteAlways]
public class LobbyObjectOffests : MonoBehaviour
{
	private const float PositionEpsilon = 1E-06; //Field offset: 0x0
	private const float MinAspect = 0,0001; //Field offset: 0x0
	private const float ReferenceAspect = 1,7777778; //Field offset: 0x0
	[SerializeField]
	[Tooltip("Local X units applied for each 1.0 aspect-ratio amount wider than 16:9.")]
	private float _localXOffsetPerAspectDelta; //Field offset: 0x20
	private int _lastScreenWidth; //Field offset: 0x24
	private int _lastScreenHeight; //Field offset: 0x28
	private int _lastSafeAreaX; //Field offset: 0x2C
	private int _lastSafeAreaY; //Field offset: 0x30
	private int _lastSafeAreaWidth; //Field offset: 0x34
	private int _lastSafeAreaHeight; //Field offset: 0x38
	private ScreenOrientation _lastScreenOrientation; //Field offset: 0x3C
	private bool _hasViewportState; //Field offset: 0x40

	public float CurrentAspect
	{
		 get { } //Length: 4
	}

	public float CurrentLocalXOffset
	{
		 get { } //Length: 52
	}

	public LobbyObjectOffests() { }

	private void ApplyOffset() { }

	private void ApplyOffsetIfViewportChanged() { }

	private float CalculateLocalXOffset(float currentAspect) { }

	public float get_CurrentAspect() { }

	public float get_CurrentLocalXOffset() { }

	private float GetCurrentSafeAreaAspect() { }

	private static RectInt GetCurrentSafeAreaPixels() { }

	private void OnDisable() { }

	private void OnEnable() { }

	private void OnValidate() { }

	private void SetLocalPosition(Vector3 targetLocalPosition) { }

	private void Update() { }

	private bool UpdateViewportState() { }

}

