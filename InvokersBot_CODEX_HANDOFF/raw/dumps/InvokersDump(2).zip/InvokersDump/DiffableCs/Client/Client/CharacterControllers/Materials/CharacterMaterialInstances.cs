namespace Client.CharacterControllers.Materials;

public sealed class CharacterMaterialInstances : IDisposable
{
	private struct RendererMaterials
	{
		public readonly SkinnedMeshRenderer Renderer; //Field offset: 0x0
		public readonly Material[] Materials; //Field offset: 0x8

		public RendererMaterials(SkinnedMeshRenderer renderer, Material[] materials) { }

	}

	private readonly List<Material> _sources; //Field offset: 0x10
	private readonly List<Material> _clones; //Field offset: 0x18
	private readonly List<RendererMaterials> _originals; //Field offset: 0x20
	private bool _created; //Field offset: 0x28

	public IReadOnlyList<Material> Clones
	{
		 get { } //Length: 8
	}

	public bool IsCreated
	{
		 get { } //Length: 8
	}

	public CharacterMaterialInstances(bool revertible) { }

	private void Convert(SkinnedMeshRenderer renderer, in TPolicy policy) { }

	public void Create(Transform root, in TPolicy policy) { }

	public void Create(SkinnedMeshRenderer renderer, in TPolicy policy) { }

	public override void Dispose() { }

	public IReadOnlyList<Material> get_Clones() { }

	public bool get_IsCreated() { }

	public void Restore() { }

	public bool TryGetOrCreate(Material source, in TPolicy policy, out Material clone) { }

}

