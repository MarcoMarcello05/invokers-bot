namespace Client.CameraShake;

public class CameraShakeConfig : ScriptableObject
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<CameraShakePreset, Int64> <>9__15_2; //Field offset: 0x8
		public static Func<CameraShakePreset, Int64> <>9__19_0; //Field offset: 0x10
		public static Func<CameraShakePreset, String> <>9__20_1; //Field offset: 0x18
		public static Func<CameraShakePreset, Int64> <>9__22_0; //Field offset: 0x20

		private static <>c() { }

		public <>c() { }

		internal long <CloneConfig>b__15_2(CameraShakePreset p) { }

		internal long <OnAddPreset>b__22_0(CameraShakePreset p) { }

		internal string <UpdateFilteredPresets>b__20_1(CameraShakePreset x) { }

		internal long <UpdateIDs>b__19_0(CameraShakePreset p) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass15_0
	{
		public long id; //Field offset: 0x10
		public CameraShakePreset copy; //Field offset: 0x18

		public <>c__DisplayClass15_0() { }

		internal bool <CloneConfig>b__0(CameraShakePreset p) { }

		internal bool <CloneConfig>b__1(CameraShakePreset p) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass16_0
	{
		public long id; //Field offset: 0x10

		public <>c__DisplayClass16_0() { }

		internal bool <DeleteConfig>b__0(CameraShakePreset p) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass20_0
	{
		public CameraShakeConfig <>4__this; //Field offset: 0x10
		public Nullable<ShakeCategory> selectedCategory; //Field offset: 0x18

		public <>c__DisplayClass20_0() { }

		internal bool <UpdateFilteredPresets>b__0(CameraShakePreset p) { }

	}

	internal enum CategoryFilter : int
	{
		All = 0,
		Common = 1,
		Specific = 2,
	}

	internal enum ShakeTypeFilter : int
	{
		All = 0,
		Shake = 1,
		Zoom = 2,
	}

	private const string CONFIG_PATH = "CameraShakeConfig"; //Field offset: 0x0
	[HideInInspector]
	[SerializeField]
	public List<CameraShakePreset> Presets; //Field offset: 0x18
	public AnimationCurve MultiplierByDistanceCurve; //Field offset: 0x20
	private CategoryFilter _categoryFilter; //Field offset: 0x28
	private ShakeTypeFilter _shakeTypeFilter; //Field offset: 0x2C
	private string _filter; //Field offset: 0x30
	private List<CameraShakePreset> _filteredPresets; //Field offset: 0x38

	private bool IsClearable
	{
		private get { } //Length: 32
	}

	public CameraShakeConfig() { }

	private Nullable<ShakeCategory> ButtonToCategory(CategoryFilter filterButton) { }

	private void ClearFilter() { }

	public long CloneConfig(long id) { }

	public void DeleteConfig(long id) { }

	public void Filter(string filter, CategoryFilter category = 0, ShakeTypeFilter shakeType = 0) { }

	private void ForceSave() { }

	private bool get_IsClearable() { }

	private void Init() { }

	public static CameraShakeConfig Load(IResourcesApi resourcesApi) { }

	public static UniTask<CameraShakeConfig> LoadAsync(IResourcesApi resourcesApi) { }

	private CameraShakePreset OnAddPreset() { }

	private void UpdateFilteredPresets() { }

	private void UpdateIDs() { }

}

