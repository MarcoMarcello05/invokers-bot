//Type is in global namespace

public struct BakeryLightmapGroupPlain
{
	public string name; //Field offset: 0x0
	public int resolution; //Field offset: 0x8
	public int id; //Field offset: 0xC
	public int renderMode; //Field offset: 0x10
	public int renderDirMode; //Field offset: 0x14
	public int atlasPacker; //Field offset: 0x18
	public bool vertexBake; //Field offset: 0x1C
	public bool containsTerrains; //Field offset: 0x1D
	public bool probes; //Field offset: 0x1E
	public bool isImplicit; //Field offset: 0x1F
	public bool computeSSS; //Field offset: 0x20
	public int sssSamples; //Field offset: 0x24
	public float sssDensity; //Field offset: 0x28
	public float sssR; //Field offset: 0x2C
	public float sssG; //Field offset: 0x30
	public float sssB; //Field offset: 0x34
	public float fakeShadowBias; //Field offset: 0x38
	public bool transparentSelfShadow; //Field offset: 0x3C
	public bool flipNormal; //Field offset: 0x3D
	public string parentName; //Field offset: 0x40
	public int sceneLodLevel; //Field offset: 0x48
	public bool autoResolution; //Field offset: 0x4C
	public int holeFilling; //Field offset: 0x50
	public int vertexSamplingDensity; //Field offset: 0x54

}

