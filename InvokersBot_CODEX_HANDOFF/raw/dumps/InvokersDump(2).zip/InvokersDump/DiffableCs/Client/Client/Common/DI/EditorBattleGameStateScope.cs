namespace Client.Common.DI;

public static class EditorBattleGameStateScope
{

	public static T Resolve() { }

}

