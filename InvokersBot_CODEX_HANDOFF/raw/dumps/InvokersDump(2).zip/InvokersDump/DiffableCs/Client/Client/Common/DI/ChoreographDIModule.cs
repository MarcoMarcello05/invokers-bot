namespace Client.Common.DI;

[Extension]
public static class ChoreographDIModule
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<IObjectResolver, IInternetConnectionStatus> <>9__0_0; //Field offset: 0x8
		public static Func<IObjectResolver, ShopSkusStorage> <>9__0_1; //Field offset: 0x10
		public static Func<IObjectResolver, SkusPricesStorage> <>9__0_2; //Field offset: 0x18
		public static Func<IObjectResolver, IStaticDataCache> <>9__0_4; //Field offset: 0x20
		public static Func<IObjectResolver, IActiveStaticDataCache> <>9__0_5; //Field offset: 0x28
		public static Func<IObjectResolver, IClientAggregateStore`1<PlayerAggregate>> <>9__0_6; //Field offset: 0x30
		public static Func<IObjectResolver, IStaticDataDownloader> <>9__0_7; //Field offset: 0x38
		public static Func<IObjectResolver, IClientKeyValueStore> <>9__2_0; //Field offset: 0x40
		public static Func<IObjectResolver, IAggregateEventMapper`1<PlayerAggregate>> <>9__4_0; //Field offset: 0x48

		private static <>c() { }

		public <>c() { }

		internal IAggregateEventMapper<PlayerAggregate> <AddAggregates>b__4_0(IObjectResolver x) { }

		internal IInternetConnectionStatus <AddChoreograph>b__0_0(IObjectResolver x) { }

		internal ShopSkusStorage <AddChoreograph>b__0_1(IObjectResolver _) { }

		internal SkusPricesStorage <AddChoreograph>b__0_2(IObjectResolver _) { }

		internal IStaticDataCache <AddChoreograph>b__0_4(IObjectResolver x) { }

		internal IActiveStaticDataCache <AddChoreograph>b__0_5(IObjectResolver x) { }

		internal IClientAggregateStore<PlayerAggregate> <AddChoreograph>b__0_6(IObjectResolver x) { }

		internal IStaticDataDownloader <AddChoreograph>b__0_7(IObjectResolver x) { }

		internal IClientKeyValueStore <AddOfflineChoreographSession>b__2_0(IObjectResolver x) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass0_0
	{
		public bool offlineMode; //Field offset: 0x10

		public <>c__DisplayClass0_0() { }

		internal IClientSessionContextFactory <AddChoreograph>b__3(IObjectResolver x) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass3_0
	{
		public Assembly assembly; //Field offset: 0x10

		public <>c__DisplayClass3_0() { }

		internal IPlayerActionMapping <AddActionHandlers>b__0(IObjectResolver _) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass5_0
	{
		public Type handlerType; //Field offset: 0x10
		public Func<Type, Boolean> <>9__0; //Field offset: 0x18
		public Func<Type, Boolean> <>9__1; //Field offset: 0x20

		public <>c__DisplayClass5_0() { }

		internal bool <AddDeterministicActionExecutors>b__0(Type x) { }

		internal bool <AddDeterministicActionExecutors>b__1(Type x) { }

	}


	[Extension]
	private static void AddActionHandlers(IContainerBuilder builder) { }

	[Extension]
	private static void AddAggregates(IContainerBuilder builder) { }

	[Extension]
	public static IContainerBuilder AddChoreograph(IContainerBuilder builder, bool offlineMode = false) { }

	[Extension]
	private static void AddDeterministicActionExecutors(IContainerBuilder builder, Assembly scanAssembly) { }

	[Extension]
	private static void AddEventSubscribers(IContainerBuilder builder, Assembly scanAssembly) { }

	[Extension]
	private static IContainerBuilder AddOfflineChoreographSession(IContainerBuilder builder) { }

	[Extension]
	private static IContainerBuilder AddOnlineChoreographSession(IContainerBuilder builder) { }

}

