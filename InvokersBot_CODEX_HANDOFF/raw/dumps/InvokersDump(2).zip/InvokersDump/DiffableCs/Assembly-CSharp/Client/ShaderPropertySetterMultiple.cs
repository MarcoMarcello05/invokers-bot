namespace Client;

[ExecuteAlways]
public class ShaderPropertySetterMultiple : MonoBehaviour
{
	private struct Original
	{
		public Material mat; //Field offset: 0x0
		public int propId; //Field offset: 0x8
		public Vector4 vec; //Field offset: 0xC

	}

	[Tooltip("Shader property name (e.g. _MainTex_Tiling or _Cutoff). Intended for Vector/Color.")]
	public string property; //Field offset: 0x20
	public bool useX; //Field offset: 0x28
	public float x; //Field offset: 0x2C
	public bool useY; //Field offset: 0x30
	public float y; //Field offset: 0x34
	public bool useZ; //Field offset: 0x38
	public float z; //Field offset: 0x3C
	public bool useW; //Field offset: 0x40
	public float w; //Field offset: 0x44
	private readonly List<Material> _targets; //Field offset: 0x48
	private readonly HashSet<Material> _seen; //Field offset: 0x50
	private readonly List<Original> _originals; //Field offset: 0x58
	private int _propId; //Field offset: 0x60
	private bool _propIdValid; //Field offset: 0x64
	private bool _captured; //Field offset: 0x65

	public ShaderPropertySetterMultiple() { }

	private void Apply() { }

	private void CachePropId() { }

	private void CaptureMissingOriginals() { }

	private void CollectMaterialsOnThisObject() { }

	private bool HasOriginal(Material m, int propId) { }

	private void OnDidApplyAnimationProperties() { }

	private void OnDisable() { }

	private void OnEnable() { }

	private void OnValidate() { }

	private void RestoreOriginals() { }

	private void Update() { }

}

