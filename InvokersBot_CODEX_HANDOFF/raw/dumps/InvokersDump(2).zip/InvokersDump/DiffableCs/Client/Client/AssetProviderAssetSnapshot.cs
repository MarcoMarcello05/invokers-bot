namespace Client;

[Nullable(0)]
[NullableContext(1)]
public sealed class AssetProviderAssetSnapshot : IEquatable<AssetProviderAssetSnapshot>
{
	[CompilerGenerated]
	private readonly AssetKey <Key>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly AssetCacheGroup <CacheGroup>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly string <Status>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private readonly int <RefCount>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private readonly bool <InCache>k__BackingField; //Field offset: 0x2C
	[CompilerGenerated]
	private readonly TimeSpan <LoadTime>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private readonly string <DownloadStatus>k__BackingField; //Field offset: 0x38

	public AssetCacheGroup CacheGroup
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string DownloadStatus
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	[CompilerGenerated]
	private Type EqualityContract
	{
		[CompilerGenerated]
		private get { } //Length: 96
	}

	public bool InCache
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public AssetKey Key
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public TimeSpan LoadTime
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public int RefCount
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string Status
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public AssetProviderAssetSnapshot(AssetKey Key, AssetCacheGroup CacheGroup, string Status, int RefCount, bool InCache, TimeSpan LoadTime, string DownloadStatus) { }

	[CompilerGenerated]
	private AssetProviderAssetSnapshot(AssetProviderAssetSnapshot original) { }

	[CompilerGenerated]
	public AssetProviderAssetSnapshot <Clone>$() { }

	[CompilerGenerated]
	public void Deconstruct(out AssetKey Key, out AssetCacheGroup CacheGroup, out string Status, out int RefCount, out bool InCache, out TimeSpan LoadTime, out string DownloadStatus) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public override bool Equals(AssetProviderAssetSnapshot other) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	public AssetCacheGroup get_CacheGroup() { }

	[CompilerGenerated]
	public string get_DownloadStatus() { }

	[CompilerGenerated]
	private Type get_EqualityContract() { }

	[CompilerGenerated]
	public bool get_InCache() { }

	[CompilerGenerated]
	public AssetKey get_Key() { }

	[CompilerGenerated]
	public TimeSpan get_LoadTime() { }

	[CompilerGenerated]
	public int get_RefCount() { }

	[CompilerGenerated]
	public string get_Status() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Equality(AssetProviderAssetSnapshot left, AssetProviderAssetSnapshot right) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public static bool op_Inequality(AssetProviderAssetSnapshot left, AssetProviderAssetSnapshot right) { }

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	public void set_CacheGroup(AssetCacheGroup value) { }

	[CompilerGenerated]
	public void set_DownloadStatus(string value) { }

	[CompilerGenerated]
	public void set_InCache(bool value) { }

	[CompilerGenerated]
	public void set_Key(AssetKey value) { }

	[CompilerGenerated]
	public void set_LoadTime(TimeSpan value) { }

	[CompilerGenerated]
	public void set_RefCount(int value) { }

	[CompilerGenerated]
	public void set_Status(string value) { }

	[CompilerGenerated]
	public virtual string ToString() { }

}

