namespace Client.Core.GameServices;

public interface IGameLifeCycleObserver
{

	public CancellationToken AppQuitCancellationToken
	{
		 get { } //Length: 0
	}

	public Observable<Boolean> OnApplicationFocus
	{
		 get { } //Length: 0
	}

	public Observable<Boolean> OnApplicationPause
	{
		 get { } //Length: 0
	}

	public Observable<Unit> OnApplicationQuit
	{
		 get { } //Length: 0
	}

	public CancellationToken get_AppQuitCancellationToken() { }

	public Observable<Boolean> get_OnApplicationFocus() { }

	public Observable<Boolean> get_OnApplicationPause() { }

	public Observable<Unit> get_OnApplicationQuit() { }

}

