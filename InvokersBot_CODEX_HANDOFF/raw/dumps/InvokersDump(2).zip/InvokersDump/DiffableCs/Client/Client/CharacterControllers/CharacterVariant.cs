namespace Client.CharacterControllers;

public struct CharacterVariant : IEquatable<CharacterVariant>
{
	[CompilerGenerated]
	private readonly BaseCharacterConfig <Config>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private readonly CharacterSkin <Skin>k__BackingField; //Field offset: 0x8

	public BaseCharacterConfig Config
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public CharacterSkin Skin
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public CharacterVariant(BaseCharacterConfig Config, CharacterSkin Skin) { }

	[CompilerGenerated]
	public void Deconstruct(out BaseCharacterConfig Config, out CharacterSkin Skin) { }

	[CompilerGenerated]
	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	public override bool Equals(CharacterVariant other) { }

	[CompilerGenerated]
	public BaseCharacterConfig get_Config() { }

	[CompilerGenerated]
	public CharacterSkin get_Skin() { }

	[CompilerGenerated]
	public virtual int GetHashCode() { }

	[CompilerGenerated]
	public static bool op_Equality(CharacterVariant left, CharacterVariant right) { }

	[CompilerGenerated]
	public static bool op_Inequality(CharacterVariant left, CharacterVariant right) { }

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder) { }

	[CompilerGenerated]
	public void set_Config(BaseCharacterConfig value) { }

	[CompilerGenerated]
	public void set_Skin(CharacterSkin value) { }

	[CompilerGenerated]
	public virtual string ToString() { }

}

