namespace Client.Core.ErrorHandling;

public class ErrorModalPopup : BaseDialogView
{
	[SerializeField]
	private HZButton _closeButton; //Field offset: 0x58
	[SerializeField]
	private HZButton _supportButton; //Field offset: 0x60
	[SerializeField]
	private TextMeshProUGUI _sessionDebugInfo; //Field offset: 0x68
	[SerializeField]
	private TextMeshProUGUI _errorTitle; //Field offset: 0x70
	[SerializeField]
	private TextMeshProUGUI _errorText; //Field offset: 0x78

	public HZButton CloseButton
	{
		 get { } //Length: 8
	}

	public HZButton SupportButton
	{
		 get { } //Length: 8
	}

	public ErrorModalPopup() { }

	public HZButton get_CloseButton() { }

	public HZButton get_SupportButton() { }

	private void OnValidate() { }

	public void SetData(string sessionDebugInfo, string errorTitle, string errorText) { }

	public void SetSupportButtonActive(bool isActive) { }

}

