namespace Client.Analytics;

public class AnalyticsEventAttribute : PropertyAttribute
{

	public AnalyticsEventAttribute() { }

}

