namespace AppsFlyerSDK;

public enum Store : int
{
	GOOGLE = 0,
}

