namespace Client.Core.Dialogs;

public interface IChromaLossConfirmation
{

	public UniTask<Boolean> ConfirmAnimaLossAsync(IReadOnlyCollection<Int32> animaInventoryIds) { }

	public UniTask<Boolean> ConfirmHeroLossAsync(IReadOnlyCollection<Int32> heroInventoryIds) { }

}

