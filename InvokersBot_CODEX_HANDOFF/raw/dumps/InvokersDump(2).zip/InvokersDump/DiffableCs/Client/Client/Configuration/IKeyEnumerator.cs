namespace Client.Configuration;

public interface IKeyEnumerator
{

	public IEnumerable<String> GetAllKeys() { }

}

