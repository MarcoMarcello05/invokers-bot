namespace Client.CharacterControllers;

public class CharacterHudView : BaseCharacterView
{
	private ISoundManager _soundManager; //Field offset: 0x20
	[SerializeField]
	private SegmentedHealthBar _healthBar; //Field offset: 0x28
	[SerializeField]
	private UISlider _hpBar; //Field offset: 0x30
	[SerializeField]
	private Image _destroyedHpImage; //Field offset: 0x38
	[SerializeField]
	private GameObject _statusGO; //Field offset: 0x40
	[SerializeField]
	private UIToggle _toggle; //Field offset: 0x48
	[SerializeField]
	private GameObject _cooldownRoot; //Field offset: 0x50
	[SerializeField]
	private GameObject _blockRoot; //Field offset: 0x58
	[SerializeField]
	private OnScreenUIButton _ultimateOnScreenButton; //Field offset: 0x60
	[SerializeField]
	private Image _characterIconImage; //Field offset: 0x68
	[SerializeField]
	private CharacterBuffContainer _characterBuffContainer; //Field offset: 0x70
	[SerializeField]
	private HudSkillCooldown _skillButton; //Field offset: 0x78
	[SerializeField]
	private UltimateButtonScaleWidget _scaleWidget; //Field offset: 0x80
	[SerializeField]
	private SingleTweenAnimator _titanActiveElement; //Field offset: 0x88
	[SerializeField]
	private PortraitNumberWidget _portraitNumberWidget; //Field offset: 0x90
	[SerializeField]
	private PortraitNumberWidget _portraitCritNumberWidget; //Field offset: 0x98
	[SerializeField]
	private PortraitNumberWidget _portraitShieldHitView; //Field offset: 0xA0
	[SerializeField]
	private PortraitNumberWidget _portraitCorruptionHitView; //Field offset: 0xA8
	[SerializeField]
	private PortraitNumberWidget _portraitNumber; //Field offset: 0xB0
	[SerializeField]
	private EventReference _titanChargeSoundEvent; //Field offset: 0xB8
	[SerializeField]
	private Image _elementImage; //Field offset: 0xC8
	[SerializeField]
	private TextMeshProUGUI _levelLabel; //Field offset: 0xD0
	private EventInstance _titanChargeSoundInstance; //Field offset: 0xD8
	private PLAYBACK_STATE _titanChargeSoundPlayBackState; //Field offset: 0xE0
	private UIToggleGroup _toggleGroup; //Field offset: 0xE8
	[CompilerGenerated]
	private bool <IsHidden>k__BackingField; //Field offset: 0xF0

	public private bool IsHidden
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public CharacterHudView() { }

	public void AddBuff(ref StatusEffectHudData statusEffectHudData) { }

	public void AddCorruption(ref CorruptionHudData corruptionHudData) { }

	public void AddCorruptionHitValue(int value) { }

	public void AddCritDamageValue(int value) { }

	public void AddCustomStatusEffect(ref CustomStatusEffectHudData customStatusEffectHudData) { }

	public void AddDamageValue(int value) { }

	public void AddMovementEffect(ref MovementEffectHudData movementEffectHudData) { }

	public void AddShieldHitValue(int value) { }

	public void Block(bool needBlock) { }

	public void ChangeUltimateIcon(HudActiveOrUltSkillData skill) { }

	[CompilerGenerated]
	public bool get_IsHidden() { }

	public void Hide() { }

	public void Init(HealthBarColorsTweaks colors, IObjectsPool<BuffView> buffViewPool, BuffsInfo buffsInfo, ISoundManager soundManager) { }

	private void OnDestroy() { }

	private void OnDisable() { }

	public void PlayTitanChargeSound() { }

	public void RemoveBuff(StatusEffectType buffType, uint effectId) { }

	public void RemoveCorruption(CorruptionType type) { }

	public void RemoveCustomStatusEffect(long effectType, uint effectUniqueId) { }

	public void RemoveMovementEffect(MovementEffectType type) { }

	[CompilerGenerated]
	private void set_IsHidden(bool value) { }

	public void SetAlive(bool hasUltimateSkill) { }

	public void SetCharacterIcon(Sprite icon) { }

	public void SetDead() { }

	public void SetInteractable(bool interactable) { }

	public void SetLevelAndElement(int level, Sprite elementSprite) { }

	public void SetSelection(bool state) { }

	public void SetTitanActive(bool titanActive) { }

	public void SetUltimateCooldown(float cooldown, float timeLeft) { }

	public void SetUltimateMana(int manaChange, float normalizedMana, bool isInstant) { }

	public void Show() { }

	public void UpdateBuff(ref StatusEffectHudData statusEffectHudData) { }

	public void UpdateCorruption(ref CorruptionHudData corruptionHudData) { }

	public void UpdateCustomStatusEffect(ref CustomStatusEffectHudData customStatusEffectHudData) { }

	public void UpdateHealthBar(HealthBarState state) { }

	public void UpdateMovementEffect(ref MovementEffectHudData movementEffectHudData) { }

}

