namespace Client.Authentication.AppleGameCenter;

[Nullable(0)]
[NullableContext(1)]
public sealed class AppleGameCenterService : IAppleGameCenterService
{
	private readonly ILogger<AppleGameCenterService> _logger; //Field offset: 0x10
	[CompilerGenerated]
	private readonly Observable<Boolean> <AuthenticationStateChanged>k__BackingField; //Field offset: 0x18

	public override Observable<Boolean> AuthenticationStateChanged
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public override bool IsAuthenticated
	{
		 get { } //Length: 8
	}

	public override bool IsAvailable
	{
		 get { } //Length: 8
	}

	[Nullable(2)]
	public override string UserName
	{
		[NullableContext(2)]
		 get { } //Length: 8
	}

	public AppleGameCenterService() { }

	[NullableContext(0)]
	public override ValueTask<AppleGameCenterAuthStatus> AuthenticateAsync(bool manual, CancellationToken cancellationToken = null) { }

	[CompilerGenerated]
	public override Observable<Boolean> get_AuthenticationStateChanged() { }

	public override bool get_IsAuthenticated() { }

	public override bool get_IsAvailable() { }

	[NullableContext(2)]
	public override string get_UserName() { }

	public override ValueTask<AppleGameCenterIdentityVerificationPayload> GetIdentityVerificationPayloadAsync(CancellationToken cancellationToken = null) { }

}

