namespace Client.Common.DI;

[Extension]
public static class ConfigurationDiModule
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<IObjectResolver, IConfigurationRoot> <>9__0_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal IConfigurationRoot <AddAppConfiguration>b__0_0(IObjectResolver provider) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass1_0
	{
		public string sectionName; //Field offset: 0x0

		public <>c__DisplayClass1_0`1() { }

		internal IOptions<TOptions> <AddOptions>b__0(IObjectResolver provider) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass3_0
	{
		public string sectionName; //Field offset: 0x0

		public <>c__DisplayClass3_0`1() { }

		internal IOptionsMonitor<TOptions> <AddOptionsMonitor>b__0(IObjectResolver provider) { }

	}


	[Extension]
	public static IContainerBuilder AddAppConfiguration(IContainerBuilder builder) { }

	[Extension]
	public static IContainerBuilder AddOptions(IContainerBuilder builder, string sectionName = null) { }

	[Extension]
	public static IContainerBuilder AddOptionsMonitor(IContainerBuilder builder, string sectionName = null) { }

	[Extension]
	public static IOptions<TOptions> GetIOptions(IConfigurationRoot configuration, string sectionName = null) { }

	[Extension]
	public static IOptionsMonitor<TOptions> GetIOptionsMonitor(IConfigurationRoot configuration, string sectionName = null) { }

}

