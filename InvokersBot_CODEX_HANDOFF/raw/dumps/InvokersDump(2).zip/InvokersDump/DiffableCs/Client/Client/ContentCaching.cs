namespace Client;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public sealed class ContentCaching : IContentCaching, IDisposable
{
	[CompilerGenerated]
	private sealed class <>c
	{
		[Nullable(0)]
		public static readonly <>c <>9; //Field offset: 0x0
		[Nullable(0)]
		public static Func<DiskSpaceTier, Boolean> <>9__9_0; //Field offset: 0x8
		[Nullable(0)]
		public static Func<Boolean> <>9__13_1; //Field offset: 0x10

		private static <>c() { }

		public <>c() { }

		internal bool <.ctor>b__9_0(DiskSpaceTier t) { }

		internal bool <ClearUnusedBundlesCache>b__13_1() { }

	}

	[CompilerGenerated]
	private struct <ClearUnusedBundlesCache>d__13 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		[Nullable(0)]
		public AsyncUniTaskMethodBuilder<ClearCachesResult> <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ContentCaching <>4__this; //Field offset: 0x28
		public bool oncePerSession; //Field offset: 0x30
		public CancellationToken ct; //Field offset: 0x38
		[Nullable(0)]
		public string caller; //Field offset: 0x40
		private AutoScope <_>5__2; //Field offset: 0x48
		[Nullable(0)]
		private Stopwatch <sw>5__3; //Field offset: 0x60
		private long <totalOccupiedBefore>5__4; //Field offset: 0x68
		[Nullable(0)]
		private AsyncOperationHandle<Boolean> <aoh>5__5; //Field offset: 0x70
		[Nullable(0)]
		private CancellationTokenSource <linkedCts>5__6; //Field offset: 0x88
		private Awaiter <>u__1; //Field offset: 0x90
		[Nullable(0)]
		private Awaiter<Boolean> <>u__2; //Field offset: 0xA0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <TrimOnDiskPressureAsync>d__10 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ContentCaching <>4__this; //Field offset: 0x18
		[Nullable(0)]
		private Awaiter<ClearCachesResult> <>u__1; //Field offset: 0x20

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity ClearActivity; //Field offset: 0x0
	private readonly IClientAnalytics _analytics; //Field offset: 0x10
	private readonly CompositeDisposable _disposables; //Field offset: 0x18
	[Nullable(2)]
	private CancellationTokenSource _contentCachingActivityCts; //Field offset: 0x20
	private bool _triedClearOnThisSession; //Field offset: 0x28
	private bool _isClearing; //Field offset: 0x29
	private bool _trimmedForDiskPressure; //Field offset: 0x2A

	public override bool IsReady
	{
		 get { } //Length: 8
	}

	private static ContentCaching() { }

	public ContentCaching(IClientAnalytics analytics, IDiskSpaceMonitor diskSpaceMonitor) { }

	[CompilerGenerated]
	private void <.ctor>b__9_1(DiskSpaceTier _) { }

	[CompilerGenerated]
	internal static ClearCachesResult <ClearUnusedBundlesCache>g__NothingClearedResult|13_0() { }

	public override bool ClearBundlesCache(TimeSpan olderThan) { }

	[AsyncStateMachine(typeof(<ClearUnusedBundlesCache>d__13))]
	[NullableContext(0)]
	public override UniTask<ClearCachesResult> ClearUnusedBundlesCache(CancellationToken ct, bool oncePerSession = false, string caller = "") { }

	public override void Dispose() { }

	public override bool get_IsReady() { }

	public override long GetTotalOccupiedBytes(out IReadOnlyList<CacheSizeInfo>& sizeInfos) { }

	public override bool IsLocationCached(IResourceLocation location, bool markAsUsed) { }

	private static bool IsLocationCachedInternal(IResourceLocation location, bool markAsUsed) { }

	[AsyncStateMachine(typeof(<TrimOnDiskPressureAsync>d__10))]
	private UniTask TrimOnDiskPressureAsync() { }

	[NullableContext(2)]
	private static bool TryGetMainCatalog(out AddressablesContentCatalog mainCatalog) { }

}

