namespace Client.Authentication;

public interface IGoogleAuthenticator
{

	public Task<AuthorizationCodeResponse> AuthenticateAsync(string authorizationUrl, string expectedRedirectUriPrefix, string expectedState, CancellationToken cancellationToken) { }

}

