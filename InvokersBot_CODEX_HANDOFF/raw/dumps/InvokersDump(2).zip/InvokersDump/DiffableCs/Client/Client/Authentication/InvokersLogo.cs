namespace Client.Authentication;

internal static class InvokersLogo
{

	public static string Svg() { }

}

