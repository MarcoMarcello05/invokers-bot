namespace Client.Core.ErrorHandling;

public class NotEnoughResourcesPopup : BaseDialogView
{
	[SerializeField]
	private HZButton _closeButton; //Field offset: 0x58
	[SerializeField]
	private HZButton _backgroundCloseButton; //Field offset: 0x60
	[SerializeField]
	private HZButton _confirmButton; //Field offset: 0x68
	[SerializeField]
	private GameItemHolderView _resourceIcon; //Field offset: 0x70
	[SerializeField]
	private TextMeshProUGUI _header; //Field offset: 0x78
	[SerializeField]
	private TextMeshProUGUI _description; //Field offset: 0x80
	[SerializeField]
	private GameObject _whereToGetLabel; //Field offset: 0x88
	[SerializeField]
	private GameObject _buttonsLayout; //Field offset: 0x90
	[SerializeField]
	private GameObject _originsLayout; //Field offset: 0x98
	[SerializeField]
	private HZButton _shopBigButton; //Field offset: 0xA0
	[SerializeField]
	private List<NavigationButton> _navigationButtons; //Field offset: 0xA8

	public HZButton CloseButton
	{
		 get { } //Length: 8
	}

	public HZButton ConfirmButton
	{
		 get { } //Length: 8
	}

	public TextMeshProUGUI Description
	{
		 get { } //Length: 8
	}

	public TextMeshProUGUI Header
	{
		 get { } //Length: 8
	}

	public IEnumerable<NavigationButton> NavigationButtons
	{
		 get { } //Length: 8
	}

	public GameItemHolderView ResourceIcon
	{
		 get { } //Length: 8
	}

	public HZButton ShopBigButton
	{
		 get { } //Length: 8
	}

	public NotEnoughResourcesPopup() { }

	public void BindCloseButton(IButtonCommand closeCommand) { }

	public HZButton get_CloseButton() { }

	public HZButton get_ConfirmButton() { }

	public TextMeshProUGUI get_Description() { }

	public TextMeshProUGUI get_Header() { }

	public IEnumerable<NavigationButton> get_NavigationButtons() { }

	public GameItemHolderView get_ResourceIcon() { }

	public HZButton get_ShopBigButton() { }

	private void OnValidate() { }

	public void SetOrigin(List<ResourceOrigin> resourceOrigins) { }

}

