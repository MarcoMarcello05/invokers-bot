namespace Client.Common.DI;

internal class PreserveAttribute : Attribute
{

	public PreserveAttribute() { }

}

