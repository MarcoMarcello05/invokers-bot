namespace AppsFlyerSDK;

public class AppsFlyerAndroid : IAppsFlyerAndroidBridge, IAppsFlyerNativeBridge
{
	private static AndroidJavaClass appsFlyerAndroid; //Field offset: 0x0
	[CompilerGenerated]
	private bool <isInit>k__BackingField; //Field offset: 0x10

	public override bool isInit
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	private static AppsFlyerAndroid() { }

	public AppsFlyerAndroid() { }

	public override void addPushNotificationDeepLinkPath(String[] paths) { }

	public override void anonymizeUser(bool isDisabled) { }

	public override void attributeAndOpenStore(string promoted_app_id, string campaign, Dictionary<String, String> userParams, MonoBehaviour gameObject) { }

	private static AndroidJavaObject convertDictionaryToJavaMap(Dictionary<String, String> dictionary) { }

	public override void enableTCFDataCollection(bool shouldCollectTcfData) { }

	public override void generateUserInviteLink(Dictionary<String, String> parameters, MonoBehaviour gameObject) { }

	[CompilerGenerated]
	public override bool get_isInit() { }

	public override string getAppsFlyerId() { }

	public override string getAttributionId() { }

	public override void getConversionData(string objectName) { }

	private static AndroidJavaObject getEmailType(EmailCryptType cryptType) { }

	private static AndroidJavaObject getMediationNetwork(MediationNetwork mediationNetwork) { }

	public override string getOutOfStore() { }

	public override string getSdkVersion() { }

	public override void handlePushNotifications() { }

	public void initSDK(string devkey, MonoBehaviour gameObject) { }

	public override bool isPreInstalledApp() { }

	public override bool isSDKStopped() { }

	public override void logAdRevenue(AFAdRevenueData adRevenueData, Dictionary<String, String> additionalParameters) { }

	public override void recordCrossPromoteImpression(string appID, string campaign, Dictionary<String, String> parameters) { }

	public override void recordLocation(double latitude, double longitude) { }

	public override void sendEvent(string eventName, Dictionary<String, String> eventValues, bool shouldCallback, string callBackObjectName) { }

	[CompilerGenerated]
	public override void set_isInit(bool value) { }

	public override void setAdditionalData(Dictionary<String, String> customData) { }

	public override void setAndroidIdData(string aAndroidId) { }

	public override void setAppInviteOneLinkID(string oneLinkId) { }

	public override void setCollectAndroidID(bool isCollect) { }

	public override void setCollectIMEI(bool isCollect) { }

	public override void setCollectOaid(bool isCollect) { }

	public override void setConsentData(AppsFlyerConsent appsFlyerConsent) { }

	public override void setCurrencyCode(string currencyCode) { }

	public override void setCustomerIdAndStartSDK(string id) { }

	public override void setCustomerUserId(string id) { }

	public override void setDeepLinkTimeout(long deepLinkTimeout) { }

	public override void setDisableAdvertisingIdentifiers(bool disable) { }

	public override void setDisableNetworkData(bool disable) { }

	public override void setHost(string hostPrefixName, string hostName) { }

	public override void setImeiData(string aImei) { }

	public override void setIsDebug(bool shouldEnable) { }

	public override void setIsUpdate(bool isUpdate) { }

	public override void setMinTimeBetweenSessions(int seconds) { }

	public override void setOneLinkCustomDomain(String[] domains) { }

	public override void setOutOfStore(string sourceName) { }

	public override void setPartnerData(string partnerId, Dictionary<String, String> partnerInfo) { }

	public override void setPhoneNumber(string phoneNumber) { }

	public override void setPreinstallAttribution(string mediaSource, string campaign, string siteId) { }

	public override void setResolveDeepLinkURLs(String[] urls) { }

	public override void setSharingFilter(String[] partners) { }

	public override void setSharingFilterForAllPartners() { }

	public static void setSharingFilterForPartners(String[] partners) { }

	public override void setUserEmails(EmailCryptType cryptMethod, String[] emails) { }

	public override void startSDK(bool onRequestResponse, string CallBackObjectName) { }

	public override void stopSDK(bool isSDKStopped) { }

	public override void subscribeForDeepLink(string objectName) { }

	public override void updateServerUninstallToken(string token) { }

	[Obsolete("This method is deprecated. Use validateAndSendInAppPurchase(AFPurchaseDetailsAndroid details, Dictionary<string, string> purchaseAdditionalDetails, MonoBehaviour gameObject) instead.")]
	public override void validateAndSendInAppPurchase(string publicKey, string signature, string purchaseData, string price, string currency, Dictionary<String, String> additionalParameters, MonoBehaviour gameObject) { }

	public override void validateAndSendInAppPurchase(AFPurchaseDetailsAndroid details, Dictionary<String, String> purchaseAdditionalDetails, MonoBehaviour gameObject) { }

	public override void waitForCustomerUserId(bool wait) { }

}

