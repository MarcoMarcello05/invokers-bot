namespace Client.Analytics;

public class AnalyticEventsServerSink : IDisposable
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Action<Unit, AnalyticEventsServerSink> <>9__12_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal void <Initialize>b__12_0(Unit _, AnalyticEventsServerSink self) { }

	}

	[CompilerGenerated]
	private struct <EnsureFlushEventsToServerAsync>d__13 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public AnalyticEventsServerSink <>4__this; //Field offset: 0x18
		public CancellationToken ct; //Field offset: 0x20
		public bool clearUndelivered; //Field offset: 0x28
		private TaskAwaiter <>u__1; //Field offset: 0x30
		private Awaiter <>u__2; //Field offset: 0x38

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <FlushEventsToServerAsync>d__15 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public AnalyticEventsServerSink <>4__this; //Field offset: 0x18
		public CancellationToken ct; //Field offset: 0x20
		private IClientSession <session>5__2; //Field offset: 0x28
		private int <successfullyDeliveredEvents>5__3; //Field offset: 0x30
		private int <count>5__4; //Field offset: 0x34
		[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
		private IReadOnlyList<ClientBiEventDto> <pending>5__5; //Field offset: 0x38
		private PooledObject<List`1<ClientBiEventDto>> <pooledBatch>5__6; //Field offset: 0x40
		private List<ClientBiEventDto> <batch>5__7; //Field offset: 0x50
		private int <i>5__8; //Field offset: 0x58
		private int <batchSize>5__9; //Field offset: 0x5C
		private TaskAwaiter <>u__1; //Field offset: 0x60

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <TryFlushEventsToServerAsync>d__14 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public AnalyticEventsServerSink <>4__this; //Field offset: 0x18
		public CancellationToken ct; //Field offset: 0x20
		private Awaiter <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private const int BATCH_SIZE = 100; //Field offset: 0x0
	private readonly ILogger _logger; //Field offset: 0x10
	private readonly AnalyticEventsStore _eventsStore; //Field offset: 0x18
	private readonly IGameLifeCycleObserver _gameLifeCycleObserver; //Field offset: 0x20
	private readonly PerformanceMonitor _performanceMonitor; //Field offset: 0x28
	private readonly CompositeDisposable _disposables; //Field offset: 0x30
	private readonly CancellationTokenSource _cts; //Field offset: 0x38
	private readonly SemaphoreSlim _processingGate; //Field offset: 0x40
	private IChoreographManager _choreograph; //Field offset: 0x48
	private bool _deliveryDisabled; //Field offset: 0x50
	private bool _automaticDeliveryPaused; //Field offset: 0x51

	public AnalyticEventsServerSink(AnalyticEventsStore eventsStore, IGameLifeCycleObserver gameLifeCycleObserver, PerformanceMonitor performanceMonitor) { }

	public override void Dispose() { }

	[AsyncStateMachine(typeof(<EnsureFlushEventsToServerAsync>d__13))]
	public UniTask EnsureFlushEventsToServerAsync(bool clearUndelivered, CancellationToken ct) { }

	[AsyncStateMachine(typeof(<FlushEventsToServerAsync>d__15))]
	private UniTask FlushEventsToServerAsync(CancellationToken ct) { }

	public void Initialize(IChoreographManager choreographManager) { }

	private void OnApplicationFocus(bool focused) { }

	private void OnApplicationPause(bool paused) { }

	private void OnPerformanceSectionChanged(PerformanceSection section) { }

	private static bool ShouldPauseAutomaticDelivery(PerformanceSection section) { }

	[AsyncStateMachine(typeof(<TryFlushEventsToServerAsync>d__14))]
	private UniTask TryFlushEventsToServerAsync(CancellationToken ct) { }

}

