namespace Client.Core;

public class AsyncLoadedPrefab : AsyncInitializableBase, IAssetHolder, IAsyncInitializable<TComponent>, IAsyncInitializable, IDisposable
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass21_0
	{
		public IOperationProgressObserver onProgressChange; //Field offset: 0x0

		public <>c__DisplayClass21_0() { }

		internal void <LoadAssetAsync>g__OnStatusChanged|0(DownloadStatus downloadStatus) { }

	}

	[CompilerGenerated]
	private sealed class <get_RequiredAssets>d__17 : IEnumerable<AssetKey>, IEnumerable, IEnumerator<AssetKey>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private AssetKey <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		public AsyncLoadedPrefab<TAsset, TComponent> <>4__this; //Field offset: 0x0

		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <get_RequiredAssets>d__17(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<AssetKey> System.Collections.Generic.IEnumerable<Client.AssetKey>.GetEnumerator() { }

		[DebuggerHidden]
		private override AssetKey System.Collections.Generic.IEnumerator<Client.AssetKey>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private sealed class <InitFactory>d__19 : IEnumerable<IAsyncOperationWithProgress>, IEnumerable, IEnumerator<IAsyncOperationWithProgress>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private IAsyncOperationWithProgress <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		public AsyncLoadedPrefab<TAsset, TComponent> <>4__this; //Field offset: 0x0

		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 8
		}

		[DebuggerHidden]
		public <InitFactory>d__19(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<IAsyncOperationWithProgress> System.Collections.Generic.IEnumerable<Client.Core.IAsyncOperationWithProgress>.GetEnumerator() { }

		[DebuggerHidden]
		private override IAsyncOperationWithProgress System.Collections.Generic.IEnumerator<Client.Core.IAsyncOperationWithProgress>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private struct <LoadAssetAsync>d__21 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x0
		public IOperationProgressObserver onProgressChange; //Field offset: 0x0
		public AsyncLoadedPrefab<TAsset, TComponent> <>4__this; //Field offset: 0x0
		public IAssetProvider assetProvider; //Field offset: 0x0
		private Awaiter<TAsset> <>u__1; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <LoadAsync>d__20 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x0
		public AsyncLoadedPrefab<TAsset, TComponent> <>4__this; //Field offset: 0x0
		public IOperationProgressObserver onProgressChange; //Field offset: 0x0
		private AutoScope <_>5__2; //Field offset: 0x0
		private Awaiter <>u__1; //Field offset: 0x0
		private Awaiter<TComponent> <>u__2; //Field offset: 0x0

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly Activity AssetLoad; //Field offset: 0x0
	private readonly ILogger _logger; //Field offset: 0x0
	private readonly AssetKey _assetKey; //Field offset: 0x0
	private readonly IAssetProvider _assetProvider; //Field offset: 0x0
	protected readonly string OwnerCallerLabel; //Field offset: 0x0
	protected readonly string OwnerCallerFilePath; //Field offset: 0x0
	protected readonly int OwnerCallerLine; //Field offset: 0x0
	private readonly Transform _parent; //Field offset: 0x0
	private readonly Func<TAsset, GameObject> _prefabSelector; //Field offset: 0x0
	private readonly IPrefabInstantiationStrategy _instantiationStrategy; //Field offset: 0x0
	private readonly string _instanceName; //Field offset: 0x0
	private IAssetRequest<TAsset> _assetRequest; //Field offset: 0x0
	[CompilerGenerated]
	private TComponent <Value>k__BackingField; //Field offset: 0x0

	public override IEnumerable<AssetKey> RequiredAssets
	{
		[IteratorStateMachine(typeof(<get_RequiredAssets>d__17))]
		 get { } //Length: 124
	}

	public private override TComponent Value
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	private static AsyncLoadedPrefab`2() { }

	public AsyncLoadedPrefab`2(AssetKey assetKey, IAssetProvider assetProvider, Func<TAsset, GameObject> prefabSelector, IPrefabInstantiationStrategy instantiationStrategy, string instanceName = null, string ownerLabelOverride = null, string callerMemberName = "", string callerFilePath = "", int callerLineNumber = 0) { }

	[IteratorStateMachine(typeof(<get_RequiredAssets>d__17))]
	public override IEnumerable<AssetKey> get_RequiredAssets() { }

	[CompilerGenerated]
	public override TComponent get_Value() { }

	[IteratorStateMachine(typeof(<InitFactory>d__19))]
	protected virtual IEnumerable<IAsyncOperationWithProgress> InitFactory() { }

	[AsyncStateMachine(typeof(<LoadAssetAsync>d__21))]
	protected override UniTask LoadAssetAsync(IAssetProvider assetProvider, IOperationProgressObserver onProgressChange = null) { }

	[AsyncStateMachine(typeof(<LoadAsync>d__20))]
	private UniTask LoadAsync(IOperationProgressObserver onProgressChange = null) { }

	[CompilerGenerated]
	private void set_Value(TComponent value) { }

}

