namespace Client.Animations.AnimStateHandlers;

public class IdleAnimationTimerHandler : StateMachineBehaviour
{
	public Action<Int32> OnIdleBreakEvent; //Field offset: 0x18
	public Action OnIdleAnimationStarted; //Field offset: 0x20
	[SerializeField]
	private bool _isLobby; //Field offset: 0x28
	[SerializeField]
	private float _idleChangeTime; //Field offset: 0x2C
	private float _idleTime; //Field offset: 0x30
	private int _prevIdleBreakIndex; //Field offset: 0x34
	private int _currentIdleBreakIndex; //Field offset: 0x38

	public IdleAnimationTimerHandler() { }

	public virtual void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) { }

	public virtual void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) { }

	public virtual void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) { }

	public void SubscribeIdleAnimationStarted(Action action) { }

	public void SubscribeIdleBreakEvent(Action<Int32> action) { }

	public void UnSubscribeIdleAnimationStarted(Action action) { }

	public void UnSubscribeIdleBreakEvent(Action<Int32> action) { }

}

