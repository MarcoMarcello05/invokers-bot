namespace Client.CharacterControllers;

public class HUDSkillCooldownContainer
{
	public readonly Dictionary<SkillType, HudSkillCooldown> HUDSkillCooldowns; //Field offset: 0x10
	private HudSkillsView _hudSkillsView; //Field offset: 0x18

	public HudSkillsView HudSkillsView
	{
		 get { } //Length: 8
	}

	public HUDSkillCooldownContainer() { }

	public void BlockSkill(SkillType skillType, bool needBlock) { }

	public void Clear() { }

	public void Dispose() { }

	public HudSkillsView get_HudSkillsView() { }

	public HudSkillCooldown HudCooldownBySkillType(SkillType type) { }

	public void ResetCast(SkillType skillType) { }

	public void ResetCooldown(SkillType skillType) { }

	public void ResetQueue() { }

	public void SetCastFill(SkillType skillType, float fillAmount) { }

	public void SetCooldown(SkillType skillType, float timeLeft, float cooldown) { }

	public void SetMoveToCastGlow(SkillType glowSkillType) { }

	public void SetUltMana(int manaChange, float normalizedMana, bool isInstant) { }

	public void UpdateViews() { }

}

