namespace Client.Core.Dialogs;

[Nullable(0)]
[NullableContext(1)]
public class StaticModalPopup : BaseDialogView
{
	[SerializeField]
	private HZButton _closeButton; //Field offset: 0x58
	[SerializeField]
	private HZButton _confirmButton; //Field offset: 0x60
	[Nullable(2)]
	[SerializeField]
	private HZButton _closeButtonX; //Field offset: 0x68
	[Nullable(2)]
	[SerializeField]
	private HZButton _closeButtonOverlay; //Field offset: 0x70
	[SerializeField]
	private TextMeshProUGUI _headerText; //Field offset: 0x78
	[SerializeField]
	private TextMeshProUGUI _contentText; //Field offset: 0x80
	[CompilerGenerated]
	[Nullable(2)]
	private IButtonCommand <CloseButtonCommand>k__BackingField; //Field offset: 0x88

	public HZButton CloseButton
	{
		 get { } //Length: 24
	}

	[Nullable(2)]
	public private IButtonCommand CloseButtonCommand
	{
		[CompilerGenerated]
		[NullableContext(2)]
		 get { } //Length: 8
		[CompilerGenerated]
		[NullableContext(2)]
		private set { } //Length: 8
	}

	public StaticModalPopup() { }

	public HZButton get_CloseButton() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public IButtonCommand get_CloseButtonCommand() { }

	private void OnValidate() { }

	[CompilerGenerated]
	[NullableContext(2)]
	private void set_CloseButtonCommand(IButtonCommand value) { }

	public void SetCloseButtonActive(bool isActive) { }

	public void SetCloseButtonHandler(IButtonCommand buttonCommand) { }

	public void SetCloseButtonOverlayActive(bool isActive) { }

	public void SetCloseButtonText(string text) { }

	public void SetCloseButtonXActive(bool isActive) { }

	public void SetConfirmButtonHandler(IButtonCommand buttonCommand) { }

	public void SetConfirmButtonText(string text) { }

	public void SetText(string header, string content) { }

}

