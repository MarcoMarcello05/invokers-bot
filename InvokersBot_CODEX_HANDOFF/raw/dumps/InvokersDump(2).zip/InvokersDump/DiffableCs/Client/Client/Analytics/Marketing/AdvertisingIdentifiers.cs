namespace Client.Analytics.Marketing;

[Nullable(0)]
[NullableContext(2)]
public sealed class AdvertisingIdentifiers
{
	[Nullable(1)]
	public static readonly AdvertisingIdentifiers Empty; //Field offset: 0x0
	[CompilerGenerated]
	private string <AppsFlyerId>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private string <Idfa>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private string <Idfv>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private string <Gaid>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private string <AndroidId>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private Nullable<Boolean> <LimitAdTrackingEnabled>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private string <AdvertisingId>k__BackingField; //Field offset: 0x40
	[CompilerGenerated]
	private string <AttAuthorizationOutcome>k__BackingField; //Field offset: 0x48
	[CompilerGenerated]
	private string <CollectionOutcome>k__BackingField; //Field offset: 0x50

	public string AdvertisingId
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string AndroidId
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string AppsFlyerId
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string AttAuthorizationOutcome
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string CollectionOutcome
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string Gaid
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string Idfa
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public string Idfv
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public Nullable<Boolean> LimitAdTrackingEnabled
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		 set { } //Length: 8
	}

	private static AdvertisingIdentifiers() { }

	public AdvertisingIdentifiers() { }

	[CompilerGenerated]
	public string get_AdvertisingId() { }

	[CompilerGenerated]
	public string get_AndroidId() { }

	[CompilerGenerated]
	public string get_AppsFlyerId() { }

	[CompilerGenerated]
	public string get_AttAuthorizationOutcome() { }

	[CompilerGenerated]
	public string get_CollectionOutcome() { }

	[CompilerGenerated]
	public string get_Gaid() { }

	[CompilerGenerated]
	public string get_Idfa() { }

	[CompilerGenerated]
	public string get_Idfv() { }

	[CompilerGenerated]
	public Nullable<Boolean> get_LimitAdTrackingEnabled() { }

	[CompilerGenerated]
	public void set_AdvertisingId(string value) { }

	[CompilerGenerated]
	public void set_AndroidId(string value) { }

	[CompilerGenerated]
	public void set_AppsFlyerId(string value) { }

	[CompilerGenerated]
	public void set_AttAuthorizationOutcome(string value) { }

	[CompilerGenerated]
	public void set_CollectionOutcome(string value) { }

	[CompilerGenerated]
	public void set_Gaid(string value) { }

	[CompilerGenerated]
	public void set_Idfa(string value) { }

	[CompilerGenerated]
	public void set_Idfv(string value) { }

	[CompilerGenerated]
	public void set_LimitAdTrackingEnabled(Nullable<Boolean> value) { }

}

