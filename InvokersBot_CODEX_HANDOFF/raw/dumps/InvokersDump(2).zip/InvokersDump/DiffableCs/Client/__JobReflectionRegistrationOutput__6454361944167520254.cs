//Type is in global namespace

internal class __JobReflectionRegistrationOutput__6454361944167520254
{

	public static void CreateJobReflectionData() { }

	[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType::AfterAssembliesLoaded (2))]
	public static void EarlyInit() { }

}

