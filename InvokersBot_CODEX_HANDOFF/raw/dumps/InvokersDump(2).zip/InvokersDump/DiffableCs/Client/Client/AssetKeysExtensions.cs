namespace Client;

[Extension]
public static class AssetKeysExtensions
{

	[Extension]
	public static void GetAllLobbyAssetsKeys(BaseCharacterConfig config, CharacterSkin skin, List<AssetKey> keysNonAlloc) { }

	[Extension]
	public static AssetKey GetBattlePrefabHolderKey(AssetsRecord record, CharacterSkin skin) { }

	[Extension]
	public static AssetKey GetBattleShadersCollectionKey(BaseCharacterConfig config, CharacterSkin skin) { }

	[Extension]
	public static AssetKey GetBattleShadersCollectionKey(AssetsRecord record, CharacterSkin skin) { }

	[Extension]
	public static AssetKey GetCharacterAssetsHolderKey(BaseCharacterConfig config) { }

	[Extension]
	public static AssetKey GetLobbyPrefabHolderKey(BaseCharacterConfig config, CharacterSkin skin) { }

	[Extension]
	public static AssetKey GetLobbyShadersCollectionKey(BaseCharacterConfig config, CharacterSkin skin) { }

	[Extension]
	public static AssetKey GetLobbySoundKey(BaseCharacterConfig config) { }

	[Extension]
	public static bool SupportsChroma(CharacterKind kind) { }

	[Extension]
	public static bool SupportsChroma(BaseCharacterConfig config) { }

	[Extension]
	public static AssetsRecord ToAssetsRecord(BaseCharacterConfig config) { }

	[Extension]
	public static AssetsRecord ToAssetsRecord(CharacterStaticData data) { }

	[Extension]
	public static PortraitRecord ToPortraitRecord(BaseCharacterConfig config) { }

	[Extension]
	public static PortraitRecord ToPortraitRecord(CharacterStaticData data) { }

}

