namespace Client.Authentication;

[Nullable(0)]
[NullableContext(1)]
public class AuthenticationResult
{
	[CompilerGenerated]
	private readonly AuthenticationStatus <Status>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly string <AuthorizationCode>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly string <PkceCodeVerifier>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private readonly string <RedirectUri>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	[Nullable(2)]
	private readonly AuthenticationError <Error>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private readonly string <ClientId>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private readonly string <JwtToken>k__BackingField; //Field offset: 0x40

	public string AuthorizationCode
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string ClientId
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	[Nullable(2)]
	public AuthenticationError Error
	{
		[CompilerGenerated]
		[NullableContext(2)]
		 get { } //Length: 8
	}

	public bool IsSuccess
	{
		 get { } //Length: 16
	}

	public string JwtToken
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string PkceCodeVerifier
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string RedirectUri
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public AuthenticationStatus Status
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public AuthenticationResult(AuthenticationStatus status, AuthenticationError error) { }

	public AuthenticationResult(string jwtToken) { }

	public AuthenticationResult(string authorizationCode, string pkceCodeVerifier, string redirectUri, string clientId) { }

	public static AuthenticationResult Fail(AuthenticationError error) { }

	public static AuthenticationResult Fail(AuthenticationStatus status, AuthenticationError error) { }

	public static AuthenticationResult Fail(string errorMessage, string errorCode, Exception ex = null) { }

	[CompilerGenerated]
	public string get_AuthorizationCode() { }

	[CompilerGenerated]
	public string get_ClientId() { }

	[CompilerGenerated]
	[NullableContext(2)]
	public AuthenticationError get_Error() { }

	public bool get_IsSuccess() { }

	[CompilerGenerated]
	public string get_JwtToken() { }

	[CompilerGenerated]
	public string get_PkceCodeVerifier() { }

	[CompilerGenerated]
	public string get_RedirectUri() { }

	[CompilerGenerated]
	public AuthenticationStatus get_Status() { }

}

