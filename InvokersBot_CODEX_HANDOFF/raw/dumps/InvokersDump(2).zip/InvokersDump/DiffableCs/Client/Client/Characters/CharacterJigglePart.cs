namespace Client.Characters;

[DisallowMultipleComponent]
public sealed class CharacterJigglePart : MonoBehaviour, ICharacterViewPart
{
	[SerializeField]
	private Jiggle[] _bones; //Field offset: 0x20

	public IReadOnlyList<Jiggle> Bones
	{
		 get { } //Length: 8
	}

	public CharacterJigglePart() { }

	public IReadOnlyList<Jiggle> get_Bones() { }

	public override void ResetForReuse() { }

}

