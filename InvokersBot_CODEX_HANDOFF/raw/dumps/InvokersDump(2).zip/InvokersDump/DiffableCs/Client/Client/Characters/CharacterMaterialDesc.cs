namespace Client.Characters;

public struct CharacterMaterialDesc
{
	public Material MaterialInstance; //Field offset: 0x0
	public Vector4 OrigEmissionParams; //Field offset: 0x8
	public Vector4 OrigRimColor; //Field offset: 0x18
	public float VfxRimAndNoise; //Field offset: 0x28
	public LocalKeyword DissolveKeyword; //Field offset: 0x30

	public void RestoreAuthored() { }

}

