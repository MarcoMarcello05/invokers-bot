namespace Client.Characters;

public class JiggleSpecificAnimations : MonoBehaviour
{
	private struct JiggleValues
	{
		public float CenterOfMassInertia; //Field offset: 0x0
		public float Gravity; //Field offset: 0x4
		public float RotationInertia; //Field offset: 0x8
		public float SpringStrength; //Field offset: 0xC
		public float Dampening; //Field offset: 0x10

	}

	private static readonly List<AnimatorClipInfo> _tempCurrentClipInfos; //Field offset: 0x0
	private static readonly List<AnimatorClipInfo> _tempNextClipInfos; //Field offset: 0x8
	[Tooltip("Reference to the Animator component.")]
	public Animator Animator; //Field offset: 0x20
	[FormerlySerializedAs("targetAnimations")]
	[Tooltip("List of AnimationClips that should DEACTIVATE the Jiggle effect.")]
	public List<String> NoJiggleClipNames; //Field offset: 0x28
	[Tooltip("All jiggle componentes affected by this component that should DEACTIVATE the Jiggle effect.")]
	public Jiggle[] JiggleComponents; //Field offset: 0x30
	[SerializeField]
	[Tooltip("The Animator layer to monitor for target animations.")]
	private int animationLayer; //Field offset: 0x38
	[SerializeField]
	[Tooltip("Duration in seconds for the Jiggle effect to smoothly fade in or out.")]
	private float SmoothTransition; //Field offset: 0x3C
	[FormerlySerializedAs("DisableJiggleOnStart")]
	[Tooltip("Skip jiggle simulation until the first animation that allows jiggle starts playing.")]
	public bool DisableJiggleUntilFirstJiggleAnimation; //Field offset: 0x40
	private float _jiggleBlend; //Field offset: 0x44
	private JiggleValues[] _defaultValues; //Field offset: 0x48
	private bool _hasValidSetup; //Field offset: 0x50
	private bool _bonesGated; //Field offset: 0x51
	private HashSet<String> _noJiggleClipNameSet; //Field offset: 0x58
	private readonly Dictionary<Int32, Boolean> _clipJiggleByIdCache; //Field offset: 0x60

	private static ILogger _logger
	{
		private get { } //Length: 64
	}

	private static JiggleSpecificAnimations() { }

	public JiggleSpecificAnimations() { }

	private void ApplySmoothedJiggleAttributes() { }

	private void EnsureSetup() { }

	private void FillComponentList() { }

	private static ILogger get__logger() { }

	private bool IsAnyClipInTargetList(List<AnimatorClipInfo> clipInfoList) { }

	private void OnEnable() { }

	private void Reset() { }

	private void SetBonesEnabled(bool value) { }

	private void Update() { }

}

