namespace Client.Characters;

public interface ICharacterViewPart
{

	public void ResetForReuse() { }

}

