namespace Client.Core.Dialogs.DeviceChange;

[Nullable(0)]
[NullableContext(1)]
public class DeviceChangeDialogView : BaseDialogView
{
	[SerializeField]
	private HZButton _continueButton; //Field offset: 0x58
	[Nullable(2)]
	[SerializeField]
	private HZButton _switchAccountButton; //Field offset: 0x60
	[SerializeField]
	private TextMeshProUGUI _thisDeviceNameText; //Field offset: 0x68
	[SerializeField]
	private TextMeshProUGUI _otherDeviceNameText; //Field offset: 0x70
	[Nullable(2)]
	[SerializeField]
	private TextMeshProUGUI _otherDeviceSyncTimeText; //Field offset: 0x78
	[SerializeField]
	private Image _thisDeviceIcon; //Field offset: 0x80
	[SerializeField]
	private Image _otherDeviceIcon; //Field offset: 0x88
	[SerializeField]
	private Sprite _mobileDeviceSprite; //Field offset: 0x90
	[SerializeField]
	private Sprite _tabletDeviceSprite; //Field offset: 0x98
	[SerializeField]
	private Sprite _desktopDeviceSprite; //Field offset: 0xA0
	[SerializeField]
	private Sprite _otherDeviceSprite; //Field offset: 0xA8
	[CompilerGenerated]
	[Nullable(2)]
	private IButtonCommand <ContinueButtonCommand>k__BackingField; //Field offset: 0xB0

	[Nullable(2)]
	public private IButtonCommand ContinueButtonCommand
	{
		[CompilerGenerated]
		[NullableContext(2)]
		 get { } //Length: 8
		[CompilerGenerated]
		[NullableContext(2)]
		private set { } //Length: 8
	}

	public DeviceChangeDialogView() { }

	private void Apply(DeviceDisplayInfo device, TextMeshProUGUI nameText, Image icon) { }

	[CompilerGenerated]
	[NullableContext(2)]
	public IButtonCommand get_ContinueButtonCommand() { }

	public void HideSwitchAccountButton() { }

	private void OnValidate() { }

	[CompilerGenerated]
	[NullableContext(2)]
	private void set_ContinueButtonCommand(IButtonCommand value) { }

	public void SetContinueButtonHandler(IButtonCommand command) { }

	public void SetDevices(DeviceDisplayInfo thisDevice, DeviceDisplayInfo otherDevice) { }

	public void SetOtherDeviceLastSyncTime(DateTime lastSyncTimeUtc) { }

}

