namespace Client.Configuration;

public class BuildAssetsConfigurationSource : IConfigurationSource
{
	[CompilerGenerated]
	private readonly string <ResourcePath>k__BackingField; //Field offset: 0x10

	public string ResourcePath
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public BuildAssetsConfigurationSource(string path) { }

	public override IConfigurationProvider Build(IConfigurationBuilder builder) { }

	[CompilerGenerated]
	public string get_ResourcePath() { }

}

