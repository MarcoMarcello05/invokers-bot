namespace Client.Authentication.GooglePlayGames;

[NullableContext(2)]
public interface IGooglePlayGamesService
{

	public bool IsAuthenticated
	{
		 get { } //Length: 0
	}

	public bool IsAvailable
	{
		 get { } //Length: 0
	}

	public string UserId
	{
		 get { } //Length: 0
	}

	public string UserName
	{
		 get { } //Length: 0
	}

	[NullableContext(0)]
	public ValueTask<GooglePlayGamesAuthStatus> AuthenticateAsync(bool manual, CancellationToken cancellationToken = null) { }

	public bool get_IsAuthenticated() { }

	public bool get_IsAvailable() { }

	public string get_UserId() { }

	public string get_UserName() { }

	public ValueTask<GooglePlayGamesServerAuthCodeResult> GetServerAuthCodeAsync(CancellationToken cancellationToken = null) { }

}

