namespace Client.Configuration;

public sealed class PlatformConfigRules
{
	private static readonly ILogger Log; //Field offset: 0x0
	private readonly ISystemInfoProvider _systemInfoProvider; //Field offset: 0x10
	private readonly PlatformConfigRulesAsset _asset; //Field offset: 0x18
	private List<String> _deviceConfigs; //Field offset: 0x20
	private QualityTier _deviceQualityTier; //Field offset: 0x28
	private string _deviceTierConfig; //Field offset: 0x30

	private static PlatformConfigRules() { }

	public PlatformConfigRules(string basePath, string rulesFilePath, ISystemInfoProvider systemInfoProvider) { }

	[CompilerGenerated]
	internal static bool <ValidateRule>g__MatchOrNull|13_0(string regex, string value) { }

	private string FindTierConfig(QualityTier qualityTier) { }

	private void LogMatchedConfigs() { }

	private void MatchDeviceRules(QualityTier deviceQualityOverride) { }

	public PlatformConfigSet Resolve(QualityTier selectedQuality, QualityTier deviceQualityOverride) { }

	private string ResolveSelectedConfig(QualityTier selectedQuality, QualityTier deviceTier) { }

	private bool ValidateRule(Rule rule, List<String> matchedConfigs) { }

	private bool ValidateRules(List<Rule> rules, List<String> matchedConfigs) { }

}

