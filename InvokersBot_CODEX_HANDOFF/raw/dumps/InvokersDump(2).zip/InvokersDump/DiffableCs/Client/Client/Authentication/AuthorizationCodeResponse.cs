namespace Client.Authentication;

public class AuthorizationCodeResponse
{
	[CompilerGenerated]
	private readonly string <AuthorizationCode>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private readonly string <Error>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private readonly string <State>k__BackingField; //Field offset: 0x20

	public string AuthorizationCode
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public string Error
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public bool IsSuccess
	{
		 get { } //Length: 60
	}

	public string State
	{
		[CompilerGenerated]
		 get { } //Length: 8
	}

	public AuthorizationCodeResponse(string authorizationCode, string error = null, string state = null) { }

	[CompilerGenerated]
	public string get_AuthorizationCode() { }

	[CompilerGenerated]
	public string get_Error() { }

	public bool get_IsSuccess() { }

	[CompilerGenerated]
	public string get_State() { }

}

