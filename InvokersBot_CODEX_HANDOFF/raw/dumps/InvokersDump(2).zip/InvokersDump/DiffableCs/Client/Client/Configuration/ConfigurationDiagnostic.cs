namespace Client.Configuration;

public class ConfigurationDiagnostic
{
	private readonly IConfigurationRoot _configuration; //Field offset: 0x10

	public ConfigurationDiagnostic(IConfigurationRoot configuration) { }

	public string Report() { }

}

