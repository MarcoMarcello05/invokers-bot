namespace Client.AutoBattle;

[DisallowMultipleComponent]
[ExecuteAlways]
public class Waypoint : SerializableConfig<AutoBattleWaypoint>
{
	public WaypointsHolder Parent; //Field offset: 0x20
	[Obsolete("Using HzGuid")]
	public string Id; //Field offset: 0x28
	public HzGuid Guid; //Field offset: 0x30
	public float Radius; //Field offset: 0x40
	public bool RegisterIfTouchedOutOfOrder; //Field offset: 0x44
	public WaypointCompletionMethod CompletionMethod; //Field offset: 0x45
	public List<Waypoint> Next; //Field offset: 0x48

	public Waypoint() { }

	public virtual AutoBattleWaypoint Serialize() { }

}

