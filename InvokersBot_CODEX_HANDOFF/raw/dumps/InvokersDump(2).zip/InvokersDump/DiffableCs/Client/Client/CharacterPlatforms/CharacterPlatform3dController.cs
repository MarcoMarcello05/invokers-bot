namespace Client.CharacterPlatforms;

public sealed class CharacterPlatform3dController : BaseViewController<CharacterPlatform3dView>
{
	private readonly AssetKey _platformPrefabKey; //Field offset: 0x68
	private readonly IAssetProvider _assetProvider; //Field offset: 0x70
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x78

	public ICharacterPlatform3dView Platform3DView
	{
		 get { } //Length: 72
	}

	public CharacterPlatform3dController(AssetKey platformPrefabKey, IAssetProvider assetProvider, IStagingContainer stagingContainer) { }

	public ICharacterPlatform3dView get_Platform3DView() { }

	protected virtual void OnViewLoaded() { }

	public void SetViewParent(Transform parent, bool worldPositionStays = false) { }

	protected virtual IAsyncInitializable<CharacterPlatform3dView> ViewFactory() { }

}

