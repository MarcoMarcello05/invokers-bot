namespace Client.Core;

[Extension]
public static class AsyncOperationsGroupExtensions
{

	[Extension]
	public static IAsyncOperationsGroup Add(IAsyncOperationsGroup self, IAsyncOperationWithProgress operation, Order order = 1) { }

}

