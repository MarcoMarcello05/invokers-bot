namespace Client.Characters;

public interface IJiggleScheduler
{

	public void FixedTick(float fixedDeltaTime) { }

	public IDisposable Register(IReadOnlyList<Jiggle> bones) { }

	public void Tick(float deltaTime) { }

}

