namespace Client.Core;

public class GameObjectsPoolItem : MonoBehaviour, IObjectsPoolItem<T>
{
	private readonly GameObjectsPoolItemBase<T> _base; //Field offset: 0x0

	public override T Template
	{
		 get { } //Length: 24
	}

	public GameObjectsPoolItem`1() { }

	public override T get_Template() { }

	public override void OnInstantiate(IObjectsPool<T> ownerPool, T template) { }

	public override void ResetBeforeRent() { }

	public override void ReturnToPool() { }

}

