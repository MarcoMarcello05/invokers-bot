namespace Client.Authentication.GooglePlayGames;

public enum GooglePlayGamesIdentityScope : int
{
	OpenId = 0,
	Profile = 1,
	Email = 2,
}

