namespace Client.Common.UI;

public class ButtonStateTextColorChangeDecorator : ButtonStateDecorator
{
	[SerializeField]
	private Color _activeColor; //Field offset: 0x20
	[SerializeField]
	private Color _inactiveColor; //Field offset: 0x30
	[SerializeField]
	private TextMeshProUGUI _label; //Field offset: 0x40

	public ButtonStateTextColorChangeDecorator() { }

	public virtual void SetSelected(bool selected) { }

}

