namespace Client.Authentication;

public static class PkceUtility
{
	private const int CodeVerifierMinLength = 43; //Field offset: 0x0
	private const int CodeVerifierMaxLength = 128; //Field offset: 0x0

	public static string GenerateCodeChallengeS256(string codeVerifier) { }

	public static string GenerateCodeVerifier(int length = 128) { }

	private static string GenerateRandomString(int length) { }

	public static string GenerateState() { }

	private static string ToBase64UrlSafeString(Byte[] bytes) { }

}

