namespace Client.Characters;

public enum CharacterAnimationEvent : byte
{
	Step = 0,
	Hit = 1,
	IdleHit = 2,
	Damage = 3,
	EventCustom = 4,
	Flinch = 5,
}

