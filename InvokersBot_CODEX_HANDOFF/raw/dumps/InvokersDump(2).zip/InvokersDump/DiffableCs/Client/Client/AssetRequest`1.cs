namespace Client;

[Nullable(0)]
[NullableContext(1)]
public class AssetRequest : IAssetRequest<T>, IAssetRequest, IDisposable
{
	private readonly IAssetLoadingTask<T> _assetLoadingTask; //Field offset: 0x0
	private readonly AddressableAssetProvider _assetProvider; //Field offset: 0x0
	private bool _isDisposed; //Field offset: 0x0
	private readonly int _ownerId; //Field offset: 0x0

	public override T Asset
	{
		 get { } //Length: 296
	}

	[Nullable(new IL2CPP_TYPE_U1[] {0, 1})]
	public override UniTask<T> AssetTask
	{
		 get { } //Length: 292
	}

	public override DownloadStatus DownloadStatus
	{
		 get { } //Length: 200
	}

	[Nullable(2)]
	public override Exception Exception
	{
		[NullableContext(2)]
		 get { } //Length: 164
	}

	public override bool Failed
	{
		 get { } //Length: 164
	}

	public override bool Finished
	{
		 get { } //Length: 164
	}

	internal IAssetLoadingTask<T> InternalLoadingTask
	{
		internal get { } //Length: 8
	}

	public override bool IsDisposed
	{
		 get { } //Length: 8
	}

	public override AssetKey Key
	{
		 get { } //Length: 160
	}

	public override Stopwatch LoadTimer
	{
		 get { } //Length: 164
	}

	public override bool Ready
	{
		 get { } //Length: 164
	}

	public AssetRequest`1(int ownerId, IAssetLoadingTask<T> assetLoadingTask, AddressableAssetProvider assetProvider) { }

	public override void Dispose() { }

	public override T get_Asset() { }

	public override UniTask<T> get_AssetTask() { }

	public override DownloadStatus get_DownloadStatus() { }

	[NullableContext(2)]
	public override Exception get_Exception() { }

	public override bool get_Failed() { }

	public override bool get_Finished() { }

	internal IAssetLoadingTask<T> get_InternalLoadingTask() { }

	public override bool get_IsDisposed() { }

	public override AssetKey get_Key() { }

	public override Stopwatch get_LoadTimer() { }

	public override bool get_Ready() { }

	public virtual string ToString() { }

}

