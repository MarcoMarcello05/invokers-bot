namespace Client.CharacterPlatforms;

public interface ICharacterPlatformsCamera
{

	public RectTransform SwipeRect
	{
		 set { } //Length: 0
	}

	public void OnLateUpdate() { }

	public void ResetCamera() { }

	public void set_SwipeRect(RectTransform value) { }

	public void SetCharacter(LobbyCharacterController character, CameraPosition position, bool skipIntro = false) { }

	public void SetPosition(Transform position) { }

	public void SetTurntable(Transform turntable) { }

}

