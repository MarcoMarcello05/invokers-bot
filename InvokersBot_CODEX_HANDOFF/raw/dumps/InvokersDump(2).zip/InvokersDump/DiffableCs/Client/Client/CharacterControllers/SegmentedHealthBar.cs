namespace Client.CharacterControllers;

public class SegmentedHealthBar
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass20_0
	{
		public SegmentedHealthBar <>4__this; //Field offset: 0x10
		public float newTotalRatio; //Field offset: 0x18

		public <>c__DisplayClass20_0() { }

		internal void <TriggerDamageCatchUp>b__0(float currentTopRatio) { }

	}

	[SerializeField]
	private Image healthImage; //Field offset: 0x10
	[SerializeField]
	private Image shieldImage; //Field offset: 0x18
	[SerializeField]
	private Image destroyedImage; //Field offset: 0x20
	[SerializeField]
	private Image damageAfterglowImage; //Field offset: 0x28
	private HealthBarState _currentState; //Field offset: 0x30
	private Sequence _damageAfterglowSequence; //Field offset: 0x40
	private Tween _healthBlinkTween; //Field offset: 0x50
	private Tween _shieldBlinkTween; //Field offset: 0x60
	private bool _isAfterglowActive; //Field offset: 0x70
	private float _afterglowTopRatio; //Field offset: 0x74
	private Color _healthColor; //Field offset: 0x78
	private Color _shieldColor; //Field offset: 0x88
	private Action _onDamageAfterGlowAnimationCompleteCached; //Field offset: 0x98

	private HealthBarTweaks _config
	{
		private get { } //Length: 32
	}

	public HealthBarState CurrentHealthState
	{
		 get { } //Length: 12
	}

	public SegmentedHealthBar() { }

	private HealthBarTweaks get__config() { }

	public HealthBarState get_CurrentHealthState() { }

	public void Init(HealthBarColorsTweaks colorTweaks) { }

	private void OnDamageAfterGlowAnimationComplete() { }

	public void OnDisable() { }

	private void SetBarAnchors(HealthBarState state) { }

	private void SetRectAnchors(RectTransform rt, float minX, float maxX) { }

	private void TriggerBlinkEffectOnHealthAndShield(float shieldRatio) { }

	private void TriggerDamageCatchUp(float newTotalRatio, float oldTotalRatio) { }

	public void UpdateState(HealthBarState newState, bool animate = true) { }

}

