namespace Client.Core.ErrorHandling;

[Nullable(0)]
[NullableContext(1)]
[UsedAsInjection]
public class ErrorDialogBuilder : IErrorDialogBuilder
{
	[CompilerGenerated]
	private struct <ShowAndWaitBanDialog>d__27 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ErrorDialogBuilder <>4__this; //Field offset: 0x18
		[Nullable(0)]
		public PlayerBanError error; //Field offset: 0x20
		private Awaiter <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ShowAndWaitCollectionLimitReachedDialog>d__24 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ErrorDialogBuilder <>4__this; //Field offset: 0x18
		public CollectionLimitType collectionLimitType; //Field offset: 0x20
		[Nullable(0)]
		public IErrorDetails error; //Field offset: 0x28
		[Nullable(0)]
		private CollectionLimitReachedPopupController <popupController>5__2; //Field offset: 0x30
		[Nullable(0)]
		private Awaiter<Boolean> <>u__1; //Field offset: 0x38
		private Awaiter <>u__2; //Field offset: 0x48

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ShowAndWaitConnectionRequiredAsync>d__16 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public IErrorDetails error; //Field offset: 0x18
		[Nullable(0)]
		public ErrorDialogBuilder <>4__this; //Field offset: 0x20
		[Nullable(0)]
		private ConnectionRequiredPopupController <dialog>5__2; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ShowAndWaitErrorDialog>d__19 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ErrorDialogBuilder <>4__this; //Field offset: 0x18
		public ErrorType errorType; //Field offset: 0x20
		[Nullable(0)]
		public string title; //Field offset: 0x28
		[Nullable(0)]
		public string errorMessage; //Field offset: 0x30
		[Nullable(0)]
		public string buttonText; //Field offset: 0x38
		[Nullable(0)]
		public string errorCode; //Field offset: 0x40
		[Nullable(0)]
		private ErrorModalPopupController <dialog>5__2; //Field offset: 0x48
		private Awaiter <>u__1; //Field offset: 0x50

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ShowAndWaitHardUpdateDialog>d__23 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ErrorDialogBuilder <>4__this; //Field offset: 0x18
		[Nullable(0)]
		private HardUpdateDialogController <popupController>5__2; //Field offset: 0x20
		private Awaiter <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ShowAndWaitNotEnoughEnergyDialog>d__22 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ErrorDialogBuilder <>4__this; //Field offset: 0x18
		[Nullable(0)]
		private NotEnoughEnergyPopupController <popupController>5__2; //Field offset: 0x20
		private Awaiter <>u__1; //Field offset: 0x28

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ShowAndWaitNotEnoughResourcesDialog>d__21 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ErrorDialogBuilder <>4__this; //Field offset: 0x18
		[Nullable(0)]
		public NotEnoughResourcesError error; //Field offset: 0x20
		[Nullable(0)]
		private NotEnoughResourcesPopupController <popupController>5__2; //Field offset: 0x28
		private Awaiter <>u__1; //Field offset: 0x30

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	private struct <ShowAndWaitOfflineModeEnabledDialog>d__17 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[Nullable(0)]
		public ErrorDialogBuilder <>4__this; //Field offset: 0x18
		public OfflineModeWarning warning; //Field offset: 0x20
		[Nullable(0)]
		public string diagnosticMessage; //Field offset: 0x48
		[Nullable(0)]
		private OfflineModeEnabledPopupController <dialog>5__2; //Field offset: 0x50
		private Awaiter <>u__1; //Field offset: 0x58

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private readonly IContentManager _content; //Field offset: 0x10
	private readonly IStagingContainer _stagingContainer; //Field offset: 0x18
	private readonly IUISystem _uiSystem; //Field offset: 0x20
	private readonly IOptionsMonitor<ClientAppSettings> _settings; //Field offset: 0x28
	private readonly Func<HardUpdateDialogController> _hardUpdateRequiredDialogControllerFactory; //Field offset: 0x30
	private readonly Func<NotEnoughResourcesPopupController> _notEnoughResourcesPopupFactory; //Field offset: 0x38
	private readonly Func<NotEnoughEnergyPopupController> _notEnoughEnergyPopupFactory; //Field offset: 0x40
	private readonly Func<CollectionLimitReachedPopupController> _collectionLimitReachedPopupFactory; //Field offset: 0x48
	private readonly ISupportService _supportService; //Field offset: 0x50
	[Nullable(2)]
	private IChoreographManager _choreograph; //Field offset: 0x58
	[Nullable(2)]
	private ApplicationExitController _applicationExitController; //Field offset: 0x60
	[Nullable(2)]
	private IGameStateManager _gameStateManager; //Field offset: 0x68

	public ErrorDialogBuilder(IContentManager content, IStagingContainer stagingContainer, IUISystem uiSystem, IOptionsMonitor<ClientAppSettings> settings, ISupportService supportService, Func<HardUpdateDialogController> hardUpdateRequiredDialogControllerFactory, Func<NotEnoughResourcesPopupController> notEnoughResourcesPopupFactory, Func<NotEnoughEnergyPopupController> notEnoughEnergyPopupFactory, Func<CollectionLimitReachedPopupController> collectionLimitReachedPopupFactory) { }

	public void CopyDiagnosticsIntoClipboard(string title, string message) { }

	private static Nullable<Int32> GetRequiredSlots(IErrorDetails error) { }

	private bool IsNotEnoughEnergyError(NotEnoughResourcesError error) { }

	private string MapCloseButtonText(IErrorDetails error, bool fatal = false) { }

	private static string MapCollectionLimitMessage(CollectionLimitType collectionLimitType) { }

	private static string MapCollectionLimitTitle(CollectionLimitType collectionLimitType) { }

	private string MapErrorMessage(IErrorDetails error) { }

	private string MapErrorTitle(IErrorDetails error) { }

	private UniTask NavigateToCollectionManagement(CollectionLimitType collectionLimitType) { }

	public override void SetApplicationExitController(ApplicationExitController applicationExitController) { }

	public override void SetChoreograph(IChoreographManager choreograph) { }

	public override void SetGameStateManager(IGameStateManager gameStateManager) { }

	[AsyncStateMachine(typeof(<ShowAndWaitBanDialog>d__27))]
	private UniTask ShowAndWaitBanDialog(PlayerBanError error) { }

	[AsyncStateMachine(typeof(<ShowAndWaitCollectionLimitReachedDialog>d__24))]
	private UniTask ShowAndWaitCollectionLimitReachedDialog(IErrorDetails error, CollectionLimitType collectionLimitType) { }

	[AsyncStateMachine(typeof(<ShowAndWaitConnectionRequiredAsync>d__16))]
	private UniTask ShowAndWaitConnectionRequiredAsync(IErrorDetails error) { }

	public override UniTask ShowAndWaitErrorDialog(IErrorDetails error) { }

	public override UniTask ShowAndWaitErrorDialog(Exception exception, ErrorType errorType = 0) { }

	[AsyncStateMachine(typeof(<ShowAndWaitErrorDialog>d__19))]
	public override UniTask ShowAndWaitErrorDialog(string title, string errorMessage, string buttonText = null, ErrorType errorType = 0, string errorCode = null) { }

	[AsyncStateMachine(typeof(<ShowAndWaitHardUpdateDialog>d__23))]
	private UniTask ShowAndWaitHardUpdateDialog() { }

	[AsyncStateMachine(typeof(<ShowAndWaitNotEnoughEnergyDialog>d__22))]
	private UniTask ShowAndWaitNotEnoughEnergyDialog(NotEnoughResourcesError error) { }

	[AsyncStateMachine(typeof(<ShowAndWaitNotEnoughResourcesDialog>d__21))]
	private UniTask ShowAndWaitNotEnoughResourcesDialog(NotEnoughResourcesError error) { }

	[AsyncStateMachine(typeof(<ShowAndWaitOfflineModeEnabledDialog>d__17))]
	public override UniTask ShowAndWaitOfflineModeEnabledDialog(OfflineModeWarning warning, string diagnosticMessage) { }

}

