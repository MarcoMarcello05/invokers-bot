namespace Client.CharacterControllers;

public sealed class ChromaVfx : MonoBehaviour
{
	[SerializeField]
	private TargetFollower _groundFollower; //Field offset: 0x20
	[SerializeField]
	private TargetFollower _bodyFollower; //Field offset: 0x28

	public ChromaVfx() { }

	public void Follow(Transform target) { }

	public void InheritMotion(Transform animatedRoot) { }

}

