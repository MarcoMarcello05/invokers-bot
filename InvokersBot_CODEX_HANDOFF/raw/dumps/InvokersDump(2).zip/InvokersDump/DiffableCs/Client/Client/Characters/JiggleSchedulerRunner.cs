namespace Client.Characters;

[UsedAsInjection]
public sealed class JiggleSchedulerRunner : IDisposable
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Action<Unit, JiggleSchedulerRunner> <>9__3_0; //Field offset: 0x8
		public static Action<Unit, JiggleSchedulerRunner> <>9__3_1; //Field offset: 0x10

		private static <>c() { }

		public <>c() { }

		internal void <Start>b__3_0(Unit _, JiggleSchedulerRunner runner) { }

		internal void <Start>b__3_1(Unit _, JiggleSchedulerRunner runner) { }

	}

	private readonly IJiggleScheduler _scheduler; //Field offset: 0x10
	private readonly CompositeDisposable _subscriptions; //Field offset: 0x18

	public JiggleSchedulerRunner(IJiggleScheduler scheduler) { }

	public override void Dispose() { }

	public void Start() { }

}

