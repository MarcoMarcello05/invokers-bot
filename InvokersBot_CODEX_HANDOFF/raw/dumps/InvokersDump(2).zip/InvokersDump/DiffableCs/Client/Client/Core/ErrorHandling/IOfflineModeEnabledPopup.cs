namespace Client.Core.ErrorHandling;

public interface IOfflineModeEnabledPopup : IDialogView, IView
{

	public Observable<Unit> CloseClicked
	{
		 get { } //Length: 0
	}

	public Observable<Unit> get_CloseClicked() { }

	public void SetWarning(OfflineModeWarning warning) { }

}

