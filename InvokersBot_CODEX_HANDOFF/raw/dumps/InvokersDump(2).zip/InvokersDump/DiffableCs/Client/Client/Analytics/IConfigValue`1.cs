namespace Client.Analytics;

public interface IConfigValue
{

	public Observable<T> OnValueChanged
	{
		 get { } //Length: 0
	}

	public T Value
	{
		 get { } //Length: 0
	}

	public Observable<T> get_OnValueChanged() { }

	public T get_Value() { }

}

