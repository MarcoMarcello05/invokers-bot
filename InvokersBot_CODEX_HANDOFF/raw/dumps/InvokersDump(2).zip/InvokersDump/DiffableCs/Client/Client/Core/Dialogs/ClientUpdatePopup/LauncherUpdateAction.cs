namespace Client.Core.Dialogs.ClientUpdatePopup;

public sealed class LauncherUpdateAction : IClientUpdateAction
{
	[CompilerGenerated]
	private struct <ExecuteAsync>d__4 : IAsyncStateMachine
	{
		public int <>1__state; //Field offset: 0x0
		public AsyncUniTaskMethodBuilder <>t__builder; //Field offset: 0x8
		public LauncherUpdateAction <>4__this; //Field offset: 0x18
		private Awaiter <>u__1; //Field offset: 0x20

		private override void MoveNext() { }

		[DebuggerHidden]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	private static readonly ILogger Logger; //Field offset: 0x0
	private readonly ILauncherClient _launcherClient; //Field offset: 0x10
	private readonly ApplicationExitController _applicationExitController; //Field offset: 0x18

	private static LauncherUpdateAction() { }

	public LauncherUpdateAction(ILauncherClient launcherClient, ApplicationExitController applicationExitController) { }

	[AsyncStateMachine(typeof(<ExecuteAsync>d__4))]
	public override UniTask ExecuteAsync() { }

}

